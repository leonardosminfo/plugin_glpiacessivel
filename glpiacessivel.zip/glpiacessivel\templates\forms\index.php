<?php
$forms = is_array($forms ?? null) ? $forms : [];
$items = is_array($forms['items'] ?? null) ? $forms['items'] : [];
$sources = is_array($forms['sources'] ?? null) ? $forms['sources'] : [];
$fallbackPolicy = (string) ($forms['fallback_policy'] ?? 'A abertura usa fallback nativo quando a fonte exige regras dinamicas ainda nao homologadas.');
$formsNativeFlowMode = (string) ($formsNativeFlowMode ?? 'native_embedded');
$showOperationalDiagnostics = !empty($showOperationalDiagnostics);
?>

<section class="glpiacessivel-section-head" aria-labelledby="forms-title">
  <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Catalogo operacional')) ?></p>
  <h2 id="forms-title"><?= glpiacessivel_e(glpiacessivel_t('Formularios')) ?></h2>
  <p><?= glpiacessivel_e(glpiacessivel_t('Acesse formularios ja cadastrados no GLPI 11 Service Catalog ou no Formcreator do GLPI 10, preservando permissao, entidade e validacao nativa.')) ?></p>
</section>

<?php if ($showOperationalDiagnostics): ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning" role="status" aria-labelledby="forms-fallback-title">
    <strong id="forms-fallback-title"><?= glpiacessivel_e(glpiacessivel_t('Fallback nativo preservado')) ?></strong>
    <p><?= glpiacessivel_e($fallbackPolicy) ?></p>
  </div>

  <section class="glpiacessivel-card" aria-labelledby="forms-sources-title">
    <h3 id="forms-sources-title"><?= glpiacessivel_e(glpiacessivel_t('Fontes detectadas')) ?></h3>
    <div class="glpiacessivel-action-grid">
      <?php foreach ($sources as $sourceKey => $source): ?>
        <?php $available = !empty($source['available']); ?>
        <article class="glpiacessivel-action-card" aria-labelledby="forms-source-<?= glpiacessivel_e((string) $sourceKey) ?>">
          <strong id="forms-source-<?= glpiacessivel_e((string) $sourceKey) ?>"><?= glpiacessivel_e((string) ($source['label'] ?? $sourceKey)) ?></strong>
          <span><?= glpiacessivel_e((string) ($source['message'] ?? '')) ?></span>
          <span class="glpiacessivel-badge glpiacessivel-badge-priority-<?= $available ? 'medium' : 'low' ?>">
            <?= glpiacessivel_e($available ? glpiacessivel_t('Detectado') : glpiacessivel_t('Nao detectado')) ?>
          </span>
          <?php if ($available && !empty($source['native_url'])): ?>
            <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e((string) $source['native_url']) ?>">
              <?= glpiacessivel_e(glpiacessivel_t('Abrir fluxo nativo')) ?>
            </a>
          <?php endif; ?>
        </article>
      <?php endforeach; ?>
    </div>
  </section>
<?php endif; ?>

<section class="glpiacessivel-card" aria-labelledby="forms-list-title">
  <div class="glpiacessivel-open-ticket-header">
    <div>
      <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Formularios disponiveis')) ?></p>
      <h3 id="forms-list-title"><?= glpiacessivel_e(glpiacessivel_t('Disponiveis neste contexto')) ?></h3>
      <?php if ($showOperationalDiagnostics): ?>
        <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('A lista abaixo aparece apenas quando a fonte permite confirmar visibilidade por item. Caso contrario, use o botao do fluxo nativo da fonte.')) ?></p>
      <?php endif; ?>
    </div>
  </div>

  <?php if ($items === []): ?>
    <p class="glpiacessivel-empty-state"><?= glpiacessivel_e(glpiacessivel_t('Nenhum formulario disponivel neste contexto.')) ?></p>
  <?php else: ?>
    <div class="glpiacessivel-form-catalog-grid" role="list" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Formularios disponiveis')) ?>">
      <?php foreach ($items as $item): ?>
        <?php
          $itemId = (int) ($item['id'] ?? 0);
          $source = (string) ($item['source'] ?? '');
          $sourceLabel = (string) ($item['source_label'] ?? glpiacessivel_t('Formulario'));
          $title = (string) ($item['name'] ?? glpiacessivel_t('Formulario'));
          $description = trim((string) ($item['description'] ?? ''));
          $renderingMessage = (string) ($item['rendering_message'] ?? glpiacessivel_t('Abertura pelo fluxo nativo.'));
          $schema = is_array($item['dynamic_form_schema'] ?? null) ? $item['dynamic_form_schema'] : [];
          $compatibilityStatus = (string) ($item['compatibility_status'] ?? 'native_fallback_required');
          $compatibilitySummary = (string) ($item['compatibility_summary'] ?? $renderingMessage);
          $compatibilityReasons = array_values(array_filter(array_map('strval', (array) ($item['compatibility_reasons'] ?? []))));
          $compatibilityAdvisories = array_values(array_filter(array_map('strval', (array) ($item['compatibility_advisories'] ?? []))));
          $compatibilityListedReasons = $compatibilityReasons;
          $capabilities = is_array($schema['capabilities'] ?? null) ? $schema['capabilities'] : [];
          $detectedApis = is_array($capabilities['detected_apis'] ?? null) ? $capabilities['detected_apis'] : [];
          $compatibilityMatrix = is_array($capabilities['compatibility_matrix'] ?? null) ? $capabilities['compatibility_matrix'] : [];
          $nativeFields = array_values(array_filter(array_map('strval', (array) ($schema['native_fields'] ?? []))));
          if ($compatibilityListedReasons !== [] && ($compatibilityListedReasons[0] ?? '') === $compatibilitySummary) {
            array_shift($compatibilityListedReasons);
          }
          $statusLabel = match ($compatibilityStatus) {
            'renderer_candidate' => glpiacessivel_t('Renderer candidato'),
            'projected_with_native_assist' => glpiacessivel_t('Renderer com apoio nativo'),
            'blocked_by_unsupported_contract' => glpiacessivel_t('Contrato nao suportado'),
            default => glpiacessivel_t('Fallback nativo obrigatorio'),
          };
          $statusPriority = in_array($compatibilityStatus, ['renderer_candidate', 'projected_with_native_assist'], true) ? 'medium' : 'low';
          $illustration = trim((string) ($item['illustration'] ?? ''));
          $visualKind = preg_replace('/[^a-z0-9_-]/i', '', (string) ($item['visual_kind'] ?? 'native')) ?: 'native';
          $canRenderImage = $illustration !== '' && (bool) preg_match('#^(?:https?:)?/|^data:image/#', $illustration);
          $titleId = 'form-title-' . preg_replace('/[^a-z0-9_-]/i', '-', $source . '-' . (string) $itemId);
          $descId = $description !== '' ? $titleId . '-description' : '';
          $messageId = $titleId . '-message';
          $describedBy = trim($descId . ($showOperationalDiagnostics ? ' ' . $messageId : ''));
          $canRenderOwnFields = !empty($capabilities['renders_own_fields']);
          $openUrl = $formsNativeFlowMode === 'native_link'
            ? glpiacessivel_url('front/form.open.php?source=' . rawurlencode($source) . '&id=' . $itemId)
            : glpiacessivel_url('front/form.render.php?source=' . rawurlencode($source) . '&id=' . $itemId);
        ?>
        <article class="glpiacessivel-form-catalog-card glpiacessivel-form-catalog-card-<?= glpiacessivel_e($visualKind) ?>" role="listitem" aria-labelledby="<?= glpiacessivel_e($titleId) ?>">
          <div class="glpiacessivel-form-catalog-visual" aria-hidden="true">
            <?php if ($canRenderImage): ?>
              <img src="<?= glpiacessivel_e($illustration) ?>" alt="" loading="lazy">
            <?php else: ?>
              <span class="glpiacessivel-form-catalog-fallback" aria-hidden="true"></span>
            <?php endif; ?>
          </div>
          <div class="glpiacessivel-form-catalog-body">
            <?php if ($showOperationalDiagnostics): ?>
              <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e($sourceLabel) ?></p>
            <?php endif; ?>
            <h3 id="<?= glpiacessivel_e($titleId) ?>"><?= glpiacessivel_e($title) ?></h3>
            <?php if ($description !== ''): ?>
              <p id="<?= glpiacessivel_e($descId) ?>" class="glpiacessivel-form-catalog-description"><?= glpiacessivel_e($description) ?></p>
            <?php endif; ?>
            <?php if ($showOperationalDiagnostics): ?>
              <p id="<?= glpiacessivel_e($messageId) ?>" class="glpiacessivel-help-text"><?= glpiacessivel_e($renderingMessage) ?></p>
              <span class="glpiacessivel-badge glpiacessivel-badge-priority-<?= glpiacessivel_e($statusPriority) ?>">
                <?= glpiacessivel_e($statusLabel) ?>
              </span>
              <details class="glpiacessivel-form-compatibility">
                <summary><?= glpiacessivel_e(glpiacessivel_t('Compatibilidade do renderer')) ?></summary>
                <p class="glpiacessivel-help-text"><?= glpiacessivel_e($compatibilitySummary) ?></p>
                <?php if ($compatibilityListedReasons !== []): ?>
                  <ul>
                    <?php foreach (array_slice($compatibilityListedReasons, 0, 4) as $reason): ?>
                      <li><?= glpiacessivel_e($reason) ?></li>
                    <?php endforeach; ?>
                  </ul>
                <?php endif; ?>
                <?php if ($compatibilityAdvisories !== []): ?>
                  <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Observacoes de homologacao')) ?></p>
                  <ul>
                    <?php foreach (array_slice($compatibilityAdvisories, 0, 3) as $advisory): ?>
                      <li><?= glpiacessivel_e($advisory) ?></li>
                    <?php endforeach; ?>
                  </ul>
                <?php endif; ?>
                <?php if ($compatibilityMatrix !== []): ?>
                  <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Matriz P1')) ?></p>
                  <dl class="glpiacessivel-form-compatibility-matrix">
                    <?php foreach ($compatibilityMatrix as $matrixItem): ?>
                      <?php
                        $area = (string) ($matrixItem['area'] ?? '');
                        $status = (string) ($matrixItem['status'] ?? '');
                        $message = (string) ($matrixItem['message'] ?? '');
                      ?>
                      <?php if ($area !== ''): ?>
                        <div>
                          <dt><?= glpiacessivel_e($area) ?> <span><?= glpiacessivel_e($status) ?></span></dt>
                          <?php if ($message !== ''): ?>
                            <dd><?= glpiacessivel_e($message) ?></dd>
                          <?php endif; ?>
                        </div>
                      <?php endif; ?>
                    <?php endforeach; ?>
                  </dl>
                <?php endif; ?>
                <?php if ($detectedApis !== []): ?>
                  <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('APIs detectadas')) ?></p>
                  <ul>
                    <?php foreach ($detectedApis as $apiName => $available): ?>
                      <li><?= glpiacessivel_e((string) $apiName) ?>: <?= glpiacessivel_e($available ? glpiacessivel_t('sim') : glpiacessivel_t('nao')) ?></li>
                    <?php endforeach; ?>
                  </ul>
                <?php endif; ?>
                <?php if ($nativeFields !== []): ?>
                  <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Campos projetados')) ?>: <?= glpiacessivel_e(implode(', ', array_slice($nativeFields, 0, 8))) ?></p>
                <?php endif; ?>
              </details>
            <?php endif; ?>
          </div>
          <div class="glpiacessivel-form-catalog-actions">
            <a class="glpiacessivel-button glpiacessivel-button-primary" href="<?= glpiacessivel_e($openUrl) ?>"<?= $describedBy !== '' ? ' aria-describedby="' . glpiacessivel_e($describedBy) . '"' : '' ?>>
              <?= glpiacessivel_e(glpiacessivel_t('Abrir formulario')) ?>
            </a>
            <?php if ($showOperationalDiagnostics && $formsNativeFlowMode !== 'native_link'): ?>
              <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/form.open.php?source=' . rawurlencode($source) . '&id=' . $itemId)) ?>">
                <?= glpiacessivel_e(glpiacessivel_t('Abrir nativo')) ?>
              </a>
            <?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>
