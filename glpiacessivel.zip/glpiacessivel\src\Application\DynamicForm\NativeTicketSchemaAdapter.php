<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application\DynamicForm;

use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormAdapterInterface;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormField;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSchema;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSection;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSubmissionResult;
use GlpiPlugin\Glpiacessivel\Support\Url;

class NativeTicketSchemaAdapter implements DynamicFormAdapterInterface
{
    public const SOURCE = 'native_ticket';
    private const SCHEMA_VERSION = '1.1';

    public function source(): string
    {
        return self::SOURCE;
    }

    /**
     * @param array<string, mixed> $context
     */
    public function supports(array $context): bool
    {
        return true;
    }

    /**
     * @param array<string, mixed> $context
     */
    public function getSchema(array $context): DynamicFormSchema
    {
        $requirements = is_array($context['field_requirements'] ?? null) ? $context['field_requirements'] : [];
        $fields = [
            $this->field('name', 'name', 'text', 'Titulo', 'main', $requirements, true, false, false, [], ['maxlength' => 255]),
            $this->field('content', 'content', 'textarea', 'Descricao', 'main', $requirements, true, false, false, [], ['maxlength' => 16000]),
            $this->field('filename', '_filename', 'file', 'Anexos', 'main', $requirements, false, false, true, [], ['glpi_document_item_required' => true]),
            $this->field('type', 'type', 'select', 'Tipo', 'properties', $requirements, true, false, false, $this->options($context['type_options'] ?? [])),
            $this->field('itilcategories_id', 'itilcategories_id', 'select', 'Categoria', 'properties', $requirements, false, false, false, $this->options($context['categories'] ?? [])),
            $this->field('tickettemplates_id', 'tickettemplates_id', 'select', 'Modelo ITIL', 'properties', $requirements, false, false, false, $this->options($context['ticket_templates'] ?? []), [], 'ticket_template'),
            $this->field('locations_id', 'locations_id', 'select', 'Localizacao', 'properties', $requirements, false, false, false, $this->options($context['locations'] ?? [])),
            $this->field('requesttypes_id', 'requesttypes_id', 'select', 'Origem da requisicao', 'properties', $requirements, false, false, false, $this->options($context['request_source_options'] ?? [])),
            $this->field('externalid', 'externalid', 'text', 'ID externo', 'properties', $requirements, false, false, false, [], ['maxlength' => 255]),
            $this->field('urgency', 'urgency', 'select', 'Urgencia', 'priority', $requirements, false, false, false, $this->options($context['urgency_options'] ?? [])),
            $this->field('impact', 'impact', 'select', 'Impacto', 'priority', $requirements, false, false, false, $this->options($context['impact_options'] ?? [])),
            $this->field('groups_assign', '_groups_id_assign', 'multiselect', 'Grupo tecnico', 'routing', $requirements, false, false, true, $this->options($context['assignable_groups'] ?? [])),
            $this->field('users_assign', '_users_id_assign', 'multiselect', 'Tecnico atribuido', 'routing', $requirements, false, false, true, $this->options($context['assignable_users'] ?? [])),
            $this->field('users_observer', '_users_id_observer', 'multiselect', 'Observador', 'routing', $requirements, false, false, true, $this->options($context['assignable_users'] ?? [])),
        ];

        $fallbackReasons = [];
        if (!empty($context['requires_native_fallback'])) {
            $fallbackReasons = array_values(array_filter(array_map('strval', (array) ($context['native_fallback_reasons'] ?? []))));
        }
        $advisoryReasons = array_values(array_filter(array_map('strval', (array) ($context['portal_limitations'] ?? []))));
        if (!empty($context['service_catalog']['available'])) {
            $advisoryReasons[] = (string) ($context['service_catalog']['message'] ?? 'Catalogo de Servicos GLPI 11 requer fallback nativo para formularios dinamicos.');
        }

        return new DynamicFormSchema(
            $this->schemaId($context),
            self::SOURCE,
            self::SCHEMA_VERSION,
            'Abertura nativa de chamado',
            [
                new DynamicFormSection('main', 'Chamado', 10, 'Dados principais da solicitacao.'),
                new DynamicFormSection('properties', 'Propriedades', 20, 'Campos ITIL e contexto operacional.'),
                new DynamicFormSection('priority', 'Prioridade', 30, 'Urgencia, impacto e pre-visualizacao.'),
                new DynamicFormSection('routing', 'Atores e encaminhamento', 40, 'Participantes e grupos permitidos pelo GLPI.'),
            ],
            $fields,
            [],
            $this->capabilities(),
            [
                'required' => $fallbackReasons !== [],
                'reasons' => $fallbackReasons,
                'advisory_reasons' => $advisoryReasons,
                'native_url' => $this->nativeUrl(),
            ],
            [
                'entity_id' => (int) ($context['entity_id'] ?? 0),
                'entity_name' => (string) ($context['entity_name'] ?? ''),
                'requester_name' => (string) ($context['requester_name'] ?? ''),
                'glpi_version' => defined('GLPI_VERSION') ? (string) GLPI_VERSION : 'unknown',
            ]
        );
    }

    /**
     * @param array<string, mixed> $answers
     * @return array<int, array{field:string, code:string, message:string}>
     */
    public function validate(array $answers, DynamicFormSchema $schema): array
    {
        $errors = [];
        foreach ($schema->fields() as $field) {
            if (!$field->isVisible() || $field->isDisabled()) {
                continue;
            }
            $name = $field->nativeField();
            $value = $answers[$name] ?? null;

            if ($field->isRequired() && !$field->isReadonly() && !$this->hasValue($value)) {
                $errors[] = $this->error($name, 'required', 'Informe ' . mb_strtolower($field->label(), 'UTF-8') . '.');
                continue;
            }

            if (!$this->hasValue($value) || $field->isReadonly()) {
                continue;
            }

            $constraints = $field->constraints();
            if (isset($constraints['maxlength']) && is_scalar($value) && mb_strlen((string) $value, 'UTF-8') > (int) $constraints['maxlength']) {
                $errors[] = $this->error($name, 'maxlength', $field->label() . ' deve ter no maximo ' . (int) $constraints['maxlength'] . ' caracteres.');
            }

            if ($field->hasAllowedOptions()) {
                $allowed = array_fill_keys($field->allowedOptionIds(), true);
                $values = $field->isMultiple() ? (array) $value : [$value];
                foreach ($values as $item) {
                    $item = (string) $item;
                    if ($item === '' || $item === '0') {
                        continue;
                    }
                    if (!isset($allowed[$item])) {
                        $errors[] = $this->error($name, 'invalid_option', $field->label() . ' invalido para o contexto atual.');
                        break;
                    }
                }
            }
        }

        return $errors;
    }

    /**
     * @param array<string, mixed> $answers
     */
    public function submit(array $answers, DynamicFormSchema $schema): DynamicFormSubmissionResult
    {
        return new DynamicFormSubmissionResult(false, [], '', [[
            'field' => '',
            'code' => 'adapter_submit_not_enabled',
            'message' => 'A submissao dinamica ainda nao esta habilitada para este adaptador.',
        ]]);
    }

    public function nativeUrl(): string
    {
        return Url::core('/front/ticket.form.php');
    }

    /**
     * @return array<string, mixed>
     */
    public function capabilities(): array
    {
        return [
            'source_of_truth' => 'glpi_core',
            'server_side_schema_reload_required' => true,
            'submits_via_native_engine' => true,
            'supports_ticket_template_projection' => false,
            'supports_formcreator_submission' => false,
            'supports_service_catalog_submission' => false,
            'supports_document_item_validation' => true,
        ];
    }

    /**
     * @param array<string, mixed> $requirements
     * @param array<int, array<string, mixed>> $options
     * @param array<string, mixed> $constraints
     */
    protected function field(
        string $id,
        string $name,
        string $type,
        string $label,
        string $section,
        array $requirements,
        bool $requiredByDefault = false,
        bool $readonlyByDefault = false,
        bool $multiple = false,
        array $options = [],
        array $constraints = [],
        string $source = self::SOURCE
    ): DynamicFormField {
        $metadata = is_array($requirements[$name] ?? null) ? $requirements[$name] : [];
        if ($metadata === [] && $id !== $name && is_array($requirements[$id] ?? null)) {
            $metadata = $requirements[$id];
        }

        return new DynamicFormField(
            $id,
            $name,
            $type,
            (string) ($metadata['label'] ?? $label),
            $section,
            !empty($metadata['required']) || $requiredByDefault,
            array_key_exists('visible', $metadata) ? !empty($metadata['visible']) : true,
            !empty($metadata['readonly']) || $readonlyByDefault,
            !empty($metadata['disabled']),
            $multiple,
            $metadata['default'] ?? null,
            $options,
            $constraints,
            $source,
            $name,
            (string) ($metadata['description'] ?? ''),
            $metadata
        );
    }

    /**
     * @param mixed $rows
     * @return array<int, array{id:int|string, label:string, metadata:array<string, mixed>}>
     */
    protected function options(mixed $rows): array
    {
        if (!is_array($rows)) {
            return [];
        }

        $options = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $id = $row['id'] ?? null;
            if ($id === null || $id === '') {
                continue;
            }
            $label = (string) ($row['label'] ?? $row['name'] ?? ('#' . $id));
            $metadata = $row;
            unset($metadata['id'], $metadata['label'], $metadata['name']);
            $options[] = [
                'id' => is_numeric($id) ? (int) $id : (string) $id,
                'label' => $label,
                'metadata' => $metadata,
            ];
        }

        return $options;
    }

    /**
     * @param array<string, mixed> $context
     */
    protected function schemaId(array $context): string
    {
        $parts = [
            $this->source(),
            (string) ($context['entity_id'] ?? 0),
            (string) ($context['selected_ticket_template']['id'] ?? 0),
            defined('GLPI_VERSION') ? (string) GLPI_VERSION : 'unknown',
            defined('PLUGIN_GLPIACESSIVEL_VERSION') ? (string) PLUGIN_GLPIACESSIVEL_VERSION : 'dev',
        ];

        return hash('sha256', implode('|', $parts));
    }

    /**
     * @return array{field:string, code:string, message:string}
     */
    protected function error(string $field, string $code, string $message): array
    {
        return [
            'field' => $field,
            'code' => $code,
            'message' => $message,
        ];
    }

    private function hasValue(mixed $value): bool
    {
        if (is_array($value)) {
            return array_values(array_filter($value, static fn($item): bool => trim((string) $item) !== '' && trim((string) $item) !== '0')) !== [];
        }

        return trim((string) $value) !== '' && trim((string) $value) !== '0';
    }
}
