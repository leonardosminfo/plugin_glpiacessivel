<?php
global $CFG_GLPI;

$items = (array) ($result['items'] ?? []);
$page = max(1, (int) ($result['page'] ?? 1));
$pages = max(1, (int) ($result['pages'] ?? 1));
$total = max(0, (int) ($result['total'] ?? 0));
$pageSize = max(1, (int) ($filters['page_size'] ?? 20));
$backend = (string) ($result['backend'] ?? 'native_find_fallback');
$showOperationalDiagnostics = !empty($showOperationalDiagnostics);
$backendReason = (string) ($result['backend_reason'] ?? '');
$backendLabel = $backend === 'search_api'
  ? 'Listagem carregada pelo modo nativo do GLPI.'
  : 'Listagem carregada em modo compativel do portal; filtros e permissoes foram preservados.';
$firstItem = $total > 0 ? (($page - 1) * $pageSize) + 1 : 0;
$lastItem = $total > 0 ? min($total, $firstItem + count($items) - 1) : 0;
$nativeTicketUrl = (string) (($CFG_GLPI['root_doc'] ?? '') . '/front/ticket.php');

$statusLabels = ['' => glpiacessivel_t('Todos')];
foreach (\GlpiPlugin\Glpiacessivel\Support\TicketStatusLabels::all() as $statusId => $statusLabel) {
  $statusLabels[(string) $statusId] = $statusLabel;
}

$scopeLabels = [
  'all' => 'Todos os chamados permitidos',
  'mine' => 'Meus chamados',
  'group' => 'Chamados do grupo',
];

$groupByLabels = [
  'none' => 'Lista unica',
  'group' => 'Agrupar por grupo',
];

$queryUrl = static function (array $changes = []) use ($filters): string {
  $params = array_merge((array) $filters, $changes);
  foreach ($params as $key => $value) {
    if ($value === '' || $value === null) {
      unset($params[$key]);
    }
  }

  return '?' . http_build_query($params);
};

$sortUrl = static function (string $column) use ($filters, $queryUrl): string {
  $currentSort = (string) ($filters['sort'] ?? 'date_mod');
  $currentDirection = strtoupper((string) ($filters['direction'] ?? 'DESC'));
  $nextDirection = ($currentSort === $column && $currentDirection === 'ASC') ? 'DESC' : 'ASC';

  return $queryUrl([
    'sort' => $column,
    'direction' => $nextDirection,
    'page' => 1,
  ]);
};

$ariaSort = static function (string $column) use ($filters): string {
  if ((string) ($filters['sort'] ?? 'date_mod') !== $column) {
    return 'none';
  }

  return strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? 'ascending' : 'descending';
};

$sortMarker = static function (string $column) use ($filters): string {
  if ((string) ($filters['sort'] ?? 'date_mod') !== $column) {
    return '';
  }

  return strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? ' crescente' : ' decrescente';
};

$groupLabel = 'Todos os grupos';
foreach ((array) ($group_options ?? []) as $groupOption) {
  if ((int) ($groupOption['id'] ?? 0) === (int) ($filters['group_id'] ?? 0)) {
    $groupLabel = (string) ($groupOption['label'] ?? $groupLabel);
    break;
  }
}

$activeFilters = [
  'Escopo' => $scopeLabels[(string) ($filters['scope'] ?? 'all')] ?? 'Todos os chamados permitidos',
  'Status' => $statusLabels[(string) ($filters['status'] ?? '')] ?? 'Todos',
  'Busca' => trim((string) ($filters['q'] ?? '')) !== '' ? (string) $filters['q'] : 'Sem termo',
  'Grupo responsavel' => $groupLabel,
  'Classificacao' => $groupByLabels[(string) ($filters['group_by'] ?? 'none')] ?? 'Lista unica',
];

$renderSortHeader = static function (string $column, string $label) use ($sortUrl, $ariaSort, $sortMarker): void {
  ?>
  <th scope="col" aria-sort="<?= glpiacessivel_e($ariaSort($column)) ?>">
    <a class="glpiacessivel-sort-link" href="<?= glpiacessivel_e($sortUrl($column)) ?>">
      <?= glpiacessivel_e($label) ?><span class="glpiacessivel-sr-only"><?= glpiacessivel_e($sortMarker($column)) ?></span>
    </a>
  </th>
  <?php
};

$renderTicketRow = static function (array $item, bool $showGroup = true): void {
  $ticketUrl = glpiacessivel_url('front/ticket.php?id=' . (int) $item['id']);
  ?>
  <tr>
    <td>
      <input
        type="checkbox"
        class="glpiacessivel-ticket-select"
        value="<?= (int) $item['id'] ?>"
        aria-label="Selecionar chamado <?= (int) $item['id'] ?>"
      />
    </td>
    <td><?= (int) $item['id'] ?></td>
    <td>
      <a href="<?= glpiacessivel_e($ticketUrl) ?>" class="glpiacessivel-ticket-title-link">
        <?= glpiacessivel_e($item['name']) ?>
      </a>
    </td>
    <td>
      <span class="glpiacessivel-badge glpiacessivel-badge-status-<?= glpiacessivel_e(glpiacessivel_status_class($item['status'])) ?>">
        <?= glpiacessivel_e(glpiacessivel_ticket_status($item['status'])) ?>
      </span>
    </td>
    <td><?= glpiacessivel_e((string) ($item['date'] ?? '')) ?></td>
    <td>
      <span class="glpiacessivel-badge glpiacessivel-badge-priority-<?= glpiacessivel_e(glpiacessivel_priority_class($item['priority'])) ?>">
        <?= glpiacessivel_e(glpiacessivel_ticket_priority($item['priority'])) ?>
      </span>
    </td>
    <?php if ($showGroup): ?>
      <td><?= glpiacessivel_e((string) (($item['primary_group_name'] ?? 'Sem grupo'))) ?></td>
    <?php endif; ?>
    <td><?= glpiacessivel_e(trim((string) $item['requester_name'])) ?></td>
    <td><?= glpiacessivel_e(trim((string) $item['assignee_name'])) ?></td>
    <td><?= glpiacessivel_e((string) ($item['date_mod'] ?? '')) ?></td>
    <td>
      <a
        class="glpiacessivel-button glpiacessivel-button-secondary"
        href="<?= glpiacessivel_e($ticketUrl) ?>"
        aria-label="Abrir chamado <?= (int) $item['id'] ?>: <?= glpiacessivel_e($item['name']) ?>"
      >Abrir</a>
    </td>
  </tr>
  <?php
};
?>

<section class="glpiacessivel-section-head" aria-labelledby="tickets-intro">
  <p class="glpiacessivel-eyebrow">Gestao de chamados</p>
  <h2 id="tickets-intro">Pesquise, filtre e acesse o detalhe do ticket no modo adaptado</h2>
  <p>Os filtros abaixo respeitam seu perfil, entidade ativa e permissoes nativas do GLPI.</p>
</section>

<nav class="glpiacessivel-ticket-toolbar" aria-label="Acoes da listagem de chamados">
  <a class="glpiacessivel-button" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.create.php')) ?>">Novo chamado</a>
  <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php')) ?>">Limpar filtros</a>
  <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($queryUrl()) ?>">Atualizar lista</a>
  <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeTicketUrl) ?>">Abrir listagem nativa do GLPI</a>
</nav>

<?php if ($showOperationalDiagnostics && $backend !== 'search_api'): ?>
  <?php
    $backendDiagnostics = is_array($result['backend_diagnostics'] ?? null) ? $result['backend_diagnostics'] : [];
    $fallbackReasonLabels = [
      'mine_scope_search_options_unavailable' => 'A instalacao nao expos Search Options para os tres papeis ITIL; o modo compativel preserva a regra de Meus chamados.',
      'group_scope_without_current_groups' => 'Nao ha grupos atuais para compor o criterio nativo; o modo compativel preserva a regra de escopo.',
      'assigned_group_search_option_unavailable' => 'A Search API nao expos uma opcao segura para grupo atribuido nesta instalacao.',
      'search_api_unavailable' => 'A Search API nativa nao esta disponivel nesta instalacao.',
      'scope_requires_portal_filter' => 'O escopo atual exige regra complementar do portal.',
      'search_api_response_unusable' => 'A resposta da Search API nao passou na validacao defensiva do plugin.',
    ];
    $fallbackReasonText = $fallbackReasonLabels[$backendReason] ?? 'O filtro atual exige validacao complementar do portal.';
  ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning" role="status" aria-live="polite" id="tickets-backend-beta-warning">
    <strong>Listagem em fallback beta.</strong>
    <p><?= glpiacessivel_e($fallbackReasonText) ?></p>
    <p>Este filtro usa varredura compativel do portal com limite operacional de <?= (int) ($result['backend_limit'] ?? 500) ?> chamados antes de aplicar regras de escopo, grupo e permissoes. Use filtros mais especificos se o resultado esperado nao aparecer.</p>
    <?php if (!empty($result['backend_limited']) || !empty($backendDiagnostics['fallback_limit_hit'])): ?>
      <p><strong>Limite atingido:</strong> a varredura chegou ao teto configurado. Abra a listagem nativa do GLPI para uma busca completa ou aplique filtros mais especificos.</p>
    <?php endif; ?>
  </div>
<?php endif; ?>

<?php if (!empty($result['backend_limited'])): ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning" role="status" aria-live="polite">
    <strong>Resultados parciais.</strong>
    <p>A consulta atingiu o limite do modo compativel. Refine os filtros ou abra a listagem nativa do GLPI para conferir todos os chamados.</p>
  </div>
<?php endif; ?>

<section aria-labelledby="tickets-filtros" class="glpiacessivel-card">
  <div class="glpiacessivel-card-heading">
    <div>
      <p class="glpiacessivel-eyebrow">Busca rapida</p>
      <h2 id="tickets-filtros">Filtros de chamados</h2>
    </div>
    <p class="glpiacessivel-card-note">A listagem prioriza o modo nativo do GLPI e usa modo compativel quando o filtro exige regra complementar do portal.</p>
  </div>

  <form method="get" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php')) ?>" class="glpiacessivel-ticket-filter-form" role="search" aria-label="Filtrar chamados">
    <div class="glpiacessivel-field glpiacessivel-ticket-filter-field glpiacessivel-ticket-filter-scope">
      <label for="scope">Escopo</label>
      <select id="scope" name="scope">
        <option value="all" <?= $filters['scope'] === 'all' ? 'selected' : '' ?>>Todos</option>
        <option value="mine" <?= $filters['scope'] === 'mine' ? 'selected' : '' ?>>Meus chamados</option>
        <option value="group" <?= $filters['scope'] === 'group' ? 'selected' : '' ?>>Chamados do grupo</option>
      </select>
    </div>

    <div class="glpiacessivel-field glpiacessivel-ticket-filter-field glpiacessivel-ticket-filter-status">
      <label for="status">Status</label>
      <select id="status" name="status">
        <?php foreach ($statusLabels as $statusValue => $statusLabel): ?>
          <option value="<?= glpiacessivel_e((string) $statusValue) ?>" <?= (string) $filters['status'] === (string) $statusValue ? 'selected' : '' ?>>
            <?= glpiacessivel_e($statusLabel) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="glpiacessivel-field glpiacessivel-ticket-filter-field glpiacessivel-ticket-filter-search">
      <label for="q">Busca</label>
      <input id="q" type="text" name="q" value="<?= glpiacessivel_e($filters['q']) ?>" autocomplete="off" />
    </div>

    <div class="glpiacessivel-field glpiacessivel-ticket-filter-field glpiacessivel-ticket-filter-group">
      <label for="group_id">Grupo responsavel</label>
      <select id="group_id" name="group_id">
        <option value="0">Todos os grupos</option>
        <?php foreach ((array) ($group_options ?? []) as $groupOption): ?>
          <option value="<?= (int) ($groupOption['id'] ?? 0) ?>" <?= ((int) ($filters['group_id'] ?? 0) === (int) ($groupOption['id'] ?? 0)) ? 'selected' : '' ?>>
            <?= glpiacessivel_e((string) ($groupOption['label'] ?? '')) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="glpiacessivel-field glpiacessivel-ticket-filter-field glpiacessivel-ticket-filter-groupby">
      <label for="group_by">Classificar por grupo</label>
      <select id="group_by" name="group_by">
        <option value="none" <?= ($filters['group_by'] ?? 'none') === 'none' ? 'selected' : '' ?>>Lista unica</option>
        <option value="group" <?= ($filters['group_by'] ?? 'none') === 'group' ? 'selected' : '' ?>>Agrupar por grupo</option>
      </select>
    </div>

    <div class="glpiacessivel-field glpiacessivel-ticket-filter-pagesize">
      <label for="page_size">Itens por pagina</label>
      <select id="page_size" name="page_size">
        <?php foreach ([10, 20, 50, 100] as $option): ?>
          <option value="<?= $option ?>" <?= (int) ($filters['page_size'] ?? 20) === $option ? 'selected' : '' ?>><?= $option ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <input type="hidden" name="sort" value="<?= glpiacessivel_e((string) ($filters['sort'] ?? 'date_mod')) ?>" />
    <input type="hidden" name="direction" value="<?= glpiacessivel_e((string) ($filters['direction'] ?? 'DESC')) ?>" />

    <div class="glpiacessivel-field glpiacessivel-field-actions glpiacessivel-ticket-filter-actions">
      <button type="submit">Aplicar filtros</button>
    </div>
  </form>

  <div class="glpiacessivel-active-filters" aria-label="Filtros ativos">
    <strong>Filtros ativos:</strong>
    <?php foreach ($activeFilters as $filterName => $filterValue): ?>
      <span class="glpiacessivel-filter-chip"><?= glpiacessivel_e($filterName) ?>: <?= glpiacessivel_e((string) $filterValue) ?></span>
    <?php endforeach; ?>
  </div>
</section>

<section aria-labelledby="tickets-lista" class="glpiacessivel-card">
  <div class="glpiacessivel-list-header">
    <div>
      <p class="glpiacessivel-eyebrow">Resultado operacional</p>
      <h2 id="tickets-lista">Lista de chamados</h2>
      <p>
        <?php if ($total > 0): ?>
          Exibindo <strong><?= $firstItem ?></strong>-<strong><?= $lastItem ?></strong> de <?= !empty($result['backend_limited']) ? 'pelo menos ' : '' ?><strong><?= $total ?></strong> chamado(s).
        <?php else: ?>
          Nenhum chamado visivel para a consulta atual.
        <?php endif; ?>
      </p>
      <?php if ($showOperationalDiagnostics): ?>
        <p class="glpiacessivel-card-note">
          <?= glpiacessivel_e($backendLabel) ?>
        </p>
      <?php endif; ?>
    </div>
    <div class="glpiacessivel-selection-summary" role="status" aria-live="polite">
      Selecionados: <strong data-glpiacessivel-selected-count>0</strong>
      <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-copy-selected disabled>Copiar IDs</button>
    </div>
  </div>

  <?php if (count($items) === 0): ?>
    <div class="glpiacessivel-empty" role="status">
      <p>Nenhum chamado encontrado para os filtros informados.</p>
      <p>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php')) ?>">Limpar filtros</a>
        <a class="glpiacessivel-button" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.create.php')) ?>">Abrir novo chamado</a>
      </p>
    </div>
  <?php else: ?>
    <?php if (in_array(($filters['scope'] ?? 'all'), ['mine', 'group'], true) && ($filters['group_by'] ?? 'none') === 'group' && !empty($grouped_items)): ?>
      <div class="glpiacessivel-ticket-grouped">
        <?php foreach ((array) ($grouped_items ?? []) as $groupIndex => $groupTickets): ?>
          <?php $groupHeadingId = 'tickets-grupo-' . md5((string) $groupIndex); ?>
          <section class="glpiacessivel-ticket-group" aria-labelledby="<?= glpiacessivel_e($groupHeadingId) ?>">
            <h3 id="<?= glpiacessivel_e($groupHeadingId) ?>"><?= glpiacessivel_e((string) $groupIndex) ?> (<?= count((array) $groupTickets) ?>)</h3>
            <div class="glpiacessivel-table-wrap" role="region" aria-labelledby="<?= glpiacessivel_e($groupHeadingId) ?>" tabindex="0">
              <table class="tab_cadre_fixehov glpiacessivel-ticket-table">
                <caption class="glpiacessivel-sr-only">Chamados do grupo <?= glpiacessivel_e((string) $groupIndex) ?> para os filtros atuais</caption>
                <thead>
                  <tr>
                    <th scope="col"><span class="glpiacessivel-sr-only">Selecionar</span></th>
                    <?php $renderSortHeader('id', 'ID'); ?>
                    <?php $renderSortHeader('name', 'Titulo'); ?>
                    <?php $renderSortHeader('status', 'Status'); ?>
                    <?php $renderSortHeader('date', 'Abertura'); ?>
                    <?php $renderSortHeader('priority', 'Prioridade'); ?>
                    <th scope="col">Requisitante</th>
                    <th scope="col">Tecnico</th>
                    <?php $renderSortHeader('date_mod', 'Ultima atualizacao'); ?>
                    <th scope="col">Acao</th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach ((array) $groupTickets as $item): ?>
                  <?php $renderTicketRow((array) $item, false); ?>
                <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </section>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="glpiacessivel-table-wrap" role="region" aria-label="Tabela de chamados" tabindex="0">
        <table class="tab_cadre_fixehov glpiacessivel-ticket-table" aria-describedby="tickets-lista">
          <caption class="glpiacessivel-sr-only">Chamados encontrados para os filtros atuais</caption>
          <thead>
            <tr>
              <th scope="col"><span class="glpiacessivel-sr-only">Selecionar</span></th>
              <?php $renderSortHeader('id', 'ID'); ?>
              <?php $renderSortHeader('name', 'Titulo'); ?>
              <?php $renderSortHeader('status', 'Status'); ?>
              <?php $renderSortHeader('date', 'Abertura'); ?>
              <?php $renderSortHeader('priority', 'Prioridade'); ?>
              <th scope="col">Grupo responsavel</th>
              <th scope="col">Requisitante</th>
              <th scope="col">Tecnico</th>
              <?php $renderSortHeader('date_mod', 'Ultima atualizacao'); ?>
              <th scope="col">Acao</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($items as $item): ?>
            <?php $renderTicketRow((array) $item, true); ?>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</section>

<nav class="glpiacessivel-pagination glpiacessivel-ticket-pagination" aria-label="Paginacao">
  <span>Pagina <?= $page ?> de <?= $pages ?></span>
  <?php if ($page > 1): ?>
    <a href="<?= glpiacessivel_e($queryUrl(['page' => 1])) ?>">Primeira</a>
    <a href="<?= glpiacessivel_e($queryUrl(['page' => $page - 1])) ?>">Anterior</a>
  <?php else: ?>
    <span aria-disabled="true">Primeira</span>
    <span aria-disabled="true">Anterior</span>
  <?php endif; ?>
  <span aria-current="page">Atual: <?= $page ?></span>
  <?php if ($page < $pages): ?>
    <a href="<?= glpiacessivel_e($queryUrl(['page' => $page + 1])) ?>">Proxima</a>
    <a href="<?= glpiacessivel_e($queryUrl(['page' => $pages])) ?>">Ultima</a>
  <?php else: ?>
    <span aria-disabled="true">Proxima</span>
    <span aria-disabled="true">Ultima</span>
  <?php endif; ?>
</nav>

