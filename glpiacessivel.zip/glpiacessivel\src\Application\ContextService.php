<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;

final class ContextService
{
    private AuditLogger $auditLogger;

    public function __construct(AuditLogger $auditLogger)
    {
        $this->auditLogger = $auditLogger;
    }

    /**
     * @return array{
     *   current_entity_id:int,
     *   current_entity_name:string,
     *   current_entity_value:string,
     *   is_all_entities:bool,
     *   current_profile_id:int,
     *   current_profile_name:string,
     *   user_label:string,
     *   is_valid:bool,
     *   summary:string,
     *   profiles:array<int,array{id:int,name:string}>,
     *   entities:array<int|string,array{id:int|string,name:string,recursive:bool}>
     * }
     */
    public function getContext(): array
    {
        $currentEntityId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        $currentProfileId = (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0);
        $isAllEntities = $this->isAllEntitiesScope();
        $entityName = $isAllEntities ? 'Todas as entidades permitidas' : $this->currentEntityName($currentEntityId);
        $profileName = $this->profileName($currentProfileId);
        $isValid = $this->isCurrentContextValid($currentProfileId);

        return [
            'current_entity_id' => $currentEntityId,
            'current_entity_name' => $entityName,
            'current_entity_value' => $isAllEntities ? 'all' : (string) $currentEntityId,
            'is_all_entities' => $isAllEntities,
            'current_profile_id' => $currentProfileId,
            'current_profile_name' => $profileName,
            'user_label' => $this->currentUserLabel(),
            'is_valid' => $isValid,
            'summary' => $isValid
                ? sprintf('Consultando como %s na entidade %s.', $profileName, $entityName)
                : 'Contexto de entidade ou perfil nao definido.',
            'profiles' => $this->profileOptions(),
            'entities' => $this->entityOptions(),
        ];
    }

    public function hasValidContext(): bool
    {
        return !empty($this->getContext()['is_valid']);
    }

    /**
     * @return array<string, mixed>
     */
    public function switchContext(int $profileId, string $entityValue, string $returnTo = ''): array
    {
        $before = [
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
        ];

        $profileChanged = false;
        if ($profileId > 0 && $profileId !== $before['profile_id']) {
            if (!isset($_SESSION['glpiprofiles'][$profileId])) {
                throw new \RuntimeException('Perfil invalido para o usuario atual.');
            }
            \Session::changeProfile($profileId);
            $profileChanged = true;
        }

        $entityValue = trim($entityValue);
        if ($entityValue === '' || $entityValue === 'current') {
            $entityValue = (string) ($_SESSION['glpiactive_entity'] ?? 0);
        }

        $changed = false;
        if ($entityValue === 'all') {
            $changed = \Session::changeActiveEntities('all');
        } else {
            $entityId = max(0, (int) $entityValue);
            $recursive = $this->recursiveForEntity($entityId);
            $changed = \Session::changeActiveEntities($entityId, $recursive);
        }

        if (!$changed && $profileChanged) {
            // changeProfile() already selected the default/all entity for the new profile.
            // If the posted entity belonged to the previous profile, keep GLPI's native choice.
            $changed = true;
        }

        if (!$changed) {
            throw new \RuntimeException('Entidade invalida para o perfil selecionado.');
        }

        $after = [
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
        ];

        $this->auditLogger->log('context.switch', [
            'before' => $before,
            'after' => $after,
            'return_to_len' => strlen($returnTo),
        ]);

        return $this->getContext();
    }

    public function safeReturnTo(string $returnTo): string
    {
        $returnTo = trim($returnTo);
        if ($returnTo === '') {
            return \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/acessivel.php');
        }

        $path = (string) parse_url($returnTo, PHP_URL_PATH);
        if ($path === '') {
            return \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/acessivel.php');
        }

        if (!str_contains($path, '/plugins/glpiacessivel/front/')) {
            return \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/acessivel.php');
        }

        return $returnTo;
    }

    /**
     * @return array<int,array{id:int,name:string}>
     */
    private function profileOptions(): array
    {
        $profiles = [];
        foreach ((array) ($_SESSION['glpiprofiles'] ?? []) as $id => $profile) {
            $id = (int) $id;
            if ($id <= 0) {
                continue;
            }

            $profiles[] = [
                'id' => $id,
                'name' => $this->profileName($id, is_array($profile) ? $profile : []),
            ];
        }

        usort($profiles, static fn (array $a, array $b): int => strcasecmp($a['name'], $b['name']));

        return $profiles;
    }

    /**
     * @return array<int|string,array{id:int|string,name:string,recursive:bool}>
     */
    private function entityOptions(): array
    {
        $entities = [];
        $profileEntities = (array) ($_SESSION['glpiactiveprofile']['entities'] ?? []);

        if (count($profileEntities) > 1) {
            $entities['all'] = [
                'id' => 'all',
                'name' => 'Todas as entidades permitidas',
                'recursive' => true,
            ];
        }

        foreach ($profileEntities as $entity) {
            if (!is_array($entity)) {
                continue;
            }

            $id = (int) ($entity['id'] ?? 0);
            if ($id < 0) {
                continue;
            }

            $recursive = !empty($entity['is_recursive']);
            $entities[$id] = [
                'id' => $id,
                'name' => $this->entityName($id) . ($recursive ? ' (arvore)' : ''),
                'recursive' => $recursive,
            ];
        }

        $activeId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        if ($activeId >= 0 && !isset($entities[$activeId])) {
            $entities[$activeId] = [
                'id' => $activeId,
                'name' => $this->currentEntityName($activeId),
                'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
            ];
        }

        return $entities;
    }

    private function recursiveForEntity(int $entityId): bool
    {
        foreach ((array) ($_SESSION['glpiactiveprofile']['entities'] ?? []) as $entity) {
            if (!is_array($entity)) {
                continue;
            }

            if ((int) ($entity['id'] ?? -1) === $entityId) {
                return !empty($entity['is_recursive']);
            }
        }

        return !empty($_SESSION['glpiactive_entity_recursive']);
    }

    private function isCurrentContextValid(int $currentProfileId): bool
    {
        if ($currentProfileId <= 0) {
            return false;
        }

        if (!isset($_SESSION['glpiactive_entity']) && !$this->isAllEntitiesScope()) {
            return false;
        }

        return true;
    }

    private function isAllEntitiesScope(): bool
    {
        return ($_SESSION['glpiactive_entity'] ?? null) === 'all';
    }

    private function profileName(int $profileId, array $profileData = []): string
    {
        $name = trim((string) ($profileData['name'] ?? ''));
        if ($name !== '') {
            return $name;
        }

        if ($profileId > 0 && class_exists('\Profile')) {
            $profile = new \Profile();
            if ($profile->getFromDB($profileId)) {
                return (string) ($profile->fields['name'] ?? ('Perfil ' . $profileId));
            }
        }

        return $profileId > 0 ? ('Perfil ' . $profileId) : 'Perfil atual';
    }

    private function currentEntityName(int $entityId): string
    {
        $name = trim((string) ($_SESSION['glpiactive_entity_name'] ?? ''));
        if ($name !== '') {
            return $name;
        }

        return $this->entityName($entityId);
    }

    private function entityName(int $entityId): string
    {
        if (class_exists('\Dropdown')) {
            $name = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName('glpi_entities', $entityId));
            if (trim($name) !== '') {
                return $name;
            }
        }

        if (class_exists('\Entity')) {
            $entity = new \Entity();
            if ($entity->getFromDB($entityId)) {
                return TextNormalizer::fromGlpi((string) ($entity->fields['completename'] ?? $entity->fields['name'] ?? ('Entidade ' . $entityId)));
            }
        }

        return $entityId === 0 ? 'Entidade raiz' : ('Entidade ' . $entityId);
    }

    private function currentUserLabel(): string
    {
        $login = trim((string) ($_SESSION['glpiname'] ?? ''));
        $display = trim((string) ($_SESSION['glpirealname'] ?? ''));

        if ($display !== '' && $login !== '') {
            return $login . ' - ' . $display;
        }

        if ($login !== '') {
            return $login;
        }

        return 'Usuario atual';
    }
}
