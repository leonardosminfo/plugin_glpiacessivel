<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Model;

final class PlaybookSuggestion extends \CommonDBTM
{
    public static function getTypeName($nb = 0): string
    {
        return __('Sugestao de roteiro do chatbot', 'glpiacessivel');
    }

    public static function getTable($classname = null): string
    {
        return 'glpi_plugin_glpiacessivel_playbooksuggestions';
    }
}
