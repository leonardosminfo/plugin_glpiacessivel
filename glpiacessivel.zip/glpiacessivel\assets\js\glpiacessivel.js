(function () {
  const DEFAULT_I18N = {
    'portal.open.label': 'Abrir portal acessivel do GLPI',
    'portal.open.sr': 'Abrir portal acessivel',
    'portal.embedded.label': 'Ir para modo acessivel do GLPI',
    'portal.embedded.sr': 'Ir para modo acessivel',
    'portal.open.title': 'Abrir portal acessivel',
    'portal.embedded.title': 'Ir para modo acessivel',
    'chatbot.open.label': 'Abrir chatbot operacional do GLPI acessivel',
    'chatbot.open.sr': 'Abrir chatbot operacional',
    'status.processing': 'Processando acao, aguarde.',
    'status.opening_accessible_journey': 'Abrindo jornada acessivel principal.',
    'status.opening_accessible_mode': 'Abrindo modo acessivel.',
    'status.opening_chatbot': 'Abrindo chatbot operacional.',
    'status.shortcut_executed': 'Atalho executado: {shortcut}.',
    'status.theme_changed': 'Tema alternado.',
    'status.contrast_changed': 'Alto contraste alternado.',
    'status.help_opened': 'Painel de ajuda aberto.',
    'status.help_closed': 'Painel de ajuda fechado.',
    'status.focus_main': 'Foco movido para o conteudo principal.',
    'status.focus_menu': 'Foco movido para o menu.',
    'status.focus_search': 'Foco movido para a busca ou formulario principal.',
    'status.opening_my_tickets': 'Abrindo meus chamados.',
    'status.opening_all_tickets': 'Abrindo todos os chamados permitidos.',
    'status.opening_new_ticket': 'Abrindo novo chamado.',
    'status.opening_forms': 'Abrindo formularios.',
    'status.opening_kb': 'Abrindo base de conhecimento.',
    'status.opening_cockpit': 'Abrindo cockpit operacional.',
    'status.opening_public_faq': 'Abrindo FAQ publica acessivel.',
    'status.no_ticket_selected': 'Nenhum chamado selecionado.',
    'status.ticket_ids_copied': 'IDs dos chamados selecionados copiados.',
    'status.ticket_ids_selected': 'IDs selecionados: {ids}.',
    'status.dynamic_form_updated': 'Regras dinamicas do formulario atualizadas.',
    'status.dynamic_form_visibility_failed': 'Nao foi possivel atualizar a visibilidade dinamica do formulario.',
    'status.form_validation_failed': 'Corrija os campos indicados antes de enviar.',
    'status.form_field_invalid': 'Campo invalido.',
    'status.form_submitted': 'Formulario enviado com sucesso pelo GLPI.',
    'status.form_submitted_with_links': 'Formulario enviado com sucesso. Itens criados: {links}.',
    'status.form_submit_failed': 'Nao foi possivel enviar o formulario. Abra no GLPI nativo ou contate o administrador.',
    'status.form_unexpected_response': 'O motor nativo respondeu em um formato inesperado. Use o formulario nativo para concluir.',
    'status.native_form_loaded': 'Formulario nativo carregado.',
    'status.native_form_unverified': 'O formulario nativo nao foi confirmado. Use o link para abrir a pagina completa do GLPI.',
    'status.native_form_timeout': 'O formulario nativo demorou para carregar. Use o link para abrir a pagina completa do GLPI.',
    'critical.required': 'Confirmacao obrigatoria',
    'critical.title': 'Confirmar acao critica',
    'critical.review': 'Revise os dados antes de executar esta acao.',
    'critical.consequence': 'Esta acao sera registrada no GLPI.',
    'critical.opened': 'Confirmacao obrigatoria aberta. Revise a acao antes de continuar.',
    'critical.cancelled': 'Acao critica cancelada.',
    'critical.confirmed': 'Acao critica confirmada. Enviando formulario.',
    'critical.none_pending': 'Nenhuma acao pendente para confirmar.',
    'button.cancel': 'Cancelar',
    'button.confirm_action': 'Confirmar acao',
    'shortcut.help': 'Abrir ajuda de acessibilidade',
    'shortcut.theme': 'Alternar tema claro e noturno',
    'shortcut.contrast': 'Ativar ou desativar alto contraste',
    'shortcut.font_decrease': 'Diminuir tamanho da fonte',
    'shortcut.font_reset': 'Restaurar tamanho da fonte',
    'shortcut.font_increase': 'Aumentar tamanho da fonte',
    'vlibras.ready': 'VLibras carregado.',
    'vlibras.unavailable': 'VLibras indisponivel no momento.',
    'vlibras.retrying': 'Conexao restaurada. Tentando carregar VLibras.'
  };

  function i18n(key, params) {
    const catalog = window.__glpiacessivelI18n && typeof window.__glpiacessivelI18n === 'object'
      ? window.__glpiacessivelI18n.messages
      : null;
    const source = catalog && Object.prototype.hasOwnProperty.call(catalog, key)
      ? catalog[key]
      : DEFAULT_I18N[key];
    const template = String(source || key);
    const values = params && typeof params === 'object' ? params : {};
    return template.replace(/\{([a-zA-Z0-9_]+)\}/g, function (match, name) {
      return Object.prototype.hasOwnProperty.call(values, name) ? String(values[name]) : match;
    });
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function portalButtonMarkup(srLabel) {
    return ''
      + '<svg class="glpiacessivel-portal-icon" viewBox="0 0 100 100" width="62" height="62" aria-hidden="true" focusable="false">'
      + '<path d="M20 34 A38 38 0 0 1 80 34" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<path d="M20 43 Q50 57 80 43" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<path d="M18 52 A38 38 0 0 0 33 81" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<path d="M82 52 A38 38 0 0 1 67 81" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<path d="M42 87 A20 20 0 0 0 58 87" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<path d="M50 57 L35 82" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<path d="M50 57 L65 82" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<circle cx="50" cy="33" r="10.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
      + '<circle cx="20" cy="43" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
      + '<circle cx="80" cy="43" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
      + '<circle cx="35" cy="82" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
      + '<circle cx="65" cy="82" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
      + '</svg>'
      + '<span class="glpiacessivel-sr-only">' + escapeHtml(srLabel || i18n('portal.open.sr')) + '</span>';
  }

  function chatbotButtonMarkup(srLabel) {
    return ''
      + '<svg class="glpiacessivel-chatbot-icon" viewBox="0 0 100 100" width="54" height="54" aria-hidden="true" focusable="false">'
      + '<path d="M18 28 C18 18, 26 12, 36 12 H64 C74 12, 82 18, 82 28 V54 C82 64, 74 72, 64 72 H45 L26 86 L30 72 H36 C26 72, 18 64, 18 54 Z" fill="#ffffff" stroke="#0a3f7a" stroke-width="5"></path>'
      + '<circle cx="38" cy="42" r="4.5" fill="#0a3f7a"></circle>'
      + '<circle cx="50" cy="42" r="4.5" fill="#0a3f7a"></circle>'
      + '<circle cx="62" cy="42" r="4.5" fill="#0a3f7a"></circle>'
      + '</svg>'
      + '<span class="glpiacessivel-sr-only">' + escapeHtml(srLabel || i18n('chatbot.open.sr')) + '</span>';
  }

  const VLIBRAS_SCRIPT_URL = 'https://vlibras.gov.br/app/vlibras-plugin.js';
  const VLIBRAS_APP_URL = 'https://vlibras.gov.br/app';
  const VLIBRAS_LOAD_TIMEOUT_MS = 8000;
  const VLIBRAS_RETRY_DELAY_MS = 1200;
  const VLIBRAS_RETRY_COOLDOWN_MS = 300000;
  const VLIBRAS_COOLDOWN_STORAGE_KEY = 'glpiacessivel-vlibras-retry-after';

  function vlibrasRuntimeConfig() {
    return window.__glpiacessivelRuntimeConfig && typeof window.__glpiacessivelRuntimeConfig === 'object'
      ? window.__glpiacessivelRuntimeConfig
      : {};
  }

  function updateVlibrasDiagnostics(status, detail) {
    const runtime = vlibrasRuntimeConfig();
    const previous = window.__glpiacessivelDiagnostics && window.__glpiacessivelDiagnostics.vlibras
      ? window.__glpiacessivelDiagnostics.vlibras
      : {};
    window.__glpiacessivelDiagnostics = window.__glpiacessivelDiagnostics || {};
    window.__glpiacessivelDiagnostics.vlibras = {
      enabled: shouldLoadVlibrasWidget(),
      scope: runtime.vlibrasScope || document.documentElement.getAttribute('data-glpiacessivel-vlibras') || '',
      src: VLIBRAS_SCRIPT_URL,
      status: status,
      reason: detail || '',
      startedAt: status === 'loading' ? new Date().toISOString() : (previous.startedAt || ''),
      endedAt: ['ready', 'timeout', 'error', 'unavailable', 'disabled', 'skipped-cooldown'].indexOf(status) !== -1
        ? new Date().toISOString()
        : '',
      timeoutMs: VLIBRAS_LOAD_TIMEOUT_MS,
      retryCooldownMs: VLIBRAS_RETRY_COOLDOWN_MS
    };
  }

  function vlibrasStatusRegion() {
    let region = document.getElementById('glpiacessivel-vlibras-status');
    if (region instanceof HTMLElement) {
      return region;
    }

    region = document.createElement('div');
    region.id = 'glpiacessivel-vlibras-status';
    region.className = 'glpiacessivel-sr-only sr-only';
    region.setAttribute('aria-live', 'polite');
    region.setAttribute('aria-atomic', 'true');
    document.body.appendChild(region);
    return region;
  }

  function announceVlibrasStatus(status) {
    const messages = {
      ready: i18n('vlibras.ready'),
      timeout: i18n('vlibras.unavailable'),
      error: i18n('vlibras.unavailable'),
      unavailable: i18n('vlibras.unavailable'),
      retrying: i18n('vlibras.retrying')
    };
    const message = messages[status];
    if (!message || window.__glpiacessivelVlibrasLastAnnouncement === message) {
      return;
    }

    window.__glpiacessivelVlibrasLastAnnouncement = message;
    vlibrasStatusRegion().textContent = message;
  }

  function setVlibrasStatus(status, detail) {
    updateVlibrasDiagnostics(status, detail);
    window.__glpiacessivelVlibrasStatus = {
      status: status,
      detail: detail || '',
      updatedAt: new Date().toISOString()
    };
    document.documentElement.setAttribute('data-glpiacessivel-vlibras-status', status);
    announceVlibrasStatus(status);
    try {
      window.dispatchEvent(new CustomEvent('glpiacessivel:vlibras-status', {
        detail: window.__glpiacessivelVlibrasStatus
      }));
    } catch (error) {
      // CustomEvent can be unavailable in older embedded browsers; status attributes remain available.
    }
  }

  function createVlibrasHost() {
    if (document.querySelector('[vw]')) {
      return;
    }

    const host = document.createElement('div');
    host.className = 'enabled';
    host.setAttribute('vw', '');
    host.dataset.glpiacessivelVlibrasHost = '1';
    host.innerHTML = ''
      + '<div vw-access-button class="active"></div>'
      + '<div vw-plugin-wrapper><div class="vw-plugin-top-wrapper"></div></div>';
    document.body.appendChild(host);
  }

  function removeVlibrasHostIfInactive() {
    if (window.__glpiacessivelVlibrasInitialized) {
      return;
    }

    document.querySelectorAll('[vw][data-glpiacessivel-vlibras-host="1"]').forEach(function (host) {
      if (host instanceof HTMLElement) {
        host.remove();
      }
    });
  }

  function initVlibrasWidget() {
    if (window.__glpiacessivelVlibrasInitialized) {
      return true;
    }

    if (!window.VLibras || typeof window.VLibras.Widget !== 'function') {
      return false;
    }

    if (isVlibrasWidgetFunctional()) {
      window.__glpiacessivelVlibrasInitialized = true;
      window.__glpiacessivelVlibrasLoading = false;
      setVlibrasStatus('ready');
      return true;
    }

    if (window.__glpiacessivelVlibrasInitializing) {
      return true;
    }

    createVlibrasHost();
    window.__glpiacessivelVlibrasInitializing = true;
    new window.VLibras.Widget(VLIBRAS_APP_URL);
    validateVlibrasWidgetReady(0);
    return true;
  }

  function isVlibrasWidgetFunctional() {
    return !!document.querySelector('[vw-access-button] img, [vp]');
  }

  function validateVlibrasWidgetReady(attempt) {
    if (isVlibrasWidgetFunctional()) {
      window.__glpiacessivelVlibrasInitialized = true;
      window.__glpiacessivelVlibrasInitializing = false;
      window.__glpiacessivelVlibrasLoading = false;
      setVlibrasStatus('ready');
      return;
    }

    if (
      attempt === 0
      && document.readyState === 'complete'
      && typeof window.onload === 'function'
      && !window.__glpiacessivelVlibrasForcedLoad
    ) {
      window.__glpiacessivelVlibrasForcedLoad = true;
      try {
        window.onload();
      } catch (error) {
        // The official widget uses window.onload internally; failures are reported by the validation below.
      }
    }

    if (attempt < 8) {
      window.setTimeout(function () {
        validateVlibrasWidgetReady(attempt + 1);
      }, 250);
      return;
    }

    window.__glpiacessivelVlibrasInitialized = false;
    window.__glpiacessivelVlibrasInitializing = false;
    window.__glpiacessivelVlibrasLoading = false;
    setVlibrasRetryCooldown();
    setVlibrasStatus('unavailable', 'vlibras-widget-dom');
    removeVlibrasHostIfInactive();
  }

  function vlibrasRetryAfter() {
    try {
      return Number(window.sessionStorage.getItem(VLIBRAS_COOLDOWN_STORAGE_KEY) || '0');
    } catch (error) {
      return 0;
    }
  }

  function setVlibrasRetryCooldown() {
    try {
      window.sessionStorage.setItem(VLIBRAS_COOLDOWN_STORAGE_KEY, String(Date.now() + VLIBRAS_RETRY_COOLDOWN_MS));
    } catch (error) {
      // sessionStorage can be blocked; cooldown is best-effort only.
    }
  }

  function clearVlibrasRetryCooldown() {
    try {
      window.sessionStorage.removeItem(VLIBRAS_COOLDOWN_STORAGE_KEY);
    } catch (error) {
      // sessionStorage can be blocked; retry still works without persisted cooldown.
    }
  }

  function clearVlibrasScript(script) {
    if (script && script.parentNode) {
      script.parentNode.removeChild(script);
    }
    window.__glpiacessivelVlibrasLoadBound = false;
    window.__glpiacessivelVlibrasLoading = false;
  }

  function bindVlibrasScript(script) {
    if (!(script instanceof HTMLScriptElement)) {
      return;
    }

    if (script.dataset.glpiacessivelVlibrasBound === '1') {
      return;
    }

    script.dataset.glpiacessivelVlibrasBound = '1';
    window.__glpiacessivelVlibrasLoadBound = true;
    window.__glpiacessivelVlibrasLoading = true;
    setVlibrasStatus('loading');

    const timeoutId = window.setTimeout(function () {
      if (window.__glpiacessivelVlibrasInitialized || isVlibrasWidgetFunctional()) {
        return;
      }
      script.dataset.glpiacessivelVlibrasExpired = '1';
      setVlibrasRetryCooldown();
      setVlibrasStatus('timeout', 'vlibras-plugin.js');
      removeVlibrasHostIfInactive();
      clearVlibrasScript(script);
    }, VLIBRAS_LOAD_TIMEOUT_MS);

    script.addEventListener('load', function () {
      window.clearTimeout(timeoutId);
      if (script.dataset.glpiacessivelVlibrasExpired === '1') {
        return;
      }
      if (!initVlibrasWidget()) {
        setVlibrasStatus('unavailable', 'VLibras.Widget');
        removeVlibrasHostIfInactive();
      }
      window.__glpiacessivelVlibrasLoading = false;
    }, { once: true });

    script.addEventListener('error', function () {
      window.clearTimeout(timeoutId);
      setVlibrasRetryCooldown();
      setVlibrasStatus('error', 'vlibras-plugin.js');
      removeVlibrasHostIfInactive();
      clearVlibrasScript(script);
    }, { once: true });
  }

  function ensureVlibrasWidget() {
    if (!shouldLoadVlibrasWidget()) {
      removeVlibrasHostIfInactive();
      setVlibrasStatus('disabled');
      return;
    }

    if (window.__glpiacessivelVlibrasInitialized) {
      setVlibrasStatus('ready');
      return;
    }

    const retryAfter = vlibrasRetryAfter();
    if (retryAfter > Date.now()) {
      setVlibrasStatus('skipped-cooldown', 'vlibras-plugin.js');
      return;
    }

    if (window.VLibras && typeof window.VLibras.Widget === 'function') {
      initVlibrasWidget();
      return;
    }

    if (window.__glpiacessivelVlibrasLoading) {
      return;
    }

    let existingScript = document.querySelector('script[src="' + VLIBRAS_SCRIPT_URL + '"]');
    if (existingScript instanceof HTMLScriptElement) {
      bindVlibrasScript(existingScript);
      return;
    }

    const script = document.createElement('script');
    script.src = VLIBRAS_SCRIPT_URL;
    script.async = true;
    script.dataset.glpiacessivelVlibras = '1';
    bindVlibrasScript(script);
    document.body.appendChild(script);
  }

  function pluginBasePath() {
    const scripts = Array.from(document.scripts || []);
    const ownScript = scripts.find(function (script) {
      return script.src && script.src.indexOf('/plugins/glpiacessivel/') !== -1;
    });

    if (!ownScript) {
      return '/plugins/glpiacessivel';
    }

    const url = new URL(ownScript.src, window.location.href);
    return url.pathname.split('/plugins/glpiacessivel/')[0] + '/plugins/glpiacessivel';
  }

  function loadRuntimeConfig() {
    if (window.__glpiacessivelRuntimeConfig && typeof window.__glpiacessivelRuntimeConfig === 'object') {
      window.__glpiacessivelRuntimeConfigLoaded = true;
      return Promise.resolve(window.__glpiacessivelRuntimeConfig);
    }

    if (window.__glpiacessivelRuntimeConfigLoaded) {
      return Promise.resolve(window.__glpiacessivelRuntimeConfig || {});
    }

    return new Promise(function (resolve) {
      const src = pluginBasePath() + '/front/runtime-config.js.php';
      const existing = document.querySelector('script[data-glpiacessivel-runtime-config], script[src*="/front/runtime-config.js.php"]');
      if (existing) {
        if (window.__glpiacessivelRuntimeConfigLoaded) {
          resolve(window.__glpiacessivelRuntimeConfig || {});
          return;
        }

        existing.addEventListener('load', function () {
          window.__glpiacessivelRuntimeConfigLoaded = true;
          resolve(window.__glpiacessivelRuntimeConfig || {});
        }, { once: true });
        existing.addEventListener('error', function () {
          resolve({});
        }, { once: true });
        return;
      }

      const script = document.createElement('script');
      script.src = src;
      script.async = false;
      script.defer = false;
      script.dataset.glpiacessivelRuntimeConfig = '1';
      script.onload = function () {
        window.__glpiacessivelRuntimeConfigLoaded = true;
        resolve(window.__glpiacessivelRuntimeConfig || {});
      };
      script.onerror = function () {
        resolve({});
      };
      document.head.appendChild(script);
    });
  }

  function portalModuleState(module) {
    const runtime = window.__glpiacessivelRuntimeConfig || {};
    const modules = runtime.portalModules && typeof runtime.portalModules === 'object'
      ? runtime.portalModules
      : {};
    const state = String(modules[module] || 'available');
    return ['available', 'hidden', 'disabled'].indexOf(state) !== -1 ? state : 'available';
  }

  function isPortalModuleVisible(module) {
    return portalModuleState(module) === 'available';
  }
  function isChatbotFloatingEnabled() {
    const runtime = window.__glpiacessivelRuntimeConfig || {};
    const scope = String(runtime.chatbotFloatingScope || '').trim();
    const isPluginPage = window.location.pathname.indexOf('/plugins/glpiacessivel/') !== -1;
    const isLogged = runtime.isLogged === true;
    const chatbotEnabled = runtime.chatbotEnabled !== false;

    if (!chatbotEnabled || !isPortalModuleVisible('chatbot')) {
      return false;
    }

    if (scope === 'disabled') {
      return false;
    }
    if (scope === 'plugin_only') {
      return isPluginPage;
    }
    if (scope === 'all_logged_pages') {
      return isLogged;
    }

    if (window.__glpiacessivelChatbotFloatingEnabled === false) {
      return false;
    }

    const attr = document.documentElement.getAttribute('data-glpiacessivel-chatbot-floating');
    return attr !== '0';
  }

  function accessibilityMode() {
    const runtime = window.__glpiacessivelRuntimeConfig || {};
    return String(runtime.accessibilityMode || 'hybrid').trim() || 'hybrid';
  }

  function portalButtonCopy() {
    if (accessibilityMode() === 'embedded') {
      return {
        label: i18n('portal.embedded.label'),
        srLabel: i18n('portal.embedded.sr'),
        title: i18n('portal.embedded.title')
      };
    }

    return {
      label: i18n('portal.open.label'),
      srLabel: i18n('portal.open.sr'),
      title: i18n('portal.open.title')
    };
  }

  function currentAccessibleTarget() {
    const path = window.location.pathname || '';
    const search = new URLSearchParams(window.location.search || '');
    const base = pluginBasePath();

    if (path.indexOf('/plugins/glpiacessivel/') !== -1) {
      return null;
    }

    if (path.indexOf('/front/ticket.form.php') !== -1) {
      const ticketId = String(search.get('id') || '').trim();
      if (ticketId) {
        return base + '/front/ticket.php?id=' + encodeURIComponent(ticketId);
      }

      return base + '/front/ticket.create.php';
    }

    if (path.indexOf('/front/ticket.php') !== -1) {
      const scope = String(search.get('scope') || '').trim();
      if (scope === 'mine') {
        return base + '/front/ticket.php?scope=mine';
      }

      return base + '/front/ticket.php';
    }

    if (path.indexOf('/front/knowbaseitem.form.php') !== -1) {
      const articleId = String(search.get('id') || '').trim();
      if (articleId) {
        return base + '/front/knowledge.php?article_id=' + encodeURIComponent(articleId);
      }

      return base + '/front/knowledge.php';
    }

    if (path.indexOf('/front/knowbaseitem.php') !== -1) {
      return base + '/front/knowledge.php';
    }

    if (path.indexOf('/front/login.php') !== -1 || path.indexOf('/index.php') !== -1) {
      return base + '/front/acessivel.php';
    }

    return base + '/front/acessivel.php';
  }

  function shouldShowPortalButton() {
    return true;
  }

  function shouldLoadVlibrasWidget() {
    const runtime = window.__glpiacessivelRuntimeConfig || {};
    if (typeof runtime.vlibrasEnabled === 'boolean') {
      return runtime.vlibrasEnabled;
    }

    const scope = String(runtime.vlibrasScope || '');
    const path = window.location.pathname || '';
    if (scope === 'disabled') {
      return false;
    }
    if (scope === 'all_pages') {
      return true;
    }
    if (scope === 'plugin_pages' && path.indexOf('/plugins/glpiacessivel/') !== -1) {
      return true;
    }

    return document.documentElement.getAttribute('data-glpiacessivel-vlibras') === '1';
  }

  function ensureFloatingButtonStyles() {
    if (document.getElementById('glpiacessivel-floating-button-fallback-styles')) {
      return;
    }

    const style = document.createElement('style');
    style.id = 'glpiacessivel-floating-button-fallback-styles';
    style.textContent = [
      '.glpiacessivel-portal-button,.glpiacessivel-chatbot-button{position:fixed!important;bottom:1.25rem!important;width:clamp(64px,10vw,92px)!important;height:clamp(64px,10vw,92px)!important;border-radius:999px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;padding:0!important;text-decoration:none!important;box-sizing:border-box!important;opacity:1!important;visibility:visible!important;overflow:visible!important;line-height:1!important;}',
      '.glpiacessivel-portal-button{right:1.25rem!important;z-index:100050!important;background:#fff!important;border:3px solid #111!important;color:#111!important;box-shadow:0 10px 28px rgba(16,32,51,.28)!important;}',
      '.glpiacessivel-chatbot-button{left:1.25rem!important;z-index:100049!important;background:#0f63c6!important;border:3px solid #fff!important;color:#fff!important;box-shadow:0 10px 28px rgba(16,32,51,.28)!important;}',
      '.glpiacessivel-portal-button svg,.glpiacessivel-chatbot-button svg{display:block!important;flex:0 0 auto!important;max-width:none!important;max-height:none!important;opacity:1!important;visibility:visible!important;overflow:visible!important;}',
      '.glpiacessivel-portal-icon{width:clamp(42px,6.8vw,62px)!important;height:clamp(42px,6.8vw,62px)!important;}',
      '.glpiacessivel-chatbot-icon{width:clamp(38px,6vw,54px)!important;height:clamp(38px,6vw,54px)!important;}',
      '.glpiacessivel-portal-button:focus-visible,.glpiacessivel-chatbot-button:focus-visible{outline:3px solid #fff!important;outline-offset:2px!important;box-shadow:0 0 0 6px #000!important;}'
    ].join('\n');
    document.head.appendChild(style);
  }

  function addLiveRegion() {
    if (document.getElementById('glpiacessivel-live-region')) {
      return document.getElementById('glpiacessivel-live-region');
    }

    const liveRegion = document.createElement('div');
    liveRegion.id = 'glpiacessivel-live-region';
    liveRegion.setAttribute('aria-live', 'polite');
    liveRegion.setAttribute('aria-atomic', 'true');
    liveRegion.className = 'sr-only';
    liveRegion.style.position = 'absolute';
    liveRegion.style.left = '-9999px';
    document.body.appendChild(liveRegion);
    return liveRegion;
  }

  function addPortalButton() {
    const path = window.location.pathname;
    if (path.indexOf('/plugins/glpiacessivel/') !== -1) {
      return;
    }

    if (!shouldShowPortalButton()) {
      const existing = document.getElementById('glpiacessivel-portal-button');
      if (existing) {
        existing.remove();
      }
      document.body.classList.remove('glpiacessivel-has-portal-button');
      return;
    }

    const targetUrl = currentAccessibleTarget();
    if (!targetUrl) {
      return;
    }

    const copy = portalButtonCopy();
    const existing = document.getElementById('glpiacessivel-portal-button');
    if (existing instanceof HTMLAnchorElement) {
      existing.href = targetUrl;
      existing.setAttribute('aria-label', copy.label);
      existing.setAttribute('aria-keyshortcuts', 'Alt+A');
      existing.removeAttribute('title');
      existing.innerHTML = portalButtonMarkup(copy.srLabel);
      document.body.classList.add('glpiacessivel-has-portal-button');
      return;
    }

    const link = document.createElement('a');
    link.id = 'glpiacessivel-portal-button';
    link.href = targetUrl;
    link.setAttribute('aria-label', copy.label);
    link.setAttribute('aria-keyshortcuts', 'Alt+A');
    link.removeAttribute('title');
    link.className = 'glpiacessivel-portal-button';
    link.innerHTML = portalButtonMarkup(copy.srLabel);
    document.body.appendChild(link);
    document.body.classList.add('glpiacessivel-has-portal-button');
  }

  function addChatbotButton() {
    if (!isChatbotFloatingEnabled()) {
      return;
    }

    const path = window.location.pathname;
    if (path.indexOf('/plugins/glpiacessivel/front/chatbot.php') !== -1) {
      return;
    }

    if (document.getElementById('glpiacessivel-chatbot-button')) {
      return;
    }

    const link = document.createElement('a');
    link.id = 'glpiacessivel-chatbot-button';
    link.href = pluginBasePath() + '/front/chatbot.php';
    link.setAttribute('aria-label', i18n('chatbot.open.label'));
    link.setAttribute('aria-keyshortcuts', 'Alt+V Control+Alt+Shift+V');
    link.removeAttribute('title');
    link.className = 'glpiacessivel-chatbot-button';
    link.innerHTML = chatbotButtonMarkup(i18n('chatbot.open.sr'));
    document.body.appendChild(link);
    document.body.classList.add('glpiacessivel-has-chatbot-button');
  }

  function bindSubmitAnnouncements(liveRegion) {
    document.addEventListener('submit', function (event) {
      const form = event.target;
      if (!(form instanceof HTMLFormElement)) {
        return;
      }

      liveRegion.textContent = i18n('status.processing');
    });
  }

  function bindAccessibilityShortcut(liveRegion) {
    if (window.__glpiacessivelShortcutAttached) {
      return;
    }

    document.addEventListener('keydown', function (event) {
      const target = event.target;
      const isEditable = target instanceof HTMLElement && (
        target.tagName === 'INPUT'
        || target.tagName === 'TEXTAREA'
        || target.tagName === 'SELECT'
        || target.isContentEditable
      );

      if (isEditable) {
        return;
      }

      const key = normalizeShortcutKey(event);
      const isLegacy = isLegacyShortcut(event) && key === 'a';
      const isPrimary = isPortalShortcut(event) && key === 'a' && window.location.pathname.indexOf('/plugins/glpiacessivel/') === -1;

      if (!isPrimary && !isLegacy) {
        return;
      }

      event.preventDefault();
      const button = document.getElementById('glpiacessivel-portal-button');
      const targetUrl = button instanceof HTMLAnchorElement
        ? button.href
        : (currentAccessibleTarget() || (pluginBasePath() + '/front/acessivel.php'));

      liveRegion.textContent = accessibilityMode() === 'portal'
        ? i18n('status.opening_accessible_journey')
        : i18n('status.opening_accessible_mode');
      if (button instanceof HTMLElement) {
        button.focus();
      }
      window.location.href = targetUrl;
    });

    window.__glpiacessivelShortcutAttached = true;
  }

  function bindChatbotShortcut(liveRegion) {
    if (window.__glpiacessivelChatbotShortcutAttached) {
      return;
    }

    document.addEventListener('keydown', function (event) {
      const target = event.target;
      const isEditable = target instanceof HTMLElement && (
        target.tagName === 'INPUT'
        || target.tagName === 'TEXTAREA'
        || target.tagName === 'SELECT'
        || target.isContentEditable
      );

      if (isEditable) {
        return;
      }

      const key = normalizeShortcutKey(event);
      const isPluginPage = window.location.pathname.indexOf('/plugins/glpiacessivel/') !== -1;
      const isLegacy = isLegacyShortcut(event) && key === 'c' && !isPluginPage;
      const isLegacyChatbot = isLegacyShortcut(event) && key === 'v';
      const isPrimary = isPortalShortcut(event) && key === 'v';
      if (!isPrimary && !isLegacy && !isLegacyChatbot) {
        return;
      }

      if (!isPortalModuleVisible('chatbot')) {
        return;
      }

      event.preventDefault();
      const button = document.getElementById('glpiacessivel-chatbot-button');
      const targetUrl = button instanceof HTMLAnchorElement
        ? button.href
        : (pluginBasePath() + '/front/chatbot.php');

      liveRegion.textContent = i18n('status.opening_chatbot');
      if (button instanceof HTMLElement) {
        button.focus();
      }
      window.location.href = targetUrl;
    });

    window.__glpiacessivelChatbotShortcutAttached = true;
  }

  function isPortalShortcut(event) {
    return event.altKey && !event.ctrlKey && !event.shiftKey && !event.metaKey;
  }

  function isLegacyShortcut(event) {
    return event.ctrlKey && event.altKey && event.shiftKey && !event.metaKey;
  }

  function normalizeShortcutKey(event) {
    const key = String(event.key || '').toLowerCase();
    const code = String(event.code || '').toLowerCase();
    if (key === '=' || key === 'add') {
      return '+';
    }
    if (key === '_' || key === 'subtract') {
      return '-';
    }
    if (key.length === 1) {
      return key;
    }
    if (code.startsWith('key') && code.length === 4) {
      return code.charAt(3);
    }
    if (code.startsWith('digit') && code.length === 6) {
      return code.charAt(5);
    }
    if (code === 'equal' || code === 'numpadadd') {
      return '+';
    }
    if (code === 'minus' || code === 'numpadsubtract') {
      return '-';
    }
    return key;
  }

  function isEditableShortcutTarget(target) {
    if (!(target instanceof HTMLElement)) {
      return false;
    }

    const tag = String(target.tagName || '').toLowerCase();
    return tag === 'input'
      || tag === 'textarea'
      || tag === 'select'
      || target.isContentEditable;
  }

  function focusShortcutTarget(selectors, liveRegion, message) {
    const target = selectors
      .map(function (selector) { return document.querySelector(selector); })
      .find(function (element) { return element instanceof HTMLElement; });

    if (!(target instanceof HTMLElement)) {
      return false;
    }

    if (!target.hasAttribute('tabindex')) {
      target.setAttribute('tabindex', '-1');
    }
    target.focus({ preventScroll: false });
    const reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    target.scrollIntoView({ block: 'start', behavior: reducedMotion ? 'auto' : 'smooth' });
    liveRegion.textContent = message;
    return true;
  }

  function setShortcutMetadata() {
    const metadata = [
      ['button[data-glpiacessivel-theme], [role="button"][data-glpiacessivel-theme]', 'Alt+T Control+Alt+Shift+T', i18n('shortcut.theme')],
      ['button[data-glpiacessivel-contrast], [role="button"][data-glpiacessivel-contrast]', 'Alt+C Control+Alt+Shift+K', i18n('shortcut.contrast')],
      ['[data-glpiacessivel-font="decrease"]', 'Alt+-', i18n('shortcut.font_decrease')],
      ['[data-glpiacessivel-font="reset"]', 'Alt+0', i18n('shortcut.font_reset')],
      ['[data-glpiacessivel-font="increase"]', 'Alt++', i18n('shortcut.font_increase')],
      ['button[data-glpiacessivel-help], [role="button"][data-glpiacessivel-help]', 'Alt+H Control+Alt+Shift+H', i18n('shortcut.help')]
    ];

    metadata.forEach(function (item) {
      const element = document.querySelector(item[0]);
      if (!(element instanceof HTMLElement)) {
        return;
      }
      element.setAttribute('aria-keyshortcuts', item[1]);
      element.removeAttribute('title');
    });

    const skipLinks = [
      ['a[href="#conteudo-principal"], a[href="#login-principal"], a[href="#faq-principal"]', 'Alt+1'],
      ['a[href="#glpiacessivel-menu"], a[href="#glpiacessivel-login-header"], a[href="#glpiacessivel-faq-header"]', 'Alt+2'],
      ['a[href="#glpiacessivel-search-anchor"], a[href="#glpiacessivel-login-form"], a[href="#faq-search-form"]', 'Alt+3']
    ];

    skipLinks.forEach(function (item) {
      document.querySelectorAll(item[0]).forEach(function (element) {
        if (element instanceof HTMLElement) {
          element.setAttribute('aria-keyshortcuts', item[1]);
        }
      });
    });
  }

  function goToPluginPage(path, liveRegion, message) {
    liveRegion.textContent = message;
    window.location.href = pluginBasePath() + path;
    return true;
  }

  function toggleTheme(liveRegion) {
    if (typeof window.glpiacessivelToggleTheme === 'function') {
      return window.glpiacessivelToggleTheme(liveRegion);
    }

    const button = document.querySelector('button[data-glpiacessivel-theme], [role="button"][data-glpiacessivel-theme]');
    if (!(button instanceof HTMLElement)) {
      return false;
    }

    button.click();
    button.focus();
    if (liveRegion) {
      liveRegion.textContent = i18n('status.theme_changed');
    }
    return true;
  }

  function toggleContrast(liveRegion) {
    if (typeof window.glpiacessivelToggleContrast === 'function') {
      return window.glpiacessivelToggleContrast(liveRegion);
    }

    const button = document.querySelector('button[data-glpiacessivel-contrast], [role="button"][data-glpiacessivel-contrast]');
    if (!(button instanceof HTMLElement)) {
      return false;
    }

    button.click();
    button.focus();
    if (liveRegion) {
      liveRegion.textContent = i18n('status.contrast_changed');
    }
    return true;
  }

  function isHelpPanelOpen() {
    const helpButton = document.querySelector('button[data-glpiacessivel-help], [role="button"][data-glpiacessivel-help]');
    const helpPanel = document.getElementById('glpiacessivel-help-panel')
      || document.getElementById('glpiacessivel-login-help')
      || document.getElementById('glpiacessivel-faq-help');
    return helpButton instanceof HTMLElement
      && helpPanel instanceof HTMLElement
      && helpButton.getAttribute('aria-expanded') === 'true'
      && helpPanel.hidden === false;
  }

  function toggleHelpPanel(liveRegion) {
    if (typeof window.glpiacessivelToggleHelp === 'function') {
      return window.glpiacessivelToggleHelp(liveRegion);
    }

    const button = document.querySelector('button[data-glpiacessivel-help], [role="button"][data-glpiacessivel-help]');
    if (!(button instanceof HTMLElement)) {
      return false;
    }

    const panelId = button.getAttribute('aria-controls');
    const panel = panelId ? document.getElementById(panelId) : null;
    if (panel instanceof HTMLElement) {
      const isOpen = button.getAttribute('aria-expanded') === 'true' || !panel.hidden;
      const willOpen = !isOpen;
      button.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
      panel.hidden = !willOpen;
      if (willOpen) {
        const closeButton = panel.querySelector('[data-glpiacessivel-help-close]');
        if (closeButton instanceof HTMLElement) {
          closeButton.focus();
        } else {
          panel.focus();
        }
      } else {
        button.focus();
      }
      if (liveRegion) {
        liveRegion.textContent = willOpen ? i18n('status.help_opened') : i18n('status.help_closed');
      }
      return true;
    }

    button.click();
    return true;
  }
  function bindPageShortcuts(liveRegion) {
    if (window.__glpiacessivelPageShortcutsAttached) {
      return;
    }

    setShortcutMetadata();

    const hasPluginShortcutShell = document.querySelector('.glpiacessivel-toolbar, .glpiacessivel-login-topbar, [data-glpiacessivel-help], #glpiacessivel-help-panel');
    if (!(hasPluginShortcutShell instanceof HTMLElement)) {
      window.__glpiacessivelPageShortcutsAttached = true;
      return;
    }

    document.addEventListener('keydown', function (event) {
      const key = normalizeShortcutKey(event);
      const isPortalCombo = isPortalShortcut(event);
      const isThemeFallbackCombo = isLegacyShortcut(event) && key === 't';
      const isContrastFallbackCombo = isLegacyShortcut(event) && key === 'k';
      const isHelpFallbackCombo = isLegacyShortcut(event) && key === 'h';
      const isFallbackCombo = isThemeFallbackCombo || isContrastFallbackCombo || isHelpFallbackCombo;
      if (!isPortalCombo && !isFallbackCombo) {
        return;
      }

      const safeInFields = ['t', 'c', 'k', 'h', '+', '-', '0'];
      const actions = {
        '1': function () {
          return focusShortcutTarget(
            ['#conteudo-principal', '#login-principal', '#faq-principal'],
            liveRegion,
            i18n('status.focus_main')
          );
        },
        '2': function () {
          return focusShortcutTarget(
            ['#glpiacessivel-menu', '#glpiacessivel-login-header', '#glpiacessivel-faq-header'],
            liveRegion,
            i18n('status.focus_menu')
          );
        },
        '3': function () {
          return focusShortcutTarget(
            [
              '#q',
              '#faq-search-form input[name="q"]',
              '#glpiacessivel-login-form input[type="text"]',
              'input[type="search"]',
              'form[method="get"] input[type="text"]',
              '[role="search"] input',
              '#glpiacessivel-search-anchor',
              '#faq-search-form',
              '#glpiacessivel-login-form'
            ],
            liveRegion,
            i18n('status.focus_search')
          );
        },
        't': function () {
          return toggleTheme(liveRegion);
        },
        'c': function () {
          return toggleContrast(liveRegion);
        },
        'k': function () {
          return toggleContrast(liveRegion);
        },
        '-': function () {
          const button = document.querySelector('[data-glpiacessivel-font="decrease"]');
          if (button instanceof HTMLElement) {
            button.click();
            button.focus();
            return true;
          }
          return false;
        },
        '0': function () {
          const button = document.querySelector('[data-glpiacessivel-font="reset"]');
          if (button instanceof HTMLElement) {
            button.click();
            button.focus();
            return true;
          }
          return false;
        },
        '+': function () {
          const button = document.querySelector('[data-glpiacessivel-font="increase"]');
          if (button instanceof HTMLElement) {
            button.click();
            button.focus();
            return true;
          }
          return false;
        },
        'h': function () {
          return toggleHelpPanel(liveRegion);
        },
        'a': function () {
          return goToPluginPage('/front/acessivel.php', liveRegion, i18n('status.opening_accessible_journey'));
        },
        'p': function () {
          return isPortalModuleVisible('tickets')
            && goToPluginPage('/front/ticket.php?scope=mine', liveRegion, i18n('status.opening_my_tickets'));
        },
        'g': function () {
          return isPortalModuleVisible('tickets')
            && goToPluginPage('/front/ticket.php', liveRegion, i18n('status.opening_all_tickets'));
        },
        'n': function () {
          return isPortalModuleVisible('ticket_create')
            && goToPluginPage('/front/ticket.create.php', liveRegion, i18n('status.opening_new_ticket'));
        },
        'm': function () {
          return isPortalModuleVisible('forms')
            && goToPluginPage('/front/forms.php', liveRegion, i18n('status.opening_forms'));
        },
        'b': function () {
          return isPortalModuleVisible('knowledge')
            && goToPluginPage('/front/knowledge.php', liveRegion, i18n('status.opening_kb'));
        },
        'o': function () {
          return isPortalModuleVisible('cockpit')
            && goToPluginPage('/front/cockpit.php', liveRegion, i18n('status.opening_cockpit'));
        },
        'f': function () {
          return goToPluginPage('/front/faq.php', liveRegion, i18n('status.opening_public_faq'));
        }
      };

      if (!Object.prototype.hasOwnProperty.call(actions, key)) {
        return;
      }

      if (isHelpPanelOpen() && key !== 'h') {
        return;
      }

      if (key === 'k' && !isContrastFallbackCombo) {
        return;
      }

      if (isEditableShortcutTarget(event.target) && safeInFields.indexOf(key) === -1) {
        return;
      }

      const handled = actions[key]();
      if (!handled) {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === 'function') {
        event.stopImmediatePropagation();
      }
      const shortcutLabel = isFallbackCombo ? 'Ctrl+Alt+Shift+' : 'Alt+';
      liveRegion.textContent = i18n('status.shortcut_executed', { shortcut: shortcutLabel + key.toUpperCase() });
    }, true);

    window.__glpiacessivelPageShortcutsAttached = true;
  }

  function bindCriticalConfirmations(liveRegion) {
    const forms = Array.from(document.querySelectorAll('[data-glpiacessivel-critical-form]'));
    if (forms.length === 0) {
      return;
    }

    let dialog = document.getElementById('glpiacessivel-critical-confirmation-dialog');
    if (!(dialog instanceof HTMLElement)) {
      dialog = document.createElement('div');
      dialog.id = 'glpiacessivel-critical-confirmation-dialog';
      dialog.className = 'glpiacessivel-critical-confirmation';
      dialog.hidden = true;
      dialog.innerHTML = ''
        + '<div class="glpiacessivel-critical-confirmation-backdrop" data-critical-cancel></div>'
        + '<section class="glpiacessivel-critical-confirmation-panel" role="alertdialog" aria-modal="true" aria-labelledby="glpiacessivel-critical-confirmation-title" aria-describedby="glpiacessivel-critical-confirmation-description" tabindex="-1">'
        + '<p class="glpiacessivel-eyebrow">' + escapeHtml(i18n('critical.required')) + '</p>'
        + '<h2 id="glpiacessivel-critical-confirmation-title">' + escapeHtml(i18n('critical.title')) + '</h2>'
        + '<p id="glpiacessivel-critical-confirmation-description"></p>'
        + '<p id="glpiacessivel-critical-confirmation-consequence" class="glpiacessivel-alert glpiacessivel-alert-warning"></p>'
        + '<div class="glpiacessivel-action-row">'
        + '<button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-critical-cancel>' + escapeHtml(i18n('button.cancel')) + '</button>'
        + '<button type="button" class="glpiacessivel-button glpiacessivel-button-danger" data-critical-confirm>' + escapeHtml(i18n('button.confirm_action')) + '</button>'
        + '</div>'
        + '</section>';
      document.body.appendChild(dialog);
    }

    const panel = dialog.querySelector('.glpiacessivel-critical-confirmation-panel');
    const title = dialog.querySelector('#glpiacessivel-critical-confirmation-title');
    const description = dialog.querySelector('#glpiacessivel-critical-confirmation-description');
    const consequence = dialog.querySelector('#glpiacessivel-critical-confirmation-consequence');
    const cancelButton = dialog.querySelector('[data-critical-cancel]');
    const confirmButton = dialog.querySelector('[data-critical-confirm]');
    let pendingForm = null;
    let pendingSubmitter = null;
    let returnFocus = null;

    function focusableElements() {
      return Array.from(dialog.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'))
        .filter(function (element) { return element instanceof HTMLElement && !element.hidden && element.offsetParent !== null; });
    }

    function setDialogOpen(open) {
      dialog.hidden = !open;
      document.body.classList.toggle('glpiacessivel-has-critical-dialog', open);
      if (open) {
        if (cancelButton instanceof HTMLElement) {
          cancelButton.focus();
        } else if (panel instanceof HTMLElement) {
          panel.focus();
        }
      } else if (returnFocus instanceof HTMLElement) {
        returnFocus.focus();
      }
    }

    function closeDialog(message) {
      pendingForm = null;
      pendingSubmitter = null;
      setDialogOpen(false);
      if (message && liveRegion) {
        liveRegion.textContent = message;
      }
    }

    function showDialog(form, submitter) {
      pendingForm = form;
      pendingSubmitter = submitter;
      returnFocus = submitter instanceof HTMLElement ? submitter : document.activeElement;
      const submitterMessage = submitter instanceof HTMLElement ? String(submitter.dataset.criticalMessage || '').trim() : '';
      const formMessage = String(form.dataset.criticalMessage || '').trim();
      const message = submitterMessage || formMessage || i18n('critical.review');
      if (title) {
        title.textContent = String(form.dataset.criticalTitle || i18n('critical.title'));
      }
      if (description) {
        description.textContent = message;
      }
      if (consequence) {
        consequence.textContent = String(form.dataset.criticalConsequence || i18n('critical.consequence'));
      }
      setDialogOpen(true);
      if (liveRegion) {
        liveRegion.textContent = i18n('critical.opened');
      }
    }

    dialog.addEventListener('keydown', function (event) {
      if (dialog.hidden) {
        return;
      }
      if (event.key === 'Escape') {
        event.preventDefault();
        closeDialog(i18n('critical.cancelled'));
        return;
      }
      if (event.key !== 'Tab') {
        return;
      }
      const focusable = focusableElements();
      if (focusable.length === 0) {
        event.preventDefault();
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });

    dialog.querySelectorAll('[data-critical-cancel]').forEach(function (button) {
      button.addEventListener('click', function () {
        closeDialog(i18n('critical.cancelled'));
      });
    });

    if (confirmButton instanceof HTMLElement) {
      confirmButton.addEventListener('click', function () {
        if (!(pendingForm instanceof HTMLFormElement)) {
          closeDialog(i18n('critical.none_pending'));
          return;
        }
        const confirmedField = pendingForm.querySelector('input[name="critical_confirmed"]');
        const tokenField = pendingForm.querySelector('input[name="critical_confirmation_token"]');
        const submitterToken = pendingSubmitter instanceof HTMLElement ? String(pendingSubmitter.dataset.criticalConfirmationToken || '') : '';
        if (confirmedField instanceof HTMLInputElement) {
          confirmedField.value = '1';
        }
        if (tokenField instanceof HTMLInputElement && submitterToken !== '') {
          tokenField.value = submitterToken;
        }
        const form = pendingForm;
        const submitter = pendingSubmitter;
        setDialogOpen(false);
        if (liveRegion) {
          liveRegion.textContent = i18n('critical.confirmed');
        }
        if (submitter instanceof HTMLElement && typeof form.requestSubmit === 'function') {
          form.requestSubmit(submitter);
        } else if (typeof form.requestSubmit === 'function') {
          form.requestSubmit();
        } else {
          form.submit();
        }
      });
    }

    forms.forEach(function (form) {
      if (!(form instanceof HTMLFormElement)) {
        return;
      }
      form.addEventListener('click', function (event) {
        const target = event.target;
        if (target instanceof HTMLElement) {
          const submitter = target.closest('button[type="submit"], input[type="submit"]');
          if (submitter instanceof HTMLElement) {
            form.__glpiacessivelCriticalSubmitter = submitter;
          }
        }
      }, true);
      form.addEventListener('submit', function (event) {
        const confirmedField = form.querySelector('input[name="critical_confirmed"]');
        if (confirmedField instanceof HTMLInputElement && confirmedField.value === '1') {
          return;
        }
        event.preventDefault();
        const submitter = event.submitter instanceof HTMLElement
          ? event.submitter
          : (form.__glpiacessivelCriticalSubmitter instanceof HTMLElement ? form.__glpiacessivelCriticalSubmitter : null);
        showDialog(form, submitter);
      });
    });
  }

  function bindTicketSelection(liveRegion) {
    const checkboxes = Array.from(document.querySelectorAll('.glpiacessivel-ticket-select'));
    if (checkboxes.length === 0) {
      return;
    }

    const countNode = document.querySelector('[data-glpiacessivel-selected-count]');
    const copyButton = document.querySelector('[data-glpiacessivel-copy-selected]');

    function selectedIds() {
      return checkboxes
        .filter(function (checkbox) { return checkbox.checked; })
        .map(function (checkbox) { return String(checkbox.value || '').trim(); })
        .filter(Boolean);
    }

    function refresh() {
      const ids = selectedIds();
      if (countNode) {
        countNode.textContent = String(ids.length);
      }
      if (copyButton) {
        copyButton.disabled = ids.length === 0;
      }
    }

    checkboxes.forEach(function (checkbox) {
      checkbox.addEventListener('change', refresh);
    });

    if (copyButton) {
      copyButton.addEventListener('click', function () {
        const ids = selectedIds();
        if (ids.length === 0) {
          liveRegion.textContent = i18n('status.no_ticket_selected');
          return;
        }

        const text = ids.join(', ');
        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
          navigator.clipboard.writeText(text).then(function () {
            liveRegion.textContent = i18n('status.ticket_ids_copied');
          }).catch(function () {
            liveRegion.textContent = i18n('status.ticket_ids_selected', { ids: text });
          });
          return;
        }

        liveRegion.textContent = i18n('status.ticket_ids_selected', { ids: text });
      });
    }

    refresh();
  }

  function bindDynamicFormRenderer(liveRegion) {
    const form = document.querySelector('[data-glpiacessivel-dynamic-form-renderer]');
    const conditionsNode = document.getElementById('form-render-conditions-json');
    if (!(form instanceof HTMLFormElement)) {
      return;
    }
    if (form.dataset.glpiacessivelDynamicBound === '1') {
      return;
    }
    form.dataset.glpiacessivelDynamicBound = '1';

    let conditions = [];
    if (conditionsNode instanceof HTMLElement) {
      try {
        conditions = JSON.parse(conditionsNode.textContent || '[]');
      } catch (error) {
        conditions = [];
      }
    }
    conditions = conditions.filter(function (condition) {
      return condition
        && condition.supported === true
        && ['show', 'hide', 'require', 'disable'].indexOf(String(condition.effect || '')) !== -1
        && condition.expression
        && typeof condition.expression === 'object';
    });
    function bindNativeDelegatedSubmission() {
      if (form.dataset.glpiacessivelNativeSubmit !== '1' || form.dataset.glpiacessivelNativeSubmitBound === '1') {
        return;
      }
      form.dataset.glpiacessivelNativeSubmitBound = '1';

      const submitButton = form.querySelector('[data-glpiacessivel-native-submit-button]');
      const errorSummary = document.getElementById('form-render-error-summary');
      const submitStatus = document.getElementById('form-render-submit-status');
      const validateUrl = form.dataset.glpiacessivelValidateUrl || '';
      const conditionUrl = form.dataset.glpiacessivelConditionUrl || '';
      const formId = form.dataset.glpiacessivelFormId || '';

      function csrfToken() {
        if (typeof window.getAjaxCsrfToken === 'function') {
          return window.getAjaxCsrfToken();
        }
        const tokenInput = document.querySelector('input[name="_glpi_csrf_token"]');
        return tokenInput instanceof HTMLInputElement ? tokenInput.value : '';
      }

      function clearNativeErrors() {
        form.querySelectorAll('.glpiacessivel-field-error').forEach(function (node) { node.remove(); });
        form.querySelectorAll('[aria-invalid="true"]').forEach(function (control) {
          control.removeAttribute('aria-invalid');
          control.removeAttribute('aria-errormessage');
        });
        form.querySelectorAll('[aria-describedby]').forEach(function (control) {
          const describedBy = (control.getAttribute('aria-describedby') || '').split(/\s+/).filter(function (id) {
            return id && id.indexOf('form-render-error-') !== 0;
          });
          if (describedBy.length > 0) {
            control.setAttribute('aria-describedby', describedBy.join(' '));
          } else {
            control.removeAttribute('aria-describedby');
          }
        });
        if (errorSummary) {
          errorSummary.hidden = true;
          errorSummary.textContent = '';
        }
      }
      function escapeSelectorValue(value) {
        return window.CSS && typeof window.CSS.escape === 'function'
          ? window.CSS.escape(String(value))
          : String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
      }

      function controlsForNativeQuestion(questionId) {
        const safe = escapeSelectorValue(questionId);
        return Array.from(form.querySelectorAll('[name="answers_' + safe + '"], [name="answers_' + safe + '[]"]'));
      }

      function controlsForField(field) {
        const safe = escapeSelectorValue(field);
        const wrapper = form.querySelector('[data-field-name="' + safe + '"]');
        return wrapper instanceof HTMLElement ? Array.from(wrapper.querySelectorAll('input, select, textarea')) : [];
      }

      function normalizeNativeErrors(errors) {
        const source = Array.isArray(errors) ? errors : Object.entries(errors || {}).map(function (entry) {
          const value = entry[1];
          if (value && typeof value === 'object' && !Array.isArray(value)) {
            return Object.assign({ field: entry[0] }, value);
          }
          return { field: entry[0], message: value };
        });
        return source.map(function (error) {
          const item = error && typeof error === 'object' ? error : { message: error };
          const field = String(item.field || item.name || '');
          const questionMatch = String(item.question_id || field).match(/^answers_(\d+)/);
          return {
            field: field,
            code: String(item.code || item.error_code || item.type || 'validation_error'),
            message: String(item.message || item.detail || item.error || i18n('status.form_field_invalid')),
            question_id: item.question_id ? String(item.question_id) : (questionMatch ? questionMatch[1] : '')
          };
        }).filter(function (error) { return error.message !== ''; });
      }

      function showValidationErrors(errors) {
        clearNativeErrors();
        const normalized = normalizeNativeErrors(errors);
        if (normalized.length === 0) {
          return;
        }

        if (errorSummary) {
          const title = document.createElement('strong');
          title.textContent = i18n('status.form_validation_failed');
          const list = document.createElement('ul');
          normalized.forEach(function (error) {
            const item = document.createElement('li');
            const questionId = error.question_id;
            const controls = questionId !== '' ? controlsForNativeQuestion(questionId) : controlsForField(error.field);
            const target = controls.find(function (control) { return control instanceof HTMLElement && control.id !== ''; });
            if (target instanceof HTMLElement) {
              const link = document.createElement('a');
              link.href = '#' + target.id;
              link.textContent = error.message;
              item.appendChild(link);
            } else {
              item.textContent = error.message;
            }
            list.appendChild(item);
          });
          errorSummary.replaceChildren(title, list);
          errorSummary.hidden = false;
        }

        let firstControl = null;
        normalized.forEach(function (error, index) {
          const questionId = error.question_id;
          const field = error.field;
          const key = questionId || field || 'form';
          const controls = questionId !== '' ? controlsForNativeQuestion(questionId) : controlsForField(field);
          const selector = questionId !== ''
            ? '[data-native-question-id="' + escapeSelectorValue(questionId) + '"]'
            : '[data-field-name="' + escapeSelectorValue(field) + '"]';
          const wrapper = form.querySelector(selector);
          const errorId = 'form-render-error-' + escapeSelectorValue(key) + '-' + index;
          const message = document.createElement('p');
          message.id = errorId;
          message.className = 'glpiacessivel-field-error';
          message.textContent = error.message;
          if (wrapper instanceof HTMLElement) { wrapper.appendChild(message); }
          controls.forEach(function (control) {
            if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement) {
              control.setAttribute('aria-invalid', 'true');
              control.setAttribute('aria-errormessage', errorId);
              const describedBy = (control.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
              if (describedBy.indexOf(errorId) === -1) {
                describedBy.push(errorId);
                control.setAttribute('aria-describedby', describedBy.join(' '));
              }
              if (firstControl === null) { firstControl = control; }
            }
          });
        });

        if (errorSummary) { errorSummary.focus(); } else if (firstControl) { firstControl.focus(); }
      }


      async function postFormData(url, data) {
        const headers = { 'X-Requested-With': 'XMLHttpRequest' };
        const token = csrfToken();
        if (token !== '') {
          headers['X-Glpi-Csrf-Token'] = token;
        }
        const response = await fetch(url, {
          method: 'POST',
          body: data,
          credentials: 'same-origin',
          headers: headers
        });
        const contentType = String(response.headers.get('content-type') || '').toLowerCase();
        let payload = {};
        let isJson = contentType.indexOf('json') !== -1;
        if (isJson) {
          try {
            payload = await response.json();
          } catch (error) {
            isJson = false;
          }
        } else {
          await response.text();
        }
        if (!response.ok) {
          const failure = new Error(String(response.status));
          failure.payload = isJson ? payload : { message: i18n('status.form_submit_failed') };
          throw failure;
        }
        if (response.redirected && response.url !== '') {
          return { redirect: response.url };
        }
        if (!isJson) {
          const failure = new Error('unexpected_native_response');
          failure.payload = { message: i18n('status.form_unexpected_response') };
          throw failure;
        }
        return payload;
      }

      async function validateNativeAnswers() {
        if (validateUrl === '') {
          return true;
        }
        const payload = await postFormData(validateUrl, new FormData(form));
        if (payload && payload.success === false) {
          showValidationErrors(payload.errors || []);
          return false;
        }
        clearNativeErrors();
        return true;
      }

      function applyNativeVisibilityResult(payload) {
        if (!payload || typeof payload !== 'object') {
          return;
        }
        const activeElement = document.activeElement instanceof HTMLElement ? document.activeElement : null;
        const activeWrapper = activeElement ? activeElement.closest('[data-glpiacessivel-field-wrapper], [data-glpiacessivel-section-wrapper]') : null;
        let focusTarget = null;

        function focusableIn(wrapper) {
          if (!(wrapper instanceof HTMLElement) || wrapper.hidden) {
            return null;
          }
          const candidates = Array.from(wrapper.querySelectorAll('input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), [tabindex]:not([tabindex="-1"])'));
          return candidates.find(function (candidate) {
            return candidate instanceof HTMLElement && !candidate.hidden && candidate.offsetParent !== null;
          }) || null;
        }

        function rememberFocusBeforeHiding(wrapper, visible) {
          if (visible || !(activeWrapper instanceof HTMLElement) || activeWrapper !== wrapper || focusTarget !== null) {
            return;
          }
          const wrappers = Array.from(form.querySelectorAll('[data-glpiacessivel-field-wrapper], [data-glpiacessivel-section-wrapper]'));
          const currentIndex = wrappers.indexOf(wrapper);
          for (let index = currentIndex + 1; index < wrappers.length; index += 1) {
            const candidate = focusableIn(wrappers[index]);
            if (candidate !== null) {
              focusTarget = candidate;
              return;
            }
          }
          const heading = form.querySelector('h3, legend');
          if (heading instanceof HTMLElement) {
            heading.setAttribute('tabindex', '-1');
            focusTarget = heading;
          }
        }

        const questionVisibility = payload.questions_visibility || {};
        Object.keys(questionVisibility).forEach(function (questionId) {
          const wrapper = form.querySelector('[data-native-question-id="' + String(questionId).replace(/"/g, '\\"') + '"]');
          if (!(wrapper instanceof HTMLElement)) {
            return;
          }
          const visible = Boolean(questionVisibility[questionId]);
          rememberFocusBeforeHiding(wrapper, visible);
          wrapper.hidden = !visible;
          wrapper.setAttribute('aria-hidden', visible ? 'false' : 'true');
          wrapper.querySelectorAll('input, select, textarea').forEach(function (control) {
            if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement) {
              control.disabled = !visible || control.closest('[data-original-disabled="1"]') !== null;
            }
          });
        });

        const sectionVisibility = payload.sections_visibility || {};
        Object.keys(sectionVisibility).forEach(function (sectionId) {
          const wrapper = form.querySelector('[data-native-section-id="' + String(sectionId).replace(/"/g, '\\"') + '"]');
          if (!(wrapper instanceof HTMLElement)) {
            return;
          }
          const visible = Boolean(sectionVisibility[sectionId]);
          rememberFocusBeforeHiding(wrapper, visible);
          wrapper.hidden = !visible;
          wrapper.setAttribute('aria-hidden', visible ? 'false' : 'true');
        });
        if (focusTarget instanceof HTMLElement) {
          focusTarget.focus({ preventScroll: false });
          if (liveRegion) {
            liveRegion.textContent = i18n('status.dynamic_form_updated');
          }
        }
      }

      function applyQuestionBooleanMap(map, attribute) {
        Object.keys(map || {}).forEach(function (questionId) {
          const wrapper = form.querySelector('[data-native-question-id="' + escapeSelectorValue(questionId) + '"]');
          if (!(wrapper instanceof HTMLElement)) {
            return;
          }
          const enabled = Boolean(map[questionId]);
          wrapper.querySelectorAll('input, select, textarea').forEach(function (control) {
            if (!(control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement)) {
              return;
            }
            if (attribute === 'required') {
              control.required = enabled;
              control.setAttribute('aria-required', enabled ? 'true' : 'false');
            } else {
              control.disabled = enabled || wrapper.hidden || control.closest('[data-original-disabled="1"]') !== null;
            }
          });
          if (attribute === 'required') {
            wrapper.setAttribute('data-dynamic-required', enabled ? '1' : '0');
            const choiceGroup = wrapper.querySelector('fieldset.glpiacessivel-dynamic-renderer-choice');
            if (choiceGroup instanceof HTMLElement) {
              choiceGroup.setAttribute('aria-required', enabled ? 'true' : 'false');
            }
          }
        });
      }

      function applyNativeBooleanMaps(payload) {
        applyQuestionBooleanMap(payload.questions_required || payload.questions_mandatory || {}, 'required');
        applyQuestionBooleanMap(payload.questions_disabled || {}, 'disabled');
      }
      function buildConditionEnginePayload() {
        const output = new FormData();
        output.append('form_id', formId);
        const data = new FormData(form);
        for (const entry of data.entries()) {
          const key = String(entry[0]);
          const value = entry[1];
          const match = /^answers_(\d+)(\[\])?$/.exec(key);
          if (!match) {
            continue;
          }
          const outputKey = match[2] ? 'answers[' + match[1] + '][]' : 'answers[' + match[1] + ']';
          output.append(outputKey, value);
        }
        return output;
      }

      async function computeNativeVisibility() {
        if (conditionUrl === '' || formId === '') {
          return null;
        }
        try {
          const payload = await postFormData(conditionUrl, buildConditionEnginePayload());
          applyNativeVisibilityResult(payload);
          applyNativeBooleanMaps(payload);
          if (submitButton instanceof HTMLButtonElement) {
            submitButton.disabled = false;
            submitButton.removeAttribute('aria-disabled');
          }
          return payload;
        } catch (error) {
          if (liveRegion) {
            liveRegion.textContent = i18n('status.dynamic_form_visibility_failed');
          }
          if (submitButton instanceof HTMLButtonElement) {
            submitButton.disabled = true;
            submitButton.setAttribute('aria-disabled', 'true');
          }
          if (submitStatus) {
            submitStatus.hidden = false;
            submitStatus.textContent = i18n('status.dynamic_form_visibility_failed');
          }
          return null;
        }
      }

      form.addEventListener('input', function () { computeNativeVisibility(); });
      form.addEventListener('change', function () { computeNativeVisibility(); });
      computeNativeVisibility();

      form.addEventListener('submit', async function (event) {
        event.preventDefault();
        clearNativeErrors();
        if (submitStatus) {
          submitStatus.hidden = true;
          submitStatus.textContent = '';
        }
        if (submitButton instanceof HTMLButtonElement) {
          submitButton.disabled = true;
          submitButton.setAttribute('aria-busy', 'true');
        }
        try {
          await computeNativeVisibility();
          const valid = await validateNativeAnswers();
          if (!valid) {
            return;
          }
          const payload = await postFormData(form.action, new FormData(form));
          if (payload && typeof payload.redirect === 'string' && payload.redirect !== '') {
            window.location.assign(payload.redirect);
            return;
          }
          if (submitStatus) {
            const links = Array.isArray(payload.links_to_created_items) ? payload.links_to_created_items : [];
            submitStatus.textContent = links.length > 0
              ? i18n('status.form_submitted_with_links', { links: links.join(', ') })
              : i18n('status.form_submitted');
            submitStatus.hidden = false;
            submitStatus.focus();
          }
          if (liveRegion) {
            liveRegion.textContent = i18n('status.form_submitted');
          }
          form.querySelectorAll('input, select, textarea, button').forEach(function (control) {
            if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement || control instanceof HTMLButtonElement) {
              control.disabled = true;
            }
          });
        } catch (error) {
          const payload = error && error.payload ? error.payload : {};
          if (payload && payload.errors) {
            showValidationErrors(payload.errors);
          } else if (errorSummary) {
            errorSummary.textContent = payload && payload.message ? String(payload.message) : i18n('status.form_submit_failed');
            errorSummary.hidden = false;
            errorSummary.focus();
          }
        } finally {
          if (submitButton instanceof HTMLButtonElement && submitStatus && submitStatus.hidden) {
            submitButton.disabled = false;
            submitButton.removeAttribute('aria-busy');
          }
        }
      });
    }

    bindNativeDelegatedSubmission();

    if (conditions.length === 0) {
      return;
    }

    const status = document.getElementById('form-render-condition-status') || liveRegion;

    function escapeSelectorValue(value) {
      if (window.CSS && typeof window.CSS.escape === 'function') {
        return window.CSS.escape(String(value));
      }
      return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    }

    function fieldWrapper(name) {
      return form.querySelector('[data-glpiacessivel-field-wrapper][data-field-name="' + escapeSelectorValue(name) + '"]');
    }

    function sectionWrapper(id) {
      return form.querySelector('[data-glpiacessivel-section-wrapper][data-section-id="' + escapeSelectorValue(id) + '"]');
    }

    function targetWrapper(condition) {
      const expression = condition.expression || {};
      const targetType = String(expression.target_type || condition.target_type || 'field');
      if (targetType === 'section') {
        return sectionWrapper(condition.target_field);
      }
      return fieldWrapper(condition.target_field);
    }

    function controlsFor(name) {
      const safe = escapeSelectorValue(name);
      return Array.from(form.querySelectorAll('[name="' + safe + '"], [name="' + safe + '[]"]'));
    }

    function fieldValue(name) {
      const controls = controlsFor(name);
      const values = [];
      controls.forEach(function (control) {
        if (!(control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement)) {
          return;
        }
        if ((control.type === 'checkbox' || control.type === 'radio') && !control.checked) {
          return;
        }
        if (control instanceof HTMLSelectElement && control.multiple) {
          Array.from(control.selectedOptions).forEach(function (option) { values.push(String(option.value)); });
          return;
        }
        values.push(String(control.value || ''));
      });
      return values;
    }

    function comparisonMatches(expression) {
      const values = fieldValue(expression.field);
      const expected = expression.values && expression.values.length ? expression.values.map(String) : [String(expression.value ?? '')];
      const operator = String(expression.operator || 'equals');
      const hasValue = values.some(function (value) { return value !== ''; });
      if (operator === 'empty') {
        return !hasValue;
      }
      if (operator === 'not_empty') {
        return hasValue;
      }
      if (operator === 'equals') {
        return values.some(function (value) { return value === expected[0]; });
      }
      if (operator === 'not_equals') {
        return values.every(function (value) { return value !== expected[0]; });
      }
      if (operator === 'contains') {
        return values.some(function (value) { return value.indexOf(expected[0]) !== -1; });
      }
      if (operator === 'in') {
        return values.some(function (value) { return expected.indexOf(value) !== -1; });
      }
      if (operator === 'not_in') {
        return values.every(function (value) { return expected.indexOf(value) === -1; });
      }
      return false;
    }

    function expressionMatches(expression) {
      if (!expression || typeof expression !== 'object') {
        return false;
      }
      if (Array.isArray(expression.all)) {
        return expression.all.every(expressionMatches);
      }
      if (Array.isArray(expression.any)) {
        return expression.any.some(expressionMatches);
      }
      if (expression.not && typeof expression.not === 'object') {
        return !expressionMatches(expression.not);
      }
      if (String(expression.field || '') !== '') {
        return comparisonMatches(expression);
      }
      return false;
    }

    function collectExpressionFields(expression, output) {
      if (!expression || typeof expression !== 'object') {
        return;
      }
      if (String(expression.field || '') !== '') {
        output.add(String(expression.field));
      }
      ['all', 'any'].forEach(function (key) {
        if (Array.isArray(expression[key])) {
          expression[key].forEach(function (child) { collectExpressionFields(child, output); });
        }
      });
      if (expression.not && typeof expression.not === 'object') {
        collectExpressionFields(expression.not, output);
      }
    }

    function controlsInWrapper(wrapper) {
      return Array.from(wrapper.querySelectorAll('input, select, textarea'));
    }

    function setRequired(wrapper, required) {
      wrapper.dataset.dynamicRequired = required ? '1' : '0';
      controlsFor(wrapper.dataset.fieldName || '').forEach(function (control) {
        if (!(control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement)) {
          return;
        }
        control.required = required;
        control.setAttribute('aria-required', required ? 'true' : 'false');
      });
      const label = wrapper.querySelector('label, legend');
      if (label instanceof HTMLElement) {
        const base = label.dataset.baseLabel || label.textContent || '';
        label.dataset.baseLabel = base.replace(/\s\*$/, '');
        label.textContent = label.dataset.baseLabel + (required ? ' *' : '');
      }
    }

    function setDisabled(wrapper, disabled) {
      const controls = wrapper.dataset.fieldName ? controlsFor(wrapper.dataset.fieldName || '') : controlsInWrapper(wrapper);
      controls.forEach(function (control) {
        if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement) {
          const originalDisabled = control.closest('[data-original-disabled="1"]') !== null;
          control.disabled = disabled || originalDisabled;
        }
      });
      wrapper.classList.toggle('glpiacessivel-dynamic-disabled', disabled);
    }

    function setVisible(wrapper, visible) {
      const activeElement = document.activeElement instanceof HTMLElement ? document.activeElement : null;
      const moveFocus = !visible && activeElement !== null && wrapper.contains(activeElement);
      wrapper.hidden = !visible;
      wrapper.setAttribute('aria-hidden', visible ? 'false' : 'true');
      const controls = wrapper.dataset.fieldName ? controlsFor(wrapper.dataset.fieldName || '') : controlsInWrapper(wrapper);
      controls.forEach(function (control) {
        if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement) {
          const originalDisabled = control.closest('[data-original-disabled="1"]') !== null;
          control.disabled = !visible || wrapper.dataset.dynamicDisabled === '1' || originalDisabled;
          if (!visible) {
            control.required = false;
            control.setAttribute('aria-required', 'false');
            control.removeAttribute('aria-invalid');
            control.removeAttribute('aria-errormessage');
          } else {
            const required = wrapper.dataset.dynamicRequired === '1' || wrapper.dataset.originalRequired === '1';
            control.required = required;
            control.setAttribute('aria-required', required ? 'true' : 'false');
          }
        }
      });

      if (moveFocus) {
        const wrappers = Array.from(form.querySelectorAll('[data-glpiacessivel-field-wrapper], [data-glpiacessivel-section-wrapper]'));
        const currentIndex = wrappers.indexOf(wrapper);
        let nextControl = null;
        for (let index = currentIndex + 1; index < wrappers.length; index += 1) {
          if (wrappers[index] instanceof HTMLElement && !wrappers[index].hidden) {
            nextControl = wrappers[index].querySelector('input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled])');
            if (nextControl instanceof HTMLElement) {
              break;
            }
          }
        }
        if (!(nextControl instanceof HTMLElement)) {
          nextControl = form.querySelector('h3, legend');
        }
        if (nextControl instanceof HTMLElement) {
          nextControl.setAttribute('tabindex', '-1');
          nextControl.focus({ preventScroll: false });
          if (status) {
            status.textContent = i18n('status.dynamic_form_updated');
          }
        }
      }
    }

    function applyConditions() {
      let changed = 0;
      conditions.forEach(function (condition) {
        const wrapper = targetWrapper(condition);
        if (!(wrapper instanceof HTMLElement)) {
          return;
        }
        const matches = expressionMatches(condition.expression || {});
        const effect = String(condition.effect || '');
        if (effect === 'show') {
          setVisible(wrapper, matches);
          changed += 1;
        } else if (effect === 'hide') {
          setVisible(wrapper, !matches);
          changed += 1;
        } else if (effect === 'require' && wrapper.dataset.fieldName) {
          setRequired(wrapper, matches || wrapper.dataset.originalRequired === '1');
          changed += 1;
        } else if (effect === 'disable') {
          wrapper.dataset.dynamicDisabled = matches ? '1' : '0';
          setDisabled(wrapper, matches);
          changed += 1;
        }
      });
      if (changed > 0 && status) {
        status.textContent = i18n('status.dynamic_form_updated');
      }
    }

    const sourceFieldSet = new Set();
    conditions.forEach(function (condition) {
      collectExpressionFields(condition.expression || {}, sourceFieldSet);
    });
    Array.from(sourceFieldSet).forEach(function (name) {
      controlsFor(name).forEach(function (control) {
        control.addEventListener('change', applyConditions);
        control.addEventListener('input', applyConditions);
      });
    });
    applyConditions();
  }

  function bindNativeEmbeddedForms() {
    document.querySelectorAll('[data-glpiacessivel-native-frame]').forEach(function (frame) {
      if (!(frame instanceof HTMLIFrameElement) || frame.dataset.glpiacessivelNativeFrameBound === '1') {
        return;
      }
      frame.dataset.glpiacessivelNativeFrameBound = '1';
      const status = document.getElementById('form-render-native-frame-status');
      const fallbackLink = document.querySelector('[data-glpiacessivel-native-full-link]');
      let timeoutId = window.setTimeout(function () {
        if (status) {
          status.textContent = i18n('status.native_form_timeout');
        }
      }, 8000);

      frame.addEventListener('load', function () {
        window.clearTimeout(timeoutId);
        let hasForm = false;
        try {
          const body = frame.contentDocument && frame.contentDocument.body;
          hasForm = Boolean(body && body.querySelector('form'));
          if (body && body.scrollHeight > 0) {
            const nextHeight = Math.min(Math.max(body.scrollHeight + 32, 760), 1400);
            frame.style.minHeight = nextHeight + 'px';
          }
        } catch (error) {
          hasForm = false;
        }
        if (status) {
          status.textContent = i18n(hasForm ? 'status.native_form_loaded' : 'status.native_form_unverified');
        }
        if (!hasForm && fallbackLink instanceof HTMLElement) {
          fallbackLink.focus({ preventScroll: false });
        }
      });
    });
  }

  function bindModulePresetControls(liveRegion) {
    const select = document.querySelector('[data-glpiacessivel-module-preset]');
    const button = document.querySelector('[data-glpiacessivel-module-preset-apply]');
    if (!(select instanceof HTMLSelectElement) || !(button instanceof HTMLButtonElement) || button.dataset.bound === '1') {
      return;
    }

    button.dataset.bound = '1';
    const status = document.querySelector('[data-glpiacessivel-module-status]');
    const dependency = document.querySelector('[data-glpiacessivel-module-dependency]');
    let presets = {};
    try {
      presets = JSON.parse(select.dataset.presets || '{}');
    } catch (error) {
      presets = {};
    }

    function updateDependency() {
      if (!(dependency instanceof HTMLElement)) {
        return;
      }
      const tickets = document.querySelector('input[name="module_states[tickets]"]:checked');
      const state = tickets instanceof HTMLInputElement ? tickets.value : 'available';
      if (state === 'disabled') {
        dependency.textContent = dependency.dataset.disabledMessage || '';
        dependency.hidden = false;
      } else if (state === 'hidden') {
        dependency.textContent = dependency.dataset.hiddenMessage || '';
        dependency.hidden = false;
      } else {
        dependency.textContent = '';
        dependency.hidden = true;
      }
    }

    document.querySelectorAll('input[name="module_states[tickets]"]').forEach(function (control) {
      control.addEventListener('change', updateDependency);
    });

    button.addEventListener('click', function () {
      const states = presets[select.value];
      if (!states || typeof states !== 'object') {
        return;
      }
      Object.keys(states).forEach(function (module) {
        const selector = 'input[name="module_states[' + module + ']"][value="' + states[module] + '"]';
        const radio = document.querySelector(selector);
        if (radio instanceof HTMLInputElement) {
          radio.checked = true;
        }
      });
      updateDependency();
      const message = button.dataset.announcement || '';
      if (status instanceof HTMLElement) {
        status.textContent = message;
      }
      if (liveRegion && message) {
        liveRegion.textContent = message;
      }
    });

    updateDependency();
  }
  function applyNativeEmbeddedPageMode() {
    try {
      const params = new URLSearchParams(window.location.search || '');
      if (params.get('glpiacessivel_native_embed') === '1') {
        document.body.classList.add('glpiacessivel-native-embedded-page');
      }
    } catch (error) {
      return;
    }
  }

  function refreshFloatingUi() {
    ensureFloatingButtonStyles();
    addPortalButton();
    addChatbotButton();
    setShortcutMetadata();
  }

  function start() {
    applyNativeEmbeddedPageMode();
    const liveRegion = addLiveRegion();
    bindSubmitAnnouncements(liveRegion);
    bindModulePresetControls(liveRegion);
    bindPageShortcuts(liveRegion);
    bindTicketSelection(liveRegion);
    bindDynamicFormRenderer(liveRegion);
    bindNativeEmbeddedForms();
    bindAccessibilityShortcut(liveRegion);
    bindChatbotShortcut(liveRegion);
    loadRuntimeConfig().finally(function () {
      refreshFloatingUi();
      if (shouldLoadVlibrasWidget()) {
        window.setTimeout(ensureVlibrasWidget, 300);
      }
      window.setTimeout(refreshFloatingUi, 500);
      window.setTimeout(refreshFloatingUi, 1400);
    });

    window.addEventListener('online', function () {
      const state = window.__glpiacessivelVlibrasStatus && window.__glpiacessivelVlibrasStatus.status;
      if (['timeout', 'error', 'unavailable'].indexOf(state) === -1 || !shouldLoadVlibrasWidget()) {
        return;
      }
      clearVlibrasRetryCooldown();
      setVlibrasStatus('retrying');
      window.setTimeout(ensureVlibrasWidget, VLIBRAS_RETRY_DELAY_MS);
    });

    window.addEventListener('pageshow', refreshFloatingUi, { once: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();


