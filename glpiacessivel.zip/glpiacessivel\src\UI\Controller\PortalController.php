<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\Security\SessionContextGuard;
use GlpiPlugin\Glpiacessivel\Support\LoginSourceDiscovery;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class PortalController extends BaseController
{
    public static function entry(): void
    {
        if (!self::isLogged()) {
            self::renderAccessibleLogin();
            return;
        }

        \Session::checkLoginUser();

        $sessionStatus = (new SessionContextGuard())->ensureReady();
        if (empty($sessionStatus['session_ready'])) {
            self::container()->auditLogger()->log('session.context_incomplete', [
                'issue_code' => (string) ($sessionStatus['issue_code'] ?? 'unknown'),
                'profile_id' => (int) ($sessionStatus['profile_id'] ?? 0),
                'profile_count' => (int) ($sessionStatus['profile_count'] ?? 0),
                'entity_id' => (int) ($sessionStatus['entity_id'] ?? 0),
                'has_active_entities' => !empty($sessionStatus['has_active_entities']) ? 1 : 0,
                'active_entities_count' => (int) ($sessionStatus['active_entities_count'] ?? 0),
                'normalization_attempted' => !empty($sessionStatus['normalization_attempted']) ? 1 : 0,
                'normalization_changed' => !empty($sessionStatus['normalization_changed']) ? 1 : 0,
            ]);
        }

        $sessionReady = !empty($sessionStatus['session_ready']);
        $authorization = self::container()->authorization();
        $modulePolicy = self::container()->portalModulePolicy();
        $canCreateTicket = $sessionReady
            && $modulePolicy->isVisible(ConfigService::MODULE_TICKET_CREATE)
            && $authorization->canCreateTickets();
        $canUseForms = $sessionReady
            && $modulePolicy->isVisible(ConfigService::MODULE_FORMS)
            && $authorization->canUseForms();
        $createTicketUrl = self::getCreateTicketUrl();

        View::render('portal/index', [
            'title' => __('Portal acessivel', 'glpiacessivel'),
            'chatbot_enabled' => $sessionReady
                && $modulePolicy->isVisible(ConfigService::MODULE_CHATBOT)
                && $authorization->canUseChatbot(),
            'canCreateTicket' => $canCreateTicket,
            'canUseForms' => $canUseForms,
            'canViewTickets' => $sessionReady
                && $modulePolicy->isVisible(ConfigService::MODULE_TICKETS)
                && $authorization->canViewTickets(),
            'canViewCockpit' => $sessionReady
                && $modulePolicy->isVisible(ConfigService::MODULE_COCKPIT)
                && $authorization->canViewCockpit(),
            'canViewKnowledgeBase' => $sessionReady
                && $modulePolicy->isVisible(ConfigService::MODULE_KNOWLEDGE)
                && $authorization->canViewKnowledgeBase(),
            'createTicketUrl' => $createTicketUrl,
            'session_status' => $sessionStatus,
            'nativeLoginUrl' => self::nativeLoginUrl(),
        ]);
    }

    private static function assetVersionFor(string $assetPath): string
    {
        if (function_exists('plugin_glpiacessivel_asset_version')) {
            return plugin_glpiacessivel_asset_version($assetPath);
        }

        $version = defined('PLUGIN_GLPIACESSIVEL_VERSION') ? (string) PLUGIN_GLPIACESSIVEL_VERSION : 'dev';
        $fullPath = __DIR__ . '/../../../' . ltrim($assetPath, '/');
        $mtime = is_file($fullPath) ? @filemtime($fullPath) : false;

        return $mtime !== false ? $version . '-' . (string) $mtime : $version;
    }

    public static function publicFaq(): void
    {
        global $CFG_GLPI;

        self::sendPublicSecurityHeaders();

        $sanitizer = new InputSanitizer();
        $filters = [
            'query' => $sanitizer->text($_GET['q'] ?? '', 120),
            'category_id' => max(0, $sanitizer->int($_GET['category'] ?? 0, 0)),
            'public_only' => true,
            'page' => max(1, $sanitizer->int($_GET['page'] ?? 1, 1)),
            'page_size' => 10,
            'article_id' => max(0, $sanitizer->int($_GET['article'] ?? 0, 0)),
        ];
        $overview = self::container()->knowledgeBaseService()->overview($filters);

        $css = Url::asset('public/assets/css/glpiacessivel.css?v=' . rawurlencode(self::assetVersionFor('public/assets/css/glpiacessivel.css')));
        $portalCss = Url::asset('public/assets/css/portal.css?v=' . rawurlencode(self::assetVersionFor('public/assets/css/portal.css')));
        $globalJs = Url::asset('public/assets/js/glpiacessivel.js?v=' . rawurlencode(self::assetVersionFor('public/assets/js/glpiacessivel.js')));
        $runtimeConfigJs = Url::plugin('front/runtime-config.js.php?v=' . rawurlencode(self::assetVersionFor('front/runtime-config.js.php')));
        $baseUrl = Url::plugin('front/faq.php');
        $loginUrl = (string) ($CFG_GLPI['root_doc'] ?? '') . '/front/login.php';
        $accessibilityMode = self::container()->configService()->getAccessibilityMode();

        require __DIR__ . '/../../../templates/portal/faq.php';
    }

    private static function isLogged(): bool
    {
        return isset($_SESSION['glpiID']) && (int) $_SESSION['glpiID'] > 0;
    }

    private static function nativeLoginUrl(): string
    {
        global $CFG_GLPI;

        $root = (string) ($CFG_GLPI['root_doc'] ?? '');
        $redirect = rawurlencode(Url::plugin('front/acessivel.php'));
        return $root . '/front/login.php?redirect=' . $redirect;
    }

    private static function renderAccessibleLogin(): void
    {
        global $CFG_GLPI;

        self::sendPublicSecurityHeaders();

        $_SESSION['glpicookietest'] = 'testcookie';

        $root = (string) ($CFG_GLPI['root_doc'] ?? '');
        $loginAction = $root . '/front/login.php';
        $redirect = rawurlencode(Url::plugin('front/acessivel.php'));
        $nativeLoginUrl = $loginAction . '?redirect=' . $redirect;
        $css = Url::asset('public/assets/css/glpiacessivel.css?v=' . rawurlencode(self::assetVersionFor('public/assets/css/glpiacessivel.css')));
        $portalCss = Url::asset('public/assets/css/portal.css?v=' . rawurlencode(self::assetVersionFor('public/assets/css/portal.css')));
        $globalJs = Url::asset('public/assets/js/glpiacessivel.js?v=' . rawurlencode(self::assetVersionFor('public/assets/js/glpiacessivel.js')));
        $runtimeConfigJs = Url::plugin('front/runtime-config.js.php?v=' . rawurlencode(self::assetVersionFor('front/runtime-config.js.php')));
        $csrfToken = method_exists('Session', 'getNewCSRFToken') ? \Session::getNewCSRFToken() : '';
        $faqUrl = Url::plugin('front/faq.php');
        $accessibilityMode = self::container()->configService()->getAccessibilityMode();
        $loginSource = LoginSourceDiscovery::discover($loginAction);
        $noAuto = isset($_REQUEST['noAUTO']) ? max(0, (int) $_REQUEST['noAUTO']) : 0;
        $loginFieldName = 'login_name';
        $passwordFieldName = 'login_password';
        $rememberFieldName = 'login_remember';

        if (!plugin_glpiacessivel_is_glpi11()) {
            $_SESSION['namfield'] = (string) ($_SESSION['namfield'] ?? 'login_name');
            $_SESSION['pwdfield'] = (string) ($_SESSION['pwdfield'] ?? 'login_password');
            $_SESSION['rmbfield'] = (string) ($_SESSION['rmbfield'] ?? 'login_remember');

            $loginFieldName = $_SESSION['namfield'];
            $passwordFieldName = $_SESSION['pwdfield'];
            $rememberFieldName = $_SESSION['rmbfield'];
        }

        require __DIR__ . '/../../../templates/portal/login.php';
    }

    private static function sendPublicSecurityHeaders(): void
    {
        if (headers_sent()) {
            return;
        }

        header('X-Frame-Options: DENY');
        header('X-Content-Type-Options: nosniff');
        header("Content-Security-Policy: frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
        header('Referrer-Policy: same-origin');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
    }

    private static function getCreateTicketUrl(): string
    {
        return Url::plugin('front/ticket.create.php');
    }
}
