<section class="glpiacessivel-section-head" aria-labelledby="cockpit-resumo">
  <p class="glpiacessivel-eyebrow">Cockpit operacional</p>
  <h2 id="cockpit-resumo">Indicadores do seu escopo de atendimento</h2>
  <p>Os numeros abaixo consideram apenas chamados que seu perfil pode visualizar.</p>
</section>

<h2 id="cockpit-kpis-title" class="glpiacessivel-sr-only">Indicadores principais</h2>
<section class="glpiacessivel-kpis" role="list" aria-labelledby="cockpit-kpis-title">
  <article role="listitem" class="glpiacessivel-kpi glpiacessivel-kpi-open">
    <h3 class="glpiacessivel-kpi-label">Abertos</h3>
    <strong><?= (int) $metrics['total_open'] ?></strong>
    <p>Chamados novos, em atendimento ou pendentes.</p>
  </article>
  <article role="listitem" class="glpiacessivel-kpi glpiacessivel-kpi-pending">
    <h3 class="glpiacessivel-kpi-label">Pendentes</h3>
    <strong><?= (int) $metrics['pending'] ?></strong>
    <p>Aguardam informacao, decisao ou evento externo.</p>
  </article>
  <article role="listitem" class="glpiacessivel-kpi glpiacessivel-kpi-solved">
    <h3 class="glpiacessivel-kpi-label">Solucionados hoje</h3>
    <strong><?= (int) $metrics['solved_today'] ?></strong>
    <p>Resolvidos na data atual dentro do seu escopo.</p>
  </article>
  <article role="listitem" class="glpiacessivel-kpi glpiacessivel-kpi-mine">
    <h3 class="glpiacessivel-kpi-label">Meus abertos</h3>
    <strong><?= (int) $metrics['mine_open'] ?></strong>
    <p>Chamados abertos vinculados ao seu usuario.</p>
  </article>
  <article role="listitem" class="glpiacessivel-kpi glpiacessivel-kpi-group">
    <h3 class="glpiacessivel-kpi-label">Grupo aberto</h3>
    <strong><?= (int) ($metrics['group_open'] ?? 0) ?></strong>
    <p>Chamados abertos vinculados aos seus grupos.</p>
  </article>
</section>

<h2 id="cockpit-reading-title" class="glpiacessivel-sr-only">Leitura dos indicadores</h2>
<section class="glpiacessivel-note-grid" aria-labelledby="cockpit-reading-title">
  <article class="glpiacessivel-note">
    <h3>Como ler estes numeros</h3>
    <p>Abertos reune os tickets que ainda exigem trabalho. Pendentes mostra fila aguardando retorno, informacao ou evento externo.</p>
  </article>
  <article class="glpiacessivel-note">
    <h3>Uso recomendado</h3>
    <p>Comece por pendentes e meus abertos. Isso reduz chamados esquecidos e facilita priorizacao diaria.</p>
  </article>
  <article class="glpiacessivel-note">
    <h3>Escopo respeitado</h3>
    <p>O cockpit aplica a mesma autorizacao por ticket usada nas demais telas do portal para evitar vazamento agregado.</p>
  </article>
</section>

<section class="glpiacessivel-action-band" aria-labelledby="cockpit-atalhos">
  <h2 id="cockpit-atalhos">Atalhos operacionais</h2>
  <div class="glpiacessivel-action-grid">
    <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php?scope=mine')) ?>">
      <strong>Ver meus chamados</strong>
      <span>Abra a fila em que voce participa diretamente.</span>
    </a>
    <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php?scope=group&group_by=group')) ?>">
      <strong>Ver chamados do grupo</strong>
      <span>Acompanhe a fila dos grupos em que voce atua.</span>
    </a>
    <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php?status=4')) ?>">
      <strong>Ver pendentes</strong>
      <span>Filtre rapidamente tickets aguardando retorno.</span>
    </a>
    <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/knowledge.php')) ?>">
      <strong>Consultar KB</strong>
      <span>Use a base de conhecimento para acelerar respostas.</span>
    </a>
  </div>
</section>
