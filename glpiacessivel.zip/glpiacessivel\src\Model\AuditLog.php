<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Model;

final class AuditLog extends \CommonDBTM
{
    public static function getTypeName($nb = 0): string
    {
        return __('Auditoria GLPI Acessivel', 'glpiacessivel');
    }

    public static function getTable($classname = null): string
    {
        return 'glpi_plugin_glpiacessivel_auditlogs';
    }
}
