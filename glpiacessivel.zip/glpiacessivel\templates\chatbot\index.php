<?php
$chatbotDisplayName = trim((string) ($chatbot_name ?? 'Assistente'));
$portalModuleStates = is_array($portal_module_states ?? null) ? $portal_module_states : [];
$showTicketsSuggestion = ($portalModuleStates['tickets'] ?? 'available') === 'available';
$showKnowledgeSuggestions = ($portalModuleStates['knowledge'] ?? 'available') === 'available';
$showTicketCreateSuggestion = ($portalModuleStates['ticket_create'] ?? 'available') === 'available';
$showAnySuggestion = $showTicketsSuggestion || $showKnowledgeSuggestions || $showTicketCreateSuggestion;
if ($chatbotDisplayName === '') {
    $chatbotDisplayName = 'Assistente';
}
$intent = (string) ($result['intent'] ?? '');
$data = is_array($result['data'] ?? null) ? $result['data'] : [];
$tickets = is_array($data['tickets'] ?? null) ? $data['tickets'] : [];
$ticket = is_array($data['ticket'] ?? null) ? $data['ticket'] : [];
$articles = is_array($data['articles'] ?? null) ? $data['articles'] : [];
$draft = is_array($data['draft'] ?? null) ? $data['draft'] : [];
$auditRows = is_array($data['rows'] ?? null) ? $data['rows'] : [];
$debug = is_array($result['debug'] ?? null) ? $result['debug'] : [];
$showDebug = !empty($show_debug);
$chatbotContext = is_array($context ?? null) ? $context : [];
$contextValid = array_key_exists('context_valid', get_defined_vars())
    ? !empty($context_valid)
    : ($chatbotContext === [] || !empty($chatbotContext['is_valid']));
$contextSummary = trim((string) ($chatbotContext['summary'] ?? 'Contexto GLPI nao informado.'));
$contextChangeTarget = !empty($glpiacessivelStandaloneLayout)
    ? '#glpiacessivel-context-entity'
    : glpiacessivel_url('front/acessivel.php');
$stage = (string) ($data['stage'] ?? '');
$isCollectingTicketDraft = $intent === 'ticket_criar_guiado'
    && in_array($stage, ['collect_problem', 'collect_missing'], true);
$shouldShowDraftDetails = $intent === 'ticket_criar_guiado'
    && $draft !== []
    && !$isCollectingTicketDraft
    && ($stage === 'ready_for_confirmation' || trim((string) ($draft['texto_gerado'] ?? '')) !== '');
$hasRenderableDetails = ($intent === 'mine_tickets' && $tickets !== [])
    || ($intent === 'ticket_lookup' && $ticket !== [])
    || ($intent === 'kb_recomendar_contextual' && $articles !== [])
    || $shouldShowDraftDetails
    || ($intent === 'auditoria_consulta' && $auditRows !== [])
    || ($showDebug && $data !== []);
$shouldShowResponseDetails = $enabled
    && is_array($result)
    && !$isCollectingTicketDraft
    && ($hasRenderableDetails || !empty($result['requires_handoff']) || !empty($result['next_steps']));
$chatbotVoiceLocale = (string) (($voice_config ?? [])['locale'] ?? 'pt-BR');
$chatbotVoiceStatus = sprintf(glpiacessivel_t('Voz pronta para %s.'), $chatbotVoiceLocale);
$chatbotJsI18n = [
    'voice_disable_auto' => sprintf(glpiacessivel_t('Desativar leitura automatica de %s'), $chatbotDisplayName),
    'voice_enable_auto' => sprintf(glpiacessivel_t('Ativar leitura automatica de %s'), $chatbotDisplayName),
    'voice_auto_enabled' => glpiacessivel_t('Ouvir Chatbot ativado'),
    'voice_auto_idle' => glpiacessivel_t('Ouvir Chatbot'),
    'voice_browser_native' => glpiacessivel_t('Fala configurada pelo sintetizador nativo do navegador. Ative Ouvir Chatbot para ler automaticamente as respostas.'),
    'voice_local_missing' => glpiacessivel_t('Arquivos locais de voz ausentes. Publique os arquivos no servidor para habilitar a voz.'),
    'voice_local_only' => glpiacessivel_t('Voz configurada somente com arquivos locais do servidor.'),
    'voice_external_fallback' => glpiacessivel_t('Voz operando com fallback externo. Publique os arquivos locais para producao.'),
    'voice_local_ready' => glpiacessivel_t('Voz pronta com arquivos locais priorizados no servidor.'),
    'voice_ready_locale' => glpiacessivel_t('Voz pronta para {locale}.'),
    'voice_script_url_missing' => glpiacessivel_t('URL de script nao informada.'),
    'voice_script_load_failed' => glpiacessivel_t('Falha ao carregar script: {url}'),
    'voice_disabled' => glpiacessivel_t('Voz desativada na configuracao do plugin.'),
    'voice_mic_vosklet' => glpiacessivel_t('Microfone ativo com Vosklet em {locale}.'),
    'voice_mic_native' => glpiacessivel_t('Microfone ativo no fallback nativo do navegador.'),
    'voice_speak_failed' => glpiacessivel_t('Nao foi possivel falar a resposta. {primaryError} Voz nativa: {fallbackMessage}'),
    'suggestion_filled' => glpiacessivel_t('Sugestao preenchida. Revise a pergunta e acione Enviar.'),
    'sending_message' => sprintf(glpiacessivel_t('Enviando mensagem para %s.'), $chatbotDisplayName),
    'voice_text_captured' => glpiacessivel_t('Texto capturado por voz: {text}'),
    'voice_partial_capture' => glpiacessivel_t('Captura parcial: {text}'),
    'voice_vosk_model_missing' => glpiacessivel_t('Modelo Vosklet pt-BR nao configurado.'),
    'voice_vosklet_not_loaded' => glpiacessivel_t('Vosklet nao carregado.'),
    'voice_recognition_unsupported' => glpiacessivel_t('Reconhecimento de voz nao suportado no navegador.'),
    'voice_recognition_failed' => glpiacessivel_t('Falha no reconhecimento de voz: {reason}'),
    'voice_capture_already_active' => glpiacessivel_t('Captura de voz ja estava ativa.'),
    'voice_capture_stopped' => glpiacessivel_t('Captura de voz encerrada.'),
    'stt_disabled' => glpiacessivel_t('Motor de STT desativado.'),
    'stt_invalid' => glpiacessivel_t('Motor de STT invalido: {engine}'),
    'piper_module_url_missing' => glpiacessivel_t('URL do modulo Piper nao configurada.'),
    'piper_local_files_incomplete' => glpiacessivel_t('piper_dependency_unavailable: arquivos locais incompletos'),
    'piper_predict_missing' => glpiacessivel_t('Modulo Piper carregado sem funcao predict.'),
    'chatbot_prompt_required' => glpiacessivel_t('Digite uma pergunta antes de enviar.'),
    'chatbot_http_redirected' => glpiacessivel_t(' redirecionado'),
    'chatbot_response_region_missing' => glpiacessivel_t('Resposta do chatbot sem regiao atualizavel.'),
    'chatbot_message_loaded' => glpiacessivel_t('Mensagem enviada e resposta carregada.'),
    'chatbot_unknown_error' => glpiacessivel_t('erro nao identificado'),
    'chatbot_security_title' => glpiacessivel_t('Sessao ou token invalidos'),
    'chatbot_processing_title' => glpiacessivel_t('Falha no processamento'),
    'chatbot_security_message' => glpiacessivel_t('Sua sessao pode ter expirado ou o token de seguranca pode ter vencido. Recarregue a pagina e tente novamente.'),
    'chatbot_processing_message' => glpiacessivel_t('Nao consegui processar essa mensagem agora. A pergunta foi preservada no historico da conversa; tente reenviar ou reformular.'),
    'chatbot_security_bot_message' => glpiacessivel_t('Nao consegui enviar essa mensagem agora. Recarregue a pagina e tente novamente.'),
    'chatbot_processing_bot_message' => glpiacessivel_t('Nao consegui processar essa mensagem agora. Tente reformular ou use uma das opcoes abaixo.'),
    'chatbot_security_send_failed' => glpiacessivel_t('Falha de seguranca no envio da mensagem.'),
    'chatbot_processing_failed' => glpiacessivel_t('Falha no processamento da mensagem.'),
];
?>
<section class="glpiacessivel-card" aria-labelledby="chatbot-title">
  <div class="glpiacessivel-chatbot-shell">
    <div class="glpiacessivel-chatbot-agent">
      <span class="glpiacessivel-chatbot-avatar" aria-hidden="true">
        <svg viewBox="0 0 48 48" width="32" height="32" focusable="false">
          <path d="M12 18a10 10 0 0 1 10-10h4a10 10 0 0 1 10 10v6a10 10 0 0 1-10 10h-5l-8 6v-7.2A10 10 0 0 1 12 24v-6Z" fill="currentColor" opacity=".92" />
          <circle cx="20" cy="21" r="2" fill="#fff" />
          <circle cx="28" cy="21" r="2" fill="#fff" />
          <path d="M19 27c2.8 2 7.2 2 10 0" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" />
        </svg>
      </span>
      <div>
        <h2 id="chatbot-title"><?= glpiacessivel_e($chatbotDisplayName) ?></h2>
        <p><?= glpiacessivel_e(glpiacessivel_t('Assistente operacional do portal acessivel')) ?></p>
      </div>
    </div>

    <aside
      class="glpiacessivel-chatbot-context <?= $contextValid ? 'glpiacessivel-alert-success' : 'glpiacessivel-alert-error' ?>"
      role="<?= $contextValid ? 'status' : 'alert' ?>"
      aria-live="<?= $contextValid ? 'polite' : 'assertive' ?>"
    >
      <p><strong><?= glpiacessivel_e(glpiacessivel_t('Contexto do GLPI')) ?>:</strong> <?= glpiacessivel_e($contextSummary) ?></p>
      <?php if ($contextValid): ?>
        <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('As respostas do chatbot usam esta entidade, este perfil e as permissoes atuais.')) ?></p>
      <?php else: ?>
        <p><?= glpiacessivel_e(glpiacessivel_t('Confirme entidade e perfil antes de consultar, abrir ou alterar chamados.')) ?></p>
      <?php endif; ?>
      <p>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($contextChangeTarget) ?>">
          <?= glpiacessivel_e(glpiacessivel_t('Alterar entidade/perfil')) ?>
        </a>
      </p>
    </aside>

    <div class="glpiacessivel-chatbot-thread" role="log" aria-live="polite" aria-relevant="additions text" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Mensagens do chatbot')) ?>">
      <article class="glpiacessivel-chatbot-message glpiacessivel-chatbot-message-agent">
        <span class="glpiacessivel-sr-only"><?= glpiacessivel_e(sprintf(glpiacessivel_t('Mensagem de %s:'), $chatbotDisplayName)) ?></span>
        <p>
          <?= glpiacessivel_e(sprintf(glpiacessivel_t('Ola, sou %s. Voce pode me pedir ajuda para consultar chamados, entender prazos, procurar orientacoes na base de conhecimento, montar um novo chamado e apoiar acoes operacionais permitidas pelo seu perfil.'), $chatbotDisplayName)) ?>
        </p>
      </article>
      <?php if (trim((string) ($prompt ?? '')) !== ''): ?>
        <article class="glpiacessivel-chatbot-message glpiacessivel-chatbot-message-user">
          <span class="glpiacessivel-sr-only"><?= glpiacessivel_e(glpiacessivel_t('Sua pergunta:')) ?></span>
          <p><?= glpiacessivel_e((string) $prompt) ?></p>
        </article>
      <?php endif; ?>
      <?php if ($enabled && is_array($result) && trim((string) ($result['answer'] ?? '')) !== ''): ?>
        <article
          class="glpiacessivel-chatbot-message glpiacessivel-chatbot-message-answer"
          data-chatbot-answer="<?= glpiacessivel_e((string) ($result['answer'] ?? '')) ?>"
          data-chatbot-speech-text="<?= glpiacessivel_e((string) ($result['speech_text'] ?? $result['answer'] ?? '')) ?>"
          tabindex="-1"
        >
          <span class="glpiacessivel-sr-only"><?= glpiacessivel_e(sprintf(glpiacessivel_t('Resposta de %s:'), $chatbotDisplayName)) ?></span>
          <p><?= glpiacessivel_e((string) ($result['answer'] ?? '')) ?></p>
          <span class="glpiacessivel-chatbot-answer-badge" aria-hidden="true"><?= glpiacessivel_e(sprintf(glpiacessivel_t('Respondido por %s'), $chatbotDisplayName)) ?></span>
        </article>
      <?php endif; ?>
    </div>

    <div id="glpiacessivel-chatbot-response-region" aria-live="polite" aria-atomic="false">
<?php if ($shouldShowResponseDetails): ?>
<section
  class="glpiacessivel-card glpiacessivel-chatbot-answer glpiacessivel-chatbot-answer-inline"
  aria-labelledby="chatbot-resposta"
>
  <h2 id="chatbot-resposta"><?= glpiacessivel_e(glpiacessivel_t('Detalhes da resposta')) ?></h2>
  <?php if (!empty($result['requires_handoff'])): ?>
    <p class="glpiacessivel-alert-error" role="status" aria-live="assertive">
      <?= glpiacessivel_e(glpiacessivel_t('Fluxo encaminhado para atendimento individualizado.')) ?>
    </p>
  <?php endif; ?>

  <?php if ($intent === 'mine_tickets' && $tickets !== []): ?>
    <div class="glpiacessivel-table-wrap">
      <table class="glpiacessivel-chatbot-table">
        <caption class="glpiacessivel-sr-only"><?= glpiacessivel_e(glpiacessivel_t('Lista resumida dos seus chamados')) ?></caption>
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Titulo')) ?></th>
            <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Status')) ?></th>
            <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Prioridade')) ?></th>
            <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Ultima atualizacao')) ?></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($tickets as $row): ?>
            <tr>
              <td>
                <a href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php?id=' . (int) ($row['id'] ?? 0))) ?>">
                  #<?= glpiacessivel_e((string) ($row['id'] ?? '')) ?>
                </a>
              </td>
              <td><?= glpiacessivel_e((string) ($row['name'] ?? '')) ?></td>
              <td><?= glpiacessivel_e((string) ($row['status'] ?? '')) ?></td>
              <td><?= glpiacessivel_e((string) ($row['priority'] ?? '')) ?></td>
              <td><?= glpiacessivel_e((string) ($row['date_mod'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php elseif ($intent === 'ticket_lookup' && $ticket !== []): ?>
    <div class="glpiacessivel-definition-grid">
      <p><strong>ID</strong><span>#<?= glpiacessivel_e((string) ($ticket['id'] ?? '')) ?></span></p>
      <p><strong><?= glpiacessivel_e(glpiacessivel_t('Status')) ?></strong><span><?= glpiacessivel_e((string) ($ticket['status'] ?? '')) ?></span></p>
      <p><strong><?= glpiacessivel_e(glpiacessivel_t('Prioridade')) ?></strong><span><?= glpiacessivel_e((string) ($ticket['priority'] ?? '')) ?></span></p>
      <p><strong><?= glpiacessivel_e(glpiacessivel_t('Urgencia')) ?></strong><span><?= glpiacessivel_e((string) ($ticket['urgency'] ?? '')) ?></span></p>
      <p><strong><?= glpiacessivel_e(glpiacessivel_t('Impacto')) ?></strong><span><?= glpiacessivel_e((string) ($ticket['impact'] ?? '')) ?></span></p>
      <p><strong><?= glpiacessivel_e(glpiacessivel_t('Ultima atualizacao')) ?></strong><span><?= glpiacessivel_e((string) ($ticket['date_mod'] ?? '')) ?></span></p>
      <p class="glpiacessivel-chatbot-full"><strong><?= glpiacessivel_e(glpiacessivel_t('Titulo')) ?></strong><span><?= glpiacessivel_e((string) ($ticket['name'] ?? '')) ?></span></p>
    </div>
    <p>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php?id=' . (int) ($ticket['id'] ?? 0))) ?>">
        <?= glpiacessivel_e(glpiacessivel_t('Abrir tela detalhada do chamado')) ?>
      </a>
    </p>
  <?php elseif ($intent === 'kb_recomendar_contextual' && $articles !== []): ?>
    <div class="glpiacessivel-chatbot-grid">
      <?php foreach ($articles as $article): ?>
        <?php $articleId = (int) ($article['id'] ?? 0); ?>
        <article class="glpiacessivel-chatbot-card">
          <h3><?= glpiacessivel_e((string) ($article['name'] ?? '')) ?></h3>
          <?php if (!empty($article['playbook_name'])): ?>
            <p class="glpiacessivel-help-text">
              <strong><?= glpiacessivel_e(glpiacessivel_t('Roteiro')) ?>:</strong> <?= glpiacessivel_e((string) $article['playbook_name']) ?>
            </p>
          <?php endif; ?>
          <?php if (!empty($article['category'])): ?>
            <p class="glpiacessivel-help-text"><strong><?= glpiacessivel_e(glpiacessivel_t('Categoria')) ?>:</strong> <?= glpiacessivel_e((string) $article['category']) ?></p>
          <?php endif; ?>
          <?php if (!empty($article['summary'])): ?>
            <p><?= glpiacessivel_e((string) $article['summary']) ?></p>
          <?php endif; ?>
          <?php if ($articleId > 0): ?>
            <a href="<?= glpiacessivel_e(glpiacessivel_url('front/knowledge.php?article=' . $articleId)) ?>">
              <?= glpiacessivel_e(glpiacessivel_t('Ler artigo completo')) ?>
            </a>
          <?php else: ?>
            <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Artigo associado sem ID cadastrado.')) ?></p>
          <?php endif; ?>
        </article>
      <?php endforeach; ?>
    </div>
  <?php elseif ($shouldShowDraftDetails): ?>
    <div class="glpiacessivel-definition-grid">
      <?php foreach ($draft as $key => $value): ?>
        <?php if ($key === 'categorias_sugeridas' && is_array($value)): ?>
          <p class="glpiacessivel-chatbot-full">
            <strong><?= glpiacessivel_e(glpiacessivel_t('Categorias sugeridas')) ?></strong>
            <span>
              <?php if ($value === []): ?>
                Nenhuma sugestão encontrada.
              <?php else: ?>
                <?php foreach ($value as $index => $category): ?>
                  <?= $index > 0 ? '<br />' : '' ?>
                  <?= glpiacessivel_e((string) ($category['id'] ?? '')) ?> - <?= glpiacessivel_e((string) ($category['label'] ?? '')) ?>
                <?php endforeach; ?>
              <?php endif; ?>
            </span>
          </p>
        <?php elseif ($key === 'texto_gerado' && trim((string) $value) !== ''): ?>
          <div class="glpiacessivel-chatbot-full glpiacessivel-chatbot-draft">
            <strong><?= glpiacessivel_e(glpiacessivel_t('Texto gerado para o chamado')) ?></strong>
            <pre class="glpiacessivel-pre"><?= glpiacessivel_e((string) $value) ?></pre>
          </div>
        <?php else: ?>
          <p class="<?= in_array($key, ['descricao'], true) ? 'glpiacessivel-chatbot-full' : '' ?>">
            <strong><?= glpiacessivel_e(ucfirst(str_replace('_', ' ', (string) $key))) ?></strong>
            <span><?= glpiacessivel_e((string) $value) ?></span>
          </p>
        <?php endif; ?>
      <?php endforeach; ?>
    </div>
  <?php elseif ($intent === 'auditoria_consulta' && $auditRows !== []): ?>
    <div class="glpiacessivel-table-wrap">
      <table class="glpiacessivel-chatbot-table">
        <caption class="glpiacessivel-sr-only"><?= glpiacessivel_e(glpiacessivel_t('Registros recentes de auditoria')) ?></caption>
        <thead>
          <tr>
            <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Data')) ?></th>
            <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Evento')) ?></th>
            <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Ticket')) ?></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($auditRows as $row): ?>
            <tr>
              <td><?= glpiacessivel_e((string) ($row['date_creation'] ?? $row['updated_at'] ?? '')) ?></td>
              <td><?= glpiacessivel_e((string) ($row['event_name'] ?? $row['action'] ?? '')) ?></td>
              <td><?= glpiacessivel_e((string) ($row['tickets_id'] ?? '-')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php elseif ($showDebug && $data !== []): ?>
    <div class="glpiacessivel-definition-grid">
      <?php foreach ($data as $key => $value): ?>
        <?php if (is_scalar($value) || $value === null): ?>
          <p>
            <strong><?= glpiacessivel_e(ucfirst(str_replace('_', ' ', (string) $key))) ?></strong>
            <span><?= glpiacessivel_e((string) $value) ?></span>
          </p>
        <?php endif; ?>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($result['next_steps']) && is_array($result['next_steps'])): ?>
    <h3><?= glpiacessivel_e(glpiacessivel_t('Proximos passos')) ?></h3>
    <ol>
      <?php foreach ($result['next_steps'] as $step): ?>
        <li><?= glpiacessivel_e((string) $step) ?></li>
      <?php endforeach; ?>
    </ol>
  <?php endif; ?>

  <?php if ($showDebug): ?>
  <details class="glpiacessivel-chatbot-debug">
    <summary><?= glpiacessivel_e(glpiacessivel_t('Diagnostico tecnico')) ?></summary>
    <p class="glpiacessivel-help-text">
      <?= glpiacessivel_e(glpiacessivel_t('Intent')) ?>: <strong><?= glpiacessivel_e((string) ($result['intent'] ?? '')) ?></strong>
      | Confiança: <strong><?= glpiacessivel_e((string) ($result['confidence'] ?? '')) ?></strong>
      | Versão: <strong><?= glpiacessivel_e((string) ($result['intent_version'] ?? '')) ?></strong>
    </p>
    <?php if ($debug !== []): ?>
      <h3><?= glpiacessivel_e(glpiacessivel_t('Deteccao de intencao')) ?></h3>
      <pre class="glpiacessivel-pre"><?= glpiacessivel_e(json_encode($debug, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?></pre>
    <?php endif; ?>
    <?php if (is_array($voice_config ?? null)): ?>
      <h3><?= glpiacessivel_e(glpiacessivel_t('Voz no navegador')) ?></h3>
      <pre class="glpiacessivel-pre"><?= glpiacessivel_e(json_encode($voice_config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?></pre>
    <?php endif; ?>
    <?php if ($data !== []): ?>
      <h3><?= glpiacessivel_e(glpiacessivel_t('Dados da resposta')) ?></h3>
      <pre class="glpiacessivel-pre"><?= glpiacessivel_e(json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) ?></pre>
    <?php endif; ?>
  </details>
  <?php endif; ?>
</section>
<?php endif; ?>
</div>

    <?php if ($showAnySuggestion): ?>
    <nav class="glpiacessivel-chatbot-suggestions" aria-label="<?= glpiacessivel_e(sprintf(glpiacessivel_t('Sugestoes de perguntas para %s'), $chatbotDisplayName)) ?>">
      <?php if ($showTicketsSuggestion): ?>
      <button type="button" data-chatbot-prompt="meus chamados">
        <span class="glpiacessivel-chatbot-suggestion-icon" aria-hidden="true">#</span>
        <span><strong><?= glpiacessivel_e(glpiacessivel_t('Meus chamados')) ?></strong><small><?= glpiacessivel_e(glpiacessivel_t('Ver situacao e proximos passos')) ?></small></span>
      </button>
      <?php endif; ?>
      <?php if ($showKnowledgeSuggestions): ?>
      <button type="button" data-chatbot-prompt="tenho um problema">
        <span class="glpiacessivel-chatbot-suggestion-icon" aria-hidden="true">?</span>
        <span><strong><?= glpiacessivel_e(glpiacessivel_t('Resolver problema')) ?></strong><small><?= glpiacessivel_e(glpiacessivel_t('Buscar orientacao na base')) ?></small></span>
      </button>
      <?php endif; ?>
      <?php if ($showTicketCreateSuggestion): ?>
      <button type="button" data-chatbot-prompt="abrir chamado">
        <span class="glpiacessivel-chatbot-suggestion-icon" aria-hidden="true">+</span>
        <span><strong><?= glpiacessivel_e(glpiacessivel_t('Abrir chamado')) ?></strong><small><?= glpiacessivel_e(glpiacessivel_t('Montar solicitacao guiada')) ?></small></span>
      </button>
      <?php endif; ?>
      <?php if ($showKnowledgeSuggestions): ?>
      <button type="button" data-chatbot-prompt="consultar base de conhecimento">
        <span class="glpiacessivel-chatbot-suggestion-icon" aria-hidden="true">i</span>
        <span><strong><?= glpiacessivel_e(glpiacessivel_t('Consultar FAQ')) ?></strong><small><?= glpiacessivel_e(glpiacessivel_t('Encontrar artigos e respostas')) ?></small></span>
      </button>
      <?php endif; ?>
    </nav>
    <?php endif; ?>
  </div>

  <?php if (!$enabled): ?>
    <p role="status" aria-live="polite"><?= glpiacessivel_e(glpiacessivel_t('Chatbot desativado pela configuracao do plugin.')) ?></p>
  <?php elseif (!$contextValid): ?>
    <section class="glpiacessivel-alert-error" role="alert" aria-live="assertive" tabindex="-1">
      <h2><?= glpiacessivel_e(glpiacessivel_t('Contexto necessario')) ?></h2>
      <p><?= glpiacessivel_e(glpiacessivel_t('O chatbot fica bloqueado ate que uma entidade e um perfil validos estejam ativos.')) ?></p>
      <p><?= glpiacessivel_e(glpiacessivel_t('Use o seletor de contexto desta tela e clique em Aplicar. Depois envie sua pergunta novamente.')) ?></p>
    </section>
  <?php else: ?>
  <form class="glpiacessivel-chatbot-compose" method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/chatbot.php')) ?>" data-glpiacessivel-chatbot-consult-form>
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" data-glpiacessivel-csrf-token />
    <label for="prompt"><?= glpiacessivel_e(glpiacessivel_t('Pergunta')) ?></label>
    <textarea id="prompt" name="prompt" required aria-describedby="chatbot-examples"><?= glpiacessivel_e($prompt ?? '') ?></textarea>
    <p id="chatbot-examples" class="glpiacessivel-help-text">
      <?= glpiacessivel_e(glpiacessivel_t('Exemplos: "meus chamados", "ticket 123", "tenho um problema na VPN", "abrir chamado" ou "registrar acompanhamento no ticket 123".')) ?>
    </p>

    <div class="glpiacessivel-actions" style="margin-top:0.75rem;">
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-chatbot-submit"><?= glpiacessivel_e(glpiacessivel_t('Enviar')) ?></button>
      <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary glpiacessivel-voice-control" id="glpiacessivel-voice-listen" aria-pressed="false">
        <span class="glpiacessivel-voice-pulse" aria-hidden="true"></span>
        <span><?= glpiacessivel_e(glpiacessivel_t('Ouvir minha voz')) ?></span>
      </button>
      <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" id="glpiacessivel-voice-stop-listen"><?= glpiacessivel_e(glpiacessivel_t('Parar captura')) ?></button>
      <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary glpiacessivel-voice-control" id="glpiacessivel-voice-speak" aria-pressed="false">
        <span class="glpiacessivel-voice-pulse" aria-hidden="true"></span>
        <span><?= glpiacessivel_e(glpiacessivel_t('Ouvir Chatbot')) ?></span>
      </button>
      <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" id="glpiacessivel-voice-stop-speak"><?= glpiacessivel_e(glpiacessivel_t('Parar fala')) ?></button>
    </div>
    <p id="glpiacessivel-voice-status" class="glpiacessivel-help-text" role="status" aria-live="polite"><?= glpiacessivel_e($chatbotVoiceStatus) ?></p>
  </form>
  <?php endif; ?>
</section>

<?php if ($enabled): ?>
<script id="glpiacessivel-chatbot-voice-config" type="application/json"><?= (string) json_encode($voice_config ?? [], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
<script>
  (function () {
    var configNode = document.getElementById('glpiacessivel-chatbot-voice-config');
    if (!configNode) {
      return;
    }

    var listenButton = document.getElementById('glpiacessivel-voice-listen');
    var stopListenButton = document.getElementById('glpiacessivel-voice-stop-listen');
    var speakButton = document.getElementById('glpiacessivel-voice-speak');
    var stopSpeakButton = document.getElementById('glpiacessivel-voice-stop-speak');
    var promptField = document.getElementById('prompt');
    var answerContainer = document.querySelector('[data-chatbot-answer]');
    var statusField = document.getElementById('glpiacessivel-voice-status');

    if (!promptField || !listenButton || !stopListenButton || !speakButton || !stopSpeakButton || !statusField) {
      return;
    }

    var voiceConfig = {};
    var chatbotI18n = <?= glpiacessivel_json_for_script($chatbotJsI18n) ?>;
    try {
      voiceConfig = JSON.parse(configNode.textContent || '{}');
    } catch (error) {
      voiceConfig = {};
    }

    var state = {
      listening: false,
      speaking: false,
      autoSpeak: false,
      submitting: false,
      recognition: null,
      piperModule: null,
      piperAudio: null,
      vosk: {
        audioContext: null,
        stream: null,
        micNode: null,
        transferer: null,
        recognizer: null,
      },
    };

    function chatbotText(key, params) {
      var template = chatbotI18n && chatbotI18n[key] ? String(chatbotI18n[key]) : key;
      var values = params || {};
      return template.replace(/\{([a-zA-Z0-9_]+)\}/g, function (match, name) {
        return Object.prototype.hasOwnProperty.call(values, name) ? String(values[name]) : match;
      });
    }

    function setStatus(message) {
      statusField.textContent = message;
    }

    function setSpeakingState(active) {
      state.speaking = Boolean(active);
      speakButton.classList.toggle('is-speaking', state.speaking);
      speakButton.setAttribute('aria-busy', state.speaking ? 'true' : 'false');
    }

    function setAutoSpeakState(active) {
      state.autoSpeak = Boolean(active);
      speakButton.classList.toggle('is-auto-enabled', state.autoSpeak);
      speakButton.setAttribute('aria-pressed', state.autoSpeak ? 'true' : 'false');
      speakButton.setAttribute('aria-label', state.autoSpeak ? chatbotText('voice_disable_auto') : chatbotText('voice_enable_auto'));
      var label = speakButton.querySelector('span:last-child');
      if (label) {
        label.textContent = state.autoSpeak ? chatbotText('voice_auto_enabled') : chatbotText('voice_auto_idle');
      }
    }

    function setListeningState(active) {
      state.listening = Boolean(active);
      listenButton.classList.toggle('is-listening', state.listening);
      listenButton.setAttribute('aria-pressed', state.listening ? 'true' : 'false');
      listenButton.setAttribute('aria-busy', state.listening ? 'true' : 'false');
    }

    function describeSpeechError(reason) {
      if (reason === 'synthesis-failed') {
        return chatbotText('speech_synthesis_failed');
      }

      if (reason === 'interrupted' || reason === 'canceled') {
        return chatbotText('speech_interrupted');
      }

      return chatbotText('speech_native_failed', { reason: reason || chatbotText('speech_unknown_reason') });
    }

    function isPiperDependencyError(error) {
      var message = error && error.message ? error.message : String(error || '');
      return /onnxruntime-web|Failed to resolve module specifier|piper_dependency_unavailable|Failed to fetch dynamically imported module|Importing a module script failed/i.test(message);
    }

    function describePiperError(error) {
      var message = error && error.message ? error.message : String(error || '');
      if (isPiperDependencyError(error)) {
        return chatbotText('piper_unavailable');
      }

      if (/Failed to fetch|NetworkError|Load failed/i.test(message)) {
        return chatbotText('piper_load_failed');
      }

      return message || chatbotText('piper_unknown');
    }

    function splitSpeechText(text) {
      var cleanText = String(text || '').replace(/\s+/g, ' ').trim();
      if (!cleanText) {
        return [];
      }

      var sentences = cleanText.match(/[^.!?;:]+[.!?;:]?/g) || [cleanText];
      var chunks = [];
      var current = '';

      sentences.forEach(function (sentence) {
        var next = sentence.trim();
        if (!next) {
          return;
        }

        if ((current + ' ' + next).trim().length <= 180) {
          current = (current + ' ' + next).trim();
          return;
        }

        if (current) {
          chunks.push(current);
          current = '';
        }

        while (next.length > 180) {
          chunks.push(next.slice(0, 180));
          next = next.slice(180).trim();
        }

        current = next;
      });

      if (current) {
        chunks.push(current);
      }

      return chunks;
    }

    function refreshAnswerContainer() {
      var answers = document.querySelectorAll('[data-chatbot-answer]');
      answerContainer = answers.length ? answers[answers.length - 1] : null;
    }

    function getChatbotThread() {
      return document.querySelector('.glpiacessivel-chatbot-thread');
    }

    function scrollChatbotThread() {
      var thread = getChatbotThread();
      if (!thread) {
        return;
      }
      thread.scrollTop = thread.scrollHeight;
    }

    function appendChatbotTextMessage(type, text) {
      var thread = getChatbotThread();
      if (!thread || !text) {
        return null;
      }

      var article = document.createElement('article');
      article.className = 'glpiacessivel-chatbot-message glpiacessivel-chatbot-message-' + type;
      if (type === 'answer') {
        article.setAttribute('data-chatbot-answer', text);
        article.setAttribute('data-chatbot-speech-text', text);
        article.setAttribute('tabindex', '-1');
      }

      var label = document.createElement('span');
      label.className = 'glpiacessivel-sr-only';
      label.textContent = type === 'user' ? chatbotText('message_user') : chatbotText('message_agent');

      var paragraph = document.createElement('p');
      paragraph.textContent = text;

      article.appendChild(label);
      article.appendChild(paragraph);
      thread.appendChild(article);
      scrollChatbotThread();
      return article;
    }

    function appendLatestAnswerFromParsed(parsed) {
      var thread = getChatbotThread();
      if (!thread || !parsed) {
        return null;
      }

      var parsedAnswers = parsed.querySelectorAll('[data-chatbot-answer]');
      var nextAnswer = parsedAnswers.length ? parsedAnswers[parsedAnswers.length - 1] : null;
      if (!nextAnswer) {
        return null;
      }

      var imported = document.importNode(nextAnswer, true);
      thread.appendChild(imported);
      scrollChatbotThread();
      return imported;
    }

    function describeVoiceSource() {
      if (voiceConfig.ttsEngine === 'browser_native') {
        return chatbotText('voice_browser_native');
      }

      var localOnlyMissing = hasMissingLocalVoiceDependency();
      if (voiceConfig.assetMode === 'local_only') {
        if (localOnlyMissing) {
          return chatbotText('voice_local_missing');
        }

        return chatbotText('voice_local_only');
      }

      if (
        voiceConfig.sttScriptSource === 'external_fallback'
        || voiceConfig.sttModelSource === 'external_fallback'
        || voiceConfig.ttsScriptSource === 'external_fallback'
        || voiceConfig.ttsOnnxRuntimeSource === 'external_fallback'
        || voiceConfig.ttsOnnxWasmBaseSource === 'external_fallback'
        || voiceConfig.ttsPiperWasmSource === 'external_fallback'
        || voiceConfig.ttsPiperDataSource === 'external_fallback'
      ) {
        return chatbotText('voice_external_fallback');
      }

      if (
        voiceConfig.sttScriptSource === 'local'
        || voiceConfig.sttModelSource === 'local'
        || voiceConfig.ttsScriptSource === 'local'
        || voiceConfig.ttsOnnxRuntimeSource === 'local'
        || voiceConfig.ttsOnnxWasmBaseSource === 'local'
        || voiceConfig.ttsPiperWasmSource === 'local'
        || voiceConfig.ttsPiperDataSource === 'local'
        || voiceConfig.ttsVoiceModelSource === 'local'
        || voiceConfig.ttsVoiceConfigSource === 'local'
      ) {
        return chatbotText('voice_local_ready');
      }

      return chatbotText('voice_ready_locale', { locale: (voiceConfig.locale || 'pt-BR') });
    }

    function hasMissingLocalVoiceDependency() {
      var requiredSources = [];
      if (voiceConfig.sttEngine === 'vosklet') {
        requiredSources.push('sttScriptSource', 'sttModelSource');
      }

      if (voiceConfig.ttsEngine === 'piper_wasm') {
        requiredSources.push(
          'ttsScriptSource',
          'ttsOnnxRuntimeSource',
          'ttsOnnxWasmBaseSource',
          'ttsPiperWasmSource',
          'ttsPiperDataSource',
          'ttsVoiceModelSource',
          'ttsVoiceConfigSource'
        );
      }

      return requiredSources.some(function (key) {
        return voiceConfig[key] === 'missing_local';
      });
    }

    function loadScript(url) {
      return new Promise(function (resolve, reject) {
        if (!url) {
          reject(new Error(chatbotText('voice_script_url_missing')));
          return;
        }

        var existing = document.querySelector('script[data-chatbot-src="' + url.replace(/"/g, '\\"') + '"]');
        if (existing) {
          if (existing.dataset.loaded === 'true') {
            resolve();
            return;
          }

          existing.addEventListener('load', function () { resolve(); }, { once: true });
          existing.addEventListener('error', function () { reject(new Error(chatbotText('voice_script_load_failed', { url: url }))); }, { once: true });
          return;
        }

        var script = document.createElement('script');
        script.src = url;
        script.async = true;
        script.defer = true;
        script.dataset.chatbotSrc = url;
        script.onload = function () {
          script.dataset.loaded = 'true';
          resolve();
        };
        script.onerror = function () {
          reject(new Error(chatbotText('voice_script_load_failed', { url: url })));
        };
        document.head.appendChild(script);
      });
    }

    setStatus(describeVoiceSource());

    function waitForBrowserVoices(timeoutMs) {
      return new Promise(function (resolve) {
        if (!window.speechSynthesis || typeof window.speechSynthesis.getVoices !== 'function') {
          resolve([]);
          return;
        }

        var done = false;
        var finish = function (voices) {
          if (done) {
            return;
          }
          done = true;
          if (typeof window.speechSynthesis.onvoiceschanged === 'function') {
            window.speechSynthesis.onvoiceschanged = null;
          }
          resolve(Array.isArray(voices) ? voices : window.speechSynthesis.getVoices());
        };

        var voices = window.speechSynthesis.getVoices();
        if (voices && voices.length > 0) {
          finish(voices);
          return;
        }

        var timer = window.setTimeout(function () {
          finish(window.speechSynthesis.getVoices());
        }, timeoutMs || 1200);

        window.speechSynthesis.onvoiceschanged = function () {
          window.clearTimeout(timer);
          finish(window.speechSynthesis.getVoices());
        };
      });
    }

    function chooseBrowserVoice(voices) {
      if (!Array.isArray(voices) || voices.length === 0) {
        return null;
      }

      var targetLocale = String(voiceConfig.locale || 'pt-BR').toLowerCase();
      var localePrefix = targetLocale.split('-')[0];
      var preferred = voices.find(function (voice) {
        return String(voice.lang || '').toLowerCase() === targetLocale;
      });

      if (preferred) {
        return preferred;
      }

      preferred = voices.find(function (voice) {
        return String(voice.lang || '').toLowerCase().indexOf(localePrefix) === 0;
      });

      if (preferred) {
        return preferred;
      }

      preferred = voices.find(function (voice) {
        return /portugu/i.test(String(voice.name || '') + ' ' + String(voice.lang || ''));
      });

      return preferred || voices[0] || null;
    }

    function buildBrowserVoiceCandidates(voices, preferredVoice) {
      var candidates = [];
      var seen = {};
      var add = function (voice) {
        var key = voice ? String(voice.voiceURI || voice.name || voice.lang || 'voice') : 'default';
        if (seen[key]) {
          return;
        }
        seen[key] = true;
        candidates.push(voice || null);
      };

      add(preferredVoice || null);
      add(null);

      if (Array.isArray(voices)) {
        var targetLocale = String(voiceConfig.locale || 'pt-BR').toLowerCase();
        var localePrefix = targetLocale.split('-')[0];
        voices.forEach(function (voice) {
          if (String(voice.lang || '').toLowerCase() === targetLocale) {
            add(voice);
          }
        });
        voices.forEach(function (voice) {
          if (String(voice.lang || '').toLowerCase().indexOf(localePrefix) === 0) {
            add(voice);
          }
        });
        voices.forEach(function (voice) {
          if (/portugu/i.test(String(voice.name || '') + ' ' + String(voice.lang || ''))) {
            add(voice);
          }
        });
        voices.forEach(add);
      }

      return candidates;
    }

    function wait(ms) {
      return new Promise(function (resolve) {
        window.setTimeout(resolve, ms);
      });
    }

    function createCompatibleAudioContext(AudioContextClass) {
      var attempts = [
        function () { return new AudioContextClass({ latencyHint: 'interactive' }); },
        function () { return new AudioContextClass(); }
      ];
      var lastError = null;

      for (var i = 0; i < attempts.length; i += 1) {
        try {
          return attempts[i]();
        } catch (error) {
          lastError = error;
        }
      }

      throw lastError || new Error(chatbotText('audio_context_failed'));
    }

    function extractSpeechText(payload) {
      if (!payload) {
        return '';
      }

      if (typeof payload === 'string') {
        return payload;
      }

      if (typeof payload.text === 'string') {
        return payload.text;
      }

      if (payload.result && typeof payload.result.text === 'string') {
        return payload.result.text;
      }

      if (payload.partial && typeof payload.partial === 'string') {
        return payload.partial;
      }

      if (payload.result && typeof payload.result.partial === 'string') {
        return payload.result.partial;
      }

      return '';
    }

    async function startVosklet() {
      var AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) {
        throw new Error(chatbotText('audio_context_unavailable'));
      }

      if (!voiceConfig.sttModelUrl) {
        throw new Error(chatbotText('voice_vosk_model_missing'));
      }

      await loadScript(voiceConfig.sttScriptUrl || '');
      if (typeof window.loadVosklet !== 'function') {
        throw new Error(chatbotText('voice_vosklet_not_loaded'));
      }

      state.vosk.audioContext = createCompatibleAudioContext(AudioContextClass);
      if (state.vosk.audioContext && typeof state.vosk.audioContext.resume === 'function') {
        await state.vosk.audioContext.resume();
      }
      state.vosk.stream = await navigator.mediaDevices.getUserMedia({
        video: false,
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          channelCount: 1,
        },
      });
      state.vosk.micNode = state.vosk.audioContext.createMediaStreamSource(state.vosk.stream);

      var module = await window.loadVosklet();
      var model = await module.createModel(
        voiceConfig.sttModelUrl,
        voiceConfig.sttModelLabel || 'Portugues (Brasil)',
        voiceConfig.sttModelCacheId || 'glpi-vosk-ptbr'
      );
      state.vosk.recognizer = await module.createRecognizer(model, state.vosk.audioContext.sampleRate);
      state.vosk.transferer = await module.createTransferer(state.vosk.audioContext, 128 * 150);

      state.vosk.recognizer.addEventListener('result', function (event) {
        var text = extractSpeechText(event.detail || {});
        if (text) {
          promptField.value = text;
          setStatus(chatbotText('voice_text_captured', { text: text }));
        }
      });

      state.vosk.recognizer.addEventListener('partialResult', function (event) {
        var text = extractSpeechText(event.detail || {});
        if (text) {
          setStatus(chatbotText('voice_partial_capture', { text: text }));
        }
      });

      state.vosk.transferer.port.onmessage = function (event) {
        if (state.vosk.recognizer && typeof state.vosk.recognizer.acceptWaveform === 'function') {
          state.vosk.recognizer.acceptWaveform(event.data);
        }
      };

      state.vosk.micNode.connect(state.vosk.transferer);
      setListeningState(true);
      setStatus(chatbotText('voice_mic_vosklet', { locale: (voiceConfig.locale || 'pt-BR') }));
    }

    function stopVosklet() {
      if (state.vosk.stream) {
        state.vosk.stream.getTracks().forEach(function (track) { track.stop(); });
      }
      if (state.vosk.micNode && typeof state.vosk.micNode.disconnect === 'function') {
        state.vosk.micNode.disconnect();
      }
      if (state.vosk.transferer && typeof state.vosk.transferer.disconnect === 'function') {
        state.vosk.transferer.disconnect();
      }
      if (state.vosk.audioContext && typeof state.vosk.audioContext.close === 'function') {
        state.vosk.audioContext.close();
      }

      state.vosk.audioContext = null;
      state.vosk.stream = null;
      state.vosk.micNode = null;
      state.vosk.transferer = null;
      state.vosk.recognizer = null;
    }

    function startWebSpeechFallback() {
      var SpeechRecognitionClass = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SpeechRecognitionClass) {
        throw new Error(chatbotText('voice_recognition_unsupported'));
      }

      state.recognition = new SpeechRecognitionClass();
      state.recognition.lang = voiceConfig.locale || 'pt-BR';
      state.recognition.interimResults = true;
      state.recognition.maxAlternatives = 1;

      state.recognition.onresult = function (event) {
        var finalText = '';
        for (var i = 0; i < event.results.length; i += 1) {
          finalText += event.results[i][0].transcript;
        }

        finalText = finalText.trim();
        if (finalText) {
          promptField.value = finalText;
          setStatus(chatbotText('voice_text_captured', { text: finalText }));
        }
      };

      state.recognition.onerror = function (event) {
        setStatus(chatbotText('voice_recognition_failed', { reason: event.error || chatbotText('speech_unknown_reason') }));
        setListeningState(false);
      };

      state.recognition.onend = function () {
        setListeningState(false);
      };

      state.recognition.start();
      setListeningState(true);
      setStatus(chatbotText('voice_mic_native'));
    }

    async function startListening() {
      if (!voiceConfig.enabled) {
        setStatus(chatbotText('voice_disabled'));
        return;
      }

      if (state.listening) {
        setStatus(chatbotText('voice_capture_already_active'));
        return;
      }

      try {
        if (voiceConfig.sttEngine === 'vosklet') {
          await startVosklet();
          return;
        }

        if (voiceConfig.sttEngine === 'none') {
          throw new Error(chatbotText('stt_disabled'));
        }

        throw new Error(chatbotText('stt_invalid', { engine: voiceConfig.sttEngine }));
      } catch (error) {
        stopVosklet();
        try {
          startWebSpeechFallback();
          setStatus(chatbotText('vosklet_unavailable'));
        } catch (fallbackError) {
          setStatus(chatbotText('voice_capture_failed', { message: error && error.message ? error.message : String(error) }));
        }
      }
    }

    function stopListening() {
      if (state.recognition && typeof state.recognition.stop === 'function') {
        state.recognition.stop();
      }

      stopVosklet();
      state.recognition = null;
      setListeningState(false);
      setStatus(chatbotText('voice_capture_stopped'));
    }

    async function loadPiperModule() {
      if (state.piperModule) {
        return state.piperModule;
      }

      if (!voiceConfig.ttsScriptUrl) {
        throw new Error(chatbotText('piper_module_url_missing'));
      }

      state.piperModule = await import(voiceConfig.ttsScriptUrl);
      return state.piperModule;
    }

    async function speakWithPiper(text) {
      try {
        if (voiceConfig.assetMode === 'local_only' && hasMissingLocalVoiceDependency()) {
          throw new Error(chatbotText('piper_local_files_incomplete'));
        }

        var piper = await loadPiperModule();
        if (!piper || typeof piper.predict !== 'function') {
          throw new Error(chatbotText('piper_predict_missing'));
        }

        var wavBlob = await piper.predict({
          text: text,
          voiceId: voiceConfig.ttsVoiceId || 'pt_BR-faber-medium',
          onnxRuntimeUrl: voiceConfig.ttsOnnxRuntimeUrl || '',
          wasmPaths: {
            onnxWasm: voiceConfig.ttsOnnxWasmBaseUrl || '',
            piperData: voiceConfig.ttsPiperDataUrl || '',
            piperWasm: voiceConfig.ttsPiperWasmUrl || '',
          },
          voiceModelUrl: voiceConfig.ttsVoiceModelUrl || '',
          voiceConfigUrl: voiceConfig.ttsVoiceConfigUrl || '',
        });

        state.piperAudio = new Audio();
        state.piperAudio.src = URL.createObjectURL(wavBlob);
        setSpeakingState(true);
        setStatus(chatbotText('piper_speaking', { voice: voiceConfig.ttsVoiceId || 'pt_BR-faber-medium' }));

        await new Promise(function (resolve, reject) {
          state.piperAudio.onended = function () {
            setSpeakingState(false);
            setStatus(chatbotText('voice_read_complete'));
            resolve();
          };
          state.piperAudio.onerror = function () {
            setSpeakingState(false);
            reject(new Error(chatbotText('audio_play_failed')));
          };

          var playPromise = state.piperAudio.play();
          if (playPromise && typeof playPromise.catch === 'function') {
            playPromise.catch(function (error) {
              setSpeakingState(false);
              reject(error);
            });
          }
        });
      } catch (error) {
        if (isPiperDependencyError(error)) {
          state.piperModule = null;
          throw new Error('piper_dependency_unavailable');
        }

        throw error;
      }
    }

    function speakBrowserChunk(text, selectedVoice) {
      return new Promise(function (resolve, reject) {
        var utterance = new window.SpeechSynthesisUtterance(text);
        utterance.lang = voiceConfig.locale || 'pt-BR';
        if (selectedVoice) {
          utterance.voice = selectedVoice;
          if (selectedVoice.lang) {
            utterance.lang = selectedVoice.lang;
          }
        }
        utterance.rate = 1;
        utterance.pitch = 1;
        utterance.onend = function () {
          resolve();
        };
        utterance.onerror = function (event) {
          var reason = event && (event.error || event.name || event.type) ? (event.error || event.name || event.type) : chatbotText('speech_reason_unknown_masculine');
          if (reason === 'interrupted' || reason === 'canceled') {
            resolve();
            return;
          }
          reject(new Error(reason));
        };
        window.speechSynthesis.speak(utterance);
        if (window.speechSynthesis && typeof window.speechSynthesis.resume === 'function') {
          window.speechSynthesis.resume();
        }
      });
    }

    async function speakBrowserChunks(chunks, selectedVoice) {
      for (var i = 0; i < chunks.length; i += 1) {
        if (!state.speaking) {
          return;
        }
        await speakBrowserChunk(chunks[i], selectedVoice);
      }
    }

    async function speakWithBrowser(text) {
      if (!window.speechSynthesis || typeof window.SpeechSynthesisUtterance !== 'function') {
        throw new Error(chatbotText('native_synthesis_unavailable'));
      }

      var voices = await waitForBrowserVoices(1500);
      var selectedVoice = chooseBrowserVoice(voices);
      var voiceCandidates = buildBrowserVoiceCandidates(voices, selectedVoice);
      var chunks = splitSpeechText(text);
      if (chunks.length === 0) {
        throw new Error(chatbotText('empty_text_for_speech'));
      }

      window.speechSynthesis.cancel();
      setSpeakingState(true);
      setStatus(chatbotText('browser_speaking', { voice: selectedVoice ? ' (' + (selectedVoice.name || selectedVoice.lang || chatbotText('default_voice')) + ')' : '' }));

      var lastError = null;
      try {
        for (var i = 0; i < voiceCandidates.length; i += 1) {
          var candidate = voiceCandidates[i];
          try {
            window.speechSynthesis.cancel();
            await wait(120);
            if (!state.speaking) {
              return;
            }
            await speakBrowserChunks(chunks, candidate);
            lastError = null;
            break;
          } catch (candidateError) {
            lastError = candidateError;
          }
        }

        if (lastError) {
          throw lastError;
        }

        if (!state.speaking) {
          return;
        }

        setSpeakingState(false);
        setStatus(state.autoSpeak ? chatbotText('voice_read_complete_auto') : chatbotText('voice_read_complete'));
      } catch (error) {
        var reason = error && error.message ? error.message : String(error);
        setSpeakingState(false);
        setStatus(describeSpeechError(reason));
        throw error;
      }
    }

    async function speakAnswer() {
      if (!voiceConfig.enabled) {
        setStatus(chatbotText('voice_disabled'));
        return;
      }

      var text = '';
      if (answerContainer && answerContainer.dataset) {
        text = String(answerContainer.dataset.chatbotSpeechText || answerContainer.dataset.chatbotAnswer || '').trim();
      }

      if (!text) {
        setStatus(chatbotText('no_answer_to_read'));
        return;
      }

      try {
        if (voiceConfig.ttsEngine === 'browser_native') {
          await speakWithBrowser(text);
          return;
        }

        if (voiceConfig.ttsEngine === 'piper_wasm') {
          await speakWithPiper(text);
          return;
        }

        if (voiceConfig.ttsEngine === 'none') {
          throw new Error(chatbotText('tts_disabled'));
        }

        throw new Error(chatbotText('tts_invalid', { engine: voiceConfig.ttsEngine }));
      } catch (error) {
        if (voiceConfig.ttsEngine !== 'piper_wasm') {
          setSpeakingState(false);
          var directMessage = error && error.message ? error.message : String(error);
          setStatus(chatbotText('speak_answer_failed', { message: describeSpeechError(directMessage) }));
          return;
        }

        try {
          await speakWithBrowser(text);
        } catch (fallbackError) {
          setSpeakingState(false);
          var primaryError = describePiperError(error);
          var fallbackMessage = fallbackError && fallbackError.message ? fallbackError.message : String(fallbackError);
          if (fallbackMessage === 'synthesis-failed') {
            setStatus(chatbotText('piper_and_browser_failed', { primaryError: primaryError }));
          } else {
            setStatus(chatbotText('voice_speak_failed', { primaryError: primaryError, fallbackMessage: describeSpeechError(fallbackMessage) }));
          }
        }
      }
    }

    function stopSpeaking() {
      if (state.piperAudio) {
        state.piperAudio.pause();
        state.piperAudio.currentTime = 0;
      }
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }

      state.piperAudio = null;
      setSpeakingState(false);
      setStatus(state.autoSpeak ? chatbotText('voice_interrupted_auto') : chatbotText('speech_interrupted'));
    }

    function toggleAutoSpeak() {
      if (state.autoSpeak) {
        setAutoSpeakState(false);
        stopSpeaking();
        setStatus(chatbotText('voice_auto_disabled'));
        return;
      }

      setAutoSpeakState(true);
      setStatus(chatbotText('voice_auto_enabled_next'));
      speakAnswer();
    }

    setAutoSpeakState(false);

    listenButton.addEventListener('click', function () {
      startListening();
    });

    stopListenButton.addEventListener('click', function () {
      stopListening();
    });

    speakButton.addEventListener('click', function () {
      toggleAutoSpeak();
    });

    stopSpeakButton.addEventListener('click', function () {
      stopSpeaking();
    });

    var consultForm = document.querySelector('[data-glpiacessivel-chatbot-consult-form]');
    if (consultForm) {
      var promptField = consultForm.querySelector('#prompt');
      var suggestionButtons = document.querySelectorAll('[data-chatbot-prompt]');
      suggestionButtons.forEach(function (button) {
        button.addEventListener('click', function () {
          if (!promptField) {
            return;
          }
          promptField.value = String(button.getAttribute('data-chatbot-prompt') || '');
          promptField.focus();
          setStatus(chatbotText('suggestion_filled'));
        });
      });

      consultForm.addEventListener('submit', async function (event) {
        if (!window.fetch || !window.DOMParser || !window.URLSearchParams || !window.FormData) {
          state.submitting = true;
          return;
        }

        event.preventDefault();
        var submittedPrompt = promptField ? String(promptField.value || '').trim() : '';
        if (!submittedPrompt) {
          if (promptField) {
            promptField.focus();
          }
          setStatus(chatbotText('chatbot_prompt_required'));
          return;
        }

        state.submitting = true;
        if (state.recognition && typeof state.recognition.stop === 'function') {
          state.recognition.stop();
        }
        stopVosklet();
        if (state.piperAudio) {
          state.piperAudio.pause();
          state.piperAudio.currentTime = 0;
        }
        if (window.speechSynthesis) {
          window.speechSynthesis.cancel();
        }
        setSpeakingState(false);
        setStatus(chatbotText('sending_message'));

        var tokenInput = consultForm.querySelector('[data-glpiacessivel-csrf-token]');
        var formData = new FormData(consultForm);
        var body = new URLSearchParams();
        formData.forEach(function (value, key) {
          body.append(key, String(value || ''));
        });
        appendChatbotTextMessage('user', submittedPrompt);
        if (promptField) {
          promptField.value = '';
        }

        try {
          var csrfValue = tokenInput ? String(tokenInput.value || '') : '';
          var response = await fetch(consultForm.action, {
            method: 'POST',
            body: body,
            credentials: 'same-origin',
            headers: {
              'Accept': 'text/html',
              'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
              'X-Requested-With': 'XMLHttpRequest',
              'X-GLPI-CSRF-TOKEN': csrfValue
            }
          });

          var html = await response.text();
          var parsed = new DOMParser().parseFromString(html, 'text/html');
          var nextToken = parsed.querySelector('[data-glpiacessivel-csrf-token]');
          if (tokenInput && nextToken && nextToken.value) {
            tokenInput.value = nextToken.value;
          }

          if (!response.ok) {
            var httpError = new Error('HTTP ' + response.status + (response.redirected ? chatbotText('chatbot_http_redirected') : ''));
            httpError.status = response.status;
            throw httpError;
          }

          var nextRegion = parsed.getElementById('glpiacessivel-chatbot-response-region');
          var currentRegion = document.getElementById('glpiacessivel-chatbot-response-region');
          if (!nextRegion || !currentRegion) {
            throw new Error(chatbotText('chatbot_response_region_missing'));
          }

          currentRegion.innerHTML = nextRegion.innerHTML;
          var answer = appendLatestAnswerFromParsed(parsed);
          if (tokenInput && nextToken) {
            tokenInput.value = nextToken.value || tokenInput.value;
          }
          refreshAnswerContainer();

          if (promptField && typeof promptField.focus === 'function') {
            promptField.focus();
          }
          setStatus(chatbotText('chatbot_message_loaded'));
          if (state.autoSpeak) {
            speakAnswer();
          }
        } catch (error) {
          var currentRegion = document.getElementById('glpiacessivel-chatbot-response-region');
          var diagnostic = error && error.message ? String(error.message) : chatbotText('chatbot_unknown_error');
          if (window.console && typeof window.console.warn === 'function') {
            window.console.warn('[glpiacessivel] chatbot request failed:', diagnostic);
          }
          var statusCode = error && typeof error.status !== 'undefined' ? Number(error.status) : 0;
          var isSecurityError = statusCode === 401 || statusCode === 403 || statusCode === 419;
          var alertTitle = isSecurityError ? chatbotText('chatbot_security_title') : chatbotText('chatbot_processing_title');
          var alertMessage = isSecurityError
            ? chatbotText('chatbot_security_message')
            : chatbotText('chatbot_processing_message');
          var botMessage = isSecurityError
            ? chatbotText('chatbot_security_bot_message')
            : chatbotText('chatbot_processing_bot_message');
          if (currentRegion) {
            currentRegion.textContent = '';
            var alert = document.createElement('section');
            alert.className = 'glpiacessivel-card glpiacessivel-alert glpiacessivel-alert-error';
            alert.setAttribute('role', 'alert');
            alert.setAttribute('tabindex', '-1');
            var alertHeading = document.createElement('h2');
            alertHeading.textContent = alertTitle;
            var alertParagraph = document.createElement('p');
            alertParagraph.textContent = alertMessage;
            alert.appendChild(alertHeading);
            alert.appendChild(alertParagraph);
            currentRegion.appendChild(alert);
            if (typeof alert.focus === 'function') {
              alert.focus();
            }
          }
          appendChatbotTextMessage('answer', botMessage);
          setStatus(isSecurityError ? chatbotText('chatbot_security_send_failed') : chatbotText('chatbot_processing_failed'));
        } finally {
          state.submitting = false;
        }
      });
    }

    window.addEventListener('beforeunload', function () {
      stopListening();
      if (!state.submitting) {
        stopSpeaking();
      }
    });
  })();
</script>
<?php endif; ?>

