<?php
$overview = is_array($overview ?? null) ? $overview : [];
$filters = is_array($overview['filters'] ?? null) ? $overview['filters'] : [];
$result = is_array($overview['result'] ?? null) ? $overview['result'] : ['items' => [], 'total' => 0, 'page' => 1, 'pages' => 1, 'page_size' => 10];
$article = is_array($overview['article'] ?? null) ? $overview['article'] : null;
$categories = is_array($overview['categories'] ?? null) ? $overview['categories'] : [];
$homeLists = is_array($overview['home_lists'] ?? null) ? $overview['home_lists'] : [];

$query = (string) ($filters['query'] ?? '');
$categoryId = (int) ($filters['category_id'] ?? 0);
$publicOnly = !empty($filters['public_only']);
$page = max(1, (int) ($result['page'] ?? 1));
$pages = max(1, (int) ($result['pages'] ?? 1));
$total = max(0, (int) ($result['total'] ?? 0));
$pageSize = max(1, (int) ($result['page_size'] ?? 10));
$items = is_array($result['items'] ?? null) ? $result['items'] : [];
$hasSearch = ($query !== '' || $categoryId > 0);
$showHome = !$hasSearch && $article === null;
$baseUrl = glpiacessivel_url('front/knowledge.php');
$homeBaseParams = $publicOnly ? ['public' => '1'] : [];

if (!function_exists('glpiacessivel_kb_query')) {
    function glpiacessivel_kb_query(array $changes = []): string
    {
        global $query, $categoryId, $publicOnly, $page;

        $params = [
            'q' => $query,
            'category' => $categoryId > 0 ? $categoryId : null,
            'public' => $publicOnly ? '1' : null,
            'page' => $page > 1 ? $page : null,
        ];

        foreach ($changes as $key => $value) {
            $params[$key] = $value;
        }

        $params = array_filter(
            $params,
            static fn($value): bool => !($value === null || $value === '' || $value === false)
        );

        return http_build_query($params);
    }
}

if (!function_exists('glpiacessivel_kb_mark')) {
    function glpiacessivel_kb_mark(string $text, string $queryString): string
    {
        $escaped = glpiacessivel_e($text);
        $terms = array_values(array_filter(preg_split('/\s+/u', trim($queryString)) ?: []));
        foreach ($terms as $term) {
            if (mb_strlen($term) < 2) {
                continue;
            }

            $escapedTerm = preg_quote(glpiacessivel_e($term), '/');
            $escaped = preg_replace('/(' . $escapedTerm . ')/iu', '<mark>$1</mark>', $escaped) ?? $escaped;
        }

        return nl2br($escaped);
    }
}

if (!function_exists('glpiacessivel_kb_home_list')) {
    function glpiacessivel_kb_home_list(array $items, string $emptyLabel, string $baseUrl, array $baseParams = []): void
    {
        if ($items === []) {
            echo '<li>' . glpiacessivel_e($emptyLabel) . '</li>';
            return;
        }

        foreach ($items as $item) {
            $query = http_build_query(array_merge($baseParams, ['article' => (int) ($item['id'] ?? 0)]));
            $href = $baseUrl . ($query !== '' ? '?' . $query : '');
            echo '<li>';
            echo '<a href="' . glpiacessivel_e($href) . '">' . glpiacessivel_e((string) ($item['assunto'] ?? 'Artigo')) . '</a>';
            echo '<small>' . glpiacessivel_e((string) ($item['category'] ?? 'Sem categoria')) . '</small>';
            echo '</li>';
        }
    }
}

$currentStart = $total === 0 ? 0 : (($page - 1) * $pageSize) + 1;
$currentEnd = $total === 0 ? 0 : min($total, $page * $pageSize);
?>

<section class="glpiacessivel-section-head" aria-labelledby="kb-titulo">
  <p class="glpiacessivel-eyebrow">Consulta orientada</p>
  <h2 id="kb-titulo">Base de conhecimento</h2>
  <p>Organizacao inspirada no portal acessivel de referencia, agora executando diretamente no GLPI com seus perfis, entidades e regras nativas.</p>
</section>

<section class="glpiacessivel-card glpiacessivel-kb-card" aria-labelledby="kb-busca-titulo">
  <div class="glpiacessivel-kb-header">
    <div>
      <h3 id="kb-busca-titulo">Pesquisar artigos e FAQ</h3>
      <p class="glpiacessivel-help-text">Use a busca por assunto ou selecione uma categoria. O leitor completo aparece na mesma tela.</p>
    </div>
    <div class="glpiacessivel-kb-header-actions">
      <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" id="glpiacessivel-kb-toggle-a11y" aria-expanded="false" aria-controls="glpiacessivel-kb-a11y">
        Acessibilidade
      </button>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($baseUrl . ($publicOnly ? '?public=1' : '')) ?>">
        Atualizar
      </a>
    </div>
  </div>

  <form method="get" action="<?= glpiacessivel_e($baseUrl) ?>" class="glpiacessivel-kb-filters" role="search" aria-label="Pesquisar artigos e FAQ">
    <div class="glpiacessivel-field glpiacessivel-kb-field-search">
      <label for="q">Busca por assunto ou conteudo</label>
      <input id="q" type="text" name="q" value="<?= glpiacessivel_e($query) ?>" placeholder="Ex: certificado digital" />
    </div>

    <div class="glpiacessivel-field glpiacessivel-kb-field-category">
      <label for="category">Categoria</label>
      <select id="category" name="category">
        <option value="0">Todas as categorias</option>
        <?php foreach ($categories as $category): ?>
          <option value="<?= (int) $category['id'] ?>"<?= ((int) $category['id'] === $categoryId) ? ' selected' : '' ?>>
            <?= glpiacessivel_e((string) $category['label']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="glpiacessivel-kb-filter-options">
      <label class="glpiacessivel-kb-check glpiacessivel-kb-field-public">
        <input type="checkbox" name="public" value="1"<?= $publicOnly ? ' checked' : '' ?> />
        Somente FAQ publica
      </label>
    </div>

    <div class="glpiacessivel-kb-filter-actions">
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary">Buscar</button>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($baseUrl) ?>">Limpar</a>
    </div>
  </form>

  <div id="glpiacessivel-kb-a11y" class="glpiacessivel-kb-a11y" hidden>
    <label class="glpiacessivel-kb-check">
      <input type="checkbox" id="glpiacessivel-kb-compact" checked />
      Layout compacto
    </label>
    <label class="glpiacessivel-kb-check">
      <input type="checkbox" id="glpiacessivel-kb-highlight" checked />
      Destacar termo pesquisado
    </label>
  </div>
</section>

<section class="glpiacessivel-card glpiacessivel-kb-article" aria-labelledby="kb-artigo-titulo">
  <div class="glpiacessivel-kb-article-head">
    <h3 id="kb-artigo-titulo">Artigo completo</h3>
    <div class="glpiacessivel-kb-article-actions">
      <?php if ($article !== null): ?>
        <?php if ($hasSearch): ?>
          <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($baseUrl . '?' . glpiacessivel_kb_query(['article' => null])) ?>">
            Voltar para resultados
          </a>
        <?php endif; ?>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($baseUrl . ($publicOnly ? '?public=1' : '')) ?>">
          Voltar para listas iniciais
        </a>
      <?php endif; ?>
    </div>
  </div>

  <?php if ($article === null): ?>
    <p class="glpiacessivel-empty">Selecione um resultado e use a acao <strong>Abrir artigo completo</strong> para carregar os detalhes nesta area.</p>
  <?php else: ?>
    <article class="glpiacessivel-kb-article-body" tabindex="-1">
      <header class="glpiacessivel-kb-article-meta">
        <div>
          <h4><?= glpiacessivel_e((string) ($article['assunto'] ?? 'Artigo')) ?></h4>
          <p class="glpiacessivel-help-text">
            Categoria: <?= glpiacessivel_e((string) ($article['category'] ?? 'Sem categoria')) ?>
            <?php if (!empty($article['is_faq'])): ?>
              <span class="glpiacessivel-meta-chip">FAQ</span>
            <?php endif; ?>
          </p>
        </div>
        <p class="glpiacessivel-help-text">
          Atualizado em <?= glpiacessivel_e((string) ($article['date_mod'] ?? '')) ?>
        </p>
      </header>
      <div class="glpiacessivel-content glpiacessivel-kb-reader">
        <?= (string) ($article['body_html'] ?? '') ?>
      </div>
      <dl class="glpiacessivel-kb-article-grid">
        <div>
          <dt>Elementos associados</dt>
          <dd><?= glpiacessivel_e((string) ($article['associados'] ?? 'Nao informado')) ?></dd>
        </div>
        <div>
          <dt>Criado em</dt>
          <dd><?= glpiacessivel_e((string) ($article['date_creation'] ?? '')) ?></dd>
        </div>
      </dl>
    </article>
  <?php endif; ?>
</section>

<?php if ($showHome): ?>
  <section class="glpiacessivel-card glpiacessivel-kb-home" aria-labelledby="kb-home-title">
    <h3 id="kb-home-title" class="glpiacessivel-sr-only">Listas iniciais da base de conhecimento</h3>
    <div class="glpiacessivel-kb-home-grid">
      <section>
        <h4>Entradas recentes</h4>
        <ul class="glpiacessivel-kb-home-list">
          <?php glpiacessivel_kb_home_list((array) ($homeLists['recentes'] ?? []), 'Nenhuma entrada recente disponivel.', $baseUrl, $homeBaseParams); ?>
        </ul>
      </section>
      <section>
        <h4>Ultimas entradas atualizadas</h4>
        <ul class="glpiacessivel-kb-home-list">
          <?php glpiacessivel_kb_home_list((array) ($homeLists['atualizadas'] ?? []), 'Nenhuma entrada atualizada disponivel.', $baseUrl, $homeBaseParams); ?>
        </ul>
      </section>
      <section>
        <h4>Questoes mais populares</h4>
        <ul class="glpiacessivel-kb-home-list">
          <?php glpiacessivel_kb_home_list((array) ($homeLists['populares'] ?? []), 'Nenhuma questao popular disponivel.', $baseUrl, $homeBaseParams); ?>
        </ul>
      </section>
    </div>
  </section>
<?php endif; ?>

<?php if ($hasSearch): ?>
  <section class="glpiacessivel-card glpiacessivel-kb-results" aria-labelledby="kb-resultados-titulo">
    <div class="glpiacessivel-kb-results-head">
      <div>
        <h3 id="kb-resultados-titulo">Resultados</h3>
        <p class="glpiacessivel-help-text">Mostrando <strong><?= (int) $currentStart ?>-<?= (int) $currentEnd ?></strong> de <strong><?= (int) $total ?></strong> artigos.</p>
      </div>
      <?php if ($publicOnly): ?>
        <span class="glpiacessivel-meta-chip">Somente FAQ publica</span>
      <?php endif; ?>
    </div>

    <div class="glpiacessivel-table-wrap">
      <table class="glpiacessivel-kb-table">
        <caption class="glpiacessivel-sr-only">Tabela de resultados da base de conhecimento</caption>
        <thead>
          <tr>
            <th scope="col">ASSUNTO</th>
            <th scope="col" class="glpiacessivel-kb-col-category">CATEGORIA</th>
            <th scope="col" class="glpiacessivel-kb-col-associated">ELEMENTOS ASSOCIADOS</th>
            <th scope="col" class="glpiacessivel-kb-col-actions">ACOES</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($items === []): ?>
            <tr>
              <td colspan="4">Nenhum artigo encontrado para os filtros informados.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($items as $item): ?>
              <?php $articleQuery = glpiacessivel_kb_query(['article' => (int) ($item['id'] ?? 0)]); ?>
              <tr>
                <td class="glpiacessivel-kb-cell-subject">
                  <strong><?= glpiacessivel_e((string) ($item['assunto'] ?? 'Artigo')) ?></strong>
                  <div class="glpiacessivel-help-text"><?= glpiacessivel_kb_mark((string) ($item['summary'] ?? ''), $query) ?></div>
                </td>
                <td><?= glpiacessivel_e((string) ($item['category'] ?? 'Sem categoria')) ?></td>
                <td><?= glpiacessivel_e((string) ($item['associados'] ?? 'Nao informado')) ?></td>
                <td>
                  <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($baseUrl . ($articleQuery !== '' ? '?' . $articleQuery : '')) ?>">
                    Abrir artigo completo
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <?php if ($pages > 1): ?>
      <nav class="glpiacessivel-pagination glpiacessivel-kb-pagination" aria-label="Paginacao da base de conhecimento">
        <?php if ($page > 1): ?>
          <a href="<?= glpiacessivel_e($baseUrl . '?' . glpiacessivel_kb_query(['page' => $page - 1])) ?>">&laquo; Anterior</a>
        <?php else: ?>
          <span aria-disabled="true">&laquo; Anterior</span>
        <?php endif; ?>

        <span aria-current="page">Pagina <?= (int) $page ?> de <?= (int) $pages ?></span>

        <?php if ($page < $pages): ?>
          <a href="<?= glpiacessivel_e($baseUrl . '?' . glpiacessivel_kb_query(['page' => $page + 1])) ?>">Proxima &raquo;</a>
        <?php else: ?>
          <span aria-disabled="true">Proxima &raquo;</span>
        <?php endif; ?>
      </nav>
    <?php endif; ?>
  </section>
<?php endif; ?>

<script>
  (function () {
    var storageKey = 'glpiacessivel-kb-preferences-v1';
    var toggleButton = document.getElementById('glpiacessivel-kb-toggle-a11y');
    var panel = document.getElementById('glpiacessivel-kb-a11y');
    var compact = document.getElementById('glpiacessivel-kb-compact');
    var highlight = document.getElementById('glpiacessivel-kb-highlight');
    var root = document.getElementById('conteudo-principal');

    if (!toggleButton || !panel || !compact || !highlight || !root) {
      return;
    }

    function readPrefs() {
      try {
        var raw = window.localStorage.getItem(storageKey);
        if (!raw) {
          return { compact: true, highlight: true };
        }
        var parsed = JSON.parse(raw);
        return {
          compact: parsed.compact !== false,
          highlight: parsed.highlight !== false
        };
      } catch (error) {
        return { compact: true, highlight: true };
      }
    }

    function writePrefs(state) {
      window.localStorage.setItem(storageKey, JSON.stringify(state));
    }

    function applyPrefs(state) {
      compact.checked = state.compact;
      highlight.checked = state.highlight;
      root.classList.toggle('glpiacessivel-kb-compact-mode', state.compact);
      root.classList.toggle('glpiacessivel-kb-hide-highlight', !state.highlight);
    }

    var state = readPrefs();
    applyPrefs(state);

    toggleButton.addEventListener('click', function () {
      var expanded = toggleButton.getAttribute('aria-expanded') === 'true';
      toggleButton.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      panel.hidden = expanded;
    });

    function onChange() {
      state.compact = compact.checked;
      state.highlight = highlight.checked;
      applyPrefs(state);
      writePrefs(state);
    }

    compact.addEventListener('change', onChange);
    highlight.addEventListener('change', onChange);
  })();
</script>
