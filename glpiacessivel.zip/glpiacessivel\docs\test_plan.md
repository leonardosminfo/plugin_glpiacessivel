# Plano de Testes

## 1. Unitários
- `TicketPolicy`: transições válidas/ inválidas.
- `PiiMasker`: máscara de email/telefone/texto.
- `InputSanitizer`: int/text/enum.

## 2. Integração
- `TicketService` com `TicketRepository` em base de homolog.
- Criação de followup/task/solution.
- Mudança de status com política ITIL.
- Registro de auditoria e PII reveal.

## 3. Regressão funcional
- Listagem: todos/meus, filtros, paginação e ordenação.
- Detalhe de ticket + timeline completa.
- Cockpit com métricas consistentes.
- FAQ por palavra-chave.
- Chatbot para intents principais.

## 4. Acessibilidade
- Navegação completa por teclado.
- Leitura de feedback por NVDA.
- Contraste AA em componentes críticos.
- Reflow em 320px sem perda funcional.

## 5. Compatibilidade GLPI 10/11
- Instalar/habilitar/desinstalar em GLPI 10.x e 11.x.
- Verificar hooks, menus, direitos e ações ITIL.

## 6. Segurança
- CSRF: bloqueio de POST sem token.
- Autorização: negar ações sem direito.
- Log de auditoria para ações sensíveis.

## Evidências esperadas
- Capturas de tela por fluxo.
- Logs de auditoria por ação.
- Relatório de testes automatizados e manuais.

