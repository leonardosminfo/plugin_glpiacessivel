<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\DynamicForm;

use GlpiPlugin\Glpiacessivel\Support\ValidationErrorNormalizer;

final class DynamicFormSubmissionResult
{
    /**
     * @param int[] $createdTicketIds
     * @param array<int, mixed> $errors
     * @param string[] $warnings
     * @param array<string, mixed> $metadata
     */
    public function __construct(
        private bool $success,
        private array $createdTicketIds = [],
        private string $redirectUrl = '',
        array $errors = [],
        private array $warnings = [],
        private array $metadata = []
    ) {
        $this->errors = ValidationErrorNormalizer::normalize($errors);
    }

    /** @var array<int, array{field:string, code:string, message:string}> */
    private array $errors = [];

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'success' => $this->success,
            'created_ticket_ids' => $this->createdTicketIds,
            'redirect_url' => $this->redirectUrl,
            'errors' => $this->errors,
            'warnings' => $this->warnings,
            'metadata' => $this->metadata,
        ];
    }
}
