# Intellectual property release checklist


This checklist records release controls. It is not a legal opinion and does
not replace review of employment, service or institutional agreements by a
qualified lawyer.

## Before changing repository visibility or publishing a release

- confirm that the original project was not assigned by an employment,
  statutory, research, service or funding agreement;
- preserve the complete Git history and identify every contributor;
- require DCO sign-off for external contributions;
- confirm that every bundled dependency has version, origin, license and
  corresponding-source information in `THIRD_PARTY_NOTICES.md`;
- verify that offline voice models and runtimes with incomplete provenance are
  not tracked or distributed;
- inspect screenshots and samples for personal data, confidential information
  and third-party branding;
- use only the project's own visual identity and retain the independence and
  trademark disclaimer;
- generate and preserve the release ZIP, source revision, tag and SHA-256;
- consider registering a stable source hash with the Brazilian INPI.

## Customization agreements

A customization agreement should distinguish the pre-existing project from
customer-specific work and define license, delivery, support, confidentiality,
data protection, branding and liability. Use a non-exclusive license when the
intention is to permit customization without transferring the pre-existing
project's economic ownership. Any assignment of economic rights should be
reviewed and signed as a separate written instrument.
