<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Security;

final class CsrfGuard
{
    public function validateRequest(bool $preserveToken = false): void
    {
        $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
        if (!in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
            return;
        }

        if ($this->isValidatedByGlpiCoreListener()) {
            return;
        }

        $token = (string) ($_POST['_glpi_csrf_token'] ?? ($_SERVER['HTTP_X_GLPI_CSRF_TOKEN'] ?? ''));
        $this->logDiagnostic($token, $preserveToken);

        if ($token === '') {
            throw new \RuntimeException('Token CSRF ausente.');
        }

        if (!method_exists('Session', 'checkCSRF')) {
            throw new \RuntimeException('Validador CSRF do GLPI indisponivel.');
        }

        if ($preserveToken && !defined('GLPI_KEEP_CSRF_TOKEN')) {
            define('GLPI_KEEP_CSRF_TOKEN', '1');
        }

        if ($this->isLegacyGlpi()) {
            $this->validateLegacyToken($token, $preserveToken);
            return;
        }

        $payload = $_POST;
        if (!isset($payload['_glpi_csrf_token'])) {
            $payload['_glpi_csrf_token'] = $token;
        }

        try {
            \Session::checkCSRF($payload, $preserveToken);
        } catch (\ArgumentCountError $e) {
            \Session::checkCSRF($payload);
        }
    }

    public function token(bool $standalone = false): string
    {
        if (method_exists('Session', 'getNewCSRFToken')) {
            $useStandalone = $standalone && $this->supportsStandaloneTokens();
            try {
                $token = (string) \Session::getNewCSRFToken($useStandalone);
            } catch (\ArgumentCountError $e) {
                $token = (string) \Session::getNewCSRFToken();
            }

            $this->touchTokenForLegacyGlpi($token);
            $this->cleanupTokensForLegacyGlpi();
            $this->touchTokenForLegacyGlpi($token);
            $this->logGeneratedToken($token, $useStandalone);

            return $token;
        }

        return '';
    }

    private function isValidatedByGlpiCoreListener(): bool
    {
        return defined('GLPI_VERSION')
            && version_compare((string) GLPI_VERSION, '11.0.0', '>=')
            && class_exists('\\Glpi\\Kernel\\Listener\\ControllerListener\\CheckCsrfListener');
    }

    private function supportsStandaloneTokens(): bool
    {
        return defined('GLPI_VERSION') && version_compare((string) GLPI_VERSION, '11.0.0', '>=');
    }

    private function isLegacyGlpi(): bool
    {
        return !defined('GLPI_VERSION') || version_compare((string) GLPI_VERSION, '11.0.0', '<');
    }

    private function cleanupTokensForLegacyGlpi(): void
    {
        if (!$this->isLegacyGlpi()) {
            return;
        }

        if (method_exists('Session', 'cleanCSRFTokens')) {
            \Session::cleanCSRFTokens();
        }
    }

    private function touchTokenForLegacyGlpi(string $token): void
    {
        if ($token === '') {
            return;
        }

        if (!$this->isLegacyGlpi()) {
            return;
        }

        if (!isset($_SESSION['glpicsrftokens']) || !is_array($_SESSION['glpicsrftokens'])) {
            $_SESSION['glpicsrftokens'] = [];
        }

        $expires = $_SESSION['glpicsrftokens'][$token] ?? null;
        if (is_numeric($expires)) {
            $expires = (int) $expires;
        }

        if (!is_int($expires) || $expires < time()) {
            $expires = time() + $this->legacyTokenTtl();
        }

        unset($_SESSION['glpicsrftokens'][$token]);
        $_SESSION['glpicsrftokens'][$token] = $expires;
        $this->storePluginLegacyToken($token, $expires);
    }

    private function validateLegacyToken(string $token, bool $preserveToken): void
    {
        $nativeExpires = $this->getLegacyTokenExpires($_SESSION['glpicsrftokens'] ?? [], $token);
        $pluginExpires = $this->getLegacyTokenExpires($_SESSION['glpiacessivel_csrf_tokens'] ?? [], $token);

        if ($token === '' || ($nativeExpires === null && $pluginExpires === null)) {
            $this->logLegacyValidation($token, 'missing');
            throw new \RuntimeException('Token CSRF invalido ou ausente.');
        }

        $expires = max((int) ($nativeExpires ?? 0), (int) ($pluginExpires ?? 0));
        if ($expires < time()) {
            unset($_SESSION['glpicsrftokens'][$token]);
            unset($_SESSION['glpiacessivel_csrf_tokens'][$token]);
            $this->logLegacyValidation($token, 'expired');
            throw new \RuntimeException('Token CSRF expirado.');
        }

        if (!$preserveToken) {
            unset($_SESSION['glpicsrftokens'][$token]);
            unset($_SESSION['glpiacessivel_csrf_tokens'][$token]);
        } else {
            $this->storePluginLegacyToken($token, $expires);
            $this->touchTokenForLegacyGlpi($token);
        }

        $this->logLegacyValidation($token, 'valid');
    }

    private function getLegacyTokenExpires(mixed $tokens, string $token): ?int
    {
        if ($token === '' || !is_array($tokens) || !array_key_exists($token, $tokens)) {
            return null;
        }

        $expires = $tokens[$token];
        if (!is_numeric($expires)) {
            return null;
        }

        return (int) $expires;
    }

    private function storePluginLegacyToken(string $token, int $expires): void
    {
        if ($token === '') {
            return;
        }

        if (!isset($_SESSION['glpiacessivel_csrf_tokens']) || !is_array($_SESSION['glpiacessivel_csrf_tokens'])) {
            $_SESSION['glpiacessivel_csrf_tokens'] = [];
        }

        $now = time();
        foreach ($_SESSION['glpiacessivel_csrf_tokens'] as $storedToken => $storedExpires) {
            if (!is_numeric($storedExpires) || (int) $storedExpires < $now) {
                unset($_SESSION['glpiacessivel_csrf_tokens'][$storedToken]);
            }
        }

        unset($_SESSION['glpiacessivel_csrf_tokens'][$token]);
        $_SESSION['glpiacessivel_csrf_tokens'][$token] = $expires;
        if (count($_SESSION['glpiacessivel_csrf_tokens']) > 200) {
            $_SESSION['glpiacessivel_csrf_tokens'] = array_slice(
                $_SESSION['glpiacessivel_csrf_tokens'],
                -200,
                null,
                true
            );
        }
    }

    private function legacyTokenTtl(): int
    {
        if (defined('GLPI_CSRF_EXPIRES')) {
            return max(300, (int) GLPI_CSRF_EXPIRES);
        }

        return 7200;
    }

    private function logGeneratedToken(string $token, bool $standalone): void
    {
        if (!$this->isLegacyGlpi()) {
            return;
        }

        $tokens = $_SESSION['glpicsrftokens'] ?? [];
        $line = sprintf(
            "[%s] event=token_generated glpi=%s user=%d uri=%s token_len=%d token_hash=%s session_tokens=%d session_has_token=%s plugin_tokens=%d plugin_has_token=%s standalone=%s session_name=%s session_hash=%s\n",
            date('c'),
            defined('GLPI_VERSION') ? (string) GLPI_VERSION : 'unknown',
            (int) ($_SESSION['glpiID'] ?? 0),
            (string) ($_SERVER['REQUEST_URI'] ?? ''),
            strlen($token),
            $token !== '' ? substr(hash('sha256', $token), 0, 12) : '',
            is_array($tokens) ? count($tokens) : 0,
            is_array($tokens) && $token !== '' && array_key_exists($token, $tokens) ? 'yes' : 'no',
            is_array($_SESSION['glpiacessivel_csrf_tokens'] ?? null) ? count($_SESSION['glpiacessivel_csrf_tokens']) : 0,
            $this->getLegacyTokenExpires($_SESSION['glpiacessivel_csrf_tokens'] ?? [], $token) !== null ? 'yes' : 'no',
            $standalone ? 'yes' : 'no',
            function_exists('session_name') ? (string) session_name() : '',
            function_exists('session_id') && session_id() !== '' ? substr(hash('sha256', session_id()), 0, 12) : ''
        );

        $this->writeLog($line);
    }

    private function logDiagnostic(string $token, bool $preserveToken): void
    {
        if (!$this->isLegacyGlpi()) {
            return;
        }

        $source = 'none';
        if (isset($_POST['_glpi_csrf_token'])) {
            $source = 'post';
        } elseif (isset($_SERVER['HTTP_X_GLPI_CSRF_TOKEN'])) {
            $source = 'header';
        }

        $tokens = $_SESSION['glpicsrftokens'] ?? [];
        $tokenExists = is_array($tokens) && $token !== '' && array_key_exists($token, $tokens);
        $line = sprintf(
            "[%s] glpi=%s user=%d method=%s uri=%s content_type=%s content_length=%s token_source=%s token_len=%d token_hash=%s session_tokens=%d session_has_token=%s plugin_tokens=%d plugin_has_token=%s preserve=%s session_name=%s session_hash=%s\n",
            date('c'),
            defined('GLPI_VERSION') ? (string) GLPI_VERSION : 'unknown',
            (int) ($_SESSION['glpiID'] ?? 0),
            (string) ($_SERVER['REQUEST_METHOD'] ?? ''),
            (string) ($_SERVER['REQUEST_URI'] ?? ''),
            (string) ($_SERVER['CONTENT_TYPE'] ?? ''),
            (string) ($_SERVER['CONTENT_LENGTH'] ?? ''),
            $source,
            strlen($token),
            $token !== '' ? substr(hash('sha256', $token), 0, 12) : '',
            is_array($tokens) ? count($tokens) : 0,
            $tokenExists ? 'yes' : 'no',
            is_array($_SESSION['glpiacessivel_csrf_tokens'] ?? null) ? count($_SESSION['glpiacessivel_csrf_tokens']) : 0,
            $this->getLegacyTokenExpires($_SESSION['glpiacessivel_csrf_tokens'] ?? [], $token) !== null ? 'yes' : 'no',
            $preserveToken ? 'yes' : 'no',
            function_exists('session_name') ? (string) session_name() : '',
            function_exists('session_id') && session_id() !== '' ? substr(hash('sha256', session_id()), 0, 12) : ''
        );

        $this->writeLog($line);
    }

    private function logLegacyValidation(string $token, string $result): void
    {
        if (!$this->isLegacyGlpi()) {
            return;
        }

        $tokens = $_SESSION['glpicsrftokens'] ?? [];
        $line = sprintf(
            "[%s] event=legacy_validate glpi=%s user=%d uri=%s token_hash=%s result=%s session_tokens=%d plugin_tokens=%d session_name=%s session_hash=%s\n",
            date('c'),
            defined('GLPI_VERSION') ? (string) GLPI_VERSION : 'unknown',
            (int) ($_SESSION['glpiID'] ?? 0),
            (string) ($_SERVER['REQUEST_URI'] ?? ''),
            $token !== '' ? substr(hash('sha256', $token), 0, 12) : '',
            $result,
            is_array($tokens) ? count($tokens) : 0,
            is_array($_SESSION['glpiacessivel_csrf_tokens'] ?? null) ? count($_SESSION['glpiacessivel_csrf_tokens']) : 0,
            function_exists('session_name') ? (string) session_name() : '',
            function_exists('session_id') && session_id() !== '' ? substr(hash('sha256', session_id()), 0, 12) : ''
        );

        $this->writeLog($line);
    }

    private function writeLog(string $line): void
    {
        if (class_exists('\\Toolbox') && method_exists('\\Toolbox', 'logInFile')) {
            \Toolbox::logInFile('glpiacessivel-csrf', $line);
            return;
        }

        error_log('[glpiacessivel-csrf] ' . trim($line));
    }
}
