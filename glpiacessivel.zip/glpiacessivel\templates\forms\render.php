<?php
$form = is_array($form ?? null) ? $form : [];
$schema = is_array($schema ?? null) ? $schema : [];
$nativeUrl = (string) ($nativeUrl ?? ($form['native_url'] ?? glpiacessivel_url('front/forms.php')));
$showOperationalDiagnostics = !empty($showOperationalDiagnostics);
$formsNativeFlowMode = (string) ($formsNativeFlowMode ?? 'native_embedded');
$title = (string) ($schema['title'] ?? $form['name'] ?? glpiacessivel_t('Formulario'));
$sections = is_array($schema['sections'] ?? null) ? $schema['sections'] : [];
$fields = is_array($schema['fields'] ?? null) ? $schema['fields'] : [];
$capabilities = is_array($schema['capabilities'] ?? null) ? $schema['capabilities'] : [];
$fallback = is_array($schema['fallback'] ?? null) ? $schema['fallback'] : [];
$metadata = is_array($schema['metadata'] ?? null) ? $schema['metadata'] : [];
$conditions = is_array($schema['conditions'] ?? null) ? $schema['conditions'] : [];
$matrix = is_array($capabilities['compatibility_matrix'] ?? null) ? $capabilities['compatibility_matrix'] : [];
$submissionReadiness = is_array($capabilities['own_submission_readiness'] ?? null) ? $capabilities['own_submission_readiness'] : [];
$nativeSubmitContract = is_array($capabilities['native_submit_contract'] ?? null) ? $capabilities['native_submit_contract'] : [];
$nativeHiddenFields = is_array($nativeSubmitContract['hidden_fields'] ?? null) ? $nativeSubmitContract['hidden_fields'] : [];
$requiresNativeCsrf = !empty($nativeSubmitContract['requires_csrf']);
$nativeCsrfToken = (string) ($csrf_token ?? '');
$unsupported = is_array($metadata['unsupported_questions'] ?? null) ? $metadata['unsupported_questions'] : [];
global $CFG_GLPI;
$glpiRoot = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/');
$canSubmitViaNativeContract = !empty($nativeSubmitContract['enabled']) && !empty($submissionReadiness['ready']);
$source = (string) ($form['source'] ?? '');
$wantsConvertedPortalForm = $formsNativeFlowMode === 'plugin_converted_with_native_callback';
$canUseConvertedPortalForm = $wantsConvertedPortalForm && $canSubmitViaNativeContract;
$nativeSubmitUrl = $glpiRoot . (string) ($nativeSubmitContract['submit_endpoint'] ?? ($source === 'glpi11_service_catalog' ? '/Form/SubmitAnswers' : ''));
$nativeValidateUrl = $nativeSubmitContract !== [] && isset($nativeSubmitContract['validate_endpoint'])
    ? $glpiRoot . (string) $nativeSubmitContract['validate_endpoint']
    : ($source === 'glpi11_service_catalog' ? $glpiRoot . '/Form/ValidateAnswers' : '');
$nativeConditionUrl = $nativeSubmitContract !== [] && isset($nativeSubmitContract['condition_endpoint'])
    ? $glpiRoot . (string) $nativeSubmitContract['condition_endpoint']
    : ($source === 'glpi11_service_catalog' ? $glpiRoot . '/Form/Condition/Engine' : '');
$formId = (int) ($metadata['form_id'] ?? $nativeSubmitContract['form_id'] ?? $form['id'] ?? 0);
$nativeEngineLabel = match ($source) {
    'glpi11_service_catalog' => 'Service Catalog GLPI 11',
    'formcreator_glpi10' => 'Formcreator GLPI 10',
    default => glpiacessivel_t('GLPI nativo'),
};
$canEmbedNativeFlow = !$canUseConvertedPortalForm
    && $formsNativeFlowMode !== 'native_link'
    && in_array($source, ['glpi11_service_catalog', 'formcreator_glpi10'], true)
    && $formId > 0
    && $nativeUrl !== '';
$nativeEmbedUrl = $nativeUrl;
if ($canEmbedNativeFlow) {
    $nativeEmbedUrl .= (str_contains($nativeEmbedUrl, '?') ? '&' : '?') . 'glpiacessivel_native_embed=1';
}
$sectionMap = [];
foreach ($sections as $section) {
    if (!is_array($section)) {
        continue;
    }
    $id = (string) ($section['id'] ?? '');
    if ($id === '') {
        continue;
    }
    $sectionMap[$id] = $section;
}
$fieldsBySection = [];
foreach ($fields as $field) {
    if (!is_array($field) || empty($field['visible'])) {
        continue;
    }
    $sectionId = (string) ($field['section_id'] ?? 'metadata');
    $fieldsBySection[$sectionId][] = $field;
}
$sectionIds = array_values(array_unique(array_merge(array_keys($sectionMap), array_keys($fieldsBySection))));
$projectedFieldCount = 0;
foreach ($fieldsBySection as $sectionFields) {
    $projectedFieldCount += is_array($sectionFields) ? count($sectionFields) : 0;
}
$canRenderPortalForm = $canUseConvertedPortalForm;
$rendererDecision = $canRenderPortalForm
    ? 'plugin_converted'
    : ($canEmbedNativeFlow ? 'native_embedded_callback' : 'native_link');
$nativeDescribedBy = 'form-render-native-note';
?>

<section class="glpiacessivel-section-head" aria-labelledby="form-render-title">
  <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Formulario acessivel')) ?></p>
  <h2 id="form-render-title"><?= glpiacessivel_e($title) ?></h2>
  <?php if ($canRenderPortalForm): ?>
    <p><?= glpiacessivel_e(glpiacessivel_t('Preencha pelo formulario acessivel convertido. A validacao, as condicoes e a criacao final serao delegadas ao motor nativo homologado.')) ?></p>
  <?php elseif ($canEmbedNativeFlow): ?>
    <p><?= glpiacessivel_e(sprintf(glpiacessivel_t('Preencha somente o formulario nativo incorporado nesta pagina. O portal preserva o motor do %s para permissoes, condicoes, destinos, validacoes e anexos.'), $nativeEngineLabel)) ?></p>
  <?php else: ?>
    <p><?= glpiacessivel_e(glpiacessivel_t('Revise os campos projetados pelo portal. A conclusao do envio continua no fluxo nativo para preservar permissoes, destinos, validacoes e anexos.')) ?></p>
  <?php endif; ?>
</section>

<div class="glpiacessivel-alert <?= $canRenderPortalForm ? 'glpiacessivel-alert-info' : 'glpiacessivel-alert-warning' ?>" role="status" aria-labelledby="form-render-native-note">
  <strong id="form-render-native-note"><?= glpiacessivel_e($canRenderPortalForm ? glpiacessivel_t('Formulario acessivel convertido disponivel') : ($canEmbedNativeFlow ? sprintf(glpiacessivel_t('Envio nativo incorporado: %s'), $nativeEngineLabel) : glpiacessivel_t('Envio final pelo GLPI nativo'))) ?></strong>
  <?php if ($canRenderPortalForm): ?>
    <p><?= glpiacessivel_e(glpiacessivel_t('Este e o unico formulario editavel desta solicitacao. Se houver divergencia de validacao, o portal bloqueia o envio e orienta retorno ao fluxo nativo.')) ?></p>
  <?php elseif ($canEmbedNativeFlow): ?>
    <p><?= glpiacessivel_e(sprintf(glpiacessivel_t('O componente nativo abaixo e o unico formulario de preenchimento. Campos complexos, seletores, anexos, validacoes condicionais e criacao final continuam no %s.'), $nativeEngineLabel)) ?></p>
    <a class="glpiacessivel-button glpiacessivel-button-primary" href="#form-render-native-frame" aria-describedby="<?= glpiacessivel_e($nativeDescribedBy) ?>">
      <?= glpiacessivel_e(glpiacessivel_t('Ir para formulario nativo')) ?>
    </a>
  <?php else: ?>
    <p><?= glpiacessivel_e((string) (($fallback['reasons'][0] ?? null) ?: glpiacessivel_t('Este formulario ainda exige fallback nativo para submissao segura.'))) ?></p>
  <?php endif; ?>
  <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeUrl) ?>" aria-describedby="<?= glpiacessivel_e($nativeDescribedBy) ?>">
    <?= glpiacessivel_e(glpiacessivel_t('Abrir no GLPI nativo')) ?>
  </a>
</div>

<?php if ($canEmbedNativeFlow): ?>
  <section class="glpiacessivel-card glpiacessivel-native-embed" aria-labelledby="form-render-native-embedded-title">
    <div class="glpiacessivel-native-embed-head">
      <div>
        <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e($nativeEngineLabel) ?></p>
        <h3 id="form-render-native-embedded-title"><?= glpiacessivel_e(glpiacessivel_t('Formulario nativo incorporado')) ?></h3>
        <p id="form-render-native-embedded-help" class="glpiacessivel-help-text">
          <?= glpiacessivel_e(sprintf(glpiacessivel_t('Use esta area para concluir a solicitacao com o mesmo fluxo do %s. Se o leitor de tela preferir a pagina completa, use Abrir no GLPI nativo.'), $nativeEngineLabel)) ?>
        </p>
      </div>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeUrl) ?>" data-glpiacessivel-native-full-link>
        <?= glpiacessivel_e(glpiacessivel_t('Abrir pagina completa')) ?>
      </a>
    </div>
    <div id="form-render-native-frame-status" class="glpiacessivel-sr-only" role="status" aria-live="polite">
      <?= glpiacessivel_e(sprintf(glpiacessivel_t('Carregando formulario nativo: %s.'), $nativeEngineLabel)) ?>
    </div>
    <iframe
      id="form-render-native-frame"
      class="glpiacessivel-native-embed-frame"
      src="<?= glpiacessivel_e($nativeEmbedUrl) ?>"
      title="<?= glpiacessivel_e(sprintf(glpiacessivel_t('Formulario nativo %s: %s'), $nativeEngineLabel, $title)) ?>"
      aria-describedby="form-render-native-embedded-help"
      loading="eager"
      referrerpolicy="same-origin"
      data-glpiacessivel-native-frame>
    </iframe>
  </section>
<?php endif; ?>

<?php if ($canRenderPortalForm): ?>
<form class="glpiacessivel-form-grid glpiacessivel-dynamic-renderer" method="post" action="<?= glpiacessivel_e($nativeSubmitUrl) ?>" enctype="multipart/form-data" aria-labelledby="form-render-fields-title" novalidate data-glpiacessivel-dynamic-form-renderer data-glpiacessivel-native-submit="<?= $canSubmitViaNativeContract ? '1' : '0' ?>" data-glpiacessivel-form-id="<?= (int) $formId ?>" data-glpiacessivel-validate-url="<?= glpiacessivel_e($nativeValidateUrl) ?>" data-glpiacessivel-condition-url="<?= glpiacessivel_e($nativeConditionUrl) ?>">
  <?php if ($canSubmitViaNativeContract): ?>
    <?php if ($nativeHiddenFields === []): ?>
      <input type="hidden" name="forms_id" value="<?= (int) $formId ?>">
    <?php else: ?>
      <?php foreach ($nativeHiddenFields as $hiddenName => $hiddenValue): ?>
        <input type="hidden" name="<?= glpiacessivel_e((string) $hiddenName) ?>" value="<?= glpiacessivel_e((string) $hiddenValue) ?>">
      <?php endforeach; ?>
    <?php endif; ?>
    <?php if ($requiresNativeCsrf && $nativeCsrfToken !== ''): ?>
      <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($nativeCsrfToken) ?>">
    <?php endif; ?>
  <?php endif; ?>
  <div id="form-render-error-summary" class="glpiacessivel-alert glpiacessivel-alert-danger" role="alert" tabindex="-1" hidden></div>
  <div id="form-render-submit-status" class="glpiacessivel-alert glpiacessivel-alert-success" role="status" tabindex="-1" hidden></div>
  <h3 id="form-render-fields-title"><?= glpiacessivel_e(glpiacessivel_t('Campos do formulario')) ?></h3>
  <div id="form-render-condition-status" class="glpiacessivel-sr-only" role="status" aria-live="polite" aria-atomic="true"></div>

  <?php if ($fieldsBySection === []): ?>
    <p class="glpiacessivel-empty-state"><?= glpiacessivel_e(glpiacessivel_t('Nenhum campo projetado com seguranca para renderizacao propria. Use o fluxo nativo.')) ?></p>
  <?php endif; ?>

  <?php foreach ($sectionIds as $sectionId): ?>
    <?php
      $section = $sectionMap[$sectionId] ?? ['title' => glpiacessivel_t('Secao'), 'description' => ''];
      $sectionFields = $fieldsBySection[$sectionId] ?? [];
      if ($sectionFields === []) {
          continue;
      }
      $legendId = 'form-render-section-' . preg_replace('/[^a-z0-9_-]/i', '-', (string) $sectionId);
      $nativeSectionId = preg_replace('/^section_/', '', (string) $sectionId);
    ?>
    <fieldset class="glpiacessivel-form-fieldset glpiacessivel-dynamic-renderer-section" aria-labelledby="<?= glpiacessivel_e($legendId) ?>" data-glpiacessivel-section-wrapper data-section-id="<?= glpiacessivel_e((string) $sectionId) ?>" data-native-section-id="<?= glpiacessivel_e((string) $nativeSectionId) ?>">
      <legend id="<?= glpiacessivel_e($legendId) ?>"><?= glpiacessivel_e((string) ($section['title'] ?? glpiacessivel_t('Secao'))) ?></legend>
      <?php if (trim((string) ($section['description'] ?? '')) !== ''): ?>
        <p class="glpiacessivel-help-text"><?= glpiacessivel_e((string) $section['description']) ?></p>
      <?php endif; ?>

      <?php foreach ($sectionFields as $field): ?>
        <?php
          $fieldId = 'field-' . preg_replace('/[^a-z0-9_-]/i', '-', (string) ($field['id'] ?? $field['name'] ?? uniqid('field_', false)));
          $fieldName = (string) ($field['name'] ?? $field['id'] ?? $fieldId);
          $fieldType = (string) ($field['type'] ?? 'text');
          $fieldMetadata = is_array($field['metadata'] ?? null) ? $field['metadata'] : [];
          $nativeQuestionId = (int) ($fieldMetadata['native_question_id'] ?? 0);
          $nativeInputName = (string) ($fieldMetadata['native_input_name'] ?? ($nativeQuestionId > 0 ? 'answers_' . $nativeQuestionId : $fieldName));
          $inputName = $canSubmitViaNativeContract && $nativeQuestionId > 0 ? $nativeInputName : $fieldName;
          $isProjectionOnly = !empty($fieldMetadata['projection_only']);
          $label = (string) ($field['label'] ?? $fieldName);
          $description = trim((string) ($field['description'] ?? ''));
          $required = !empty($field['required']);
          $readonly = !empty($field['readonly']) || $isProjectionOnly;
          $disabled = !empty($field['disabled']) || $isProjectionOnly;
          $multiple = !empty($field['multiple']);
          $default = $field['default'] ?? '';
          $value = is_scalar($default) ? (string) $default : '';
          $options = is_array($field['options'] ?? null) ? $field['options'] : [];
          $helpId = $description !== '' ? $fieldId . '-help' : '';
          $describedBy = trim($helpId . ($fieldType === 'file' ? ' ' . $fieldId . '-file-note' : ''));
          $commonAttributes = ($required ? ' required aria-required="true"' : '')
            . ($readonly ? ' readonly' : '')
            . ($disabled ? ' disabled' : '')
            . ($describedBy !== '' ? ' aria-describedby="' . glpiacessivel_e($describedBy) . '"' : '');
        ?>
        <div class="glpiacessivel-dynamic-renderer-field glpiacessivel-dynamic-renderer-field-<?= glpiacessivel_e(preg_replace('/[^a-z0-9_-]/i', '-', $fieldType)) ?>" data-glpiacessivel-field-wrapper data-field-name="<?= glpiacessivel_e($fieldName) ?>" data-field-id="<?= glpiacessivel_e((string) ($field['id'] ?? $fieldName)) ?>" data-native-question-id="<?= (int) $nativeQuestionId ?>" data-native-input-name="<?= glpiacessivel_e($nativeInputName) ?>" data-original-required="<?= $required ? '1' : '0' ?>" data-original-disabled="<?= $disabled ? '1' : '0' ?>">
          <?php if (in_array($fieldType, ['radio', 'checkbox'], true) && $options !== []): ?>
            <fieldset class="glpiacessivel-dynamic-renderer-choice"<?= $required ? ' aria-required="true"' : '' ?><?= $describedBy !== '' ? ' aria-describedby="' . glpiacessivel_e($describedBy) . '"' : '' ?>>
              <legend><?= glpiacessivel_e($label) ?><?= $required ? ' *' : '' ?></legend>
              <?php if ($description !== ''): ?>
                <p id="<?= glpiacessivel_e($helpId) ?>" class="glpiacessivel-help-text"><?= glpiacessivel_e($description) ?></p>
              <?php endif; ?>
              <div class="glpiacessivel-dynamic-renderer-options">
                <?php foreach ($options as $optionIndex => $option): ?>
                  <?php
                    $optionValue = (string) (is_array($option) ? ($option['id'] ?? $option['value'] ?? $optionIndex) : $optionIndex);
                    $optionLabel = (string) (is_array($option) ? ($option['label'] ?? $option['name'] ?? $optionValue) : $option);
                    $optionId = $fieldId . '-' . preg_replace('/[^a-z0-9_-]/i', '-', $optionValue);
                  ?>
                  <label for="<?= glpiacessivel_e($optionId) ?>" class="glpiacessivel-dynamic-renderer-option">
                    <input type="<?= glpiacessivel_e($fieldType) ?>" id="<?= glpiacessivel_e($optionId) ?>" name="<?= glpiacessivel_e($inputName . ($fieldType === 'checkbox' && $multiple ? '[]' : '')) ?>" value="<?= glpiacessivel_e($optionValue) ?>"<?= $disabled ? ' disabled' : '' ?>>
                    <span><?= glpiacessivel_e($optionLabel) ?></span>
                  </label>
                <?php endforeach; ?>
              </div>
            </fieldset>
          <?php else: ?>
            <label for="<?= glpiacessivel_e($fieldId) ?>"><?= glpiacessivel_e($label) ?><?= $required ? ' *' : '' ?></label>
            <?php if ($description !== ''): ?>
              <p id="<?= glpiacessivel_e($helpId) ?>" class="glpiacessivel-help-text"><?= glpiacessivel_e($description) ?></p>
            <?php endif; ?>

            <?php if ($fieldType === 'native_reference'): ?>
              <div id="<?= glpiacessivel_e($fieldId) ?>" class="glpiacessivel-native-reference" role="note"<?= $describedBy !== '' ? ' aria-describedby="' . glpiacessivel_e($describedBy) . '"' : '' ?>>
                <strong><?= glpiacessivel_e(glpiacessivel_t('Campo assistido pelo GLPI nativo')) ?></strong>
                <p><?= glpiacessivel_e(glpiacessivel_t('Este campo depende de seletor, permissao ou validacao nativa. Revise no fluxo nativo antes de concluir o envio.')) ?></p>
              </div>
            <?php elseif ($fieldType === 'hidden'): ?>
              <div id="<?= glpiacessivel_e($fieldId) ?>" class="glpiacessivel-native-reference" role="note"<?= $describedBy !== '' ? ' aria-describedby="' . glpiacessivel_e($describedBy) . '"' : '' ?>>
                <strong><?= glpiacessivel_e(glpiacessivel_t('Campo oculto nativo')) ?></strong>
                <p><?= glpiacessivel_e(glpiacessivel_t('Este valor e definido pelo formulario nativo e nao deve ser editado diretamente no portal.')) ?></p>
              </div>
            <?php elseif ($fieldType === 'textarea'): ?>
              <textarea id="<?= glpiacessivel_e($fieldId) ?>" name="<?= glpiacessivel_e($inputName) ?>" rows="5"<?= $commonAttributes ?>><?= glpiacessivel_e($value) ?></textarea>
            <?php elseif ($fieldType === 'select' || $fieldType === 'multiselect'): ?>
              <select id="<?= glpiacessivel_e($fieldId) ?>" name="<?= glpiacessivel_e($inputName . ($multiple ? '[]' : '')) ?>"<?= $multiple ? ' multiple' : '' ?><?= $commonAttributes ?>>
                <?php if (!$required && !$multiple): ?>
                  <option value=""><?= glpiacessivel_e(glpiacessivel_t('Selecione')) ?></option>
                <?php endif; ?>
                <?php foreach ($options as $optionIndex => $option): ?>
                  <?php
                    $optionValue = (string) (is_array($option) ? ($option['id'] ?? $option['value'] ?? $optionIndex) : $optionIndex);
                    $optionLabel = (string) (is_array($option) ? ($option['label'] ?? $option['name'] ?? $optionValue) : $option);
                  ?>
                  <option value="<?= glpiacessivel_e($optionValue) ?>"<?= $optionValue === $value ? ' selected' : '' ?>><?= glpiacessivel_e($optionLabel) ?></option>
                <?php endforeach; ?>
              </select>
            <?php elseif ($fieldType === 'file'): ?>
              <input type="file" id="<?= glpiacessivel_e($fieldId) ?>" name="<?= glpiacessivel_e($inputName) ?>"<?= $multiple ? ' multiple' : '' ?> disabled aria-describedby="<?= glpiacessivel_e(trim($describedBy . ' ' . $fieldId . '-file-note')) ?>">
              <p id="<?= glpiacessivel_e($fieldId) ?>-file-note" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Anexos devem ser enviados no fluxo nativo ate a validacao Document_Item ser homologada.')) ?></p>
            <?php else: ?>
              <?php
                $htmlType = in_array($fieldType, ['email', 'number', 'date'], true) ? $fieldType : ($fieldType === 'datetime' ? 'datetime-local' : 'text');
              ?>
              <input type="<?= glpiacessivel_e($htmlType) ?>" id="<?= glpiacessivel_e($fieldId) ?>" name="<?= glpiacessivel_e($inputName) ?>" value="<?= glpiacessivel_e($value) ?>"<?= $commonAttributes ?>>
            <?php endif; ?>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </fieldset>
  <?php endforeach; ?>

  <div class="glpiacessivel-form-actions">
    <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/forms.php')) ?>">
      <?= glpiacessivel_e(glpiacessivel_t('Voltar aos formularios')) ?>
    </a>
    <?php if ($canSubmitViaNativeContract): ?>
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary" data-glpiacessivel-native-submit-button>
        <?= glpiacessivel_e(glpiacessivel_t('Enviar pelo portal acessivel')) ?>
      </button>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeUrl) ?>" aria-describedby="<?= glpiacessivel_e($nativeDescribedBy) ?>">
        <?= glpiacessivel_e(glpiacessivel_t('Abrir no GLPI nativo')) ?>
      </a>
    <?php elseif ($canEmbedNativeFlow): ?>
      <a class="glpiacessivel-button glpiacessivel-button-primary" href="#form-render-native-frame" aria-describedby="<?= glpiacessivel_e($nativeDescribedBy) ?>">
        <?= glpiacessivel_e(glpiacessivel_t('Concluir no formulario nativo incorporado')) ?>
      </a>
    <?php else: ?>
      <a class="glpiacessivel-button glpiacessivel-button-primary" href="<?= glpiacessivel_e($nativeUrl) ?>" aria-describedby="<?= glpiacessivel_e($nativeDescribedBy) ?>">
        <?= glpiacessivel_e(glpiacessivel_t('Concluir no GLPI nativo')) ?>
      </a>
    <?php endif; ?>
  </div>
  <script type="application/json" id="form-render-conditions-json"><?= json_encode($conditions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?: '[]' ?></script>
</form>
<?php else: ?>
  <section class="glpiacessivel-card glpiacessivel-dynamic-renderer-summary" aria-labelledby="form-render-summary-title">
    <h3 id="form-render-summary-title"><?= glpiacessivel_e(glpiacessivel_t('Resumo acessivel do formulario')) ?></h3>
    <p class="glpiacessivel-help-text">
      <?= glpiacessivel_e(glpiacessivel_t('Para evitar preenchimento duplicado, o portal mostra apenas um resumo dos campos detectados. O preenchimento e o envio devem ser feitos no formulario nativo indicado acima.')) ?>
    </p>

    <?php if ($projectedFieldCount <= 0): ?>
      <p class="glpiacessivel-empty-state"><?= glpiacessivel_e(glpiacessivel_t('Nenhum campo foi projetado com seguranca para resumo. Use o fluxo nativo.')) ?></p>
    <?php else: ?>
      <details class="glpiacessivel-form-compatibility">
        <summary><?= glpiacessivel_e(sprintf(glpiacessivel_t('Ver campos detectados (%d)'), $projectedFieldCount)) ?></summary>
        <?php foreach ($sectionIds as $sectionId): ?>
          <?php
            $section = $sectionMap[$sectionId] ?? ['title' => glpiacessivel_t('Secao'), 'description' => ''];
            $sectionFields = $fieldsBySection[$sectionId] ?? [];
            if ($sectionFields === []) {
                continue;
            }
          ?>
          <div class="glpiacessivel-form-summary-section">
            <h4><?= glpiacessivel_e((string) ($section['title'] ?? glpiacessivel_t('Secao'))) ?></h4>
            <?php if (trim((string) ($section['description'] ?? '')) !== ''): ?>
              <p class="glpiacessivel-help-text"><?= glpiacessivel_e((string) $section['description']) ?></p>
            <?php endif; ?>
            <ul>
              <?php foreach ($sectionFields as $field): ?>
                <?php
                  if (!is_array($field)) {
                      continue;
                  }
                  $fieldType = (string) ($field['type'] ?? 'text');
                  $fieldLabel = (string) ($field['label'] ?? $field['name'] ?? $field['id'] ?? glpiacessivel_t('Campo'));
                  $fieldRequired = !empty($field['required']);
                  $fieldMetadata = is_array($field['metadata'] ?? null) ? $field['metadata'] : [];
                  $isProjectionOnly = !empty($fieldMetadata['projection_only']) || in_array($fieldType, ['native_reference', 'file', 'hidden'], true);
                ?>
                <li>
                  <strong><?= glpiacessivel_e($fieldLabel) ?></strong>
                  <span><?= glpiacessivel_e($fieldRequired ? glpiacessivel_t('obrigatorio') : glpiacessivel_t('opcional')) ?></span>
                  <span><?= glpiacessivel_e($isProjectionOnly ? glpiacessivel_t('assistido pelo nativo') : $fieldType) ?></span>
                </li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php endforeach; ?>
      </details>
    <?php endif; ?>

    <div class="glpiacessivel-form-actions">
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/forms.php')) ?>">
        <?= glpiacessivel_e(glpiacessivel_t('Voltar aos formularios')) ?>
      </a>
      <?php if ($canEmbedNativeFlow): ?>
        <a class="glpiacessivel-button glpiacessivel-button-primary" href="#form-render-native-frame" aria-describedby="<?= glpiacessivel_e($nativeDescribedBy) ?>">
          <?= glpiacessivel_e(glpiacessivel_t('Ir para formulario nativo')) ?>
        </a>
      <?php else: ?>
        <a class="glpiacessivel-button glpiacessivel-button-primary" href="<?= glpiacessivel_e($nativeUrl) ?>" aria-describedby="<?= glpiacessivel_e($nativeDescribedBy) ?>">
          <?= glpiacessivel_e(glpiacessivel_t('Concluir no GLPI nativo')) ?>
        </a>
      <?php endif; ?>
    </div>
  </section>
<?php endif; ?>

<?php if ($showOperationalDiagnostics): ?>
  <section class="glpiacessivel-card" aria-labelledby="form-render-diagnostics-title">
    <h3 id="form-render-diagnostics-title"><?= glpiacessivel_e(glpiacessivel_t('Diagnostico do renderer')) ?></h3>
    <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Decisao de abertura')) ?>: <?= glpiacessivel_e($rendererDecision) ?></p>
    <dl class="glpiacessivel-form-compatibility-matrix">
      <?php foreach ($matrix as $item): ?>
        <?php if (!is_array($item)) { continue; } ?>
        <div>
          <dt><?= glpiacessivel_e((string) ($item['area'] ?? '')) ?> <span><?= glpiacessivel_e((string) ($item['status'] ?? '')) ?></span></dt>
          <dd><?= glpiacessivel_e((string) ($item['message'] ?? '')) ?></dd>
        </div>
      <?php endforeach; ?>
    </dl>
    <?php if ($submissionReadiness !== []): ?>
      <details class="glpiacessivel-form-compatibility">
        <summary><?= glpiacessivel_e(glpiacessivel_t('Gate de submissao propria')) ?></summary>
        <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Decisao')) ?>: <?= glpiacessivel_e((string) ($submissionReadiness['decision'] ?? 'native_fallback_required')) ?></p>
        <?php $blockers = is_array($submissionReadiness['blockers'] ?? null) ? $submissionReadiness['blockers'] : []; ?>
        <?php if ($blockers !== []): ?>
          <ul>
            <?php foreach ($blockers as $area => $message): ?>
              <li><strong><?= glpiacessivel_e((string) $area) ?></strong>: <?= glpiacessivel_e((string) $message) ?></li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </details>
    <?php endif; ?>

    <?php if ($unsupported !== []): ?>
      <details class="glpiacessivel-form-compatibility">
        <summary><?= glpiacessivel_e(glpiacessivel_t('Perguntas ainda nao suportadas')) ?></summary>
        <ul>
          <?php foreach ($unsupported as $question): ?>
            <?php if (!is_array($question)) { continue; } ?>
            <li><?= glpiacessivel_e((string) ($question['label'] ?? $question['id'] ?? '')) ?>: <?= glpiacessivel_e((string) ($question['type'] ?? '')) ?></li>
          <?php endforeach; ?>
        </ul>
      </details>
    <?php endif; ?>
  </section>
<?php endif; ?>



