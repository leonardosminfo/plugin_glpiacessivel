<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\DynamicForm;

final class DynamicFormField
{
    /**
     * @param array<int, array<string, mixed>> $options
     * @param array<string, mixed> $constraints
     * @param array<string, mixed> $metadata
     */
    public function __construct(
        private string $id,
        private string $name,
        private string $type,
        private string $label,
        private string $sectionId,
        private bool $required = false,
        private bool $visible = true,
        private bool $readonly = false,
        private bool $disabled = false,
        private bool $multiple = false,
        private mixed $defaultValue = null,
        private array $options = [],
        private array $constraints = [],
        private string $source = 'native_ticket',
        private ?string $nativeField = null,
        private string $description = '',
        private array $metadata = []
    ) {
    }

    public function id(): string
    {
        return $this->id;
    }

    public function name(): string
    {
        return $this->name;
    }

    public function nativeField(): string
    {
        return $this->nativeField ?? $this->name;
    }

    public function label(): string
    {
        return $this->label;
    }

    public function isRequired(): bool
    {
        return $this->required;
    }

    public function isVisible(): bool
    {
        return $this->visible;
    }

    public function isReadonly(): bool
    {
        return $this->readonly;
    }

    public function isDisabled(): bool
    {
        return $this->disabled;
    }

    public function isMultiple(): bool
    {
        return $this->multiple;
    }

    public function hasAllowedOptions(): bool
    {
        return $this->options !== [];
    }

    /**
     * @return array<int, string>
     */
    public function allowedOptionIds(): array
    {
        $ids = [];
        foreach ($this->options as $option) {
            if (is_array($option) && array_key_exists('id', $option)) {
                $ids[] = (string) $option['id'];
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * @return array<string, mixed>
     */
    public function constraints(): array
    {
        return $this->constraints;
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'type' => $this->type,
            'label' => $this->label,
            'section_id' => $this->sectionId,
            'required' => $this->required,
            'visible' => $this->visible,
            'readonly' => $this->readonly,
            'disabled' => $this->disabled,
            'multiple' => $this->multiple,
            'default' => $this->defaultValue,
            'options' => $this->options,
            'constraints' => $this->constraints,
            'source' => $this->source,
            'native_field' => $this->nativeField ?? $this->name,
            'description' => $this->description,
            'metadata' => $this->metadata,
        ];
    }
}
