# Hardening de seguranca

## Regras para release

Nunca publicar a pasta de trabalho inteira em producao. O pacote de release deve excluir:

- `.backup/`
- `tests/`
- `phpunit.xml`
- arquivos temporarios locais

O plugin deve ser instalado no GLPI com o nome tecnico exato:

`plugins/glpiacessivel`

## Superficies protegidas

- `front/acessivel.php` e publico para permitir login acessivel no GLPI 11, mas emite headers contra clickjacking, sniffing e cache.
- POSTs autenticados usam CSRF do GLPI.
- Revelacao de PII exige permissao global e permissao de atualizacao no chamado especifico.
- Cockpit contabiliza somente tickets que passam por `Ticket::can(..., READ)`.
- Chatbot retorna DTO minimo, sem despejar o objeto completo do ticket no HTML.
- Templates ITIL, artigos da base e tickets sao revalidados por entidade e ACL no momento do uso.
- Arquivos temporarios enviados pelo plugin possuem ownership e sao descartados se a operacao nativa nao concluir.
- O mascaramento de contatos pessoais e opcional e desativado por padrao; quando ativado, a revelacao autorizada exige campo, justificativa, auditoria e expira em cinco minutos.
- Aprovacao e rejeicao de roteiros aceitam somente sugestoes pendentes e usam claim condicional contra replay.

## Pendencias operacionais

- Definir retencao de auditoria/LGPD em dias por politica institucional.
- Empacotar release por allowlist ou `git archive`, respeitando `.gitattributes`.
- Executar teste DAST em instancia GLPI 10 e 11 de homologacao.

