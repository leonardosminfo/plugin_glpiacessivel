<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Repository;

use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;
use GlpiPlugin\Glpiacessivel\Support\Url;

final class FormRepository
{
    /**
     * @return array<string, mixed>
     */
    public function listFormSources(): array
    {
        $glpi11 = $this->listGlpi11ServiceCatalogForms();
        $formcreator = $this->listFormcreatorForms();

        return [
            'items' => array_merge($glpi11['items'], $formcreator['items']),
            'sources' => [
                'glpi11_service_catalog' => [
                    'available' => $glpi11['available'],
                    'enabled' => $glpi11['enabled'],
                    'label' => 'Catalogo de Servicos / Forms GLPI 11',
                    'native_url' => $this->serviceCatalogUrl(),
                    'message' => $glpi11['message'],
                ],
                'formcreator_glpi10' => [
                    'available' => $formcreator['available'],
                    'enabled' => $formcreator['enabled'],
                    'label' => 'Formcreator GLPI 10',
                    'native_url' => Url::core('plugins/formcreator/front/formlist.php'),
                    'message' => $formcreator['message'],
                ],
            ],
            'fallback_policy' => 'O portal lista formularios permitidos quando consegue detectar a fonte, mas a abertura e submissao continuam no motor nativo ate homologacao completa do renderer dinamico.',
        ];
    }

    /**
     * @return array<string, mixed>|null
     */
    public function resolveForm(string $source, int $id): ?array
    {
        $sources = $this->listFormSources();
        foreach ((array) ($sources['items'] ?? []) as $item) {
            if ((string) ($item['source'] ?? '') === $source && (int) ($item['id'] ?? 0) === $id) {
                return $item;
            }
        }

        return null;
    }

    /**
     * @return array{available:bool, enabled:bool, message:string, items:array<int, array<string, mixed>>}
     */
    private function listGlpi11ServiceCatalogForms(): array
    {
        $available = class_exists('\Glpi\Form\Form')
            || class_exists('\Glpi\Form\ServiceCatalog\ServiceCatalog')
            || $this->tableExists('glpi_forms_forms');
        if (!$available) {
            return [
                'available' => false,
                'enabled' => false,
                'message' => 'Service Catalog/Forms nao detectado nesta instalacao.',
                'items' => [],
            ];
        }

        if (
            class_exists('\Glpi\Form\ServiceCatalog\ServiceCatalog')
            && method_exists('\Glpi\Form\ServiceCatalog\ServiceCatalog', 'canView')
            && !\Glpi\Form\ServiceCatalog\ServiceCatalog::canView()
        ) {
            return [
                'available' => true,
                'enabled' => false,
                'message' => 'Service Catalog/Forms detectado, mas indisponivel para a entidade ou perfil atual.',
                'items' => [],
            ];
        }

        $items = $this->readGlpi11FormsFromServiceCatalog();
        return [
            'available' => true,
            'enabled' => true,
            'message' => $items === []
                ? 'Service Catalog/Forms detectado. Nenhum formulario foi retornado pelo catalogo nativo para este contexto; use o fluxo nativo para pesquisar categorias ou revisar permissoes.'
                : 'Formularios retornados pelo Service Catalog GLPI 11 com validacao nativa de entidade, perfil e controles de acesso.',
            'items' => $items,
        ];
    }
    /**
     * @return array<int, array<string, mixed>>
     */
    private function readGlpi11FormsFromServiceCatalog(): array
    {
        $managerClass = '\Glpi\Form\ServiceCatalog\ServiceCatalogManager';
        $requestClass = '\Glpi\Form\ServiceCatalog\ItemRequest';
        $parametersClass = '\Glpi\Form\AccessControl\FormAccessParameters';
        if (
            !class_exists($managerClass)
            || !class_exists($requestClass)
            || !class_exists($parametersClass)
            || !class_exists('\Glpi\Form\Form')
            || !method_exists('\Session', 'getCurrentSessionInfo')
        ) {
            return [];
        }

        try {
            $session = \Session::getCurrentSessionInfo();
            if ($session === null) {
                return [];
            }

            $parameters = new $parametersClass($session, [], false);
            $manager = $managerClass::getInstance();
            $items = [];
            $page = 1;
            $pageSize = 80;
            $total = null;
            do {
                $request = new $requestClass($parameters, '', 0, $page, $pageSize);
                $result = (array) $manager->getItems($request);
                $pageItems = (array) ($result['items'] ?? []);
                foreach ($pageItems as $item) {
                    array_push($items, ...$this->mapGlpi11CatalogItem($item));
                }

                if (isset($result['total']) && is_numeric($result['total'])) {
                    $total = max(0, (int) $result['total']);
                }
                $page++;
                $moreByTotal = $total !== null && (($page - 1) * $pageSize) < $total;
                $moreByPageSize = $total === null && count($pageItems) === $pageSize;
            } while (($moreByTotal || $moreByPageSize) && $page <= 100);

            return $this->uniqueForms($items);
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function mapGlpi11CatalogItem(object $item): array
    {
        if ($item instanceof \Glpi\Form\Form) {
            return [$this->mapGlpi11Form($item)];
        }

        if (
            class_exists('\Glpi\Form\ServiceCatalog\ServiceCatalogCompositeInterface')
            && $item instanceof \Glpi\Form\ServiceCatalog\ServiceCatalogCompositeInterface
            && method_exists($item, 'getChildren')
        ) {
            $forms = [];
            foreach ((array) $item->getChildren() as $child) {
                if (is_object($child)) {
                    array_push($forms, ...$this->mapGlpi11CatalogItem($child));
                }
            }
            return $forms;
        }

        return [];
    }

    /**
     * @return array<string, mixed>
     */
    private function mapGlpi11Form(object $form): array
    {
        $id = method_exists($form, 'getID') ? (int) $form->getID() : (int) ($form->fields['id'] ?? 0);
        $name = method_exists($form, 'getServiceCatalogItemTitle')
            ? (string) $form->getServiceCatalogItemTitle()
            : (string) ($form->fields['name'] ?? ('Formulario #' . $id));
        $description = method_exists($form, 'getServiceCatalogItemDescription')
            ? (string) $form->getServiceCatalogItemDescription()
            : (string) ($form->fields['description'] ?? '');
        $nativeUrl = method_exists($form, 'getServiceCatalogLink')
            ? (string) $form->getServiceCatalogLink()
            : Url::core('Form/Render/' . $id);
        $illustration = method_exists($form, 'getServiceCatalogItemIllustration')
            ? (string) $form->getServiceCatalogItemIllustration()
            : (string) ($form->fields['illustration'] ?? '');

        return [
            'id' => $id,
            'source' => 'glpi11_service_catalog',
            'source_label' => 'Service Catalog GLPI 11',
            'visual_kind' => 'glpi11',
            'illustration' => $illustration,
            'name' => TextNormalizer::fromGlpi($name) ?: ('Formulario #' . $id),
            'description' => TextNormalizer::fromGlpi($description),
            'entity_id' => (int) ($form->fields['entities_id'] ?? 0),
            'is_recursive' => !empty($form->fields['is_recursive']),
            'native_url' => $nativeUrl,
            'rendering_status' => 'native_fallback',
            'rendering_message' => 'Abertura e submissao pelo Service Catalog nativo para preservar controles de acesso, condicoes, validacoes e destinos.',
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $items
     * @return array<int, array<string, mixed>>
     */
    private function uniqueForms(array $items): array
    {
        $seen = [];
        $unique = [];
        foreach ($items as $item) {
            $id = (int) ($item['id'] ?? 0);
            $key = (string) ($item['source'] ?? '') . ':' . $id;
            if ($id <= 0 || isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $unique[] = $item;
        }

        return $unique;
    }

    /**
     * @return array{available:bool, enabled:bool, message:string, items:array<int, array<string, mixed>>}
     */
    private function listFormcreatorForms(): array
    {
        $formcreatorTable = $this->formcreatorTable();
        $available = class_exists('\PluginFormcreatorForm') || $this->tableExists($formcreatorTable);
        if ($available && !$this->isFormcreatorPluginActive()) {
            return [
                'available' => false,
                'enabled' => false,
                'message' => 'Formcreator detectado, mas nao ativo nesta instalacao.',
                'items' => [],
            ];
        }

        if (!$available) {
            return [
                'available' => false,
                'enabled' => false,
                'message' => 'Formcreator nao detectado nesta instalacao.',
                'items' => [],
            ];
        }

        $items = [];
        if (class_exists('\PluginFormcreatorForm')) {
            $items = $this->readFormcreatorFromCommonDBTM();
        }

        return [
            'available' => true,
            'enabled' => true,
            'message' => $items === []
                ? 'Formcreator detectado. Use o fluxo nativo para consultar formularios disponiveis ao perfil atual.'
                : 'Formularios do Formcreator detectados. A abertura usa o motor nativo do plugin ate homologacao completa do renderer acessivel.',
            'items' => $items,
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function readFormcreatorFromCommonDBTM(): array
    {
        $form = new \PluginFormcreatorForm();
        $rows = [];
        try {
            $table = $this->formcreatorTable();
            foreach ($form->find($this->activeCriteria($table), 'name ASC', 80) as $row) {
                $id = (int) ($row['id'] ?? 0);
                if ($id <= 0 || !$this->rowVisibleInCurrentEntity($row)) {
                    continue;
                }
                if (method_exists($form, 'canViewForRequest')) {
                    if (!$form->canViewForRequest($id)) {
                        continue;
                    }
                } elseif (method_exists($form, 'can') && !$form->can($id, READ)) {
                    continue;
                } else {
                    return [];
                }
                $rows[] = $this->mapFormRow(
                    $row,
                    'formcreator_glpi10',
                    'Formcreator GLPI 10',
                    Url::core('plugins/formcreator/front/formdisplay.php?id=' . $id)
                );
            }
        } catch (\Throwable $e) {
            return [];
        }

        return $rows;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function readRowsAsForms(string $table, string $source, string $sourceLabel, string $baseUrl, int $limit): array
    {
        global $DB;

        if (!isset($DB) || !method_exists($DB, 'request') || !$this->tableExists($table)) {
            return [];
        }

        $rows = [];
        try {
            foreach (
                $DB->request([
                'SELECT' => $this->selectColumns($table),
                'FROM' => $table,
                'WHERE' => $this->activeCriteria($table),
                'ORDER' => ['name ASC'],
                'LIMIT' => $limit,
                ]) as $row
            ) {
                $id = (int) ($row['id'] ?? 0);
                if ($id <= 0 || !$this->rowVisibleInCurrentEntity($row)) {
                    continue;
                }

                $nativeUrl = $source === 'formcreator_glpi10'
                    ? $baseUrl . '?id=' . $id
                    : $baseUrl;
                $rows[] = $this->mapFormRow($row, $source, $sourceLabel, $nativeUrl);
            }
        } catch (\Throwable $e) {
            return [];
        }

        return $rows;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private function mapFormRow(array $row, string $source, string $sourceLabel, string $nativeUrl): array
    {
        $id = (int) ($row['id'] ?? 0);
        $name = TextNormalizer::fromGlpi((string) ($row['name'] ?? $row['title'] ?? ('Formulario #' . $id)));
        $description = TextNormalizer::fromGlpi((string) ($row['description'] ?? $row['content'] ?? $row['comment'] ?? ''));

        return [
            'id' => $id,
            'source' => $source,
            'source_label' => $sourceLabel,
            'visual_kind' => $source === 'formcreator_glpi10' ? 'formcreator' : 'native',
            'illustration' => (string) ($row['illustration'] ?? ''),
            'name' => $name !== '' ? $name : ('Formulario #' . $id),
            'description' => $description,
            'entity_id' => (int) ($row['entities_id'] ?? 0),
            'is_recursive' => !empty($row['is_recursive']),
            'native_url' => $nativeUrl,
            'rendering_status' => 'native_fallback',
            'rendering_message' => 'Abertura e submissao pelo motor nativo para preservar condicoes, validacoes, destinos e anexos.',
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function activeCriteria(string $table): array
    {
        $criteria = [];
        if ($this->columnExists($table, 'is_deleted')) {
            $criteria['is_deleted'] = 0;
        }
        foreach (['is_active', 'is_enabled'] as $column) {
            if ($this->columnExists($table, $column)) {
                $criteria[$column] = 1;
                break;
            }
        }

        return $criteria;
    }

    /**
     * @return string[]
     */
    private function selectColumns(string $table): array
    {
        $columns = ['id'];
        foreach (['name', 'title', 'description', 'content', 'comment', 'entities_id', 'is_recursive', 'is_active', 'is_deleted'] as $column) {
            if ($this->columnExists($table, $column)) {
                $columns[] = $column;
            }
        }

        return array_values(array_unique($columns));
    }

    /**
     * @param array<string, mixed> $row
     */
    private function rowVisibleInCurrentEntity(array $row): bool
    {
        if (!array_key_exists('entities_id', $row)) {
            return true;
        }

        $entityId = (int) ($row['entities_id'] ?? 0);
        $activeEntity = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        if ($entityId === $activeEntity || $entityId === 0) {
            return true;
        }

        return !empty($row['is_recursive']) && in_array($entityId, $this->currentEntityTree(), true);
    }

    /**
     * @return int[]
     */
    private function currentEntityTree(): array
    {
        $activeEntities = $_SESSION['glpiactiveentities'] ?? [];
        if (is_array($activeEntities) && $activeEntities !== []) {
            $entities = [];
            foreach ($activeEntities as $key => $value) {
                $entities[] = is_numeric($value) ? (int) $value : (int) $key;
            }
            return array_values(array_unique(array_filter($entities, static fn(int $id): bool => $id >= 0)));
        }

        return [(int) ($_SESSION['glpiactive_entity'] ?? 0)];
    }

    private function formcreatorTable(): string
    {
        if (class_exists('\PluginFormcreatorForm') && method_exists('\PluginFormcreatorForm', 'getTable')) {
            return (string) \PluginFormcreatorForm::getTable();
        }

             return 'glpi_plugin_formcreator_forms';
    }

    private function isFormcreatorPluginActive(): bool
    {
        if (!class_exists('\Plugin')) {
            return true;
        }

        try {
            $plugin = new \Plugin();
            if (method_exists($plugin, 'isActivated')) {
                return (bool) $plugin->isActivated('formcreator');
            }
        } catch (\Throwable $e) {
            return true;
        }

        return true;
    }

    private function serviceCatalogUrl(): string
    {
        return Url::core('ServiceCatalog');
    }

    private function tableExists(string $table): bool
    {
        global $DB;

        return isset($DB) && method_exists($DB, 'tableExists') && (bool) $DB->tableExists($table);
    }

    private function columnExists(string $table, string $column): bool
    {
        global $DB;

        return isset($DB) && method_exists($DB, 'fieldExists') && (bool) $DB->fieldExists($table, $column);
    }
}
