<?php

require '../../../inc/includes.php';
require_once dirname(__DIR__) . '/hook.php';

\GlpiPlugin\Glpiacessivel\UI\Controller\KnowledgeController::index();
