<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class FormController extends BaseController
{
    public static function index(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_FORMS)) {
            return;
        }

        if (!self::container()->configService()->isFormsEnabled()) {
            self::setMessage('error', __('Formularios do portal acessivel estao desativados nas opcoes gerais do plugin.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/acessivel.php'));
            return;
        }

        $service = self::container()->formService();
        $forms = $service->listAvailableForms();

        View::render('forms/index', [
            'title' => __('Formularios', 'glpiacessivel'),
            'forms' => $forms,
            'formsNativeFlowMode' => self::container()->configService()->getFormsNativeFlowMode(),
            'showOperationalDiagnostics' => self::container()->authorization()->canViewFormDiagnostics(),
        ]);
    }


    public static function renderAccessible(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_FORMS)) {
            return;
        }

        if (!self::container()->configService()->isFormsEnabled()) {
            self::setMessage('error', __('Formularios do portal acessivel estao desativados nas opcoes gerais do plugin.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/acessivel.php'));
            return;
        }

        $sanitizer = new InputSanitizer();
        $source = $sanitizer->enum($_GET['source'] ?? '', ['glpi11_service_catalog', 'formcreator_glpi10'], '');
        $id = max(0, $sanitizer->int($_GET['id'] ?? 0, 0));

        if ($source === '' || $id <= 0) {
            self::setMessage('error', __('Formulario invalido ou indisponivel.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/forms.php'));
            return;
        }

        $form = self::container()->formService()->resolveForm($source, $id);
        if ($form === null) {
            self::setMessage('error', __('Formulario nao encontrado ou sem acesso no contexto atual.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/forms.php'));
            return;
        }

        $schema = is_array($form['dynamic_form_schema'] ?? null) ? $form['dynamic_form_schema'] : [];
        View::render('forms/render', [
            'title' => (string) ($form['name'] ?? __('Formulario', 'glpiacessivel')),
            'form' => $form,
            'schema' => $schema,
            'nativeUrl' => (string) ($form['native_url'] ?? Url::plugin('front/forms.php')),
            'formsNativeFlowMode' => self::container()->configService()->getFormsNativeFlowMode(),
            'showOperationalDiagnostics' => self::container()->authorization()->canViewFormDiagnostics(),
            'csrf_token' => self::csrf()->token(true),
        ]);
    }
    public static function open(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_FORMS)) {
            return;
        }

        if (!self::container()->configService()->isFormsEnabled()) {
            self::setMessage('error', __('Formularios do portal acessivel estao desativados nas opcoes gerais do plugin.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/acessivel.php'));
            return;
        }

        $sanitizer = new InputSanitizer();
        $source = $sanitizer->enum($_GET['source'] ?? '', ['glpi11_service_catalog', 'formcreator_glpi10'], '');
        $id = max(0, $sanitizer->int($_GET['id'] ?? 0, 0));

        if ($source === '' || $id <= 0) {
            self::setMessage('error', __('Formulario invalido ou indisponivel.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/forms.php'));
            return;
        }

        $form = self::container()->formService()->resolveForm($source, $id);
        if ($form === null) {
            self::setMessage('error', __('Formulario nao encontrado ou sem acesso no contexto atual.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/forms.php'));
            return;
        }

        \Html::redirect((string) ($form['native_url'] ?? Url::plugin('front/forms.php')));
    }
}
