(function () {
  'use strict';

  var axeLoadPromise = null;

  function loadAxe(sourceUrl) {
    if (window.axe && typeof window.axe.run === 'function') {
      return Promise.resolve(window.axe);
    }
    if (axeLoadPromise) {
      return axeLoadPromise;
    }
    if (!sourceUrl) {
      return Promise.reject(new Error('axe source is unavailable'));
    }

    axeLoadPromise = new Promise(function (resolve, reject) {
      var existing = document.getElementById('glpiacessivel-axe-core');
      if (existing) {
        existing.remove();
      }

      var script = document.createElement('script');
      var timeoutId = window.setTimeout(function () {
        script.remove();
        reject(new Error('axe load timed out'));
      }, 10000);

      function fail() {
        window.clearTimeout(timeoutId);
        script.remove();
        reject(new Error('axe load failed'));
      }

      script.id = 'glpiacessivel-axe-core';
      script.src = sourceUrl;
      script.async = true;
      script.onload = function () {
        window.clearTimeout(timeoutId);
        if (window.axe && typeof window.axe.run === 'function') {
          resolve(window.axe);
        } else {
          fail();
        }
      };
      script.onerror = fail;
      document.head.appendChild(script);
    }).catch(function (error) {
      axeLoadPromise = null;
      throw error;
    });

    return axeLoadPromise;
  }

  function appendText(parent, tag, text, className) {
    var node = document.createElement(tag);
    if (className) {
      node.className = className;
    }
    node.textContent = text;
    parent.appendChild(node);
    return node;
  }

  function renderFindingList(container, findings, messages, linkLabel) {
    if (!Array.isArray(findings) || findings.length === 0) {
      return;
    }

    var list = document.createElement('ol');
    list.className = 'glpiacessivel-a11y-audit-list';
    findings.forEach(function (finding) {
      var item = document.createElement('li');
      var heading = appendText(item, 'h3', finding.help || finding.id);
      var detail = appendText(item, 'p', (finding.impact || messages.impactUnknown) + ': ' + finding.description);
      detail.className = 'glpiacessivel-a11y-audit-detail';
      appendText(item, 'p', messages.affected.replace('{count}', String((finding.nodes || []).length)));
      if (finding.helpUrl) {
        var link = document.createElement('a');
        link.href = finding.helpUrl;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.textContent = linkLabel.replace('{rule}', finding.id);
        item.appendChild(link);
      }
      list.appendChild(item);
      heading.tabIndex = -1;
    });
    container.appendChild(list);
  }

  function renderResults(container, result, messages) {
    container.replaceChildren();
    appendText(
      container,
      'p',
      result.violations.length === 0
        ? messages.none
        : messages.complete.replace('{count}', String(result.violations.length)),
      'glpiacessivel-a11y-audit-summary'
    );
    renderFindingList(container, result.violations, messages, messages.rule);

    if (Array.isArray(result.incomplete) && result.incomplete.length > 0) {
      appendText(
        container,
        'p',
        messages.incomplete.replace('{count}', String(result.incomplete.length)),
        'glpiacessivel-a11y-audit-summary'
      );
      renderFindingList(container, result.incomplete, messages, messages.review);
    }

    appendText(container, 'p', messages.limit, 'glpiacessivel-a11y-audit-limit');
  }
  function init() {
    var button = document.querySelector('[data-glpiacessivel-a11y-audit]');
    var panel = document.getElementById('glpiacessivel-a11y-audit-panel');
    var results = document.getElementById('glpiacessivel-a11y-audit-results');
    var title = document.getElementById('glpiacessivel-a11y-audit-title');
    if (!(button instanceof HTMLButtonElement) || !(panel instanceof HTMLElement) || !(results instanceof HTMLElement) || !(title instanceof HTMLElement)) {
      return;
    }

    var closeButtons = panel.querySelectorAll('[data-glpiacessivel-a11y-audit-close]');
    var messages = {
      running: button.dataset.runningLabel || 'Auditoria em execucao.',
      failed: button.dataset.failedLabel || 'Nao foi possivel executar a auditoria local.',
      complete: button.dataset.completeLabel || 'Foram encontradas {count} regra(s) com violacao.',
      none: button.dataset.noneLabel || 'Nenhuma violacao automatizada foi encontrada nesta pagina.',
      incomplete: button.dataset.incompleteLabel || 'A auditoria encontrou {count} regra(s) que exigem revisao manual.',
      limit: button.dataset.limitLabel || 'O resultado e local e nao substitui avaliacao manual.',
      affected: button.dataset.affectedLabel || 'Elementos afetados: {count}.',
      rule: button.dataset.ruleLabel || 'Ver regra {rule}.',
      review: button.dataset.reviewLabel || 'Revisar regra {rule}.',
      impactUnknown: button.dataset.impactUnknownLabel || 'Impacto nao classificado'
    };
    var originalLabel = button.textContent;

    function closePanel() {
      panel.hidden = true;
      button.setAttribute('aria-expanded', 'false');
      button.focus();
    }

    closeButtons.forEach(function (closeButton) {
      closeButton.addEventListener('click', closePanel);
    });
    panel.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        event.preventDefault();
        closePanel();
      }
    });

    button.addEventListener('click', function () {
      button.disabled = true;
      button.setAttribute('aria-busy', 'true');
      button.textContent = messages.running;
      panel.hidden = false;
      panel.setAttribute('aria-busy', 'true');
      button.setAttribute('aria-expanded', 'true');
      results.setAttribute('role', 'status');
      results.setAttribute('aria-live', 'polite');
      results.replaceChildren();
      appendText(results, 'p', messages.running);
      title.focus();

      loadAxe(button.dataset.axeSourceUrl || '')
        .then(function (axe) {
          var auditRootSelector = document.getElementById('conteudo-principal')
            ? '#conteudo-principal'
            : 'html';

          return axe.run({
            include: [[auditRootSelector]],
            exclude: [['#glpiacessivel-a11y-audit-panel']]
          }, {
            runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22a', 'wcag22aa'] },
            resultTypes: ['violations', 'incomplete', 'passes']
          });
        })
        .then(function (result) {
          if (!panel.hidden) {
            renderResults(results, result, messages);
          }
        })
        .catch(function () {
          if (!panel.hidden) {
            results.setAttribute('role', 'alert');
            results.setAttribute('aria-live', 'assertive');
            results.replaceChildren();
            appendText(results, 'p', messages.failed);
          }
        })
        .finally(function () {
          panel.removeAttribute('aria-busy');
          button.disabled = false;
          button.removeAttribute('aria-busy');
          button.textContent = originalLabel;
        });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
