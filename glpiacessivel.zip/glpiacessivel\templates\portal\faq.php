<?php

$glpiacessivelHtmlLang = function_exists('glpiacessivel_html_lang') ? glpiacessivel_html_lang() : 'pt-BR';
if (!function_exists('glpiacessivel_faq_e')) {
    function glpiacessivel_faq_e($value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

$filters = is_array($overview['filters'] ?? null) ? $overview['filters'] : [];
$result = is_array($overview['result'] ?? null) ? $overview['result'] : ['items' => [], 'total' => 0, 'page' => 1, 'pages' => 1, 'page_size' => 10];
$article = is_array($overview['article'] ?? null) ? $overview['article'] : null;
$categories = is_array($overview['categories'] ?? null) ? $overview['categories'] : [];
$homeLists = is_array($overview['home_lists'] ?? null) ? $overview['home_lists'] : [];

$query = (string) ($filters['query'] ?? '');
$categoryId = (int) ($filters['category_id'] ?? 0);
$page = max(1, (int) ($result['page'] ?? 1));
$pages = max(1, (int) ($result['pages'] ?? 1));
$total = max(0, (int) ($result['total'] ?? 0));
$items = is_array($result['items'] ?? null) ? $result['items'] : [];
$hasSearch = ($query !== '' || $categoryId > 0);

if (!function_exists('glpiacessivel_faq_query')) {
    function glpiacessivel_faq_query(array $changes = []): string
    {
        global $query, $categoryId, $page;
        $params = [
            'q' => $query !== '' ? $query : null,
            'category' => $categoryId > 0 ? $categoryId : null,
            'page' => $page > 1 ? $page : null,
        ];
        foreach ($changes as $k => $v) {
            $params[$k] = $v;
        }

        return http_build_query(array_filter($params, static fn($v): bool => !($v === null || $v === '')));
    }
}
?>
<!doctype html>
<html lang="<?= htmlspecialchars($glpiacessivelHtmlLang, ENT_QUOTES, 'UTF-8') ?>">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>FAQ publica - Portal acessivel</title>
  <link rel="stylesheet" href="<?= glpiacessivel_faq_e($css) ?>" />
  <link rel="stylesheet" href="<?= glpiacessivel_faq_e($portalCss) ?>" />
</head>
<body class="glpiacessivel-login-page">
  <a class="glpiacessivel-skip-link" href="#faq-principal" aria-keyshortcuts="Alt+1">Ir para o conteudo</a>
  <a class="glpiacessivel-skip-link" href="#glpiacessivel-faq-header" aria-keyshortcuts="Alt+2">Ir para o menu</a>
  <a class="glpiacessivel-skip-link" href="#faq-search-form" aria-keyshortcuts="Alt+3">Ir para a busca</a>
  <div id="glpiacessivel-faq-live" class="glpiacessivel-sr-only" aria-live="polite" aria-atomic="true"></div>

  <header class="glpiacessivel-login-topbar" aria-label="Ferramentas de acessibilidade">
    <nav class="glpiacessivel-login-shortcuts" aria-label="Atalhos da pagina">
      <a href="#faq-principal" aria-keyshortcuts="Alt+1">Ir para o conteudo [1]</a>
      <a href="#glpiacessivel-faq-header" aria-keyshortcuts="Alt+2">Ir para o menu [2]</a>
      <a href="#faq-search-form" aria-keyshortcuts="Alt+3">Ir para a busca [3]</a>
    </nav>
    <div class="glpiacessivel-login-tools" role="toolbar" aria-label="Controles de acessibilidade">
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-theme aria-pressed="false" aria-keyshortcuts="Alt+T Control+Alt+Shift+T" aria-label="Alternar tema claro e noturno">Tema</button>
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-contrast aria-pressed="false" aria-keyshortcuts="Alt+C Control+Alt+Shift+K" aria-label="Ativar ou desativar alto contraste">Alto Contraste</button>
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-font="decrease" aria-keyshortcuts="Alt+-" aria-label="Diminuir tamanho da fonte">A-</button>
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-font="reset" aria-keyshortcuts="Alt+0" aria-label="Restaurar tamanho da fonte">A</button>
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-font="increase" aria-keyshortcuts="Alt++" aria-label="Aumentar tamanho da fonte">A+</button>
      <button
        type="button"
        class="glpiacessivel-login-tool"
        data-glpiacessivel-help
        aria-expanded="false"
        aria-controls="glpiacessivel-faq-help"
        aria-keyshortcuts="Alt+H Control+Alt+Shift+H"
      >Ajuda</button>
    </div>
  </header>

  <header id="glpiacessivel-faq-header" class="glpiacessivel-login-hero">
    <div class="glpiacessivel-login-brand">
      <div class="glpiacessivel-login-brand-icon" aria-hidden="true">
        <?php if (function_exists('plugin_glpiacessivel_portal_icon_markup')): ?>
          <?= plugin_glpiacessivel_portal_icon_markup() ?>
        <?php endif; ?>
      </div>
      <div>
        <h1>FAQ publica</h1>
        <p class="glpiacessivel-login-brand-copy">Consulte respostas frequentes sem autenticar.</p>
        <p class="glpiacessivel-login-brand-copy">Modo atual: <?= glpiacessivel_faq_e((string) ($accessibilityMode ?? 'hybrid')) ?>. A FAQ continua independente da interface nativa do GLPI.</p>
      </div>
    </div>
  </header>

  <main id="faq-principal" class="glpiacessivel-login-shell">
    <section class="glpiacessivel-login-panel" style="width:min(100%,980px)">
      <p>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_faq_e($loginUrl) ?>">Voltar para login</a>
      </p>

      <form method="get" action="<?= glpiacessivel_faq_e($baseUrl) ?>" class="glpiacessivel-kb-filters glpiacessivel-kb-filters-public" id="faq-search-form" role="search" aria-label="Pesquisar FAQ publica">
        <div class="glpiacessivel-field glpiacessivel-kb-field-search">
          <label for="q">Busca publica</label>
          <input id="q" type="text" name="q" value="<?= glpiacessivel_faq_e($query) ?>" placeholder="Ex: certificado digital" />
        </div>
        <div class="glpiacessivel-field glpiacessivel-kb-field-category">
          <label for="category">Categoria</label>
          <select id="category" name="category">
            <option value="0">Todas as categorias</option>
            <?php foreach ($categories as $category): ?>
              <option value="<?= (int) $category['id'] ?>"<?= ((int) $category['id'] === $categoryId) ? ' selected' : '' ?>>
                <?= glpiacessivel_faq_e((string) ($category['label'] ?? '')) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="glpiacessivel-kb-filter-actions">
          <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary">Pesquisar</button>
          <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_faq_e($baseUrl) ?>">Limpar</a>
        </div>
      </form>

      <section
        id="glpiacessivel-faq-help"
        class="glpiacessivel-login-help"
        aria-labelledby="glpiacessivel-faq-help-title"
        role="dialog"
        aria-modal="true"
        tabindex="-1"
        hidden
      >
        <div class="glpiacessivel-help-heading">
          <h2 id="glpiacessivel-faq-help-title">Ajuda de Acessibilidade</h2>
          <button type="button" class="glpiacessivel-help-close" data-glpiacessivel-help-close aria-label="Fechar ajuda">X</button>
        </div>
        <p>Atalhos disponiveis para facilitar a navegacao e a consulta da FAQ publica.</p>
        <div class="glpiacessivel-shortcut-table-wrap" tabindex="0">
          <table class="glpiacessivel-shortcut-table">
            <thead><tr><th>Atalho</th><th>Acao</th></tr></thead>
            <tbody>
              <tr><td><kbd>Alt</kbd> + <kbd>1</kbd></td><td>Ir para conteudo principal</td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>2</kbd></td><td>Ir para menu de navegacao</td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>3</kbd></td><td>Ir para campo de busca</td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>C</kbd></td><td>Alternar alto contraste</td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>T</kbd></td><td>Alternar tema claro/noturno</td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>-</kbd></td><td>Diminuir tamanho da fonte</td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>0</kbd></td><td>Restaurar tamanho da fonte</td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>+</kbd></td><td>Aumentar tamanho da fonte</td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>H</kbd><br><kbd>Ctrl</kbd> + <kbd>Alt</kbd> + <kbd>Shift</kbd> + <kbd>H</kbd></td><td>Abrir ou fechar ajuda de acessibilidade</td></tr>
            </tbody>
          </table>
        </div>
        <div class="glpiacessivel-help-notes" aria-label="Orientacoes complementares de acessibilidade">
          <section>
            <h3>Leitores de Tela</h3>
            <p>Este portal e otimizado para leitores de tela como NVDA, JAWS e VoiceOver.</p>
            <ul>
              <li><strong>Landmarks:</strong> use teclas de navegacao rapida do leitor de tela, como R no NVDA, para pular entre secoes.</li>
              <li><strong>Headings:</strong> use H para navegar por titulos.</li>
              <li><strong>Tabelas:</strong> navegue pelas celulas com os comandos de tabela do leitor, como Ctrl+Alt+Setas quando suportado.</li>
              <li><strong>Formularios:</strong> campos obrigatorios sao anunciados como obrigatorios.</li>
            </ul>
          </section>
          <section>
            <h3>Recursos Visuais</h3>
            <ul>
              <li><strong>Modo escuro:</strong> ative via botao Tema, Alt+T ou Ctrl+Alt+Shift+T.</li>
              <li><strong>Alto contraste:</strong> ative pela barra de acessibilidade, Alt+C ou Ctrl+Alt+Shift+K.</li>
              <li><strong>Foco visivel:</strong> bordas destacadas indicam o elemento ativo.</li>
              <li><strong>VLibras:</strong> traducao automatica para Lingua Brasileira de Sinais quando habilitada.</li>
            </ul>
          </section>
        </div>
        <div class="glpiacessivel-help-footer">
          <button type="button" class="glpiacessivel-button glpiacessivel-button-primary" data-glpiacessivel-help-close>Fechar</button>
        </div>
      </section>

      <?php if (!$hasSearch): ?>
        <div class="glpiacessivel-kb-home-grid">
          <section>
            <h3>Entradas recentes</h3>
            <ul class="glpiacessivel-kb-home-list">
              <?php foreach (($homeLists['recentes'] ?? []) as $item): ?>
                <li><a href="<?= glpiacessivel_faq_e($baseUrl . '?' . http_build_query(['article' => (int) ($item['id'] ?? 0)])) ?>"><?= glpiacessivel_faq_e((string) ($item['assunto'] ?? '')) ?></a></li>
              <?php endforeach; ?>
            </ul>
          </section>
          <section>
            <h3>Ultimas atualizadas</h3>
            <ul class="glpiacessivel-kb-home-list">
              <?php foreach (($homeLists['atualizadas'] ?? []) as $item): ?>
                <li><a href="<?= glpiacessivel_faq_e($baseUrl . '?' . http_build_query(['article' => (int) ($item['id'] ?? 0)])) ?>"><?= glpiacessivel_faq_e((string) ($item['assunto'] ?? '')) ?></a></li>
              <?php endforeach; ?>
            </ul>
          </section>
          <section>
            <h3>Mais populares</h3>
            <ul class="glpiacessivel-kb-home-list">
              <?php foreach (($homeLists['populares'] ?? []) as $item): ?>
                <li><a href="<?= glpiacessivel_faq_e($baseUrl . '?' . http_build_query(['article' => (int) ($item['id'] ?? 0)])) ?>"><?= glpiacessivel_faq_e((string) ($item['assunto'] ?? '')) ?></a></li>
              <?php endforeach; ?>
            </ul>
          </section>
        </div>
      <?php endif; ?>

      <?php if ($article !== null): ?>
        <section class="glpiacessivel-card glpiacessivel-kb-article">
          <h2><?= glpiacessivel_faq_e((string) ($article['assunto'] ?? 'Artigo')) ?></h2>
          <div class="glpiacessivel-content glpiacessivel-kb-reader">
            <?= (string) ($article['body_html'] ?? '') ?>
          </div>
        </section>
      <?php endif; ?>

      <?php if ($hasSearch): ?>
        <section class="glpiacessivel-card glpiacessivel-kb-results">
          <h2>Resultados (<?= (int) $total ?>)</h2>
          <div class="glpiacessivel-table-wrap">
            <table class="glpiacessivel-kb-table">
              <thead>
                <tr><th>Assunto</th><th>Categoria</th><th>Acoes</th></tr>
              </thead>
              <tbody>
                <?php foreach ($items as $item): ?>
                  <tr>
                    <td><strong><?= glpiacessivel_faq_e((string) ($item['assunto'] ?? '')) ?></strong><div class="glpiacessivel-help-text"><?= glpiacessivel_faq_e((string) ($item['summary'] ?? '')) ?></div></td>
                    <td><?= glpiacessivel_faq_e((string) ($item['category'] ?? 'Sem categoria')) ?></td>
                    <td><a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_faq_e($baseUrl . '?' . glpiacessivel_faq_query(['article' => (int) ($item['id'] ?? 0)])) ?>">Abrir</a></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
          <?php if ($pages > 1): ?>
            <nav class="glpiacessivel-pagination" aria-label="Paginacao da FAQ publica">
              <?php if ($page > 1): ?><a href="<?= glpiacessivel_faq_e($baseUrl . '?' . glpiacessivel_faq_query(['page' => $page - 1])) ?>">&laquo; Anterior</a><?php endif; ?>
              <span>Pagina <?= (int) $page ?> de <?= (int) $pages ?></span>
              <?php if ($page < $pages): ?><a href="<?= glpiacessivel_faq_e($baseUrl . '?' . glpiacessivel_faq_query(['page' => $page + 1])) ?>">Proxima &raquo;</a><?php endif; ?>
            </nav>
          <?php endif; ?>
        </section>
      <?php endif; ?>
    </section>
  </main>
  <script src="<?= glpiacessivel_faq_e((string) ($runtimeConfigJs ?? '')) ?>" data-glpiacessivel-runtime-config="1"></script>
  <script src="<?= glpiacessivel_faq_e((string) ($globalJs ?? '')) ?>"></script>
  <script>
    (function () {
      var body = document.body;
      var liveRegion = document.getElementById('glpiacessivel-faq-live');
      var storageKey = 'glpiacessivel-login-preferences-v2';
      var defaultPrefs = { theme: 'light', contrast: false, fontScale: 1 };
      var themeButton = document.querySelector('button[data-glpiacessivel-theme], [role="button"][data-glpiacessivel-theme]');
      var contrastButton = document.querySelector('button[data-glpiacessivel-contrast], [role="button"][data-glpiacessivel-contrast]');
      var helpButton = document.querySelector('button[data-glpiacessivel-help], [role="button"][data-glpiacessivel-help]');
      var helpPanel = document.getElementById('glpiacessivel-faq-help');
      var helpCloseButtons = document.querySelectorAll('[data-glpiacessivel-help-close]');

      function announce(message) {
        if (liveRegion) {
          liveRegion.textContent = message;
        }
      }

      function readPrefs() {
        try {
          var saved = window.localStorage.getItem(storageKey);
          if (!saved) {
            return defaultPrefs;
          }
          var parsed = JSON.parse(saved);
          return {
            theme: parsed.theme === 'night' ? 'night' : 'light',
            contrast: parsed.contrast === true,
            fontScale: parsed.fontScale === 0.9 || parsed.fontScale === 1.1 || parsed.fontScale === 1.2 ? parsed.fontScale : 1
          };
        } catch (error) {
          return defaultPrefs;
        }
      }

      function writePrefs(prefs) {
        try {
          window.localStorage.setItem(storageKey, JSON.stringify(prefs));
        } catch (error) {
          // Ignore storage restrictions on privacy modes.
        }
      }

      function applyPrefs(prefs) {
        body.dataset.glpiacessivelTheme = prefs.theme;
        body.dataset.glpiacessivelContrast = prefs.contrast ? 'high' : 'default';
        body.style.fontSize = prefs.fontScale + 'rem';

        if (themeButton) {
          themeButton.setAttribute('aria-pressed', prefs.theme === 'night' ? 'true' : 'false');
        }
        if (contrastButton) {
          contrastButton.setAttribute('aria-pressed', prefs.contrast ? 'true' : 'false');
        }
      }

      var helpLastFocus = null;

      function getHelpFocusableElements() {
        if (!helpPanel) {
          return [];
        }
        return Array.prototype.slice.call(helpPanel.querySelectorAll('a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'))
          .filter(function (element) {
            return element instanceof HTMLElement && !element.hidden && element.offsetParent !== null;
          });
      }

      function setHelpOpen(open) {
        if (!helpButton || !helpPanel) {
          return;
        }

        if (open) {
          helpLastFocus = document.activeElement instanceof HTMLElement ? document.activeElement : helpButton;
        }
        helpButton.setAttribute('aria-expanded', open ? 'true' : 'false');
        helpPanel.hidden = !open;

        if (open) {
          var closeButton = helpPanel.querySelector('[data-glpiacessivel-help-close]');
          if (closeButton) {
            closeButton.focus();
          } else {
            helpPanel.focus();
          }
        } else if (helpLastFocus && typeof helpLastFocus.focus === 'function') {
          helpLastFocus.focus();
        }
      }

      function announceExternal(externalLiveRegion, message) {
        announce(message);
        if (externalLiveRegion && externalLiveRegion !== liveRegion && 'textContent' in externalLiveRegion) {
          externalLiveRegion.textContent = message;
        }
      }

      window.glpiacessivelToggleTheme = function (externalLiveRegion) {
        if (!themeButton) {
          return false;
        }
        var contrastWasActive = prefs.contrast;
        if (contrastWasActive) {
          prefs.contrast = false;
        }
        prefs.theme = prefs.theme === 'light' ? 'night' : 'light';
        applyPrefs(prefs);
        writePrefs(prefs);
        var message = (prefs.theme === 'night' ? 'Tema noturno ativado.' : 'Tema claro ativado.') + (contrastWasActive ? ' Alto contraste desativado.' : '');
        announceExternal(externalLiveRegion, message);
        themeButton.focus();
        return true;
      };

      window.glpiacessivelToggleContrast = function (externalLiveRegion) {
        if (!contrastButton) {
          return false;
        }
        prefs.contrast = !prefs.contrast;
        applyPrefs(prefs);
        writePrefs(prefs);
        var message = prefs.contrast ? 'Alto contraste ativado.' : 'Alto contraste desativado.';
        announceExternal(externalLiveRegion, message);
        contrastButton.focus();
        return true;
      };

      window.glpiacessivelToggleHelp = function (externalLiveRegion) {
        if (!helpButton || !helpPanel) {
          return false;
        }
        var isOpen = helpButton.getAttribute('aria-expanded') === 'true';
        setHelpOpen(!isOpen);
        var message = !isOpen ? 'Painel de ajuda aberto.' : 'Painel de ajuda fechado.';
        announce(message);
        if (externalLiveRegion && externalLiveRegion !== liveRegion && 'textContent' in externalLiveRegion) {
          externalLiveRegion.textContent = message;
        }
        return true;
      };
      var prefs = readPrefs();
      applyPrefs(prefs);

      if (themeButton) {
        themeButton.addEventListener('click', function () {
          window.glpiacessivelToggleTheme();
        });
      }

      if (contrastButton) {
        contrastButton.addEventListener('click', function () {
          window.glpiacessivelToggleContrast();
        });
      }

      Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-font]')).forEach(function (button) {
        button.addEventListener('click', function () {
          var action = button.getAttribute('data-glpiacessivel-font');
          if (action === 'increase') {
            prefs.fontScale = Math.min(1.2, prefs.fontScale + 0.1);
          } else if (action === 'decrease') {
            prefs.fontScale = Math.max(0.9, prefs.fontScale - 0.1);
          } else {
            prefs.fontScale = 1;
          }
          applyPrefs(prefs);
          writePrefs(prefs);
          announce('Tamanho da fonte ajustado para ' + Math.round(prefs.fontScale * 100) + ' por cento.');
        });
      });

      if (helpButton && helpPanel) {
        helpButton.addEventListener('click', function () {
          var isOpen = helpButton.getAttribute('aria-expanded') === 'true';
          setHelpOpen(!isOpen);
          announce(!isOpen ? 'Painel de ajuda aberto.' : 'Painel de ajuda fechado.');
        });

        helpPanel.addEventListener('keydown', function (event) {
          if (event.key === 'Escape') {
            event.preventDefault();
            setHelpOpen(false);
            announce('Painel de ajuda fechado.');
            return;
          }

          if (event.key !== 'Tab') {
            return;
          }

          var focusable = getHelpFocusableElements();
          if (focusable.length === 0) {
            event.preventDefault();
            helpPanel.focus();
            return;
          }

          var first = focusable[0];
          var last = focusable[focusable.length - 1];
          if (event.shiftKey && document.activeElement === first) {
            event.preventDefault();
            last.focus();
          } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault();
            first.focus();
          }
        });

        Array.prototype.slice.call(helpCloseButtons).forEach(function (button) {
          button.addEventListener('click', function () {
            setHelpOpen(false);
            announce('Painel de ajuda fechado.');
          });
        });
      }
    })();
  </script>
</body>
</html>

