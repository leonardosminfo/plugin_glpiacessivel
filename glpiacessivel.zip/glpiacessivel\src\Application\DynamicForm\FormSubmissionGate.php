<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application\DynamicForm;

use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSchema;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSubmissionResult;

/** Prevents an accessible projection from bypassing the native form engine. */
final class FormSubmissionGate
{
    /** @return array<string, mixed> */
    public function inspect(DynamicFormSchema $schema): array
    {
        $capabilities = $schema->toArray()['capabilities'] ?? [];
        $contract = is_array($capabilities['capability_contract'] ?? null)
            ? $capabilities['capability_contract']
            : [];

        return [
            'allowed' => !empty($contract['own_submission_allowed']),
            'mode' => (string) ($contract['submission_mode'] ?? 'native_fallback'),
            'source' => $schema->source(),
            'blockers' => array_values(array_filter(array_map('strval', (array) ($contract['blockers'] ?? [])))),
        ];
    }

    public function reject(DynamicFormSchema $schema): DynamicFormSubmissionResult
    {
        $inspection = $this->inspect($schema);
        $message = $inspection['mode'] === 'native_delegated'
            ? 'O formulario deve ser concluido no motor nativo para preservar ACL, condicoes, validacoes e destinos.'
            : 'A submissao propria ainda nao foi homologada para este formulario. Use o fluxo nativo do GLPI.';

        return new DynamicFormSubmissionResult(false, [], '', [[
            'field' => '',
            'code' => 'native_fallback_required',
            'message' => $message,
        ]], [], [
            'gate' => $inspection,
            'native_url' => $schema->toArray()['fallback']['native_url'] ?? '',
        ]);
    }
}
