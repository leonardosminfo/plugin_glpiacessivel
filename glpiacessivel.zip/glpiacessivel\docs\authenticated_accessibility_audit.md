# Auditoria autenticada de acessibilidade

Este fluxo atende a homologacao sem senha ou token em variavel de ambiente.

## Axe local no portal

O comando `Auditar esta pagina` aparece somente para quem possui o direito GLPI `config/UPDATE`.
Ele carrega o Axe local do proprio plugin, avalia apenas o DOM que ja esta aberto na sessao atual e mantem o resultado na memoria da aba. Nao ha endpoint, telemetria, banco ou envio de conteudo.

Abra cada estado relevante antes de executar: telas, erros de validacao, modais, abas e alto contraste. Iframes nativos devem ser auditados na pagina de origem.

## Pa11y com login manual

Execute esta parte no checkout do repositorio, com as dependencias de desenvolvimento instaladas. Ela nao faz parte do ZIP de instalacao do plugin.

1. Execute `npm run a11y:capture-session`.
2. O Chrome ou Edge local abre em uma janela. Faca login manualmente em uma conta de homologacao; o capturador reconhece o login concluido e salva a sessao automaticamente.
3. A sessao e gravada em `.a11y/session.local.json`.
4. Execute `npm run a11y:pa11y`.
5. Os JSONs e capturas ficam em `.a11y/reports/`.

O arquivo de sessao contem cookies autenticados. Ele e ignorado pelo Git e deve permanecer com acesso apenas do auditor. Use uma conta de menor privilegio e remova a sessao ao fim:

```powershell
node tools/a11y/capture-session.cjs --clear
```

As rotas de leitura ficam em `tools/a11y/routes.local.example.json`. Copie esse arquivo para `tools/a11y/routes.local.json` para usar URLs ou IDs especificos da homologacao. O arquivo local tambem e ignorado pelo Git.

Para usar uma lista privada de rotas, informe um arquivo local fora do repositorio:

```powershell
npm run a11y:pa11y -- --routes C:\auditoria\rotas.json
```

O executor falha quando detectar redirecionamento para login. Ele nao cria, altera, aprova, soluciona nem exclui itens. Pa11y e Axe nao substituem testes por teclado, zoom/reflow, NVDA, JAWS ou VoiceOver.

Para os campos vazios #prompt e #content, as rotas de exemplo preenchem texto de teste somente no DOM. O artefato preserva awPa11yIssueCount, executa Axe direto para color-contrast e registra cor, fundo, borda, opacidade e razao calculada. Um achado so e removido do total bloqueador quando a verificacao direta confirma razao AA e nenhuma violacao Axe; o achado bruto permanece no relatorio como candidato a falso positivo.
