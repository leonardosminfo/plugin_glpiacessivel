<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

final class LoginSourceDiscovery
{
    /**
     * Discover the authentication sources through GLPI's native renderer. No
     * recursive HTTP request is made, so cookies, TLS and virtual-host routing
     * remain entirely inside the current request.
     *
     * @return array{
     *     mode: 'none'|'hidden'|'select',
     *     value: string,
     *     options: list<array{value: string, label: string, selected: bool, disabled: bool}>
     * }
     */
    public static function discover(string $loginAction): array
    {
        $fallback = [
            'mode' => 'none',
            'value' => '',
            'options' => [],
        ];

        if ($loginAction === '') {
            return $fallback;
        }

        $requested = isset($_REQUEST['auth']) ? trim((string) $_REQUEST['auth']) : '';
        if ($requested !== '' && preg_match('/^[A-Za-z0-9_.:-]{1,120}$/D', $requested) !== 1) {
            $requested = '';
        }

        $field = self::nativeAuthField();
        if ($field === null) {
            if ($requested === '') {
                return $fallback;
            }

            return [
                'mode' => 'hidden',
                'value' => $requested,
                'options' => [],
            ];
        }

        if ($requested !== '') {
            $matched = false;
            foreach ($field['options'] as &$option) {
                $selected = !$option['disabled'] && $option['value'] === $requested;
                $option['selected'] = $selected;
                $matched = $matched || $selected;
            }
            unset($option);

            if ($matched || $field['mode'] === 'hidden') {
                $field['value'] = $requested;
            }
        }

        return $field;
    }

    /**
     * @return array{
     *     mode: 'hidden'|'select',
     *     value: string,
     *     options: list<array{value: string, label: string, selected: bool, disabled: bool}>
     * }|null
     */
    private static function nativeAuthField(): ?array
    {
        if (!class_exists('\Auth') || !method_exists('\Auth', 'dropdownLogin')) {
            return null;
        }

        try {
            $html = (string) \Auth::dropdownLogin(false, random_int(1, 999999));
        } catch (\Throwable $e) {
            return null;
        }

        return self::parseAuthField($html);
    }

    /**
     * @return array{
     *     mode: 'hidden'|'select',
     *     value: string,
     *     options: list<array{value: string, label: string, selected: bool, disabled: bool}>
     * }|null
     */
    private static function parseAuthField(string $html): ?array
    {
        if ($html === '' || !class_exists('\DOMDocument')) {
            return null;
        }

        $dom = new \DOMDocument();
        $previous = libxml_use_internal_errors(true);
        try {
            if (!$dom->loadHTML('<?xml encoding="UTF-8">' . $html)) {
                return null;
            }
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }

        $xpath = new \DOMXPath($dom);
        $hidden = $xpath->query('//input[@name="auth" and @type="hidden"]');
        if ($hidden instanceof \DOMNodeList && $hidden->length > 0) {
            $value = trim((string) $hidden->item(0)?->attributes?->getNamedItem('value')?->nodeValue);
            if ($value !== '') {
                return [
                    'mode' => 'hidden',
                    'value' => $value,
                    'options' => [],
                ];
            }
        }

        $selects = $xpath->query('//select[@name="auth"]');
        if (!$selects instanceof \DOMNodeList || $selects->length === 0) {
            return null;
        }

        $select = $selects->item(0);
        if (!$select instanceof \DOMElement) {
            return null;
        }

        $options = [];
        $selectedValue = '';
        $enabledCount = 0;
        foreach ($select->getElementsByTagName('option') as $optionNode) {
            $value = trim((string) $optionNode->getAttribute('value'));
            $label = trim(preg_replace('/\s+/u', ' ', $optionNode->textContent ?? '') ?? '');
            $selected = $optionNode->hasAttribute('selected');
            $disabled = $optionNode->hasAttribute('disabled');

            if ($selected && !$disabled) {
                $selectedValue = $value;
            }
            if (!$disabled && $value !== '') {
                $enabledCount++;
            }

            $options[] = [
                'value' => $value,
                'label' => $label !== '' ? $label : $value,
                'selected' => $selected,
                'disabled' => $disabled,
            ];
        }

        if ($selectedValue === '') {
            foreach ($options as $option) {
                if (!$option['disabled'] && $option['value'] !== '') {
                    $selectedValue = $option['value'];
                    break;
                }
            }
        }
        if ($selectedValue === '') {
            return null;
        }

        foreach ($options as &$option) {
            $option['selected'] = $option['value'] === $selectedValue;
        }
        unset($option);

        return [
            'mode' => $enabledCount > 1 ? 'select' : 'hidden',
            'value' => $selectedValue,
            'options' => $options,
        ];
    }
}
