<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\DynamicForm;

interface DynamicFormAdapterInterface
{
    public function source(): string;

    /**
     * @param array<string, mixed> $context
     */
    public function supports(array $context): bool;

    /**
     * @param array<string, mixed> $context
     */
    public function getSchema(array $context): DynamicFormSchema;

    /**
     * @param array<string, mixed> $answers
     * @return array<int, array{field:string, code:string, message:string}>
     */
    public function validate(array $answers, DynamicFormSchema $schema): array;

    /**
     * @param array<string, mixed> $answers
     */
    public function submit(array $answers, DynamicFormSchema $schema): DynamicFormSubmissionResult;

    public function nativeUrl(): string;

    /**
     * @return array<string, mixed>
     */
    public function capabilities(): array;
}
