<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

use GlpiPlugin\Glpiacessivel\Infrastructure\Compliance\SchemaManager;

final class Bootstrap
{
    private static bool $initialized = false;

    public static function init(): void
    {
        if (self::$initialized) {
            return;
        }

        self::$initialized = true;
    }

    public static function install(): bool
    {
        global $DB;
        $schema = new SchemaManager($DB);
        return $schema->install();
    }

    public static function uninstall(): bool
    {
        global $DB;
        $schema = new SchemaManager($DB);
        return $schema->uninstall();
    }
}
