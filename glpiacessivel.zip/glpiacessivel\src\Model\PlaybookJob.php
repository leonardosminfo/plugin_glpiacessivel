<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Model;

final class PlaybookJob extends \CommonDBTM
{
    public static function getTypeName($nb = 0): string
    {
        return __('Varredura de roteiros do chatbot', 'glpiacessivel');
    }

    public static function getTable($classname = null): string
    {
        return 'glpi_plugin_glpiacessivel_playbookjobs';
    }
}
