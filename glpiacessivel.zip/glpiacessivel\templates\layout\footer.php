</main>
<?php if (($glpiacessivelStandaloneLayout ?? false) === true): ?>
  <script src="<?= htmlspecialchars((string) ($standaloneJs ?? ''), ENT_QUOTES, 'UTF-8') ?>"></script>
  <script src="<?= htmlspecialchars((string) ($standaloneAuditJs ?? ''), ENT_QUOTES, 'UTF-8') ?>"></script>
</body>
</html>
<?php else: ?>
<?php Html::footer(); ?>
<?php endif; ?>

