<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Domain\Security\Authorization;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\TicketRepository;

final class KnowledgeBaseService
{
    /** @var AuditLogger */
    private $auditLogger;
    /** @var Authorization */
    private $authorization;

    public function __construct(AuditLogger $auditLogger, Authorization $authorization)
    {
        $this->auditLogger = $auditLogger;
        $this->authorization = $authorization;
    }

    public function overview(array $filters): array
    {
        $repository = new TicketRepository();

        $query = trim((string) ($filters['query'] ?? ''));
        $categoryId = max(0, (int) ($filters['category_id'] ?? 0));
        $publicOnly = (bool) ($filters['public_only'] ?? false);
        if (!$publicOnly && !$this->authorization->canViewKnowledgeBaseFull()) {
            $publicOnly = true;
        }
        $page = max(1, (int) ($filters['page'] ?? 1));
        $pageSize = max(1, min(20, (int) ($filters['page_size'] ?? 10)));
        $articleId = max(0, (int) ($filters['article_id'] ?? 0));

        $result = $repository->searchKnowledgeArticles([
            'query' => $query,
            'category_id' => $categoryId,
            'public_only' => $publicOnly,
            'page' => $page,
            'page_size' => $pageSize,
        ]);

        $article = $articleId > 0 ? $repository->getKnowledgeArticle($articleId, $publicOnly) : null;
        $homeLists = $repository->getKnowledgeHomeLists($publicOnly, 5);
        $categories = $repository->getKnowledgeCategories($publicOnly, 200);

        $this->auditLogger->log('kb.overview', [
            'query_len' => strlen($query),
            'category_id' => $categoryId,
            'public_only' => $publicOnly ? 1 : 0,
            'page' => $page,
            'count' => count($result['items'] ?? []),
            'article_id' => $articleId,
        ]);

        return [
            'filters' => [
                'query' => $query,
                'category_id' => $categoryId,
                'public_only' => $publicOnly,
                'page' => $page,
                'page_size' => $pageSize,
                'article_id' => $articleId,
            ],
            'result' => $result,
            'article' => $article,
            'categories' => $categories,
            'home_lists' => $homeLists,
        ];
    }

    public function getArticle(int $articleId): ?array
    {
        if ($articleId <= 0) {
            return null;
        }

        return (new TicketRepository())->getKnowledgeArticle(
            $articleId,
            !$this->authorization->canViewKnowledgeBaseFull()
        );
    }

    public function search(string $query, int $limit = 30): array
    {
        $result = (new TicketRepository())->searchKnowledgeArticles([
            'query' => $query,
            'page' => 1,
            'page_size' => $limit,
            'public_only' => !$this->authorization->canViewKnowledgeBaseFull(),
        ]);

        $this->auditLogger->log('kb.search', [
            'query_len' => strlen($query),
            'total' => (int) ($result['total'] ?? 0),
        ]);

        return $result['items'] ?? [];
    }
}
