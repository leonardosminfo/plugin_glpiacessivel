# Release 0.2-beta - public GitHub beta

## Purpose

This release consolidates the accessible GLPI 10/11 portal as a public beta for controlled pilots and community review. It is a pre-release, not a declaration of full Marketplace or production certification.

## Included

- accessible portal, ticket list/detail/create flows and knowledge base;
- operational chatbot with GLPI ACL, CSRF and structured confirmation boundaries;
- delegated GLPI 11 Service Catalog and GLPI 10 Formcreator entry points;
- configurable portal modules and chatbot public name;
- keyboard, reflow, high contrast, forced-colors and screen-reader-oriented semantics;
- pt-BR catalog and partial en-GB catalog;
- operational, security and accessibility documentation.

## Public package policy

The main asset is `glpiacessivel.zip`, generated with the `marketplace` profile. It has one root directory named `glpiacessivel` and excludes tests, development dependencies, local reports and offline speech binaries whose redistribution evidence is incomplete.

Publish these assets with tag `v0.2-beta`:

- `glpiacessivel.zip`;
- `SHA256SUMS`.

## Known beta limits

- complete GLPI 10/11 validation still depends on real profiles, entities and representative datasets;
- complex dynamic forms continue to delegate final validation and submission to the native GLPI/Formcreator engine when equivalence is not proven;
- English translation requires community review and may fall back to pt-BR;
- automated accessibility checks do not replace NVDA, JAWS or VoiceOver validation;
- offline speech models are not distributed in the public package.

## Validation baseline

- PHPUnit: 101 tests and 448 assertions;
- PHPStan: no errors;
- PHPCS: no errors, with historical line-length warnings excluded from the release gate;
- gettext catalogs recompiled and checked with msgfmt;
- package root, forbidden paths, version metadata and SHA-256 verified automatically.

## Upgrade

1. Back up the database and the previous plugin directory.
2. Replace the directory with the contents of `glpiacessivel.zip`.
3. Run the GLPI plugin update.
4. Review plugin settings and module availability states.
5. Clear GLPI/browser caches.
6. Validate Self-Service, technician/hotliner and Super-Admin profiles before a wider pilot.
