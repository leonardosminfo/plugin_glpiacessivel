<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\DynamicForm;

final class DynamicFormCondition
{
    /**
     * @param array<string, mixed> $expression
     */
    public function __construct(
        private string $id,
        private string $targetField,
        private string $effect,
        private array $expression,
        private bool $supported = true,
        private string $fallbackReason = ''
    ) {
    }

    public function isSupported(): bool
    {
        return $this->supported;
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'target_field' => $this->targetField,
            'effect' => $this->effect,
            'expression' => $this->expression,
            'supported' => $this->supported,
            'fallback_reason' => $this->fallbackReason,
        ];
    }
}
