<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

final class UploadedFileMapper
{
    /** @var array<string, string> */
    private static array $pendingFiles = [];
    private static bool $shutdownRegistered = false;
    /**
     * @return array{_filename: string[], _tag_filename: string[], _prefix_filename: string[]}
     */
    public static function map(string $fieldName): array
    {
        $files = $_FILES[$fieldName] ?? null;
        if (!is_array($files) || !defined('GLPI_TMP_DIR')) {
            return self::emptyPayload();
        }

        $names = self::normalizeFiles($files);
        if ($names === []) {
            return self::emptyPayload();
        }

        if (!is_dir(GLPI_TMP_DIR) || !is_writable(GLPI_TMP_DIR)) {
            throw new \RuntimeException('Diretorio temporario do GLPI indisponivel para anexos.');
        }

        $payload = self::emptyPayload();
        try {
            foreach ($names as $file) {
                if ((int) $file['error'] === UPLOAD_ERR_NO_FILE) {
                    continue;
                }
                if ((int) $file['error'] !== UPLOAD_ERR_OK) {
                    throw new \RuntimeException(self::messageForUploadError((int) $file['error'], (string) ($file['name'] ?? '')));
                }
                if (!is_uploaded_file((string) $file['tmp_name'])) {
                    throw new \RuntimeException('Upload de anexo invalido.');
                }

                $originalName = self::sanitizeFilename((string) $file['name']);
                if ($originalName === '') {
                    $originalName = 'anexo';
                }

                if (class_exists('\Document') && method_exists('\Document', 'isValidDoc')) {
                    $extension = \Document::isValidDoc($originalName);
                    if (!$extension) {
                        throw new \RuntimeException('Tipo de anexo nao permitido pelo GLPI: ' . $originalName);
                    }
                }

                $prefix = 'glpiacessivel_' . bin2hex(random_bytes(8)) . '_';
                $storedName = $prefix . $originalName;
                $target = rtrim((string) GLPI_TMP_DIR, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $storedName;

                if (!move_uploaded_file((string) $file['tmp_name'], $target)) {
                    throw new \RuntimeException('Nao foi possivel preparar o anexo para o GLPI.');
                }

                $payload['_filename'][] = $storedName;
                $payload['_tag_filename'][] = '';
                $payload['_prefix_filename'][] = $prefix;
                self::$pendingFiles[$storedName] = $target;
                self::registerCleanup();
            }
        } catch (\Throwable $e) {
            self::cleanup($payload);
            throw $e;
        }

        return $payload;
    }

    public static function cleanup(array $payload): void
    {
        if (!defined('GLPI_TMP_DIR')) {
            return;
        }

        $base = rtrim((string) GLPI_TMP_DIR, DIRECTORY_SEPARATOR);
        foreach ((array) ($payload['_filename'] ?? []) as $storedName) {
            $storedName = (string) $storedName;
            if ($storedName === '' || basename($storedName) !== $storedName || !str_starts_with($storedName, 'glpiacessivel_')) {
                continue;
            }

            $target = $base . DIRECTORY_SEPARATOR . $storedName;
            if (is_file($target)) {
                @unlink($target);
            }
            unset(self::$pendingFiles[$storedName]);
        }
    }

    public static function commit(array $payload): void
    {
        foreach ((array) ($payload['_filename'] ?? []) as $storedName) {
            unset(self::$pendingFiles[(string) $storedName]);
        }
    }

    public static function cleanupPending(): void
    {
        foreach (self::$pendingFiles as $storedName => $target) {
            if (str_starts_with($storedName, 'glpiacessivel_') && is_file($target)) {
                @unlink($target);
            }
        }
        self::$pendingFiles = [];
    }

    private static function registerCleanup(): void
    {
        if (self::$shutdownRegistered) {
            return;
        }

        register_shutdown_function([self::class, 'cleanupPending']);
        self::$shutdownRegistered = true;
    }

    public static function messageForUploadError(int $error, string $filename = ''): string
    {
        $name = trim($filename) !== '' ? ': ' . self::sanitizeFilename($filename) : '';
        return match ($error) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Arquivo de anexo excede o limite permitido pelo GLPI' . $name . '.',
            UPLOAD_ERR_PARTIAL => 'Upload de anexo incompleto' . $name . '. Selecione o arquivo novamente.',
            UPLOAD_ERR_NO_TMP_DIR => 'Diretorio temporario indisponivel para upload de anexo.',
            UPLOAD_ERR_CANT_WRITE => 'Nao foi possivel gravar o anexo no diretorio temporario do GLPI.',
            UPLOAD_ERR_EXTENSION => 'Upload de anexo bloqueado por extensao do PHP.',
            default => 'Falha no upload de anexo' . $name . '.',
        };
    }

    public static function mergeInto(array $input, array $filesPayload): array
    {
        foreach (['_filename', '_tag_filename', '_prefix_filename'] as $key) {
            if (!empty($filesPayload[$key]) && is_array($filesPayload[$key])) {
                $input[$key] = array_values(array_merge((array) ($input[$key] ?? []), $filesPayload[$key]));
            }
        }

        return $input;
    }

    /**
     * @return array{_filename: string[], _tag_filename: string[], _prefix_filename: string[]}
     */
    private static function emptyPayload(): array
    {
        return [
            '_filename' => [],
            '_tag_filename' => [],
            '_prefix_filename' => [],
        ];
    }

    /**
     * @return array<int, array{name:string,type:string,tmp_name:string,error:int,size:int}>
     */
    private static function normalizeFiles(array $files): array
    {
        if (!isset($files['name'])) {
            return [];
        }

        if (!is_array($files['name'])) {
            return [[
                'name' => (string) ($files['name'] ?? ''),
                'type' => (string) ($files['type'] ?? ''),
                'tmp_name' => (string) ($files['tmp_name'] ?? ''),
                'error' => (int) ($files['error'] ?? UPLOAD_ERR_NO_FILE),
                'size' => (int) ($files['size'] ?? 0),
            ]];
        }

        $normalized = [];
        foreach ($files['name'] as $index => $name) {
            $normalized[] = [
                'name' => (string) $name,
                'type' => (string) ($files['type'][$index] ?? ''),
                'tmp_name' => (string) ($files['tmp_name'][$index] ?? ''),
                'error' => (int) ($files['error'][$index] ?? UPLOAD_ERR_NO_FILE),
                'size' => (int) ($files['size'][$index] ?? 0),
            ];
        }

        return $normalized;
    }

    private static function sanitizeFilename(string $filename): string
    {
        $filename = basename(str_replace('\\', '/', $filename));
        if (class_exists('\Toolbox') && method_exists('\Toolbox', 'filename')) {
            return (string) \Toolbox::filename($filename);
        }

        return preg_replace('/[^A-Za-z0-9._-]+/', '_', $filename) ?? '';
    }
}
