<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\Support\UploadedFileMapper;
use GlpiPlugin\Glpiacessivel\Support\FormValidationException;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class TicketController extends BaseController
{
    private const PII_REVEAL_TTL_SECONDS = 300;
    private const CRITICAL_CONFIRM_TTL_SECONDS = 300;
    private const CRITICAL_CONFIRM_SESSION_KEY = 'glpiacessivel_ticket_critical_confirmations';

    public static function index(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }

        $sanitizer = new InputSanitizer();
        $filters = [
            'scope' => $sanitizer->enum($_GET['scope'] ?? 'all', ['all', 'mine', 'group'], 'all'),
            'status' => $sanitizer->text($_GET['status'] ?? '', 4),
            'q' => $sanitizer->text($_GET['q'] ?? '', 120),
            'group_id' => max(0, $sanitizer->int($_GET['group_id'] ?? 0, 0)),
            'group_by' => $sanitizer->enum($_GET['group_by'] ?? 'none', ['none', 'group'], 'none'),
            'page' => max(1, $sanitizer->int($_GET['page'] ?? 1, 1)),
            'page_size' => $sanitizer->int($_GET['page_size'] ?? 20, 20),
            'sort' => $sanitizer->enum($_GET['sort'] ?? 'date_mod', ['id', 'name', 'status', 'priority', 'date', 'date_mod'], 'date_mod'),
            'direction' => $sanitizer->enum($_GET['direction'] ?? 'DESC', ['ASC', 'DESC'], 'DESC'),
        ];

        $service = self::container()->ticketService();
        $result = $service->list($filters);
        $groupOptions = $service->groupFilterOptions((array) ($result['items'] ?? []));
        $groupedItems = self::groupTicketsByGroup((array) ($result['items'] ?? []), (string) $filters['scope'], (string) $filters['group_by']);

        View::render('tickets/list', [
            'title' => __('Chamados', 'glpiacessivel'),
            'result' => $result,
            'filters' => $filters,
            'group_options' => $groupOptions,
            'grouped_items' => $groupedItems,
            'showOperationalDiagnostics' => self::container()->authorization()->canViewOperationalDiagnostics(),
            'csrf_token' => self::csrf()->token(),
        ]);
    }

    public static function create(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKET_CREATE)) {
            return;
        }

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            self::csrf()->validateRequest(true);
            self::storeCreate();
            return;
        }

        self::renderCreateForm(self::defaultCreateValues(), []);
    }

    public static function detail(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }

        $sanitizer = new InputSanitizer();
        $ticketId = max(1, $sanitizer->int($_GET['id'] ?? 0));

        $service = self::container()->ticketService();
        $ticket = $service->detail($ticketId, self::getRevealedFields($ticketId));
        if ($ticket === null) {
            throw new \RuntimeException('Chamado nao encontrado ou sem acesso.');
        }

        View::render('tickets/detail', [
            'title' => __('Detalhe do chamado', 'glpiacessivel'),
            'ticket' => $ticket,
            'csrf_token' => self::csrf()->token(true),
            'csrf_tokens' => [
                'followup' => self::csrf()->token(true),
                'task' => self::csrf()->token(true),
                'solution' => self::csrf()->token(true),
                'status' => self::csrf()->token(true),
                'routing' => self::csrf()->token(true),
                'requester_decision' => self::csrf()->token(true),
                'solution_decision' => self::csrf()->token(true),
                'pii_reveal' => self::csrf()->token(true),
            ],
            'critical_confirmations' => self::ticketCriticalConfirmationTokens($ticketId),
        ]);
    }

    public static function action(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }

        $sanitizer = new InputSanitizer();
        $ticketId = max(1, $sanitizer->int($_POST['ticket_id'] ?? 0));

        try {
            self::csrf()->validateRequest(true);
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('csrf.failed', [
                'endpoint' => 'ticket.action',
                'exception' => get_class($e),
                'action_name' => (string) ($_POST['action'] ?? ''),
            ], $ticketId);

            self::setMessage(
                'error',
                __('Sua sessao expirou ou o token de seguranca venceu. Recarregue o chamado e tente novamente.', 'glpiacessivel')
            );
            \Html::redirect(Url::plugin('front/ticket.php?id=' . $ticketId));
            return;
        }

        $action = $sanitizer->enum($_POST['action'] ?? '', ['followup', 'task', 'solution', 'status', 'routing', 'requester_decision', 'solution_approve', 'solution_refuse', 'pii_reveal'], '');
        $content = $sanitizer->text($_POST['content'] ?? '', 16000);
        $status = $sanitizer->int($_POST['status'] ?? 0);
        $decision = $sanitizer->int($_POST['decision'] ?? 0, 0);
        $routingReason = $sanitizer->text($_POST['routing_reason'] ?? '', 255);
        $followupTemplateId = max(0, $sanitizer->int($_POST['itilfollowuptemplates_id'] ?? 0, 0));
        $piiField = $sanitizer->enum(
            $_POST['pii_field'] ?? '',
            ['requester_email', 'requester_phone', 'requester_mobile'],
            ''
        );
        $piiReason = $sanitizer->text($_POST['pii_reason'] ?? '', 255);
        $taskInput = [
            'state' => max(0, $sanitizer->int($_POST['task_state'] ?? 0, 0)),
            'taskcategories_id' => max(0, $sanitizer->int($_POST['taskcategories_id'] ?? 0, 0)),
            'users_id_tech' => max(0, $sanitizer->int($_POST['task_users_id_tech'] ?? 0, 0)),
            'groups_id_tech' => max(0, $sanitizer->int($_POST['task_groups_id_tech'] ?? 0, 0)),
            'actiontime' => max(0, $sanitizer->int($_POST['task_actiontime'] ?? 0, 0)),
            'begin' => $sanitizer->text($_POST['task_begin'] ?? '', 32),
            'end' => $sanitizer->text($_POST['task_end'] ?? '', 32),
            'is_private' => !empty($_POST['task_is_private']) ? 1 : 0,
        ];

        if (self::isCriticalTicketAction($action)) {
            try {
                self::validateTicketCriticalConfirmation($ticketId, $action, $_POST);
            } catch (\Throwable $e) {
                self::container()->auditLogger()->log('ticket.critical_confirmation.blocked', [
                    'action' => $action,
                    'reason' => $e->getMessage(),
                ], $ticketId);
                self::setMessage('error', __('Confirme a acao critica na tela antes de executar.', 'glpiacessivel'));
                \Html::redirect(Url::plugin('front/ticket.php?id=' . $ticketId));
                return;
            }
        }

        $service = self::container()->ticketService();

        try {
            $ok = false;
            switch ($action) {
                case 'followup':
                    $ok = $service->addFollowup($ticketId, $content, UploadedFileMapper::map('followup_filename'), $followupTemplateId);
                    break;
                case 'task':
                    $ok = $service->addTask($ticketId, $content, $taskInput, UploadedFileMapper::map('task_filename'));
                    break;
                case 'solution':
                    $ok = $service->addSolution($ticketId, $content);
                    break;
                case 'status':
                    $ok = $service->changeStatus($ticketId, $status);
                    break;
                case 'routing':
                    $ok = $service->escalateTicketRouting(
                        $ticketId,
                        array_values(array_filter(array_map('intval', (array) ($_POST['_users_id_assign'] ?? [])))),
                        array_values(array_filter(array_map('intval', (array) ($_POST['_users_id_observer'] ?? [])))),
                        $routingReason,
                        array_values(array_filter(array_map('intval', (array) ($_POST['_groups_id_assign'] ?? []))))
                    );
                    break;
                case 'requester_decision':
                    $ok = $service->registerRequesterDecision($ticketId, $decision, $content);
                    break;
                case 'solution_approve':
                    $ok = $service->approveSolution($ticketId, $content, UploadedFileMapper::map('solution_decision_filename'));
                    break;
                case 'solution_refuse':
                    $ok = $service->refuseSolution($ticketId, $content, UploadedFileMapper::map('solution_decision_filename'));
                    break;
                case 'pii_reveal':
                    if ($piiField === '') {
                        throw new \RuntimeException('Selecione o dado que precisa ser revelado.');
                    }
                    $service->revealPii($ticketId, $piiField, $piiReason);
                    self::grantTemporaryReveal($ticketId, $piiField);
                    $ok = true;
                    break;
            }

            self::setMessage(
                $ok ? 'success' : 'error',
                $ok ? __('Acao executada com sucesso.', 'glpiacessivel') : __('Nao foi possivel executar a acao.', 'glpiacessivel')
            );
        } catch (\Throwable $e) {
            self::setMessage('error', $e->getMessage());
        }

        \Html::redirect(Url::plugin('front/ticket.php?id=' . $ticketId));
    }

    /**
     * @return array<string, string>
     */
    private static function ticketCriticalConfirmationTokens(int $ticketId): array
    {
        self::purgeExpiredTicketCriticalConfirmations();
        $actions = ['solution', 'status', 'requester_decision', 'solution_approve', 'solution_refuse'];
        $tokens = [];
        foreach ($actions as $action) {
            $token = bin2hex(random_bytes(16));
            $tokens[$action] = $token;
            $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY][$token] = [
                'ticket_id' => $ticketId,
                'action' => $action,
                'user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'expires_at' => time() + self::CRITICAL_CONFIRM_TTL_SECONDS,
            ];
        }

        return $tokens;
    }

    private static function isCriticalTicketAction(string $action): bool
    {
        return in_array($action, ['solution', 'status', 'requester_decision', 'solution_approve', 'solution_refuse'], true);
    }

    /**
     * @param array<string, mixed> $post
     */
    private static function validateTicketCriticalConfirmation(int $ticketId, string $action, array $post): void
    {
        if ((string) ($post['critical_confirmed'] ?? '') !== '1') {
            throw new \RuntimeException('missing_confirmation_flag');
        }

        $token = (string) ($post['critical_confirmation_token'] ?? '');
        $state = is_array($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] ?? null)
            ? $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY]
            : [];
        $confirmation = is_array($state[$token] ?? null) ? $state[$token] : null;
        unset($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY][$token]);

        if ($token === '' || $confirmation === null) {
            throw new \RuntimeException('invalid_confirmation_token');
        }
        if ((int) ($confirmation['expires_at'] ?? 0) < time()) {
            throw new \RuntimeException('expired_confirmation_token');
        }
        if ((int) ($confirmation['ticket_id'] ?? 0) !== $ticketId || (string) ($confirmation['action'] ?? '') !== $action) {
            throw new \RuntimeException('confirmation_scope_mismatch');
        }
        if ((int) ($confirmation['user_id'] ?? 0) !== (int) ($_SESSION['glpiID'] ?? 0)) {
            throw new \RuntimeException('confirmation_user_mismatch');
        }
    }

    private static function purgeExpiredTicketCriticalConfirmations(): void
    {
        $state = is_array($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] ?? null)
            ? $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY]
            : [];
        $now = time();
        foreach ($state as $token => $confirmation) {
            if (!is_array($confirmation) || (int) ($confirmation['expires_at'] ?? 0) < $now) {
                unset($state[$token]);
            }
        }
        $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] = $state;
    }

    /**
     * @return string[]
     */
    private static function getRevealedFields(int $ticketId): array
    {
        $state = $_SESSION['glpiacessivel_pii_reveal'] ?? [];
        $ticketState = $state[$ticketId] ?? null;
        if (!is_array($ticketState)) {
            return [];
        }

        $expiresAt = (int) ($ticketState['expires_at'] ?? 0);
        if ($expiresAt < time()) {
            unset($_SESSION['glpiacessivel_pii_reveal'][$ticketId]);
            return [];
        }

        $fields = $ticketState['fields'] ?? [];
        if (!is_array($fields)) {
            return [];
        }

        return array_values(array_intersect($fields, ['requester_email', 'requester_phone', 'requester_mobile']));
    }

    private static function grantTemporaryReveal(int $ticketId, string $field): void
    {
        if (!isset($_SESSION['glpiacessivel_pii_reveal']) || !is_array($_SESSION['glpiacessivel_pii_reveal'])) {
            $_SESSION['glpiacessivel_pii_reveal'] = [];
        }

        $entry = $_SESSION['glpiacessivel_pii_reveal'][$ticketId] ?? ['fields' => []];
        if (!is_array($entry)) {
            $entry = ['fields' => []];
        }

        $fields = $entry['fields'] ?? [];
        if (!is_array($fields)) {
            $fields = [];
        }
        if (!in_array($field, $fields, true)) {
            $fields[] = $field;
        }

        $_SESSION['glpiacessivel_pii_reveal'][$ticketId] = [
            'fields' => $fields,
            'expires_at' => time() + self::PII_REVEAL_TTL_SECONDS,
        ];
    }

    private static function storeCreate(): void
    {
        $sanitizer = new InputSanitizer();
        $values = [
            'name' => $sanitizer->text($_POST['name'] ?? '', 255),
            'content' => $sanitizer->text($_POST['content'] ?? '', 16000),
            'type' => $sanitizer->int($_POST['type'] ?? self::incidentType(), self::incidentType()),
            'itilcategories_id' => max(0, $sanitizer->int($_POST['itilcategories_id'] ?? 0, 0)),
            'locations_id' => max(0, $sanitizer->int($_POST['locations_id'] ?? 0, 0)),
            'requesttypes_id' => max(0, $sanitizer->int($_POST['requesttypes_id'] ?? 1, 1)),
            'externalid' => $sanitizer->text($_POST['externalid'] ?? '', 255),
            'tickettemplates_id' => max(0, $sanitizer->int($_POST['tickettemplates_id'] ?? 0, 0)),
            'urgency' => $sanitizer->int($_POST['urgency'] ?? 3, 3),
            'impact' => $sanitizer->int($_POST['impact'] ?? 3, 3),
            '_users_id_assign' => array_values(array_filter(array_map('intval', (array) ($_POST['_users_id_assign'] ?? [])))),
            '_users_id_observer' => array_values(array_filter(array_map('intval', (array) ($_POST['_users_id_observer'] ?? [])))),
            '_groups_id_assign' => array_values(array_filter(array_map('intval', (array) ($_POST['_groups_id_assign'] ?? [])))),
        ];

        $errors = [];
        try {
            $values = UploadedFileMapper::mergeInto($values, UploadedFileMapper::map('filename'));
        } catch (\Throwable $e) {
            $errors[] = self::formError('filename', 'upload_error', $e->getMessage());
        }
        if ($values['name'] === '') {
            $errors[] = self::formError('name', 'required', 'Informe o titulo do chamado.');
        }
        if ($values['content'] === '') {
            $errors[] = self::formError('content', 'required', 'Informe a descricao do chamado.');
        }
        if (!in_array($values['type'], [self::incidentType(), self::demandType()], true)) {
            $errors[] = self::formError('type', 'invalid', 'Tipo de chamado invalido.');
        }
        if (!in_array($values['urgency'], [1, 2, 3, 4, 5], true)) {
            $errors[] = self::formError('urgency', 'invalid', 'Urgencia invalida.');
        }
        if (!in_array($values['impact'], [1, 2, 3, 4, 5], true)) {
            $errors[] = self::formError('impact', 'invalid', 'Impacto invalido.');
        }

        if ($errors !== []) {
            self::renderCreateForm($values, $errors);
            return;
        }

        try {
            $ticketId = self::container()->ticketService()->create($values);
            self::setMessage('success', 'Chamado registrado com sucesso.');
            \Html::redirect(Url::plugin('front/ticket.php?id=' . $ticketId));
        } catch (FormValidationException $e) {
            self::renderCreateForm($values, $e->errors(), $e->metadata());
        } catch (\Throwable $e) {
            self::renderCreateForm($values, [self::formError('', 'create_failed', 'Nao foi possivel registrar o chamado. Revise os dados e tente novamente.')]);
        }
    }

    /**
     * @return array{field:string, code:string, message:string}
     */
    private static function formError(string $field, string $code, string $message): array
    {
        return [
            'field' => $field,
            'code' => $code,
            'message' => $message,
        ];
    }

    private static function renderCreateForm(array $values, array $errors, array $submissionMetadata = []): void
    {
        $context = self::container()->ticketService()->creationContext($values);

        View::render('tickets/create', [
            'title' => __('Novo chamado', 'glpiacessivel'),
            'csrf_token' => self::csrf()->token(true),
            'values' => $values,
            'errors' => $errors,
            'submission_metadata' => $submissionMetadata,
            'context' => $context,
            'native_create_ticket_url' => self::nativeCreateTicketUrl(),
        ]);
    }

    private static function defaultCreateValues(): array
    {
        return [
            'name' => '',
            'content' => '',
            'type' => self::incidentType(),
            'itilcategories_id' => 0,
            'locations_id' => 0,
            'requesttypes_id' => 1,
            'externalid' => '',
            'tickettemplates_id' => 0,
            'urgency' => 3,
            'impact' => 3,
            '_users_id_assign' => [],
            '_users_id_observer' => [],
            '_groups_id_assign' => [],
        ];
    }

    private static function incidentType(): int
    {
        return defined(\Ticket::class . '::INCIDENT_TYPE') ? (int) \Ticket::INCIDENT_TYPE : 1;
    }

    private static function demandType(): int
    {
        return defined(\Ticket::class . '::DEMAND_TYPE') ? (int) \Ticket::DEMAND_TYPE : 2;
    }

    private static function nativeCreateTicketUrl(): string
    {
        if (class_exists('\Ticket') && method_exists('\Ticket', 'getFormURL')) {
            return (string) \Ticket::getFormURL(false);
        }

        return Url::core('front/ticket.form.php');
    }

    /**
     * @param array<int, array<string, mixed>> $items
     * @return array<int, array{id:int,label:string}>
     */
    private static function extractGroupOptions(array $items): array
    {
        $map = [];
        foreach ($items as $item) {
            foreach ((array) ($item['group_ids'] ?? []) as $index => $id) {
                $id = (int) $id;
                if ($id <= 0) {
                    continue;
                }
                $name = (string) (((array) ($item['group_names'] ?? []))[$index] ?? ('Grupo ' . $id));
                $map[$id] = $name;
            }
        }

        asort($map);
        $options = [];
        foreach ($map as $id => $label) {
            $options[] = ['id' => (int) $id, 'label' => (string) $label];
        }

        return $options;
    }

    /**
     * @param array<int, array<string, mixed>> $items
     * @return array<string, array<int, array<string, mixed>>>
     */
    private static function groupTicketsByGroup(array $items, string $scope, string $groupBy): array
    {
        if (!in_array($scope, ['mine', 'group'], true) || $groupBy !== 'group') {
            return [];
        }

        $grouped = [];
        foreach ($items as $item) {
            $key = trim((string) ($item['primary_group_name'] ?? ''));
            if ($key === '') {
                $key = 'Sem grupo';
            }
            if (!isset($grouped[$key])) {
                $grouped[$key] = [];
            }
            $grouped[$key][] = $item;
        }

        ksort($grouped, SORT_NATURAL | SORT_FLAG_CASE);
        return $grouped;
    }
}
