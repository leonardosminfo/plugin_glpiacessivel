<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Audit;

final class AuditLogger
{
    public function log(string $action, array $payload = [], ?int $ticketId = null): void
    {
        global $DB;

        try {
            $userId = (int) ($_SESSION['glpiID'] ?? 0);
            $entityId = (int) ($_SESSION['glpiactive_entity'] ?? 0);

            $payload = $this->sanitizePayload($payload);

            $DB->insert('glpi_plugin_glpiacessivel_auditlogs', [
                'users_id' => $userId,
                'entities_id' => $entityId,
                'tickets_id' => $ticketId,
                'action' => $action,
                'payload' => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'ip' => (string) ($_SERVER['REMOTE_ADDR'] ?? ''),
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            $this->purgeExpiredLogs();
        } catch (\Throwable $e) {
            $this->logFallback('audit.log.failed', $action, $e, $ticketId);
        }
    }

    public function logPiiReveal(int $ticketId, string $field, ?string $reason = null): void
    {
        global $DB;

        $userId = (int) ($_SESSION['glpiID'] ?? 0);
        $entityId = (int) ($_SESSION['glpiactive_entity'] ?? 0);

        try {
            $DB->insert('glpi_plugin_glpiacessivel_piireveals', [
                'users_id' => $userId,
                'entities_id' => $entityId,
                'tickets_id' => $ticketId,
                'field_name' => $field,
                'reason' => $this->normalizeReason($reason),
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        } catch (\Throwable $e) {
            $this->logFallback('audit.pii_reveal.failed', 'pii.reveal', $e, $ticketId);
        }

        $this->log('pii.reveal', [
            'field' => $field,
            'reason_len' => strlen((string) $reason),
        ], $ticketId);
    }

    public function recentActions(int $limit = 10, ?int $ticketId = null): array
    {
        global $DB;

        $limit = min(30, max(1, $limit));
        $where = $this->entityCriteria();

        if ($ticketId !== null && $ticketId > 0) {
            if (!$this->canReadTicket($ticketId)) {
                return [];
            }
            $where['tickets_id'] = $ticketId;
        }

        $rows = [];
        try {
            $criteria = [
                'SELECT' => ['id', 'action', 'tickets_id', 'users_id', 'entities_id', 'created_at'],
                'FROM' => 'glpi_plugin_glpiacessivel_auditlogs',
                'WHERE' => $where,
                'ORDER' => ['created_at DESC', 'id DESC'],
                'LIMIT' => $limit,
            ];

            foreach ($DB->request($criteria) as $row) {
                $rowTicketId = (int) ($row['tickets_id'] ?? 0);
                if ($rowTicketId > 0 && !$this->canReadTicket($rowTicketId)) {
                    continue;
                }

                $rows[] = [
                    'id' => (int) ($row['id'] ?? 0),
                    'action' => (string) ($row['action'] ?? ''),
                    'tickets_id' => $rowTicketId,
                    'users_id' => (int) ($row['users_id'] ?? 0),
                    'entities_id' => (int) ($row['entities_id'] ?? 0),
                    'created_at' => (string) ($row['created_at'] ?? ''),
                ];
            }
        } catch (\Throwable $e) {
            $this->logFallback('audit.recent_actions.failed', 'audit.recent_actions', $e, $ticketId);
        }

        return $rows;
    }

    /** @return array{entities_id:int|int[]} */
    private function entityCriteria(): array
    {
        $activeEntities = null;
        if (class_exists('\Session') && method_exists('\Session', 'getActiveEntities')) {
            $activeEntities = \Session::getActiveEntities();
        }
        if (!is_array($activeEntities)) {
            $activeEntities = (array) ($_SESSION['glpiactiveentities'] ?? []);
        }

        $entities = [];
        foreach ($activeEntities as $key => $value) {
            $candidate = is_numeric($value) ? (int) $value : (is_numeric($key) ? (int) $key : -1);
            if ($candidate >= 0) {
                $entities[$candidate] = $candidate;
            }
        }

        if ($entities === []) {
            $active = $_SESSION['glpiactive_entity'] ?? null;
            if (is_int($active) || (is_string($active) && ctype_digit($active))) {
                $entities[(int) $active] = (int) $active;
            }
        }

        $entities = array_values($entities);
        return ['entities_id' => count($entities) === 1 ? $entities[0] : ($entities !== [] ? $entities : [-1])];
    }

    private function canReadTicket(int $ticketId): bool
    {
        if ($ticketId <= 0 || !class_exists('\Ticket')) {
            return false;
        }

        try {
            $ticket = new \Ticket();
            return $ticket->can($ticketId, READ) && $ticket->getFromDB($ticketId);
        } catch (\Throwable $e) {
            return false;
        }
    }

    private function sanitizePayload(array $payload): array
    {
        $sensitiveKeys = ['prompt', 'content', 'query', 'q', 'reason'];
        foreach ($sensitiveKeys as $key) {
            if (array_key_exists($key, $payload)) {
                $payload[$key . '_len'] = strlen((string) $payload[$key]);
                unset($payload[$key]);
            }
        }

        if (isset($payload['filters']) && is_array($payload['filters'])) {
            $filters = $payload['filters'];
            if (isset($filters['q'])) {
                $filters['q_len'] = strlen((string) $filters['q']);
                unset($filters['q']);
            }
            $payload['filters'] = $filters;
        }

        return $payload;
    }

    private function normalizeReason(?string $reason): string
    {
        $raw = trim((string) $reason);
        if ($raw === '') {
            return '';
        }

        return '[len=' . strlen($raw) . ']';
    }

    private function purgeExpiredLogs(): void
    {
        global $DB;

        $days = $this->getRetentionDays();
        $cutoff = date('Y-m-d H:i:s', time() - ($days * 86400));
        if (!method_exists($DB, 'delete')) {
            $this->logFallback('audit.purge.skipped', 'audit.purge', new \RuntimeException('DB::delete indisponivel'));
            return;
        }

        $DB->delete('glpi_plugin_glpiacessivel_auditlogs', ['created_at' => ['<', $cutoff]]);
        $DB->delete('glpi_plugin_glpiacessivel_piireveals', ['created_at' => ['<', $cutoff]]);
    }

    private function logFallback(string $event, string $action, \Throwable $e, ?int $ticketId = null): void
    {
        $message = sprintf(
            "%s action=%s ticket=%s error=%s\n",
            $event,
            $action,
            $ticketId !== null ? (string) $ticketId : '-',
            get_class($e)
        );

        if (class_exists('Toolbox') && method_exists('Toolbox', 'logInFile')) {
            \Toolbox::logInFile('glpiacessivel-audit-errors', $message);
            return;
        }

        error_log('[glpiacessivel] ' . trim($message));
    }

    private function getRetentionDays(): int
    {
        global $DB;

        $result = $DB->request([
            'SELECT' => ['value_text'],
            'FROM' => 'glpi_plugin_glpiacessivel_configs',
            'WHERE' => ['key_name' => 'audit_retention_days'],
            'LIMIT' => 1,
        ])->current();

        $days = (int) ($result['value_text'] ?? 365);
        return min(3650, max(30, $days));
    }
}
