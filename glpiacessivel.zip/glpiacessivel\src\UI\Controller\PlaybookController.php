<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class PlaybookController extends BaseController
{
    private const CRITICAL_CONFIRM_TTL_SECONDS = 300;
    private const CRITICAL_CONFIRM_SESSION_KEY = 'glpiacessivel_playbook_critical_confirmations';
    public static function index(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_PLAYBOOKS)) {
            return;
        }

        $hasConfigRight = \Session::haveRight('config', UPDATE);
        if (method_exists('\\Session', 'checkRight')) {
            if (!$hasConfigRight) {
                self::logConfigRightDenied();
            }
            \Session::checkRight('config', UPDATE);
            if (!$hasConfigRight) {
                return;
            }
        } elseif (!$hasConfigRight) {
            self::displayConfigRightError();
            return;
        }

        $service = self::container()->chatbotPlaybookService();

        if ((string) ($_GET['export'] ?? '') === '1') {
            if (!headers_sent()) {
                header('Content-Type: application/json; charset=UTF-8');
                header('Content-Disposition: attachment; filename="glpiacessivel-chatbot-playbooks.json"');
            }

            echo json_encode(
                [
                    'version' => defined('PLUGIN_GLPIACESSIVEL_VERSION') ? PLUGIN_GLPIACESSIVEL_VERSION : 'dev',
                    'generated_at' => date('c'),
                    'playbooks' => $service->exportApprovedPlaybooks(),
                ],
                JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            );
            return;
        }

        $message = null;
        $result = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            self::csrf()->validateRequest(true);

            $action = (string) ($_POST['action'] ?? '');
            if (self::isCriticalPlaybookAction($action)) {
                try {
                    self::validatePlaybookCriticalConfirmation($action, $_POST);
                } catch (\Throwable $e) {
                    self::container()->auditLogger()->log('chatbot.playbook.critical_confirmation.blocked', [
                        'action' => $action,
                        'reason' => $e->getMessage(),
                    ]);
                    $message = __('Confirme a acao critica na tela antes de executar.', 'glpiacessivel');
                    $action = '';
                }
            }
            try {
                if ($action === 'run_kb_initial') {
                    $limit = min(200, max(10, (int) ($_POST['limit'] ?? 80)));
                    $publicOnly = isset($_POST['public_only']) && (string) $_POST['public_only'] === '1';
                    $result = $service->runInitialKnowledgeScan([
                        'limit' => $limit,
                        'public_only' => $publicOnly,
                    ]);
                    $message = sprintf('Varredura concluida: %d sugestao(oes) gerada(s).', (int) ($result['suggestions'] ?? 0));
                } elseif ($action === 'update_suggestion') {
                    $updated = $service->updateSuggestion((int) ($_POST['suggestion_id'] ?? 0), $_POST);
                    $message = $updated ? __('Sugestao atualizada.', 'glpiacessivel') : __('Sugestao pendente nao encontrada para atualizacao.', 'glpiacessivel');
                } elseif ($action === 'approve') {
                    $service->approveSuggestion((int) ($_POST['suggestion_id'] ?? 0));
                    $message = 'Sugestao aprovada e publicada como roteiro ativo.';
                } elseif ($action === 'reject') {
                    $service->rejectSuggestion((int) ($_POST['suggestion_id'] ?? 0));
                    $message = 'Sugestao rejeitada.';
                } elseif ($action === 'create_playbook') {
                    $created = $service->createPlaybook($_POST);
                    if (($created['status'] ?? '') === 'pending') {
                        $message = 'Roteiro cadastrado como pendente para analise.';
                    } elseif (($created['status'] ?? '') === 'invalid') {
                        $message = 'Informe ao menos o nome do roteiro.';
                    } else {
                        $message = 'Roteiro cadastrado.';
                    }
                } elseif ($action === 'update_playbook') {
                    $updated = $service->updatePlaybook((int) ($_POST['playbook_id'] ?? 0), $_POST);
                    $message = $updated && (string) ($_POST['status'] ?? '') === 'pending'
                        ? 'Roteiro retornou para sugestoes pendentes.'
                        : ($updated ? 'Roteiro atualizado.' : 'Roteiro nao encontrado para atualizacao.');
                } elseif ($action === 'delete_playbook') {
                    $deleted = $service->deletePlaybook((int) ($_POST['playbook_id'] ?? 0));
                    $message = $deleted ? 'Roteiro excluido.' : 'Roteiro nao encontrado para exclusao.';
                } elseif ($action === 'import_json') {
                    $rawJson = self::readPlaybookImportJson();
                    $payload = self::decodePlaybookImportJson($rawJson);
                    $items = self::playbookImportItems($payload);
                    if ($items === []) {
                        throw new \RuntimeException('JSON valido, mas nenhum roteiro foi encontrado para importacao.');
                    }
                    $import = $service->importPlaybooks($items, (string) ($_POST['import_status'] ?? 'active'));
                    $message = sprintf(
                        '%d ativo(s), %d inativo(s), %d pendente(s), %d ignorado(s).',
                        (int) ($import['active'] ?? 0),
                        (int) ($import['inactive'] ?? 0),
                        (int) ($import['pending'] ?? 0),
                        (int) ($import['skipped'] ?? 0)
                    );
                }
            } catch (\Throwable $e) {
                self::container()->auditLogger()->log('chatbot.playbook.admin.error', [
                    'action' => $action,
                    'error' => get_class($e),
                    'message' => mb_substr($e->getMessage(), 0, 250, 'UTF-8'),
                ]);
                $message = $action === 'import_json'
                    ? 'Importacao nao concluida: ' . $e->getMessage()
                    : __('Nao foi possivel concluir a acao solicitada. Verifique o log do GLPI.', 'glpiacessivel');
            }
        }

        View::render('playbooks/index', [
            'title' => __('Roteiros do chatbot', 'glpiacessivel'),
            'chatbot_name' => self::container()->configService()->getChatbotDisplayName(),
            'csrf_token' => self::csrf()->token(true),
            'critical_confirmations' => self::playbookCriticalConfirmationTokens(),
            'message' => $message,
            'result' => $result,
            'suggestions' => $service->listPendingSuggestions(80),
            'playbooks' => $service->listApprovedPlaybooks(80),
        ]);
    }

    private static function logConfigRightDenied(): void
    {
        self::container()->auditLogger()->log('playbook.permission_denied', [
            'required_right' => 'config_update',
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
        ]);
    }

    private static function displayConfigRightError(): void
    {
        self::logConfigRightDenied();

        if (class_exists('\Html') && method_exists('\Html', 'displayRightError')) {
            \Html::displayRightError();
            return;
        }

        if (!headers_sent()) {
            http_response_code(403);
        }

        View::render('errors/permission', [
            'title' => __('Sem permissao para roteiros do chatbot', 'glpiacessivel'),
            'message' => __('Seu perfil atual nao possui permissao de configuracao para gerenciar roteiros do chatbot.', 'glpiacessivel'),
            'alert_title' => __('Acesso bloqueado pelo GLPI', 'glpiacessivel'),
            'alert_message' => __('Entre com um perfil autorizado ou solicite a liberacao ao administrador do GLPI.', 'glpiacessivel'),
            'return_url' => \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/acessivel.php'),
        ]);
    }
    private static function readPlaybookImportJson(): string
    {
        $raw = (string) ($_POST['playbooks_json'] ?? '');
        $file = $_FILES['playbooks_json_file'] ?? null;
        if (is_array($file) && (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            if ((int) ($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
                throw new \RuntimeException('Falha no upload do arquivo JSON.');
            }
            $tmpName = (string) ($file['tmp_name'] ?? '');
            if ($tmpName === '' || !is_uploaded_file($tmpName)) {
                throw new \RuntimeException('Arquivo JSON de importacao invalido.');
            }
            $content = file_get_contents($tmpName);
            if (!is_string($content)) {
                throw new \RuntimeException('Nao foi possivel ler o arquivo JSON enviado.');
            }
            $raw = $content;
        }

        $raw = preg_replace('/^\xEF\xBB\xBF/', '', trim($raw)) ?? '';
        if ($raw === '') {
            throw new \RuntimeException('Informe ou envie um JSON de roteiros.');
        }

        return $raw;
    }

    /**
     * @return array<string|int, mixed>
     */
    private static function decodePlaybookImportJson(string $raw): array
    {
        $payload = json_decode($raw, true);
        if (!is_array($payload)) {
            $detail = function_exists('json_last_error_msg') ? json_last_error_msg() : 'JSON invalido';
            throw new \RuntimeException('JSON invalido para importacao: ' . $detail . '.');
        }

        return $payload;
    }

    /**
     * @param array<string|int, mixed> $payload
     * @return array<int, array<string, mixed>>
     */
    private static function playbookImportItems(array $payload): array
    {
        foreach (['playbooks', 'items', 'data'] as $key) {
            if (isset($payload[$key]) && is_array($payload[$key])) {
                return self::sequentialPlaybookItems($payload[$key]);
            }
        }

        if (self::isAssociativePlaybook($payload)) {
            return [$payload];
        }

        return self::sequentialPlaybookItems($payload);
    }

    /**
     * @param array<string|int, mixed> $items
     * @return array<int, array<string, mixed>>
     */
    private static function sequentialPlaybookItems(array $items): array
    {
        $normalized = [];
        foreach ($items as $item) {
            if (is_array($item)) {
                $normalized[] = $item;
            }
        }

        return $normalized;
    }

    /**
     * @param array<string|int, mixed> $payload
     */
    private static function isAssociativePlaybook(array $payload): bool
    {
        return isset($payload['name']) || isset($payload['title']) || isset($payload['keywords']) || isset($payload['content']);
    }

    /**
     * @return array<string, string>
     */
    private static function playbookCriticalConfirmationTokens(): array
    {
        self::purgeExpiredPlaybookCriticalConfirmations();
        $actions = ['approve', 'reject', 'delete_playbook'];
        $tokens = [];
        foreach ($actions as $action) {
            $token = bin2hex(random_bytes(16));
            $tokens[$action] = $token;
            $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY][$token] = [
                'action' => $action,
                'user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'expires_at' => time() + self::CRITICAL_CONFIRM_TTL_SECONDS,
            ];
        }

        return $tokens;
    }

    private static function isCriticalPlaybookAction(string $action): bool
    {
        return in_array($action, ['approve', 'reject', 'delete_playbook'], true);
    }

    /**
     * @param array<string, mixed> $post
     */
    private static function validatePlaybookCriticalConfirmation(string $action, array $post): void
    {
        if ((string) ($post['critical_confirmed'] ?? '') !== '1') {
            throw new \RuntimeException('missing_confirmation_flag');
        }

        $token = (string) ($post['critical_confirmation_token'] ?? '');
        $state = is_array($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] ?? null)
            ? $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY]
            : [];
        $confirmation = is_array($state[$token] ?? null) ? $state[$token] : null;
        unset($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY][$token]);

        if ($token === '' || $confirmation === null) {
            throw new \RuntimeException('invalid_confirmation_token');
        }
        if ((int) ($confirmation['expires_at'] ?? 0) < time()) {
            throw new \RuntimeException('expired_confirmation_token');
        }
        if ((string) ($confirmation['action'] ?? '') !== $action) {
            throw new \RuntimeException('confirmation_scope_mismatch');
        }
        if ((int) ($confirmation['user_id'] ?? 0) !== (int) ($_SESSION['glpiID'] ?? 0)) {
            throw new \RuntimeException('confirmation_user_mismatch');
        }
    }

    private static function purgeExpiredPlaybookCriticalConfirmations(): void
    {
        $state = is_array($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] ?? null)
            ? $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY]
            : [];
        $now = time();
        foreach ($state as $token => $confirmation) {
            if (!is_array($confirmation) || (int) ($confirmation['expires_at'] ?? 0) < $now) {
                unset($state[$token]);
            }
        }
        $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] = $state;
    }
}
