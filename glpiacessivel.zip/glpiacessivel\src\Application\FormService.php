<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Application\DynamicForm\DynamicFormFacade;
use GlpiPlugin\Glpiacessivel\Domain\Security\Authorization;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\FormRepository;

final class FormService
{
    public function __construct(
        private FormRepository $repository,
        private Authorization $authorization,
        private AuditLogger $auditLogger
    ) {
    }

    /**
     * @return array<string, mixed>
     */
    public function listAvailableForms(): array
    {
        if (!$this->authorization->canUseForms()) {
            throw new \RuntimeException('Usuario sem sessao valida para abrir formularios de solicitacao.');
        }

        $result = $this->enrichWithDynamicSchemas($this->repository->listFormSources());
        $this->auditLogger->log('forms.list', [
            'count' => count((array) ($result['items'] ?? [])),
            'glpi11_available' => !empty($result['sources']['glpi11_service_catalog']['available']),
            'formcreator_available' => !empty($result['sources']['formcreator_glpi10']['available']),
        ]);

        return $result;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function resolveForm(string $source, int $id): ?array
    {
        if (!$this->authorization->canUseForms()) {
            throw new \RuntimeException('Usuario sem sessao valida para abrir formularios de solicitacao.');
        }

        $form = $this->repository->resolveForm($source, $id);
        if ($form !== null) {
            $form = $this->enrichForm($form);
        }
        $this->auditLogger->log('forms.open_native_fallback', [
            'source' => $source,
            'form_id' => $id,
            'found' => $form !== null,
        ]);

        return $form;
    }
    /**
     * @param array<string, mixed> $result
     * @return array<string, mixed>
     */
    private function enrichWithDynamicSchemas(array $result): array
    {
        $items = [];
        foreach ((array) ($result['items'] ?? []) as $item) {
            if (is_array($item)) {
                $items[] = $this->enrichForm($item);
            }
        }
        $result['items'] = $items;

        return $result;
    }

    /**
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    private function enrichForm(array $form): array
    {
        $source = (string) ($form['source'] ?? '');
        if ($source === '') {
            return $form;
        }

        try {
            $schema = (new DynamicFormFacade())->formSchema($source, ['form' => $form])->toArray();
            $form['dynamic_form_schema'] = $schema;
            $capabilities = is_array($schema['capabilities'] ?? null) ? $schema['capabilities'] : [];
            $metadata = is_array($schema['metadata'] ?? null) ? $schema['metadata'] : [];
            $form['compatibility_status'] = (string) ($metadata['compatibility_status'] ?? (
                !empty($capabilities['renders_own_fields'])
                    ? 'renderer_candidate'
                    : (!empty($schema['fallback']['required']) ? 'native_fallback_required' : 'renderer_candidate')
            ));
            $reasons = array_values(array_filter(array_map('strval', (array) ($schema['fallback']['reasons'] ?? []))));
            $advisories = array_values(array_filter(array_map('strval', (array) ($schema['fallback']['advisory_reasons'] ?? []))));
            $form['compatibility_reasons'] = $reasons;
            $form['compatibility_advisories'] = $advisories;
            $form['compatibility_summary'] = $reasons[0] ?? ($advisories[0] ?? 'Schema dinamico gerado para avaliacao de compatibilidade.');
        } catch (\Throwable $e) {
            $form['compatibility_status'] = 'schema_unavailable';
            $form['compatibility_reasons'] = ['Nao foi possivel gerar schema de compatibilidade. Use o fluxo nativo.'];
            $form['compatibility_advisories'] = [];
            $form['compatibility_summary'] = 'Nao foi possivel gerar schema de compatibilidade. Use o fluxo nativo.';
        }

        return $form;
    }
}
