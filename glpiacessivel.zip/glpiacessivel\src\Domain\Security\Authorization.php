<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Security;

final class Authorization
{
    public function canViewPortal(): bool
    {
        return $this->canViewTickets() || $this->canCreateTickets() || $this->canViewKnowledgeBase() || $this->canUseForms();
    }

    public function canViewTickets(): bool
    {
        if (class_exists('\Ticket') && method_exists('\Session', 'haveRightsOr')) {
            $rights = [];
            foreach (['READMY', 'READALL', 'READGROUP', 'READASSIGN', 'READNEWTICKET'] as $constant) {
                $constantName = \Ticket::class . '::' . $constant;
                if (defined($constantName)) {
                    $rights[] = (int) constant($constantName);
                }
            }

            if (defined('READ')) {
                $rights[] = READ;
            }

            $rights = array_values(array_unique($rights));
            if ($rights !== [] && \Session::haveRightsOr('ticket', $rights)) {
                return true;
            }
        }

        if (class_exists('\Ticket') && method_exists('\Ticket', 'canView')) {
            return (bool) \Ticket::canView();
        }

        return method_exists('\Session', 'haveRight') && defined('READ') && (bool) \Session::haveRight('ticket', READ);
    }

    public function canUpdateTickets(): bool
    {
        if (class_exists('\Ticket') && method_exists('\Ticket', 'canUpdate')) {
            return (bool) \Ticket::canUpdate();
        }

        return (bool) \Session::haveRight('ticket', UPDATE);
    }

    public function canCreateTickets(): bool
    {
        if (class_exists('\Ticket') && method_exists('\Ticket', 'canCreate')) {
            return (bool) \Ticket::canCreate();
        }

        return (bool) \Session::haveRight('ticket', CREATE);
    }
    public function canUseForms(): bool
    {
        $loggedIn = method_exists('\Session', 'getLoginUserID')
            ? (int) \Session::getLoginUserID() > 0
            : isset($_SESSION['glpiID']) && (int) $_SESSION['glpiID'] > 0;
        if (!$loggedIn) {
            return false;
        }

        if (
            class_exists('\Glpi\Form\ServiceCatalog\ServiceCatalog')
            && method_exists('\Glpi\Form\ServiceCatalog\ServiceCatalog', 'canView')
            && !\Glpi\Form\ServiceCatalog\ServiceCatalog::canView()
        ) {
            if (!class_exists('\PluginFormcreatorForm')) {
                return false;
            }
        }

        return true;
    }
    public function canViewFormDiagnostics(): bool
    {
        if (method_exists('\Session', 'haveRight') && defined('UPDATE') && (bool) \Session::haveRight('config', UPDATE)) {
            return true;
        }

        $profileName = $this->activeProfileName();
        if ($profileName === '') {
            return false;
        }

        $normalized = strtolower(str_replace([' ', '-', '_'], '', $profileName));
        return in_array($normalized, ['admin', 'superadmin', 'administrador', 'superadministrador'], true);
    }

    /**
     * Technical portal diagnostics are restricted to administrators/configuration managers.
     * Keep this semantic alias for screens that are not form-specific.
     */
    public function canViewOperationalDiagnostics(): bool
    {
        return $this->canViewFormDiagnostics();
    }

    private function activeProfileName(): string
    {
        $profileData = is_array($_SESSION['glpiactiveprofile'] ?? null) ? $_SESSION['glpiactiveprofile'] : [];
        $name = trim((string) ($profileData['name'] ?? ''));
        if ($name !== '') {
            return $name;
        }

        $profileId = (int) ($profileData['id'] ?? 0);
        if ($profileId > 0 && class_exists('\Profile')) {
            $profile = new \Profile();
            if ($profile->getFromDB($profileId)) {
                return trim((string) ($profile->fields['name'] ?? ''));
            }
        }

        return '';
    }

    public function canCreateFollowup(): bool
    {
        return (bool) (\Session::haveRight('followup', CREATE) || \Session::haveRight('ticket', UPDATE));
    }

    public function canRevealPii(): bool
    {
        return (bool) (\Session::haveRight('config', UPDATE) || \Session::haveRight('ticket', UPDATE));
    }

    public function canViewKnowledgeBase(): bool
    {
        if (class_exists('\KnowbaseItem') && method_exists('\KnowbaseItem', 'canView') && (bool) \KnowbaseItem::canView()) {
            return true;
        }

        if (method_exists('\Session', 'haveRightsOr') && class_exists('\KnowbaseItem') && defined('READ')) {
            $rights = [
                READ,
            ];
            if (defined(\KnowbaseItem::class . '::READFAQ')) {
                $rights[] = \KnowbaseItem::READFAQ;
            }

            return (bool) \Session::haveRightsOr('knowbase', $rights);
        }

        if (method_exists('\Session', 'haveRight') && defined('READ') && \Session::haveRight('knowbase', READ)) {
            return true;
        }

        return class_exists('\KnowbaseItem')
            && defined(\KnowbaseItem::class . '::READFAQ')
            && \Session::haveRight('knowbase', \KnowbaseItem::READFAQ);
    }

    public function canViewKnowledgeBaseFull(): bool
    {
        if (method_exists('\Session', 'haveRight')) {
            return (bool) \Session::haveRight('knowbase', READ);
        }

        return $this->canViewKnowledgeBase();
    }

    public function canViewCockpit(): bool
    {
        return $this->canViewTickets() || $this->canCreateTickets();
    }

    public function canUseChatbot(): bool
    {
        return $this->canViewTickets() || $this->canCreateTickets() || $this->canViewKnowledgeBase() || $this->canUseForms();
    }
}
