<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

final class TextNormalizer
{
    public static function fromGlpi(?string $value): string
    {
        $text = trim((string) $value);
        if ($text === '') {
            return '';
        }

        // GLPI may return hierarchical dropdown labels already HTML-escaped
        // (for example "Entidade raiz &#62; Regional"). Decode only semantic text here;
        // templates must still escape output before rendering.
        for ($i = 0; $i < 2; $i++) {
            $decoded = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($decoded === $text) {
                break;
            }
            $text = $decoded;
        }

        $text = str_replace("\xC2\xA0", ' ', $text);

        return trim((string) (preg_replace('/[ \t]+/u', ' ', $text) ?? $text));
    }
}
