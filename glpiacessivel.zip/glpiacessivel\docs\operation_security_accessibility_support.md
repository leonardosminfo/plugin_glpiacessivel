# Operacao, seguranca, acessibilidade e suporte

Versao: 0.2-beta.

## Status atual

O plugin esta em beta tecnico. O pacote e adequado para piloto controlado, mas ainda nao deve ser tratado como liberacao ampla sem matriz GLPI 10/11 real, testes assistivos e revisao final de assets/licencas.

## Operacao

1. Instalar o ZIP na pasta de plugins do GLPI como `glpiacessivel`.
2. Validar versao do GLPI 10/11, PHP >= 8.1, permissao de escrita do GLPI e ativacao do plugin.
3. Limpar cache do GLPI e cache do navegador quando houver troca de JS/CSS injetado por hook.
4. Conferir configuracao de entidade, perfil ativo, intents liberadas, voz e escopo dos botoes flutuantes.
5. Em rollback, desativar o plugin, restaurar pacote anterior e limpar cache.

## Seguranca

- CSRF deve ser validado em POST tradicional e AJAX.
- ACL deve ser conferida no servidor para Ticket, KB, followup, task, solution e status.
- Acoes write/critical usam confirmacao acessivel; critical exige codigo forte.
- Auditoria e metricas nao devem armazenar texto livre do usuario.
- CSP deve preferir assets locais, especialmente voz e WASM.
- Permissao negada deve ser neutra, sem revelar existencia de item fora da ACL.

## Acessibilidade e eMAG/WCAG

- Todas as telas do piloto devem ser testadas por teclado, alto contraste, foco visivel e leitor de tela.
- Mensagens bloqueantes usam `role=alert`; progresso/estado usa live region curta.
- Atalhos Alt+T, Alt+C e Alt+H precisam funcionar sem conflito nos navegadores alvo.
- Componentes de voz devem permitir iniciar/parar captura e parar fala.
- WAVE/axe/pa11y ajudam, mas nao substituem NVDA/JAWS/VoiceOver com GLPI real.

## Suporte

Coletar sempre:

- Versao do plugin, GLPI, PHP, navegador, tema, entidade e perfil ativo.
- URL da tela, horario do erro e usuario/perfil de teste.
- Evento de auditoria relacionado, sem copiar prompt ou descricao sensivel.
- Backend usado na listagem: `search_api` ou `native_find_fallback`.
- Screenshot somente quando nao expuser dados sensiveis.

## Checklist de homologacao GLPI 10/11

| Area | Perfis | Evidencia |
| --- | --- | --- |
| Login e sessao operacional | self-service, tecnico, gestor, super-admin | Login pelo portal acessivel e pelo GLPI nativo com `glpiID`, perfil ativo, entidade ativa, direitos, grupos, runtime config e CSRF equivalentes |
| Listagem/Search API | self-service, tecnico, gestor, super-admin | IDs Search API vs fallback, backend_reason, SearchOption |
| Abertura | self-service e tecnico | campos obrigatorios, templates, anexos, Service Catalog GLPI 11 |
| ITIL actions | self-service, tecnico, gestor | followup, tarefa, solucao, status, permissao negada |
| Chatbot | todos | intent, ACL, confirmacao, handoff, metricas |
| Voz | usuarios de piloto | STT/TTS local, fallback bloqueado/permitido, CSP |
| Acessibilidade | usuarios teclado/leitor | foco, atalhos, live regions, contraste, erro AJAX |

## Plano P0/P1 incorporado

### Login acessivel e contexto GLPI

O portal acessivel nao deve considerar a sessao operacional pronta apenas por `glpiID`. A validacao de homologacao deve comparar o login feito pelo portal acessivel com o login nativo do GLPI e confirmar:

- perfil ativo carregado;
- entidade ativa carregada, inclusive escopo recursivo ou `all`;
- lista de perfis disponiveis;
- grupos do usuario;
- direitos de ticket, followup, base de conhecimento e configuracao;
- runtime config retornando JavaScript valido e coerente;
- tokens CSRF gerados apos autenticacao.

Se o usuario estiver autenticado, mas o contexto GLPI estiver incompleto, o plugin deve normalizar o contexto com APIs nativas seguras ou redirecionar uma unica vez para uma etapa nativa antes de voltar ao portal. Controles que dependem de permissao nao devem ficar ativos quando `sessionReady=false`.

### Search API e fallback

A homologacao da listagem deve entrar na mesma matriz GLPI 10/11, porque perfil, entidade e grupos afetam diretamente a equivalencia entre Search API e fallback.

- `group_id`: validar por IDs reais contra o fallback, registrando o SearchOption de grupo atribuido usado.
- `group`: validar grupo unico do usuario pela Search API e multiplos grupos pelo fallback documentado, ate existir criterio nativo OR seguro.
- `mine`: manter fallback beta por seguranca ate validar equivalencia entre requerente, observador e atribuido em GLPI 10/11.
- limite defensivo de 500 chamados: deve ser aceito formalmente para piloto beta ou eliminado por migracao completa para Search API/criterios obrigatorios.

O aceite do piloto exige evidencias de que nenhum backend amplia permissao, nao vaza chamados fora da ACL e informa claramente quando o fallback beta foi usado.

## Gates antes de release ampla

- Matriz GLPI 10/11 com evidencias reais concluida.
- Login pelo portal acessivel com sessao operacional equivalente ao login nativo.
- `msgfmt --check --check-format` no pipeline final.
- Axe/pa11y e teste manual NVDA/JAWS/VoiceOver sem bloqueadores P0/P1.
- Licencas e hashes dos assets de voz aprovados.
- Fallback beta aceito formalmente ou Search API completa para escopos pendentes.


