<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

final class ChatbotIntentPolicy
{
    /**
     * @return array<string, array<string, mixed>>
     */
    public static function all(): array
    {
        return [
            'fallback' => [
                'operation' => 'conversation_fallback',
                'object' => 'chatbot',
                'right' => 'none',
                'access' => 'read',
                'risk' => 'read',
                'requires_confirmation' => false,
                'audit_pii' => false,
                'metric_event' => 'fallback',
            ],
            'handoff_humano' => [
                'operation' => 'handoff_to_service_desk',
                'object' => 'service_desk',
                'right' => 'none',
                'access' => 'read',
                'risk' => 'read',
                'requires_confirmation' => false,
                'audit_pii' => false,
                'metric_event' => 'handoff',
            ],
            'mine_tickets' => [
                'operation' => 'list_visible_tickets',
                'object' => 'ticket',
                'right' => 'ticket.view',
                'access' => 'read',
                'risk' => 'read',
                'requires_confirmation' => false,
                'audit_pii' => false,
                'metric_event' => 'intent_detected',
            ],
            'ticket_lookup' => [
                'operation' => 'show_ticket_detail',
                'object' => 'ticket',
                'right' => 'ticket.view',
                'access' => 'read',
                'risk' => 'read',
                'requires_confirmation' => false,
                'audit_pii' => false,
                'metric_event' => 'intent_detected',
            ],
            'ticket_criar_guiado' => [
                'operation' => 'create_ticket_draft',
                'object' => 'ticket',
                'right' => 'ticket.create',
                'access' => 'write',
                'risk' => 'write',
                'requires_confirmation' => false,
                'audit_pii' => false,
                'metric_event' => 'ticket_draft_created',
            ],
            'ticket_triagem_inicial' => [
                'operation' => 'suggest_ticket_triage',
                'object' => 'ticket',
                'right' => 'ticket.view',
                'access' => 'read',
                'risk' => 'read',
                'requires_confirmation' => false,
                'audit_pii' => false,
                'metric_event' => 'intent_detected',
            ],
            'ticket_sla_status' => [
                'operation' => 'read_ticket_sla',
                'object' => 'ticket',
                'right' => 'ticket.view',
                'access' => 'read',
                'risk' => 'read',
                'requires_confirmation' => false,
                'audit_pii' => false,
                'metric_event' => 'intent_detected',
            ],
            'ticket_escalonar' => [
                'operation' => 'update_ticket_routing',
                'object' => 'ticket',
                'right' => 'ticket.update',
                'access' => 'write',
                'risk' => 'write',
                'requires_confirmation' => true,
                'audit_pii' => false,
                'metric_event' => 'intent_detected',
            ],
            'ticket_reclassificar' => [
                'operation' => 'update_ticket_classification',
                'object' => 'ticket',
                'right' => 'ticket.update',
                'access' => 'write',
                'risk' => 'write',
                'requires_confirmation' => true,
                'audit_pii' => false,
                'metric_event' => 'intent_detected',
            ],
            'ticket_priorizar' => [
                'operation' => 'update_ticket_priority',
                'object' => 'ticket',
                'right' => 'ticket.update',
                'access' => 'write',
                'risk' => 'write',
                'requires_confirmation' => true,
                'audit_pii' => false,
                'metric_event' => 'intent_detected',
            ],
            'ticket_followup_operacional' => [
                'operation' => 'create_ticket_followup',
                'object' => 'itilfollowup',
                'right' => 'followup.create',
                'access' => 'write',
                'risk' => 'write',
                'requires_confirmation' => true,
                'audit_pii' => false,
                'metric_event' => 'intent_detected',
            ],
            'ticket_encerrar_com_validacao' => [
                'operation' => 'create_ticket_solution',
                'object' => 'solution',
                'right' => 'ticket.update',
                'access' => 'write',
                'risk' => 'critical',
                'requires_confirmation' => true,
                'audit_pii' => false,
                'metric_event' => 'intent_detected',
            ],
            'kb_recomendar_contextual' => [
                'operation' => 'search_knowledge_base',
                'object' => 'knowbaseitem',
                'right' => 'kb.view_or_ticket.create',
                'access' => 'read',
                'risk' => 'read',
                'requires_confirmation' => false,
                'audit_pii' => false,
                'metric_event' => 'kb_suggested',
            ],
            'comunicacao_usuario' => [
                'operation' => 'draft_user_communication',
                'object' => 'ticket',
                'right' => 'ticket.view',
                'access' => 'write',
                'risk' => 'write',
                'requires_confirmation' => true,
                'audit_pii' => false,
                'metric_event' => 'intent_detected',
            ],
            'auditoria_consulta' => [
                'operation' => 'read_plugin_audit',
                'object' => 'auditlog',
                'right' => 'pii.reveal',
                'access' => 'read',
                'risk' => 'read',
                'requires_confirmation' => false,
                'audit_pii' => true,
                'metric_event' => 'intent_detected',
            ],
        ];
    }

    /**
     * @return string[]
     */
    public static function knownIntents(): array
    {
        return array_keys(self::all());
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function get(string $intent): ?array
    {
        $policies = self::all();
        return $policies[$intent] ?? null;
    }

    public static function riskLevel(string $intent): string
    {
        $policy = self::get($intent);
        return is_array($policy) ? (string) ($policy['risk'] ?? 'read') : 'read';
    }

    public static function requiresConfirmation(string $intent): bool
    {
        $policy = self::get($intent);
        return is_array($policy) && !empty($policy['requires_confirmation']);
    }

    public static function isAllowed(string $intent, object $authorization): bool
    {
        $policy = self::get($intent);
        if ($policy === null) {
            return false;
        }

        return match ((string) ($policy['right'] ?? 'none')) {
            'none' => true,
            'ticket.view' => $authorization->canViewTickets(),
            'ticket.create' => $authorization->canCreateTickets(),
            'ticket.update' => $authorization->canUpdateTickets(),
            'followup.create' => $authorization->canCreateFollowup(),
            'kb.view_or_ticket.create' => $authorization->canViewKnowledgeBase() || $authorization->canCreateTickets(),
            'pii.reveal' => $authorization->canRevealPii(),
            default => false,
        };
    }
}
