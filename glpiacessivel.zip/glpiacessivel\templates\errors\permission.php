<section class="glpiacessivel-section-head" aria-labelledby="permission-error-title">
  <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(__('Acesso restrito', 'glpiacessivel')) ?></p>
  <h2 id="permission-error-title"><?= glpiacessivel_e((string) ($title ?? __('Sem permissao', 'glpiacessivel'))) ?></h2>
  <p><?= glpiacessivel_e((string) ($message ?? __('Seu perfil atual nao possui permissao para acessar esta funcionalidade.', 'glpiacessivel'))) ?></p>
</section>

<section
  class="glpiacessivel-alert glpiacessivel-alert-warning"
  role="region"
  aria-labelledby="permission-alert-title"
  aria-describedby="permission-alert-message"
>
  <h3 id="permission-alert-title" tabindex="-1" data-glpiacessivel-focus-alert><?= glpiacessivel_e((string) ($alert_title ?? __('Permissao necessaria', 'glpiacessivel'))) ?></h3>
  <p id="permission-alert-message"><?= glpiacessivel_e((string) ($alert_message ?? __('A acao foi bloqueada pelas permissoes nativas do GLPI.', 'glpiacessivel'))) ?></p>
  <p>
    <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e((string) ($return_url ?? glpiacessivel_url('front/acessivel.php'))) ?>"><?= glpiacessivel_e(__('Voltar ao portal acessivel', 'glpiacessivel')) ?></a>
  </p>
</section>
