<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class CockpitController extends BaseController
{
    public static function index(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_COCKPIT)) {
            return;
        }

        $metrics = self::container()->ticketService()->cockpitMetrics();

        View::render('cockpit/index', [
            'title' => __('Cockpit rápido', 'glpiacessivel'),
            'metrics' => $metrics,
        ]);
    }
}
