<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application\DynamicForm;

use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormAdapterInterface;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormCondition;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormField;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSchema;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSection;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSubmissionResult;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\FormCapability;

final class FormcreatorSchemaAdapter implements DynamicFormAdapterInterface
{
    public const SOURCE = 'formcreator_glpi10';

    public function source(): string
    {
        return self::SOURCE;
    }

    /** @param array<string, mixed> $context */
    public function supports(array $context): bool
    {
        return (string) ($context['source'] ?? $context['form']['source'] ?? '') === self::SOURCE;
    }

    /** @param array<string, mixed> $context */
    public function getSchema(array $context): DynamicFormSchema
    {
        $form = is_array($context['form'] ?? null) ? $context['form'] : [];
        $id = (int) ($form['id'] ?? $context['id'] ?? 0);
        $title = (string) ($form['name'] ?? ('Formulario #' . $id));
        $nativeUrl = (string) ($form['native_url'] ?? '');
        $detectedApis = $this->detectedApis();
        if (isset($context['detected_apis']) && is_array($context['detected_apis'])) {
            $detectedApis = array_merge($detectedApis, $context['detected_apis']);
        }
        $projected = $this->projectNativeSchema($id, $form);
        $sections = $projected['sections'];
        $fields = $projected['fields'];
        $conditions = $projected['conditions'];
        $unsupported = $projected['unsupported'];
        $hasProjectedFields = count($fields) > 1;
        $submissionReadiness = $this->ownSubmissionReadiness($id, $fields, $conditions, $unsupported, $detectedApis, $form);
        $canSubmitThroughNativeContract = !empty($submissionReadiness['ready']);
        $compatibilityMatrix = $this->compatibilityMatrix($detectedApis, $projected, $submissionReadiness);
        $capabilityContract = FormCapability::fromReadiness(
            self::SOURCE,
            $submissionReadiness,
            $compatibilityMatrix,
            $canSubmitThroughNativeContract
        );

        return new DynamicFormSchema(
            'formcreator_glpi10:' . $id,
            self::SOURCE,
            '1.2',
            $title,
            $sections,
            $fields,
            $conditions,
            [
                'source_of_truth' => 'formcreator_glpi10',
                'renders_own_fields' => $hasProjectedFields,
                'submits_via_native_engine' => true,
                'supports_service_catalog_submission' => false,
                'supports_formcreator_submission' => $canSubmitThroughNativeContract,
                'supports_document_item_validation' => false,
                'detected_apis' => $detectedApis,
                'compatibility_matrix' => $compatibilityMatrix,
                'own_submission_readiness' => $submissionReadiness,
                'capability_contract' => $capabilityContract->toArray(),
                'native_submit_contract' => [
                    'enabled' => $canSubmitThroughNativeContract,
                    'form_id' => $id,
                    'submit_endpoint' => '/plugins/formcreator/ajax/formanswer.php',
                    'method' => 'POST',
                    'encoding' => 'multipart/form-data',
                    'engine' => 'formcreator_2_13_11',
                    'input_name_pattern' => 'formcreator_field_{question_id}',
                    'expected_response' => 'json_redirect',
                    'hidden_fields' => [
                        'plugin_formcreator_forms_id' => $id,
                        'add' => '',
                    ],
                    'requires_csrf' => true,
                ],
                'projected_field_count' => count($fields),
                'native_assisted_field_count' => $this->nativeAssistedFieldCount($fields),
                'unsupported_field_count' => count($unsupported),
                'minimum_supported_field_types' => ['text', 'textarea', 'select', 'radio', 'checkbox', 'multiselect', 'date', 'datetime', 'number', 'email', 'file', 'hidden', 'native_reference'],
            ],
            [
                'required' => !$canSubmitThroughNativeContract,
                'reasons' => [
                    $canSubmitThroughNativeContract
                        ? 'Formulario Formcreator 2.13.11 elegivel para submissao delegada ao endpoint nativo, preservando validacoes, targets e criacao final no plugin original.'
                        : ($hasProjectedFields
                            ? 'O formulario Formcreator pode ser projetado para leitura/preenchimento acessivel, mas a submissao permanece no fluxo nativo ate o contrato nativo ficar totalmente verde.'
                            : 'Formcreator GLPI 10 permanece no fluxo nativo ate mapear perguntas, secoes, condicoes, targets, anexos, validacoes e permissoes por formulario.'),
                ],
                'advisory_reasons' => [
                    'O portal lista somente formularios confirmados por permissao nativa quando a classe do Formcreator esta disponivel.',
                    'A submissao convertida usa delegacao para /plugins/formcreator/ajax/formanswer.php, com CSRF e nomes formcreator_field_{id}, somente quando o gate de seguranca permitir.',
                ],
                'native_url' => $nativeUrl,
            ],
            [
                'form_id' => $id,
                'source_label' => (string) ($form['source_label'] ?? 'Formcreator GLPI 10'),
                'entity_id' => (int) ($form['entity_id'] ?? 0),
                'is_recursive' => !empty($form['is_recursive']),
                'native_url' => $nativeUrl,
                'compatibility_status' => $canSubmitThroughNativeContract ? 'native_delegated_submission_ready' : $this->compatibilityStatus($hasProjectedFields, $fields, $unsupported),
                'compatibility_matrix' => $compatibilityMatrix,
                'capability_contract' => $capabilityContract->toArray(),
                'unsupported_questions' => $unsupported,
            ]
        );
    }

    /**
     * @param array<string, mixed> $answers
     * @return array<int, array{field:string, code:string, message:string}>
     */
    public function validate(array $answers, DynamicFormSchema $schema): array
    {
        return [[
            'field' => '',
            'code' => 'native_fallback_required',
            'message' => 'Este formulario do Formcreator deve ser concluido no fluxo nativo do plugin nesta etapa.',
        ]];
    }

    /** @param array<string, mixed> $answers */
    public function submit(array $answers, DynamicFormSchema $schema): DynamicFormSubmissionResult
    {
        return new DynamicFormSubmissionResult(false, [], '', $this->validate($answers, $schema));
    }

    public function nativeUrl(): string
    {
        return 'plugins/formcreator/front/formlist.php';
    }

    /** @return array<string, mixed> */
    public function capabilities(): array
    {
        $detectedApis = $this->detectedApis();
        return [
            'source_of_truth' => 'formcreator_glpi10',
            'renders_own_fields' => false,
            'submits_via_native_engine' => true,
            'supports_service_catalog_submission' => false,
            'supports_formcreator_submission' => false,
            'supports_document_item_validation' => false,
            'detected_apis' => $detectedApis,
            'compatibility_matrix' => $this->compatibilityMatrix($detectedApis, ['fields' => [], 'unsupported' => []]),
            'own_submission_readiness' => $this->ownSubmissionReadiness(0, [], [], [], $detectedApis, []),
            'capability_contract' => FormCapability::fromReadiness(
                self::SOURCE,
                $this->ownSubmissionReadiness(0, [], [], [], $detectedApis, []),
                $this->compatibilityMatrix($detectedApis, ['fields' => [], 'unsupported' => []]),
                false
            )->toArray(),
            'minimum_supported_field_types' => ['text', 'textarea', 'select', 'radio', 'checkbox', 'multiselect', 'date', 'datetime', 'number', 'email', 'file', 'hidden', 'native_reference'],
        ];
    }

    /**
     * @param array<string, mixed> $form
     * @return array{sections:array<int, DynamicFormSection>, fields:array<int, DynamicFormField>, conditions:array<int, DynamicFormCondition>, unsupported:array<int, array<string, string>>}
     */
    private function projectNativeSchema(int $formId, array $form): array
    {
        $sections = [new DynamicFormSection('metadata', 'Identificacao do formulario', 10, 'Dados seguros para exibicao no portal acessivel.')];
        $fields = [new DynamicFormField(
            'formcreator_form_title',
            'formcreator_form_title',
            'text',
            'Formulario Formcreator',
            'metadata',
            false,
            true,
            true,
            true,
            false,
            (string) ($form['name'] ?? ('Formulario #' . $formId)),
            [],
            ['readonly_projection' => true],
            self::SOURCE,
            'formcreator_form_title',
            'Titulo retornado pelo Formcreator.',
            ['projection_only' => true]
        )];
        $conditions = [];
        $unsupported = [];

        foreach ($this->rawSections($formId, $form) as $index => $rawSection) {
            $sectionId = (string) ($rawSection['id'] ?? ('section_' . ($index + 1)));
            $sections[] = new DynamicFormSection(
                'section_' . $sectionId,
                trim((string) ($rawSection['name'] ?? 'Secao ' . ($index + 1))) ?: 'Secao ' . ($index + 1),
                (int) ($rawSection['rank'] ?? (($index + 1) * 10)),
                trim((string) ($rawSection['description'] ?? ''))
            );

            $sectionConditions = $this->portableConditionsForTarget($rawSection, 'section_' . $sectionId, 'section', 'formcreator_section_condition_' . $sectionId);
            if ($sectionConditions !== []) {
                array_push($conditions, ...$sectionConditions);
            } elseif ($this->hasConditions($rawSection)) {
                $conditions[] = new DynamicFormCondition(
                    'formcreator_section_conditions_' . $sectionId,
                    'section_' . $sectionId,
                    'native_fallback',
                    ['engine' => 'formcreator_glpi10', 'reason' => 'section_conditions_not_projected', 'target_type' => 'section'],
                    false,
                    'Esta secao possui condicoes do Formcreator. O envio deve permanecer no motor nativo ate homologacao.'
                );
            }

            foreach ((array) ($rawSection['questions'] ?? []) as $questionIndex => $rawQuestion) {
                if (!is_array($rawQuestion)) {
                    continue;
                }

                $field = $this->fieldFromQuestion($rawQuestion, 'section_' . $sectionId, $questionIndex);
                if ($field === null) {
                    $unsupported[] = [
                        'id' => (string) ($rawQuestion['id'] ?? ''),
                        'label' => (string) ($rawQuestion['name'] ?? ''),
                        'type' => (string) ($rawQuestion['type'] ?? ''),
                    ];
                    continue;
                }
                $fields[] = $field;

                $portableConditions = $this->portableConditionsFromQuestion($rawQuestion, $field, 'formcreator_condition_' . (string) ($rawQuestion['id'] ?? $questionIndex));
                if ($portableConditions !== []) {
                    array_push($conditions, ...$portableConditions);
                } elseif ($this->hasConditions($rawQuestion)) {
                    $conditions[] = new DynamicFormCondition(
                        'formcreator_question_conditions_' . (string) ($rawQuestion['id'] ?? $questionIndex),
                        $field->name(),
                        'native_fallback',
                        ['engine' => 'formcreator_glpi10', 'reason' => 'question_conditions_not_projected'],
                        false,
                        'Esta pergunta possui condicoes do Formcreator. O envio deve permanecer no motor nativo ate homologacao.'
                    );
                }
            }
        }


        return ['sections' => $sections, 'fields' => $fields, 'conditions' => $conditions, 'unsupported' => $unsupported];
    }

    /**
     * @param array<string, mixed> $form
     * @return array<int, array<string, mixed>>
     */
    private function rawSections(int $formId, array $form): array
    {
        if (isset($form['sections']) && is_array($form['sections'])) {
            return array_values(array_filter($form['sections'], 'is_array'));
        }

        if ($formId <= 0) {
            return [];
        }

        $sectionsTable = 'glpi_plugin_formcreator_sections';
        $questionsTable = 'glpi_plugin_formcreator_questions';
        if (!$this->tableExists($questionsTable)) {
            return [];
        }

        $sections = [];
        if ($this->tableExists($sectionsTable)) {
            $formColumn = $this->firstExistingColumn($sectionsTable, ['plugin_formcreator_forms_id', 'forms_id', 'form_id']);
            if ($formColumn !== null) {
                foreach ($this->requestRows($sectionsTable, [$formColumn => $formId], $this->orderColumn($sectionsTable), 200) as $sectionRow) {
                    $sectionId = (int) ($sectionRow['id'] ?? 0);
                    $sections[] = $this->sectionRowToArray($sectionRow, $this->questionsForSection($questionsTable, $sectionId));
                }
            }
        }

        if ($sections !== []) {
            return $sections;
        }

        $questionFormColumn = $this->firstExistingColumn($questionsTable, ['plugin_formcreator_forms_id', 'forms_id', 'form_id']);
        if ($questionFormColumn === null) {
            return [];
        }

        return [[
            'id' => 'questions',
            'name' => 'Perguntas',
            'description' => '',
            'rank' => 10,
            'questions' => $this->questionsForForm($questionsTable, $questionFormColumn, $formId),
        ]];
    }

    /** @return array<int, array<string, mixed>> */
    private function questionsForSection(string $questionsTable, int $sectionId): array
    {
        if ($sectionId <= 0) {
            return [];
        }

        $sectionColumn = $this->firstExistingColumn($questionsTable, ['plugin_formcreator_sections_id', 'sections_id', 'section_id']);
        if ($sectionColumn === null) {
            return [];
        }

        return array_map(
            fn(array $row): array => $this->questionRowToArray($row),
            $this->requestRows($questionsTable, [$sectionColumn => $sectionId], $this->orderColumn($questionsTable), 500)
        );
    }

    /** @return array<int, array<string, mixed>> */
    private function questionsForForm(string $questionsTable, string $formColumn, int $formId): array
    {
        return array_map(
            fn(array $row): array => $this->questionRowToArray($row),
            $this->requestRows($questionsTable, [$formColumn => $formId], $this->orderColumn($questionsTable), 500)
        );
    }

    /**
     * @param array<string, mixed> $sectionRow
     * @param array<int, array<string, mixed>> $questions
     * @return array<string, mixed>
     */
    private function sectionRowToArray(array $sectionRow, array $questions): array
    {
        return [
            'id' => (int) ($sectionRow['id'] ?? 0),
            'name' => (string) ($sectionRow['name'] ?? $sectionRow['title'] ?? 'Secao'),
            'description' => (string) ($sectionRow['description'] ?? $sectionRow['comment'] ?? ''),
            'rank' => (int) ($sectionRow['rank'] ?? $sectionRow['order'] ?? $sectionRow['position'] ?? 0),
            'conditions' => (string) ($sectionRow['conditions'] ?? $sectionRow['show_rule'] ?? ''),
            'questions' => $questions,
        ];
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private function questionRowToArray(array $row): array
    {
        $type = (string) ($row['fieldtype'] ?? $row['type'] ?? $row['question_type'] ?? '');
        $rawOptions = $row['values'] ?? $row['possible_values'] ?? $row['options'] ?? null;

        return [
            'id' => (int) ($row['id'] ?? 0),
            'uuid' => (string) ($row['uuid'] ?? ''),
            'name' => (string) ($row['name'] ?? $row['question'] ?? $row['label'] ?? ''),
            'description' => (string) ($row['description'] ?? $row['comment'] ?? ''),
            'type' => $type,
            'default_value' => $this->decodeJsonish($row['default_values'] ?? $row['default_value'] ?? null),
            'extra_data' => ['options' => $this->normalizeOptions($rawOptions)],
            'required' => !empty($row['is_required']) || !empty($row['required']) || !empty($row['is_mandatory']),
            'conditions' => (string) ($row['conditions'] ?? $row['show_rule'] ?? ''),
            'validation_conditions' => (string) ($row['validation_conditions'] ?? $row['regex'] ?? ''),
            'rank' => (int) ($row['rank'] ?? $row['order'] ?? $row['position'] ?? 0),
        ];
    }

    /** @param array<string, mixed> $question */
    private function fieldFromQuestion(array $question, string $sectionId, int $index): ?DynamicFormField
    {
        $nativeType = (string) ($question['type'] ?? '');
        $type = $this->mapQuestionType($nativeType);
        if ($type === '') {
            return null;
        }

        $id = (string) ($question['id'] ?? ($index + 1));
        $name = (string) ($question['uuid'] ?? '') !== '' ? (string) $question['uuid'] : 'formcreator_question_' . $id;
        $label = trim((string) ($question['name'] ?? '')) ?: 'Pergunta ' . ($index + 1);
        $options = $this->questionOptions($question);
        $nativeAssisted = $type === 'native_reference';
        $hidden = $type === 'hidden';
        $multiple = $type === 'multiselect' || (!empty($question['multiple']));
        $description = trim((string) ($question['description'] ?? ''));
        if ($nativeAssisted) {
            $description = trim($description . ' ' . $this->nativeAssistedDescription());
        }

        return new DynamicFormField(
            'formcreator_question_' . $id,
            $name,
            $type,
            $label,
            $sectionId,
            !empty($question['required']),
            !$hidden,
            $nativeAssisted || $hidden,
            $nativeAssisted || $hidden,
            $multiple,
            $question['default_value'] ?? null,
            $options,
            $this->constraintsForType($type, $nativeType),
            self::SOURCE,
            $name,
            $description,
            [
                'native_question_id' => $id,
                'native_question_type' => $nativeType,
                'render_only_until_native_submit' => true,
                'native_input_name' => 'formcreator_field_' . $id,
                'native_assisted' => $nativeAssisted,
                'hidden_projection' => $hidden,
            ]
        );
    }

    private function mapQuestionType(string $nativeType): string
    {
        $lower = strtolower(trim($nativeType));
        return match (true) {
            $lower === '' => '',
            str_contains($lower, 'textarea') || str_contains($lower, 'text area') => 'textarea',
            str_contains($lower, 'multiselect') || str_contains($lower, 'multi select') => 'multiselect',
            str_contains($lower, 'checkbox') => 'checkbox',
            str_contains($lower, 'radio') => 'radio',
            $this->isNativeReferenceQuestionType($lower) => 'native_reference',
            str_contains($lower, 'select') => 'select',
            str_contains($lower, 'email') => 'email',
            str_contains($lower, 'integer') || str_contains($lower, 'float') || str_contains($lower, 'number') => 'number',
            str_contains($lower, 'datetime') || str_contains($lower, 'date time') => 'datetime',
            str_contains($lower, 'date') => 'date',
            str_contains($lower, 'time') => 'native_reference',
            str_contains($lower, 'file') => 'file',
            str_contains($lower, 'hidden') => 'hidden',
            str_contains($lower, 'description') => 'native_reference',
            str_contains($lower, 'urgency') || str_contains($lower, 'requesttype') || str_contains($lower, 'request type') => 'select',
            str_contains($lower, 'hostname') || str_contains($lower, 'ip') || str_contains($lower, 'text') => 'text',
            default => '',
        };
    }

    private function isNativeReferenceQuestionType(string $lowerNativeType): bool
    {
        foreach (['actor', 'glpi object', 'glpiobject', 'ldap', 'tag', 'dropdown', 'user', 'group', 'requester', 'assignee', 'observer'] as $token) {
            if (str_contains($lowerNativeType, $token)) {
                return true;
            }
        }

        return false;
    }

    private function nativeAssistedDescription(): string
    {
        return 'Este campo depende de seletor, permissao ou opcoes nativas do Formcreator/GLPI. Revise e conclua no fluxo nativo para preservar ACL, entidade e validacoes.';
    }

    /** @param array<string, mixed> $question @return array<int, array<string, mixed>> */
    private function questionOptions(array $question): array
    {
        $extra = is_array($question['extra_data'] ?? null) ? $question['extra_data'] : [];
        $rawOptions = is_array($question['options'] ?? null) ? $question['options'] : ($extra['options'] ?? []);
        return is_array($rawOptions) ? $this->normalizeOptions($rawOptions) : [];
    }

    /** @return array<int, array<string, mixed>> */
    private function normalizeOptions(mixed $rawOptions): array
    {
        if (is_string($rawOptions)) {
            $decoded = json_decode($rawOptions, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $rawOptions = $decoded;
            } else {
                $rawOptions = preg_split('/\r\n|\r|\n|;/', $rawOptions) ?: [];
            }
        }

        if (!is_array($rawOptions)) {
            return [];
        }

        $options = [];
        foreach ($rawOptions as $key => $option) {
            if (is_array($option)) {
                $label = (string) ($option['label'] ?? $option['name'] ?? $option['value'] ?? $key);
                $value = (string) ($option['id'] ?? $option['value'] ?? $key);
            } else {
                $label = trim((string) $option);
                $value = is_string($key) ? $key : $label;
            }
            if ($label !== '') {
                $options[] = ['id' => $value, 'label' => $label];
            }
        }

        return $options;
    }

    /** @return array<string, mixed> */
    private function constraintsForType(string $type, string $nativeType): array
    {
        $constraints = match ($type) {
            'email' => ['format' => 'email'],
            'number' => ['numeric' => true],
            'file' => ['native_upload_required' => true],
            'native_reference' => ['native_engine_required' => true],
            'hidden' => ['server_side_only' => true],
            default => [],
        };

        $lower = strtolower($nativeType);
        if (str_contains($lower, 'ip')) {
            $constraints['format'] = 'ip';
        }
        if (str_contains($lower, 'hostname')) {
            $constraints['format'] = 'hostname';
        }

        return $constraints;
    }

    /**
     * @param array<string, mixed> $question
     * @return array<int, DynamicFormCondition>
     */
    private function portableConditionsFromQuestion(array $question, DynamicFormField $field, string $prefix): array
    {
        return $this->portableConditionsForTarget($question, $field->name(), 'field', $prefix);
    }

    /**
     * @param array<string, mixed> $item
     * @return array<int, DynamicFormCondition>
     */
    private function portableConditionsForTarget(array $item, string $target, string $targetType, string $prefix): array
    {
        $rawConditions = $item['portable_conditions'] ?? $item['dynamic_conditions'] ?? null;
        if (!is_array($rawConditions)) {
            return [];
        }

        $conditions = [];
        foreach (array_values($rawConditions) as $index => $rawCondition) {
            if (!is_array($rawCondition)) {
                continue;
            }

            $effect = (string) ($rawCondition['effect'] ?? $rawCondition['action'] ?? 'show');
            if (!in_array($effect, ['show', 'hide', 'require', 'disable'], true)) {
                continue;
            }

            $expression = $this->normalizePortableExpression($rawCondition);
            if ($expression === []) {
                continue;
            }
            if ($targetType !== 'field') {
                $expression['target_type'] = $targetType;
            }

            $conditions[] = new DynamicFormCondition(
                $prefix . '_' . (string) ($index + 1),
                $target,
                $effect,
                $expression,
                true,
                ''
            );
        }

        return $conditions;
    }

    /**
     * @param array<string, mixed> $rawCondition
     * @return array<string, mixed>
     */
    private function normalizePortableExpression(array $rawCondition): array
    {
        $expression = is_array($rawCondition['expression'] ?? null) ? $rawCondition['expression'] : $rawCondition;
        return $this->normalizePortableExpressionNode($expression);
    }

    /**
     * @param array<string, mixed> $node
     * @return array<string, mixed>
     */
    private function normalizePortableExpressionNode(array $node): array
    {
        foreach (['all', 'any'] as $groupKey) {
            if (!isset($node[$groupKey]) || !is_array($node[$groupKey])) {
                continue;
            }
            $children = [];
            foreach ($node[$groupKey] as $child) {
                if (!is_array($child)) {
                    continue;
                }
                $normalized = $this->normalizePortableExpressionNode($child);
                if ($normalized !== []) {
                    $children[] = $normalized;
                }
            }
            return $children !== [] ? [$groupKey => $children] : [];
        }

        if (isset($node['not']) && is_array($node['not'])) {
            $normalized = $this->normalizePortableExpressionNode($node['not']);
            return $normalized !== [] ? ['not' => $normalized] : [];
        }

        $sourceField = (string) ($node['field'] ?? $node['source_field'] ?? $node['question'] ?? '');
        $operator = (string) ($node['operator'] ?? 'equals');
        if ($sourceField === '' || !in_array($operator, ['equals', 'not_equals', 'empty', 'not_empty', 'contains', 'in', 'not_in'], true)) {
            return [];
        }

        return [
            'field' => $sourceField,
            'operator' => $operator,
            'value' => $node['value'] ?? null,
            'values' => is_array($node['values'] ?? null) ? array_values($node['values']) : [],
        ];
    }
    /** @param array<string, mixed> $item */
    private function hasConditions(array $item): bool
    {
        foreach (['conditions', 'validation_conditions', 'submit_button_conditions'] as $key) {
            $value = $item[$key] ?? '';
            if (is_array($value) && $value !== []) {
                return true;
            }
            if (is_string($value)) {
                $trimmed = trim($value);
                if ($trimmed !== '' && $trimmed !== '[]' && $trimmed !== '{}') {
                    return true;
                }
            }
        }
        return false;
    }

    private function decodeJsonish(mixed $value): mixed
    {
        if (!is_string($value) || trim($value) === '') {
            return $value;
        }
        $decoded = json_decode($value, true);
        return json_last_error() === JSON_ERROR_NONE ? $decoded : $value;
    }

    /**
     * @param array<string, bool> $detectedApis
     * @param array<string, mixed> $projected
     * @param array<string, mixed> $submissionReadiness
     * @return array<int, array{area:string,status:string,message:string,fallback_required:bool}>
     */
    private function compatibilityMatrix(array $detectedApis, array $projected, array $submissionReadiness = []): array
    {
        $hasFormClass = !empty($detectedApis['PluginFormcreatorForm']);
        $hasQuestionTable = !empty($detectedApis['formcreator_questions_table']);
        $hasAccessMethod = !empty($detectedApis['PluginFormcreatorForm::canViewForRequest']);
        $hasFormAnswer = !empty($detectedApis['PluginFormcreatorFormAnswer']);
        $canSubmit = !empty($submissionReadiness['ready']);
        $blockedAreas = array_flip((array) ($submissionReadiness['blocked_areas'] ?? []));
        $fields = (array) ($projected['fields'] ?? []);
        $fieldCount = count($fields);
        $unsupportedCount = count((array) ($projected['unsupported'] ?? []));
        $nativeAssistedCount = $this->nativeAssistedFieldCount($fields);
        $conditions = (array) ($projected['conditions'] ?? []);
        $supportedConditionCount = 0;
        $nativeConditionCount = 0;
        foreach ($conditions as $condition) {
            if (!$condition instanceof DynamicFormCondition) {
                continue;
            }
            if ($condition->isSupported()) {
                $supportedConditionCount++;
            } else {
                $nativeConditionCount++;
            }
        }

        return [[
            'area' => 'field_types',
            'status' => $canSubmit ? 'projected_for_native_delegation' : $this->fieldTypesStatus($fieldCount, $unsupportedCount, $nativeAssistedCount, $hasFormClass || $hasQuestionTable),
            'message' => $fieldCount > 1
                ? sprintf('Schema Formcreator projetado com %d campo(s), %d tipo(s) assistido(s) pelo nativo e %d tipo(s) nao suportado(s).', max(0, $fieldCount - 1), $nativeAssistedCount, $unsupportedCount)
                : 'Formcreator detectado; nenhum campo dinamico foi projetado com seguranca para este item.',
            'fallback_required' => !$canSubmit && ($fieldCount <= 1 || $unsupportedCount > 0 || $nativeAssistedCount > 0),
        ], [
            'area' => 'conditions',
            'status' => $canSubmit ? 'portable_or_absent' : ($supportedConditionCount > 0 ? ($nativeConditionCount > 0 ? 'portable_partial' : 'portable_supported') : 'native_engine_required'),
            'message' => $canSubmit
                ? 'Sem condicoes nativas bloqueantes detectadas; validacao final permanece delegada ao Formcreator.'
                : ($supportedConditionCount > 0
                    ? sprintf('Condicoes portaveis suportadas: %d. Condicoes nativas/nao normalizadas: %d. Regras de secao, submit button e target ainda permanecem no Formcreator quando nao normalizadas.', $supportedConditionCount, $nativeConditionCount)
                    : 'Condicoes por pergunta, secao, botao de envio e target permanecem no Formcreator ate equivalencia homologada.'),
            'fallback_required' => isset($blockedAreas['complex_or_native_conditions']),
        ], [
            'area' => 'targets',
            'status' => $canSubmit ? 'ticket_targets_delegated' : 'native_engine_required',
            'message' => $canSubmit
                ? 'Targets de ticket foram confirmados; criacao final de um ou varios tickets sera delegada ao Formcreator.'
                : 'Targets de ticket/change/problem, multiplos targets e destinos condicionais permanecem no fluxo nativo ate inventario seguro.',
            'fallback_required' => isset($blockedAreas['targets_unverified']) || isset($blockedAreas['targets_missing']) || isset($blockedAreas['targets_non_ticket']),
        ], [
            'area' => 'attachments',
            'status' => $canSubmit ? 'not_required' : 'native_engine_required',
            'message' => $canSubmit
                ? 'Nenhum campo de arquivo bloqueante foi detectado neste formulario.'
                : 'Campos de arquivo dependem da politica nativa do Formcreator e vinculacao final no GLPI.',
            'fallback_required' => isset($blockedAreas['attachments']),
        ], [
            'area' => 'validations',
            'status' => $canSubmit ? 'native_delegated' : 'native_engine_required',
            'message' => $canSubmit
                ? 'Validacoes servidor-side serao executadas por PluginFormcreatorFormAnswer::add via endpoint nativo.'
                : 'Validacoes do Formcreator ainda nao foram normalizadas em {field, code, message}.',
            'fallback_required' => isset($blockedAreas['validator_required']),
        ], [
            'area' => 'permissions',
            'status' => $hasAccessMethod ? 'native_acl_detected' : 'native_acl_partial',
            'message' => 'Listagem e abertura devem continuar usando permissao nativa do Formcreator, entidade, perfil e sessao GLPI.',
            'fallback_required' => !$hasAccessMethod,
        ], [
            'area' => 'apis',
            'status' => $canSubmit ? 'native_submit_contract_detected' : (($hasFormClass || $hasQuestionTable || $hasFormAnswer) ? 'detected' : 'partial'),
            'message' => $canSubmit
                ? 'Contrato Formcreator 2.13.11 detectado: POST multipart para /plugins/formcreator/ajax/formanswer.php com plugin_formcreator_forms_id, add, CSRF e formcreator_field_{id}.'
                : 'APIs/tabelas detectadas sao registradas para homologacao GLPI 10/Formcreator.',
            'fallback_required' => !$canSubmit,
        ], [
            'area' => 'fallback',
            'status' => $canSubmit ? 'not_required' : 'required',
            'message' => $canSubmit
                ? 'Fallback nativo nao e obrigatorio para este formulario simples; o envio convertido delega a criacao ao Formcreator.'
                : 'Fallback nativo obrigatorio ate a matriz de perguntas, condicoes, targets, anexos, validacoes e permissoes ficar verde.',
            'fallback_required' => !$canSubmit,
        ]];
    }

    /**
     * @param array<int, DynamicFormField> $fields
     * @param array<int, DynamicFormCondition> $conditions
     * @param array<int, array<string, string>> $unsupported
     * @param array<string, bool> $detectedApis
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    private function ownSubmissionReadiness(int $formId, array $fields, array $conditions, array $unsupported, array $detectedApis, array $form): array
    {
        $blockedAreas = [];
        $requiredApis = [
            'PluginFormcreatorForm' => 'Classe base do Formcreator ausente.',
            'PluginFormcreatorFormAnswer' => 'Classe nativa PluginFormcreatorFormAnswer ausente para criar respostas e targets.',
            'PluginFormcreatorForm::canViewForRequest' => 'Metodo nativo de permissao canViewForRequest nao detectado.',
        ];

        foreach ($requiredApis as $api => $message) {
            if (empty($detectedApis[$api])) {
                $blockedAreas['api_' . strtolower((string) preg_replace('/[^a-z0-9]+/i', '_', $api))] = $message;
            }
        }

        if ($formId <= 0) {
            $blockedAreas['form_id'] = 'ID nativo do formulario Formcreator indisponivel.';
        }
        if ($unsupported !== []) {
            $blockedAreas['unsupported_fields'] = 'Ha campos ou perguntas sem mapeamento seguro no renderer proprio.';
        }
        if (!empty($form['is_captcha_enabled']) || !empty($form['captcha_enabled'])) {
            $blockedAreas['captcha'] = 'Formulario com captcha deve permanecer no fluxo nativo do Formcreator.';
        }
        if ((int) ($form['access_rights'] ?? 1) === 0 || !empty($form['is_public'])) {
            $blockedAreas['public_access'] = 'Formulario publico/anÃƒÂ´nimo do Formcreator cria sessao temporaria propria e deve permanecer no fluxo nativo.';
        }
        if ((int) ($form['validation_required'] ?? $form['is_validation_required'] ?? 0) > 0) {
            $blockedAreas['validator_required'] = 'Formulario exige validador/intermediacao nativa do Formcreator.';
        }

        $answerableQuestionCount = 0;
        foreach ($fields as $field) {
            if (!$field instanceof DynamicFormField) {
                continue;
            }
            $data = $field->toArray();
            $metadata = is_array($data['metadata'] ?? null) ? $data['metadata'] : [];
            if (!empty($metadata['projection_only']) || !empty($metadata['hidden_projection'])) {
                if (!empty($metadata['hidden_projection'])) {
                    $blockedAreas['hidden_fields'] = 'Campos ocultos do Formcreator sao definidos pelo motor nativo e nao devem ser preenchidos pelo portal.';
                }
                continue;
            }

            $answerableQuestionCount++;
            $fieldType = (string) ($data['type'] ?? '');
            $nativeQuestionId = (int) ($metadata['native_question_id'] ?? 0);
            if ($nativeQuestionId <= 0) {
                $blockedAreas['native_question_ids'] = 'Nem todos os campos projetados possuem ID nativo de pergunta para serializar formcreator_field_{id}.';
            }
            if (!empty($metadata['native_assisted']) || $fieldType === 'native_reference') {
                $blockedAreas['native_reference_fields'] = 'Campos native_reference dependem de seletores e ACL nativos: atores, observadores, dispositivos, assets, grupos, LDAP, tags e GLPI Object.';
            }
            if ($fieldType === 'file') {
                $blockedAreas['attachments'] = 'Anexos do Formcreator exigem uploader nativo e vinculacao final por PluginFormcreatorAnswer/Document_Item; manter fallback ate homologacao.';
            }
            if (!empty($data['disabled']) && empty($metadata['native_assisted']) && empty($metadata['hidden_projection'])) {
                $blockedAreas['disabled_fields'] = 'Ha campos desabilitados no renderer que podem ser obrigatorios no motor nativo.';
            }
        }

        if ($answerableQuestionCount === 0) {
            $blockedAreas['answerable_fields'] = 'Nenhuma pergunta nativa serializavel foi projetada para submissao pelo portal.';
        }

        foreach ($conditions as $condition) {
            if ($condition instanceof DynamicFormCondition && !$condition->isSupported()) {
                $blockedAreas['complex_or_native_conditions'] = 'Condicoes nativas ou nao normalizadas por pergunta, secao, submit ou target permanecem no motor original.';
                break;
            }
        }

        $targetSummary = $this->targetSummary($formId, $form);
        if (empty($targetSummary['known'])) {
            $blockedAreas['targets_unverified'] = 'Targets do Formcreator nao puderam ser inventariados com seguranca.';
        } elseif ((int) ($targetSummary['total'] ?? 0) <= 0) {
            $blockedAreas['targets_missing'] = 'Nenhum target nativo do Formcreator foi confirmado para gerar a solicitacao.';
        } elseif ((int) ($targetSummary['change'] ?? 0) > 0 || (int) ($targetSummary['problem'] ?? 0) > 0) {
            $blockedAreas['targets_non_ticket'] = 'Targets de change/problem permanecem no fluxo nativo ate homologacao especifica.';
        }

        $ready = $blockedAreas === [];

        return [
            'ready' => $ready,
            'decision' => $ready ? 'formcreator_native_delegated_submission' : 'native_fallback_required',
            'feature_flag' => 'glpiacessivel_dynamic_form_own_submission',
            'contract_source' => 'formcreator_2_13_11',
            'target_summary' => $targetSummary,
            'required_green_areas' => [
                'field_types',
                'conditions',
                'ticket_targets_delegated',
                'no_attachments',
                'native_server_validations',
                'permissions',
                'csrf',
                'accessibility',
            ],
            'blocked_areas' => array_keys($blockedAreas),
            'blockers' => $blockedAreas,
        ];
    }

    /**
     * @param array<string, mixed> $form
     * @return array{known:bool,ticket:int,change:int,problem:int,total:int}
     */
    private function targetSummary(int $formId, array $form): array
    {
        if (isset($form['target_summary']) && is_array($form['target_summary'])) {
            $summary = $form['target_summary'];
            $ticket = (int) ($summary['ticket'] ?? $summary['tickets'] ?? 0);
            $change = (int) ($summary['change'] ?? $summary['changes'] ?? 0);
            $problem = (int) ($summary['problem'] ?? $summary['problems'] ?? 0);
            return [
                'known' => (bool) ($summary['known'] ?? true),
                'ticket' => $ticket,
                'change' => $change,
                'problem' => $problem,
                'total' => (int) ($summary['total'] ?? ($ticket + $change + $problem)),
            ];
        }

        if ($formId <= 0) {
            return ['known' => false, 'ticket' => 0, 'change' => 0, 'problem' => 0, 'total' => 0];
        }

        $ticket = $this->countTargetRows('glpi_plugin_formcreator_targettickets', $formId);
        $change = $this->countTargetRows('glpi_plugin_formcreator_targetchanges', $formId);
        $problem = $this->countTargetRows('glpi_plugin_formcreator_targetproblems', $formId);
        if ($ticket === null && $change === null && $problem === null) {
            return ['known' => false, 'ticket' => 0, 'change' => 0, 'problem' => 0, 'total' => 0];
        }

        $ticket = $ticket ?? 0;
        $change = $change ?? 0;
        $problem = $problem ?? 0;
        return [
            'known' => true,
            'ticket' => $ticket,
            'change' => $change,
            'problem' => $problem,
            'total' => $ticket + $change + $problem,
        ];
    }

    private function countTargetRows(string $table, int $formId): ?int
    {
        $formColumn = $this->firstExistingColumn($table, ['plugin_formcreator_forms_id', 'forms_id', 'form_id']);
        if ($formColumn === null) {
            return null;
        }

        return $this->countRows($table, [$formColumn => $formId]);
    }

    /** @param array<string, mixed> $where */
    private function countRows(string $table, array $where): ?int
    {
        global $DB;

        if (!isset($DB) || !method_exists($DB, 'request') || !$this->tableExists($table)) {
            return null;
        }

        try {
            $count = 0;
            foreach ($DB->request(['FROM' => $table, 'WHERE' => $where]) as $_row) {
                $count++;
            }
            return $count;
        } catch (\Throwable $e) {
            return null;
        }
    }
    private function nativeAssistedFieldCount(array $fields): int
    {
        $count = 0;
        foreach ($fields as $field) {
            if (!$field instanceof DynamicFormField) {
                continue;
            }
            $data = $field->toArray();
            if (!empty($data['metadata']['native_assisted'])) {
                $count++;
            }
        }

        return $count;
    }

    /** @param array<int, DynamicFormField> $fields */
    private function compatibilityStatus(bool $hasProjectedFields, array $fields, array $unsupported): string
    {
        if (!$hasProjectedFields || $unsupported !== []) {
            return 'native_fallback_required';
        }

        return $this->nativeAssistedFieldCount($fields) > 0 ? 'projected_with_native_assist' : 'renderer_candidate';
    }

    private function fieldTypesStatus(int $fieldCount, int $unsupportedCount, int $nativeAssistedCount, bool $hasInventory): string
    {
        if ($fieldCount <= 1) {
            return $hasInventory ? 'inventory_available' : 'api_missing';
        }
        if ($unsupportedCount > 0) {
            return 'partial';
        }
        if ($nativeAssistedCount > 0) {
            return 'projected_with_native_assist';
        }

        return 'projected';
    }

    /** @return array<string, bool> */
    private function detectedApis(): array
    {
        return [
            'PluginFormcreatorForm' => class_exists('\\PluginFormcreatorForm'),
            'PluginFormcreatorFormAnswer' => class_exists('\\PluginFormcreatorFormAnswer'),
            'Plugin' => class_exists('\\Plugin'),
            'PluginFormcreatorForm::canViewForRequest' => class_exists('\\PluginFormcreatorForm') && method_exists('\\PluginFormcreatorForm', 'canViewForRequest'),
            'formcreator_sections_table' => $this->tableExists('glpi_plugin_formcreator_sections'),
            'formcreator_questions_table' => $this->tableExists('glpi_plugin_formcreator_questions'),
            'formcreator_targettickets_table' => $this->tableExists('glpi_plugin_formcreator_targettickets'),
            'formcreator_targetchanges_table' => $this->tableExists('glpi_plugin_formcreator_targetchanges'),
            'formcreator_targetproblems_table' => $this->tableExists('glpi_plugin_formcreator_targetproblems'),
        ];
    }

    /** @param array<string, mixed> $where @return array<int, array<string, mixed>> */
    private function requestRows(string $table, array $where, ?string $orderColumn, int $limit): array
    {
        global $DB;

        if (!isset($DB) || !method_exists($DB, 'request') || !$this->tableExists($table)) {
            return [];
        }

        $query = [
            'FROM' => $table,
            'WHERE' => $where,
            'LIMIT' => $limit,
        ];
        if ($orderColumn !== null) {
            $query['ORDER'] = [$orderColumn . ' ASC'];
        }

        $rows = [];
        try {
            foreach ($DB->request($query) as $row) {
                $rows[] = is_array($row) ? $row : iterator_to_array($row);
            }
        } catch (\Throwable $e) {
            return [];
        }

        return $rows;
    }

    private function orderColumn(string $table): ?string
    {
        return $this->firstExistingColumn($table, ['rank', 'order', 'position', 'id']);
    }

    /** @param string[] $columns */
    private function firstExistingColumn(string $table, array $columns): ?string
    {
        foreach ($columns as $column) {
            if ($this->columnExists($table, $column)) {
                return $column;
            }
        }

        return null;
    }

    private function tableExists(string $table): bool
    {
        global $DB;

        return isset($DB) && method_exists($DB, 'tableExists') && (bool) $DB->tableExists($table);
    }

    private function columnExists(string $table, string $column): bool
    {
        global $DB;

        return isset($DB) && method_exists($DB, 'fieldExists') && (bool) $DB->fieldExists($table, $column);
    }
}
