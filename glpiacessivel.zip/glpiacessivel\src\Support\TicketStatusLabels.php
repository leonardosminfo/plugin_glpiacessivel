<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

final class TicketStatusLabels
{
    /**
     * @return array<int, string>
     */
    public static function all(): array
    {
        if (class_exists('\Ticket') && method_exists('\Ticket', 'getAllStatusArray')) {
            $native = (array) \Ticket::getAllStatusArray(false);
            $labels = [];
            foreach ($native as $status => $label) {
                $statusId = (int) $status;
                $normalizedLabel = trim((string) $label);
                if ($statusId > 0 && $normalizedLabel !== '') {
                    $labels[$statusId] = $normalizedLabel;
                }
            }

            if ($labels !== []) {
                return $labels;
            }
        }

        return [
            1 => self::translate('Novo'),
            2 => self::translate('Em atendimento atribuido'),
            3 => self::translate('Em atendimento planejado'),
            4 => self::translate('Pendente'),
            5 => self::translate('Solucionado'),
            6 => self::translate('Fechado'),
        ];
    }

    public static function label(int $status): string
    {
        $labels = self::all();
        if (isset($labels[$status])) {
            return $labels[$status];
        }

        return self::translate('Status') . ' ' . $status;
    }

    private static function translate(string $message): string
    {
        return function_exists('__') ? (string) __($message, 'glpiacessivel') : $message;
    }
}
