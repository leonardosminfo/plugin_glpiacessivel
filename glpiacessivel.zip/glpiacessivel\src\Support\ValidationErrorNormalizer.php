<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

final class ValidationErrorNormalizer
{
    /**
     * @param mixed $errors
     * @return array<int, array{field:string, code:string, message:string}>
     */
    public static function normalize(mixed $errors, string $defaultField = '', string $defaultCode = 'validation_error'): array
    {
        if ($errors === null || $errors === []) {
            return [];
        }

        if (is_string($errors) || is_numeric($errors)) {
            return [self::item($defaultField, $defaultCode, (string) $errors)];
        }

        if (!is_array($errors)) {
            return [self::item($defaultField, $defaultCode, 'Dados invalidos.')];
        }

        if (self::looksLikeError($errors)) {
            return [self::itemFromArray($errors, $defaultField, $defaultCode)];
        }

        $normalized = [];
        foreach ($errors as $key => $error) {
            $field = is_string($key) && !is_numeric($key) ? $key : $defaultField;
            $normalized = array_merge(
                $normalized,
                self::normalize($error, $field, $defaultCode)
            );
        }

        return $normalized;
    }

    /**
     * @param array<string, mixed> $error
     * @return array{field:string, code:string, message:string}
     */
    private static function itemFromArray(array $error, string $defaultField, string $defaultCode): array
    {
        $field = trim((string) ($error['field'] ?? $error['name'] ?? $error['question_id'] ?? $defaultField));
        $code = trim((string) ($error['code'] ?? $error['error_code'] ?? $error['type'] ?? $defaultCode));
        $message = trim((string) ($error['message'] ?? $error['detail'] ?? $error['error'] ?? 'Dados invalidos.'));

        return self::item($field, $code, $message);
    }

    /**
     * @param array<string, mixed> $value
     */
    private static function looksLikeError(array $value): bool
    {
        return array_key_exists('message', $value)
            || array_key_exists('field', $value)
            || array_key_exists('code', $value)
            || array_key_exists('error_code', $value)
            || array_key_exists('question_id', $value);
    }

    /**
     * @return array{field:string, code:string, message:string}
     */
    private static function item(string $field, string $code, string $message): array
    {
        return [
            'field' => trim($field),
            'code' => trim($code) !== '' ? trim($code) : 'validation_error',
            'message' => trim($message) !== '' ? trim($message) : 'Dados invalidos.',
        ];
    }
}
