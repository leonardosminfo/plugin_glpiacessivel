<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\Support\Url;

final class ContextController extends BaseController
{
    public static function switch(): void
    {
        self::requireLogin();

        if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
            \Html::redirect(Url::plugin('front/acessivel.php'));
        }

        self::csrf()->validateRequest();

        $sanitizer = new InputSanitizer();
        $profileId = max(0, $sanitizer->int($_POST['profile_id'] ?? 0, 0));
        $entityValue = trim((string) ($_POST['entity_id'] ?? 'current'));
        $returnTo = self::container()->contextService()->safeReturnTo((string) ($_POST['return_to'] ?? ''));

        try {
            $effectiveContext = self::container()->contextService()->switchContext($profileId, $entityValue, $returnTo);
            self::setMessage(
                'success',
                'Contexto atualizado. ' . (string) ($effectiveContext['summary'] ?? 'As telas agora usam o contexto efetivo do GLPI.')
            );
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('context.switch.failed', [
                'profile_id' => $profileId,
                'entity_value' => $entityValue,
                'error' => $e->getMessage(),
            ]);
            self::setMessage('error', __('Nao foi possivel alterar entidade ou perfil. Verifique se o contexto selecionado esta permitido para seu usuario.', 'glpiacessivel'));
        }

        \Html::redirect($returnTo);
    }
}
