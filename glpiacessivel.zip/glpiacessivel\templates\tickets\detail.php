<?php
$routing = is_array($ticket['routing_context'] ?? null) ? $ticket['routing_context'] : [];
$itilActions = is_array($ticket['itil_actions'] ?? null) ? $ticket['itil_actions'] : [];
$satisfaction = is_array($ticket['satisfaction_state'] ?? null) ? $ticket['satisfaction_state'] : [];
$historyContext = is_array($ticket['history_context'] ?? null) ? $ticket['history_context'] : [];
$historyItems = array_values((array) ($historyContext['items'] ?? []));
$criticalConfirmations = is_array($critical_confirmations ?? null) ? $critical_confirmations : [];
$assignedUserIds = array_values(array_map('intval', (array) ($routing['assigned_user_ids'] ?? [])));
$observerUserIds = array_values(array_map('intval', (array) ($routing['observer_user_ids'] ?? [])));
$assignedGroupIds = array_values(array_map('intval', (array) ($routing['assigned_group_ids'] ?? [])));
$followupTemplates = array_values((array) ($ticket['followup_templates'] ?? []));
$taskCategories = array_values((array) ($routing['task_categories'] ?? []));
$taskStateOptions = array_values((array) ($routing['task_state_options'] ?? []));
$taskDurationOptions = array_values((array) ($routing['task_duration_options'] ?? []));
$assignableUsers = array_values((array) ($routing['assignable_users'] ?? []));
$assignableGroups = array_values((array) ($routing['assignable_groups'] ?? []));
$ticketStatus = (int) ($ticket['status'] ?? 0);
$solvedStatus = defined('\CommonITILObject::SOLVED') ? (int) \CommonITILObject::SOLVED : 5;
$closedStatus = defined('\CommonITILObject::CLOSED') ? (int) \CommonITILObject::CLOSED : 6;
$isSolved = $ticketStatus === $solvedStatus;
$isClosed = $ticketStatus === $closedStatus;
$isTerminal = $isSolved || $isClosed;
$currentUserId = (int) ($_SESSION['glpiID'] ?? 0);
$requesterId = (int) ($ticket['requester_id'] ?? 0);
$canAddFollowup = !$isTerminal && !empty($itilActions['can_add_followup']);
$canAddTask = !$isTerminal && !empty($itilActions['can_add_task']);
$canAddSolution = !$isTerminal && !empty($itilActions['can_add_solution']);
$canChangeStatus = !$isTerminal && !empty($itilActions['can_change_status']);
$canRoute = !$isTerminal && !empty($itilActions['can_route']);
$canDecideSolution = $isSolved && $requesterId > 0
    && ($requesterId === $currentUserId || !empty($routing['can_update']));
$itilTabs = [];
if ($canAddFollowup) {
    $itilTabs[] = ['key' => 'followup', 'label' => 'Responder', 'hint' => 'Acompanhamento'];
}
if ($canAddTask) {
    $itilTabs[] = ['key' => 'task', 'label' => 'Criar tarefa', 'hint' => 'Atividade tecnica'];
}
if ($canAddSolution) {
    $itilTabs[] = ['key' => 'solution', 'label' => 'Adicionar solucao', 'hint' => 'Encaminhar encerramento'];
}
$activeItilTab = (string) ($itilTabs[0]['key'] ?? '');
$defaultTaskState = (int) ($taskStateOptions[0]['id'] ?? 2);
foreach ($taskStateOptions as $taskStateOption) {
    $taskStateLabel = (string) ($taskStateOption['label'] ?? '');
    $taskStateId = (int) ($taskStateOption['id'] ?? 0);
    if ($taskStateId === 2 || stripos($taskStateLabel, 'fazer') !== false) {
        $defaultTaskState = $taskStateId;
        break;
    }
}
$followupTemplatePayload = [];
foreach ($followupTemplates as $template) {
    $templateId = (int) ($template['id'] ?? 0);
    if ($templateId > 0) {
        $followupTemplatePayload[(string) $templateId] = (string) ($template['content'] ?? '');
    }
}
$requesterName = trim((string) (($ticket['requester_firstname'] ?? '') . ' ' . ($ticket['requester_realname'] ?? '')));
if ($requesterName === '') {
    $requesterName = 'Nao informado';
}
$piiMaskingEnabled = !empty($ticket['pii_masking_enabled']);
$revealedPiiFields = array_fill_keys((array) ($ticket['revealed_pii_fields'] ?? []), true);
$canRevealPii = $piiMaskingEnabled && !empty($ticket['can_reveal_pii']);
?>
<section class="glpiacessivel-card" aria-labelledby="detalhe-ticket">
  <h2 id="detalhe-ticket">Chamado #<?= (int) $ticket['id'] ?> - <?= glpiacessivel_e($ticket['name']) ?></h2>
  <div class="glpiacessivel-ticket-summary">
    <p>
      <strong>Status</strong>
      <span class="glpiacessivel-badge glpiacessivel-badge-status-<?= glpiacessivel_e(glpiacessivel_status_class($ticket['status'])) ?>">
        <?= glpiacessivel_e(glpiacessivel_ticket_status($ticket['status'])) ?>
      </span>
    </p>
    <p>
      <strong>Prioridade</strong>
      <span class="glpiacessivel-badge glpiacessivel-badge-priority-<?= glpiacessivel_e(glpiacessivel_priority_class($ticket['priority'])) ?>">
        <?= glpiacessivel_e(glpiacessivel_ticket_priority($ticket['priority'])) ?>
      </span>
    </p>
    <p><strong>Entidade</strong><span><?= glpiacessivel_e((string) ($ticket['entity_name'] ?? $ticket['entities_id'])) ?></span></p>
    <p><strong>Categoria</strong><span><?= glpiacessivel_e((string) ($ticket['category_name'] ?? 'Nao informado')) ?></span></p>
    <p><strong>Localizacao</strong><span><?= glpiacessivel_e((string) ($ticket['location_name'] ?? 'Nao informado')) ?></span></p>
    <p><strong>Ultima atualizacao</strong><span><?= glpiacessivel_e($ticket['date_mod']) ?></span></p>
  </div>

  <section aria-labelledby="bloco-atores">
    <h3 id="bloco-atores">Atores do chamado</h3>
    <div class="glpiacessivel-grid-3">
      <article class="glpiacessivel-note">
        <h4>Requerentes</h4>
        <ul class="glpiacessivel-list">
          <?php foreach (($ticket['actors']['requesters'] ?? []) as $actor): ?>
            <li><?= glpiacessivel_e((string) ($actor['name'] ?? '')) ?></li>
          <?php endforeach; ?>
          <?php if (empty($ticket['actors']['requesters'])): ?><li>Nao informado</li><?php endif; ?>
        </ul>
      </article>
      <article class="glpiacessivel-note">
        <h4>Atribuidos</h4>
        <ul class="glpiacessivel-list">
          <?php foreach (($ticket['actors']['assignees'] ?? []) as $actor): ?>
            <li><?= glpiacessivel_e((string) ($actor['name'] ?? '')) ?></li>
          <?php endforeach; ?>
          <?php if (empty($ticket['actors']['assignees'])): ?><li>Nao informado</li><?php endif; ?>
        </ul>
      </article>
      <article class="glpiacessivel-note">
        <h4>Observadores</h4>
        <ul class="glpiacessivel-list">
          <?php foreach (($ticket['actors']['watchers'] ?? []) as $actor): ?>
            <li><?= glpiacessivel_e((string) ($actor['name'] ?? '')) ?></li>
          <?php endforeach; ?>
          <?php if (empty($ticket['actors']['watchers'])): ?><li>Nao informado</li><?php endif; ?>
        </ul>
      </article>
    </div>
  </section>

  <section aria-labelledby="bloco-requisitante">
    <h3 id="bloco-requisitante">Requisitante</h3>
    <?php if ($piiMaskingEnabled): ?>
      <p class="glpiacessivel-muted">Os contatos pessoais estao mascarados conforme a configuracao do plugin.</p>
    <?php else: ?>
      <p class="glpiacessivel-muted">Os contatos pessoais sao exibidos conforme as permissoes nativas do GLPI.</p>
    <?php endif; ?>
    <div class="glpiacessivel-definition-grid">
      <p><strong>Nome</strong><span><?= glpiacessivel_e($requesterName) ?></span></p>
      <?php foreach ([
        'requester_email' => 'E-mail',
        'requester_phone' => 'Telefone',
        'requester_mobile' => 'Celular',
      ] as $piiField => $piiLabel): ?>
        <?php
          $piiValue = trim((string) ($ticket[$piiField] ?? ''));
          $piiRevealed = isset($revealedPiiFields[$piiField]);
        ?>
        <p>
          <strong><?= glpiacessivel_e($piiLabel) ?></strong>
          <span>
            <?= glpiacessivel_e($piiValue !== '' ? $piiValue : 'Nao informado') ?>
            <?php if ($piiMaskingEnabled && $piiValue !== ''): ?>
              <small>(<?= $piiRevealed ? 'revelado temporariamente' : 'mascarado' ?>)</small>
            <?php endif; ?>
          </span>
        </p>
      <?php endforeach; ?>
    </div>

    <?php if ($canRevealPii): ?>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-form glpiacessivel-pii-reveal-form">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['pii_reveal'] ?? $csrf_token) ?>" />
        <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="pii_reveal" />
        <fieldset>
          <legend>Revelar contato por 5 minutos</legend>
          <p id="pii-reveal-help" class="glpiacessivel-help-text">A revelacao exige permissao de atualizacao no chamado e fica registrada na auditoria.</p>
          <label for="pii_field">Dado</label>
          <select id="pii_field" name="pii_field" required aria-describedby="pii-reveal-help">
            <option value="">Selecione</option>
            <option value="requester_email">E-mail</option>
            <option value="requester_phone">Telefone</option>
            <option value="requester_mobile">Celular</option>
          </select>
          <label for="pii_reason">Motivo da consulta</label>
          <input id="pii_reason" name="pii_reason" type="text" maxlength="255" required aria-describedby="pii-reveal-help" />
          <button type="submit">Revelar dado selecionado</button>
        </fieldset>
      </form>
    <?php endif; ?>
  </section>

  <?php if ($canRoute): ?>
    <section aria-labelledby="roteamento-ticket" class="glpiacessivel-routing-panel">
      <h3 id="roteamento-ticket">Atribuicao e escalonamento</h3>
      <p class="glpiacessivel-muted">Atualize grupo tecnico, tecnico atribuido e observadores usando os mesmos atores do GLPI.</p>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-routing-form">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['routing'] ?? $csrf_token) ?>" />
        <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="routing" />
        <div class="glpiacessivel-routing-grid">
          <div class="glpiacessivel-field-block">
            <label for="routing_groups">Grupo tecnico</label>
            <select id="routing_groups" name="_groups_id_assign[]" multiple size="6" aria-describedby="routing_groups_help">
              <?php foreach ((array) ($routing['assignable_groups'] ?? []) as $group): ?>
                <?php $id = (int) ($group['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $assignedGroupIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($group['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_groups_help" class="glpiacessivel-help-text">Use Ctrl para selecionar mais de um grupo no desktop.</small>
          </div>
          <div class="glpiacessivel-field-block">
            <label for="routing_users">Atribuir para</label>
            <select id="routing_users" name="_users_id_assign[]" multiple size="6" aria-describedby="routing_users_help">
              <?php foreach ((array) ($routing['assignable_users'] ?? []) as $user): ?>
                <?php $id = (int) ($user['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $assignedUserIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($user['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_users_help" class="glpiacessivel-help-text">Selecione os tecnicos responsaveis pelo atendimento.</small>
          </div>
          <div class="glpiacessivel-field-block">
            <label for="routing_watchers">Observadores</label>
            <select id="routing_watchers" name="_users_id_observer[]" multiple size="6" aria-describedby="routing_watchers_help">
              <?php foreach ((array) ($routing['assignable_users'] ?? []) as $user): ?>
                <?php $id = (int) ($user['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $observerUserIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($user['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_watchers_help" class="glpiacessivel-help-text">Inclui pessoas que devem acompanhar o chamado.</small>
          </div>
        </div>
        <label for="routing_reason">Motivo do escalonamento</label>
        <input id="routing_reason" type="text" name="routing_reason" maxlength="255" placeholder="Ex.: direcionado para equipe responsavel" />
        <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary">Atualizar atribuicao</button>
      </form>
    </section>
  <?php endif; ?>

  <section aria-labelledby="descricao-ticket">
    <h3 id="descricao-ticket">Descricao</h3>
    <article class="glpiacessivel-content"><?= \GlpiPlugin\Glpiacessivel\Support\RichTextFormatter::toHtml((string) $ticket['content']) ?></article>
  </section>

  <section aria-labelledby="documentos-ticket">
    <h3 id="documentos-ticket">Documentos e anexos</h3>
    <?php if (empty($ticket['documents'])): ?>
      <p class="glpiacessivel-empty">Nenhum documento vinculado.</p>
    <?php else: ?>
      <ul class="glpiacessivel-list">
        <?php foreach ($ticket['documents'] as $doc): ?>
          <li>
            <strong><?= glpiacessivel_e((string) ($doc['name'] ?: $doc['filename'])) ?></strong>
            <small>Atualizado em <?= glpiacessivel_e((string) ($doc['date_mod'] ?? '')) ?></small>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>
</section>

<section class="glpiacessivel-card glpiacessivel-itil-actions" aria-labelledby="acoes-ticket">
  <div class="glpiacessivel-itil-actions-head">
    <div>
      <p class="glpiacessivel-eyebrow">Processamento do chamado</p>
      <h2 id="acoes-ticket">Interacoes e acoes ITIL</h2>
      <p class="glpiacessivel-muted">Use as mesmas etapas conceituais do GLPI: acompanhamento, tarefa, solucao e status. As permissoes e transicoes continuam validadas pelo core.</p>
    </div>
    <span class="glpiacessivel-meta-chip">Ticket #<?= (int) $ticket['id'] ?></span>
  </div>

  <?php if ($isSolved): ?>
    <article class="glpiacessivel-itil-secondary-form" aria-labelledby="aprovacao-solucao">
      <div>
        <h3 id="aprovacao-solucao">Aprovacao da solucao</h3>
        <p class="glpiacessivel-help-text">Este chamado esta solucionado. Como no GLPI, as acoes operacionais foram encerradas e resta aprovar ou recusar a solucao.</p>
      </div>
      <?php if ($canDecideSolution): ?>
        <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" enctype="multipart/form-data" class="glpiacessivel-itil-action-form" data-glpiacessivel-critical-form data-critical-title="Confirmar decisao sobre a solucao" data-critical-message="Revise antes de aprovar ou recusar a solucao do chamado #<?= (int) $ticket['id'] ?>." data-critical-consequence="Esta acao altera o ciclo de vida do chamado no GLPI.">
          <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['solution_decision'] ?? $csrf_token) ?>" />
          <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
          <input type="hidden" name="critical_confirmed" value="0" />
          <input type="hidden" name="critical_confirmation_token" value="" />
          <label for="solution_decision_comment">Comentarios</label>
          <textarea id="solution_decision_comment" name="content" aria-describedby="solution-decision-help"></textarea>
          <small id="solution-decision-help" class="glpiacessivel-help-text">Ao recusar, informe o motivo para reabrir o atendimento. Ao aprovar, o chamado sera encaminhado ao fechamento.</small>
          <label for="solution_decision_filename">Documento</label>
          <input id="solution_decision_filename" type="file" name="solution_decision_filename[]" multiple />
          <div class="glpiacessivel-itil-form-footer">
            <button type="submit" name="action" value="solution_refuse" class="glpiacessivel-button glpiacessivel-button-secondary" data-critical-confirmation-token="<?= glpiacessivel_e((string) ($criticalConfirmations['solution_refuse'] ?? '')) ?>" data-critical-message="Recusar a solucao reabre o atendimento e registra o motivo informado.">Recusar solucao</button>
            <button type="submit" name="action" value="solution_approve" class="glpiacessivel-button glpiacessivel-button-primary" data-critical-confirmation-token="<?= glpiacessivel_e((string) ($criticalConfirmations['solution_approve'] ?? '')) ?>" data-critical-message="Aprovar a solucao encaminha o chamado para fechamento.">Aprovar solucao</button>
          </div>
        </form>
      <?php else: ?>
        <p class="glpiacessivel-empty">A aprovacao da solucao esta disponivel apenas para o requisitante autorizado ou perfil tecnico permitido.</p>
      <?php endif; ?>
    </article>
  <?php elseif ($isClosed): ?>
    <article class="glpiacessivel-itil-secondary-form" aria-labelledby="chamado-fechado">
      <h3 id="chamado-fechado">Chamado fechado</h3>
      <p class="glpiacessivel-help-text">O chamado esta fechado. O fluxo operacional do GLPI nao permite novas acoes ITIL nesta etapa.</p>
    </article>
  <?php else: ?>
  <?php if ($itilTabs !== []): ?>
  <div class="glpiacessivel-itil-action-switcher" role="tablist" aria-label="Escolha a acao ITIL do chamado">
    <?php foreach ($itilTabs as $index => $tab): ?>
      <?php
        $tabKey = (string) ($tab['key'] ?? '');
        $isActiveTab = $index === 0;
      ?>
      <button
        type="button"
        id="itil-tab-<?= glpiacessivel_e($tabKey) ?>"
        class="glpiacessivel-itil-action-tab <?= $isActiveTab ? 'is-active' : '' ?>"
        role="tab"
        aria-selected="<?= $isActiveTab ? 'true' : 'false' ?>"
        aria-controls="itil-panel-<?= glpiacessivel_e($tabKey) ?>"
        tabindex="<?= $isActiveTab ? '0' : '-1' ?>"
        data-glpiacessivel-itil-tab="<?= glpiacessivel_e($tabKey) ?>"
      >
        <span aria-hidden="true"><?= $tabKey === 'followup' ? '+' : ($tabKey === 'task' ? 'OK' : '!') ?></span>
        <strong><?= glpiacessivel_e((string) ($tab['label'] ?? '')) ?></strong>
        <small><?= glpiacessivel_e((string) ($tab['hint'] ?? '')) ?></small>
      </button>
    <?php endforeach; ?>
  </div>

  <div class="glpiacessivel-itil-panel-stack">
    <?php if ($canAddFollowup): ?>
    <section id="itil-panel-followup" class="glpiacessivel-itil-panel" role="tabpanel" aria-labelledby="itil-tab-followup" <?= $activeItilTab === 'followup' ? '' : 'hidden' ?>>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" enctype="multipart/form-data" class="glpiacessivel-itil-action-form">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['followup'] ?? $csrf_token) ?>" />
        <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="followup" />
        <div class="glpiacessivel-itil-panel-head">
          <div>
            <h3>Acompanhamento</h3>
            <p>Registre uma resposta ou atualizacao na timeline do chamado, como no botao Responder do GLPI.</p>
          </div>
        </div>
        <div class="glpiacessivel-followup-template-box">
          <div class="glpiacessivel-followup-template-grid">
            <div>
              <label for="itilfollowuptemplates_id">Modelo de acompanhamento</label>
              <select id="itilfollowuptemplates_id" name="itilfollowuptemplates_id" aria-describedby="followup-template-help">
                <option value="0">Sem modelo</option>
                <?php foreach ($followupTemplates as $template): ?>
                  <option value="<?= (int) ($template['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($template['name'] ?? '')) ?></option>
                <?php endforeach; ?>
                <?php if (empty($followupTemplates)): ?>
                  <option value="0" disabled>Nenhum modelo disponivel para este perfil e entidade</option>
                <?php endif; ?>
              </select>
            </div>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-apply-followup-template <?= empty($followupTemplates) ? 'disabled' : '' ?>>Aplicar modelo</button>
          </div>
          <small id="followup-template-help" class="glpiacessivel-help-text">Opcional. O conteudo do modelo e renderizado pelo GLPI conforme o chamado atual, como na timeline nativa.</small>
        </div>
        <script type="application/json" id="glpiacessivel-followup-template-data"><?= json_encode($followupTemplatePayload, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?></script>
        <label for="followup">Descricao do acompanhamento *</label>
        <textarea id="followup" name="content" required aria-describedby="followup-help"></textarea>
        <small id="followup-help" class="glpiacessivel-help-text">Exemplo: contato realizado, retorno do usuario, diagnostico parcial ou nova informacao.</small>
        <label for="followup_filename">Documento</label>
        <input id="followup_filename" type="file" name="followup_filename[]" multiple />
        <div class="glpiacessivel-itil-form-footer">
          <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary">Adicionar acompanhamento</button>
        </div>
      </form>
    </section>
    <?php endif; ?>

    <?php if ($canAddTask): ?>
    <section id="itil-panel-task" class="glpiacessivel-itil-panel" role="tabpanel" aria-labelledby="itil-tab-task" <?= $activeItilTab === 'task' ? '' : 'hidden' ?>>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" enctype="multipart/form-data" class="glpiacessivel-itil-action-form">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['task'] ?? $csrf_token) ?>" />
        <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="task" />
        <div class="glpiacessivel-itil-panel-head">
          <div>
            <h3>Criar tarefa</h3>
            <p>Registre uma atividade tecnica executada ou planejada. Campos opcionais seguem a gravacao nativa do GLPI quando disponiveis.</p>
          </div>
        </div>
        <div class="glpiacessivel-itil-editor-layout">
          <div class="glpiacessivel-itil-editor-main">
            <label for="task">Descricao da tarefa *</label>
            <textarea id="task" name="content" required aria-describedby="task-help"></textarea>
            <small id="task-help" class="glpiacessivel-help-text">Use para registrar atividade operacional, execucao tecnica ou acao futura.</small>
            <label for="task_filename">Documento</label>
            <input id="task_filename" type="file" name="task_filename[]" multiple />
          </div>
          <aside class="glpiacessivel-itil-editor-side" aria-label="Campos complementares da tarefa">
            <label for="taskcategories_id">Categoria da tarefa</label>
            <select id="taskcategories_id" name="taskcategories_id">
              <option value="0">Nao informar</option>
              <?php foreach ($taskCategories as $category): ?>
                <option value="<?= (int) ($category['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($category['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>

            <div class="glpiacessivel-itil-mini-grid">
              <div>
                <label for="task_begin">Inicio planejado</label>
                <input id="task_begin" type="datetime-local" name="task_begin" />
              </div>
              <div>
                <label for="task_end">Fim planejado</label>
                <input id="task_end" type="datetime-local" name="task_end" />
              </div>
            </div>

            <label for="task_state">Estado</label>
            <select id="task_state" name="task_state">
              <?php foreach ($taskStateOptions as $state): ?>
                <?php $stateId = (int) ($state['id'] ?? 0); ?>
                <option value="<?= $stateId ?>" <?= $stateId === $defaultTaskState ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($state['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>

            <label class="glpiacessivel-check-option" for="task_is_private">
              <input id="task_is_private" type="checkbox" name="task_is_private" value="1" />
              <span>Tarefa privada</span>
            </label>

            <label for="task_actiontime">Duracao</label>
            <select id="task_actiontime" name="task_actiontime">
              <?php foreach ($taskDurationOptions as $duration): ?>
                <option value="<?= (int) ($duration['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($duration['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>

            <label for="task_users_id_tech">Tecnico responsavel</label>
            <select id="task_users_id_tech" name="task_users_id_tech">
              <option value="0">Usuario atual / nao alterar</option>
              <?php foreach ($assignableUsers as $user): ?>
                <option value="<?= (int) ($user['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($user['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>

            <label for="task_groups_id_tech">Grupo tecnico</label>
            <select id="task_groups_id_tech" name="task_groups_id_tech">
              <option value="0">Nao informar</option>
              <?php foreach ($assignableGroups as $group): ?>
                <option value="<?= (int) ($group['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($group['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
          </aside>
        </div>
        <div class="glpiacessivel-itil-form-footer">
          <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary">Adicionar tarefa</button>
        </div>
      </form>
    </section>
    <?php endif; ?>

    <?php if ($canAddSolution): ?>
    <section id="itil-panel-solution" class="glpiacessivel-itil-panel" role="tabpanel" aria-labelledby="itil-tab-solution" <?= $activeItilTab === 'solution' ? '' : 'hidden' ?>>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-itil-action-form" data-glpiacessivel-critical-form data-critical-title="Confirmar adicao de solucao" data-critical-message="Revise a solucao antes de marcar o chamado #<?= (int) $ticket['id'] ?> como solucionado." data-critical-consequence="Ao salvar, o fluxo atual marca o chamado como solucionado.">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['solution'] ?? $csrf_token) ?>" />
        <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="solution" />
        <input type="hidden" name="critical_confirmed" value="0" />
        <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['solution'] ?? '')) ?>" />
        <div class="glpiacessivel-itil-panel-head">
          <div>
            <h3>Adicionar solucao</h3>
            <p>Informe a solucao aplicada para encaminhar o chamado ao encerramento.</p>
          </div>
        </div>
        <label for="solution">Descricao da solucao *</label>
        <textarea id="solution" name="content" required aria-describedby="solution-help"></textarea>
        <small id="solution-help" class="glpiacessivel-help-text">Descreva causa, acao executada e validacao. Ao salvar, o fluxo atual marca o chamado como solucionado.</small>
        <div class="glpiacessivel-itil-form-footer">
          <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary">Adicionar solucao</button>
        </div>
      </form>
    </section>
    <?php endif; ?>
  </div>
  <?php else: ?>
    <p class="glpiacessivel-empty" role="status">Nenhuma acao ITIL esta disponivel para este chamado com seu perfil e entidade atuais.</p>
  <?php endif; ?>

  <script>
    (function () {
      var select = document.getElementById('itilfollowuptemplates_id');
      var textarea = document.getElementById('followup');
      var applyButton = document.querySelector('[data-glpiacessivel-apply-followup-template]');
      var dataElement = document.getElementById('glpiacessivel-followup-template-data');
      if (select && textarea && applyButton && dataElement) {
        var templates = {};
        try {
          templates = JSON.parse(dataElement.textContent || '{}');
        } catch (error) {
          templates = {};
        }

        function applyTemplate() {
          var id = String(select.value || '0');
          var content = templates[id] || '';
          if (id === '0' || content.trim() === '') {
            return;
          }

          if (textarea.value.trim() !== '' && !window.confirm('Substituir o texto atual pelo modelo selecionado?')) {
            return;
          }

          textarea.value = content;
          textarea.focus();
          var live = document.getElementById('glpiacessivel-live') || document.getElementById('glpiacessivel-live-region');
          if (live) {
            live.textContent = 'Modelo de acompanhamento aplicado.';
          }
        }

        applyButton.addEventListener('click', applyTemplate);
        select.addEventListener('change', function () {
          if (textarea.value.trim() === '') {
            applyTemplate();
          }
        });
      }

      var tabs = Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-itil-tab]'));
      if (tabs.length === 0) {
        return;
      }

      function activateTab(tab) {
        tabs.forEach(function (item) {
          var panel = document.getElementById(item.getAttribute('aria-controls') || '');
          var active = item === tab;
          item.classList.toggle('is-active', active);
          item.setAttribute('aria-selected', active ? 'true' : 'false');
          item.setAttribute('tabindex', active ? '0' : '-1');
          if (panel) {
            panel.hidden = !active;
          }
        });
        tab.focus();
      }

      tabs.forEach(function (tab, index) {
        tab.setAttribute('tabindex', index === 0 ? '0' : '-1');
        tab.addEventListener('click', function () {
          activateTab(tab);
        });
        tab.addEventListener('keydown', function (event) {
          var next = index;
          if (event.key === 'ArrowRight') {
            next = (index + 1) % tabs.length;
          } else if (event.key === 'ArrowLeft') {
            next = (index - 1 + tabs.length) % tabs.length;
          } else if (event.key === 'Home') {
            next = 0;
          } else if (event.key === 'End') {
            next = tabs.length - 1;
          } else {
            return;
          }
          event.preventDefault();
          activateTab(tabs[next]);
        });
      });
    })();
  </script>

  <div class="glpiacessivel-itil-secondary-grid">
    <?php if ($canChangeStatus): ?>
    <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-itil-secondary-form" data-glpiacessivel-critical-form data-critical-title="Confirmar alteracao de status" data-critical-message="Revise a transicao de status do chamado #<?= (int) $ticket['id'] ?>." data-critical-consequence="A alteracao fica registrada no historico do GLPI.">
      <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['status'] ?? $csrf_token) ?>" />
      <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
      <input type="hidden" name="action" value="status" />
      <input type="hidden" name="critical_confirmed" value="0" />
      <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['status'] ?? '')) ?>" />
      <div>
        <h3>Status do chamado</h3>
        <p class="glpiacessivel-help-text">Selecione uma transicao permitida pelo perfil e pelo estado atual.</p>
      </div>
      <label for="status">Novo status</label>
      <select id="status" name="status">
        <?php foreach (($ticket['allowed_transitions'] ?? []) as $allowed): ?>
          <option value="<?= (int) $allowed ?>"><?= glpiacessivel_e(glpiacessivel_ticket_status($allowed)) ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary">Atualizar status</button>
    </form>
    <?php endif; ?>

    <?php if (!empty($satisfaction['available'])): ?>
      <article class="glpiacessivel-itil-secondary-form" aria-labelledby="satisfacao-ticket">
        <div>
          <h3 id="satisfacao-ticket">Satisfacao do requisitante</h3>
          <p class="glpiacessivel-help-text">Disponivel porque o GLPI gerou uma pesquisa de satisfacao para este chamado fechado.</p>
        </div>
        <?php if (!empty($satisfaction['can_answer'])): ?>
          <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-itil-action-form" data-glpiacessivel-critical-form data-critical-title="Confirmar resposta da satisfacao" data-critical-message="Revise a nota de satisfacao do chamado #<?= (int) $ticket['id'] ?> antes de enviar." data-critical-consequence="A resposta fica registrada na pesquisa de satisfacao do GLPI.">
            <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['requester_decision'] ?? $csrf_token) ?>" />
            <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
            <input type="hidden" name="action" value="requester_decision" />
            <input type="hidden" name="critical_confirmed" value="0" />
            <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['requester_decision'] ?? '')) ?>" />
            <label for="decision">Nota de satisfacao</label>
            <select id="decision" name="decision">
              <option value="5" <?= (int) ($satisfaction['score'] ?? 0) === 5 ? 'selected' : '' ?>>Muito satisfeito</option>
              <option value="4" <?= (int) ($satisfaction['score'] ?? 0) === 4 ? 'selected' : '' ?>>Satisfeito</option>
              <option value="3" <?= (int) ($satisfaction['score'] ?? 0) === 3 ? 'selected' : '' ?>>Neutro</option>
              <option value="2" <?= (int) ($satisfaction['score'] ?? 0) === 2 ? 'selected' : '' ?>>Insatisfeito</option>
              <option value="1" <?= (int) ($satisfaction['score'] ?? 0) === 1 ? 'selected' : '' ?>>Muito insatisfeito</option>
            </select>
            <label for="decision_comment">Comentario</label>
            <input id="decision_comment" type="text" name="content" maxlength="255" value="<?= glpiacessivel_e((string) ($satisfaction['comment'] ?? '')) ?>" />
            <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary">Responder pesquisa</button>
          </form>
        <?php else: ?>
          <p class="glpiacessivel-empty">Pesquisa disponivel apenas para o requisitante autorizado ou ja bloqueada pelo GLPI.</p>
        <?php endif; ?>
      </article>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="timeline-ticket">
  <h2 id="timeline-ticket">Timeline operacional</h2>
  <p class="glpiacessivel-muted">A linha do tempo mostra interacoes ITIL publicas registradas no fluxo do chamado.</p>
  <?php if (count($ticket['timeline']) === 0): ?>
    <p class="glpiacessivel-empty" role="status">Nenhum evento publico disponivel para este chamado.</p>
  <?php else: ?>
    <ol class="glpiacessivel-timeline">
      <?php foreach ($ticket['timeline'] as $event): ?>
        <li>
          <div class="glpiacessivel-timeline-marker" aria-hidden="true"></div>
          <article class="glpiacessivel-timeline-body">
            <header>
              <span class="glpiacessivel-meta-chip"><?= glpiacessivel_e(glpiacessivel_timeline_label($event['type'])) ?></span>
              <time datetime="<?= glpiacessivel_e((string) $event['date']) ?>"><?= glpiacessivel_e((string) $event['date']) ?></time>
            </header>
            <div class="glpiacessivel-content"><?= \GlpiPlugin\Glpiacessivel\Support\RichTextFormatter::toHtml((string) $event['content']) ?></div>
          </article>
        </li>
      <?php endforeach; ?>
    </ol>
  <?php endif; ?>
</section>


<?php if (!empty($historyContext['can_view'])): ?>
<section class="glpiacessivel-card" aria-labelledby="historico-ticket" aria-describedby="historico-ticket-desc">
  <h2 id="historico-ticket">Historico detalhado do chamado</h2>
  <p id="historico-ticket-desc" class="glpiacessivel-muted">Alteracoes registradas no historico nativo do GLPI, limitadas ao que seu perfil pode consultar.</p>
  <?php if (empty($historyContext['available'])): ?>
    <p class="glpiacessivel-empty" role="status">Historico indisponivel no momento. Tente novamente mais tarde.</p>
  <?php elseif (count($historyItems) === 0): ?>
    <p class="glpiacessivel-empty" role="status">Nenhuma alteracao detalhada disponivel para este chamado.</p>
  <?php else: ?>
    <ol class="glpiacessivel-timeline">
      <?php foreach ($historyItems as $index => $event): ?>
        <?php
          $eventId = 'historico-evento-' . (int) ($event['id'] ?? ($index + 1));
          $eventDate = (string) ($event['date'] ?? '');
          $eventField = (string) ($event['field'] ?? '');
          $eventUser = (string) ($event['user'] ?? '');
          $eventAction = (string) ($event['action'] ?? '');
          $eventSummary = (string) ($event['summary'] ?? '');
        ?>
        <li>
          <div class="glpiacessivel-timeline-marker" aria-hidden="true"></div>
          <article class="glpiacessivel-timeline-body" aria-labelledby="<?= glpiacessivel_e($eventId) ?>">
            <header>
              <h3 id="<?= glpiacessivel_e($eventId) ?>" class="glpiacessivel-sr-only">
                <?= glpiacessivel_e('Alteracao do chamado em ' . ($eventDate !== '' ? $eventDate : 'data nao informada')) ?>
              </h3>
              <span class="glpiacessivel-meta-chip"><?= glpiacessivel_e($eventField !== '' ? $eventField : 'Historico') ?></span>
              <?php if ($eventDate !== ''): ?><time datetime="<?= glpiacessivel_e($eventDate) ?>"><?= glpiacessivel_e($eventDate) ?></time><?php endif; ?>
            </header>
            <p><?= glpiacessivel_e($eventSummary) ?></p>
            <?php if ($eventUser !== '' || $eventAction !== ''): ?>
              <p class="glpiacessivel-muted">
                <?php if ($eventUser !== ''): ?>Usuario: <?= glpiacessivel_e($eventUser) ?><?php endif; ?>
                <?php if ($eventAction !== ''): ?><?= $eventUser !== '' ? ' | ' : '' ?>Acao: <?= glpiacessivel_e($eventAction) ?><?php endif; ?>
              </p>
            <?php endif; ?>
          </article>
        </li>
      <?php endforeach; ?>
    </ol>
    <p class="glpiacessivel-help-text">Exibindo ate <?= (int) ($historyContext['limit'] ?? 50) ?> registro(s) recentes do historico nativo.</p>
  <?php endif; ?>
</section>
<?php endif; ?>
<?php if (!empty($satisfaction['exists'])): ?>
  <section class="glpiacessivel-card" aria-labelledby="decisao-requisitante">
    <h2 id="decisao-requisitante">Satisfacao registrada</h2>
    <div class="glpiacessivel-definition-grid">
      <p><strong>Nota</strong><span><?= glpiacessivel_e((string) ($satisfaction['score'] ?? 'N/D')) ?></span></p>
      <p><strong>Respondida em</strong><span><?= glpiacessivel_e((string) ($satisfaction['date_answered'] ?? '')) ?></span></p>
      <p><strong>Comentario</strong><span><?= glpiacessivel_e((string) ($satisfaction['comment'] ?? '')) ?></span></p>
    </div>
  </section>
<?php endif; ?>
