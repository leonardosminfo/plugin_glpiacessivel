<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

use GlpiPlugin\Glpiacessivel\Application\ChatbotService;
use GlpiPlugin\Glpiacessivel\Application\ChatbotPlaybookService;
use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\PortalModulePolicy;
use GlpiPlugin\Glpiacessivel\Application\ContextService;
use GlpiPlugin\Glpiacessivel\Application\FormService;
use GlpiPlugin\Glpiacessivel\Application\KnowledgeBaseService;
use GlpiPlugin\Glpiacessivel\Application\TicketService;
use GlpiPlugin\Glpiacessivel\Domain\Pii\PiiMasker;
use GlpiPlugin\Glpiacessivel\Domain\Security\Authorization;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\TicketCreationPolicy;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\TicketPolicy;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\FormRepository;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\PlaybookRepository;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\TicketRepository;

final class Container
{
    private static ?self $instance = null;

    private ?AuditLogger $auditLogger = null;
    private ?TicketRepository $ticketRepository = null;
    private ?PlaybookRepository $playbookRepository = null;
    private ?FormRepository $formRepository = null;
    private ?TicketPolicy $ticketPolicy = null;
    private ?TicketCreationPolicy $ticketCreationPolicy = null;
    private ?TicketService $ticketService = null;
    private ?KnowledgeBaseService $knowledgeBaseService = null;
    private ?FormService $formService = null;
    private ?ChatbotPlaybookService $chatbotPlaybookService = null;
    private ?ChatbotService $chatbotService = null;
    private ?ConfigService $configService = null;
    private ?PortalModulePolicy $portalModulePolicy = null;
    private ?ContextService $contextService = null;
    private ?PiiMasker $piiMasker = null;
    private ?Authorization $authorization = null;

    public static function get(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function auditLogger(): AuditLogger
    {
        if ($this->auditLogger === null) {
            $this->auditLogger = new AuditLogger();
        }

        return $this->auditLogger;
    }

    public function ticketRepository(): TicketRepository
    {
        if ($this->ticketRepository === null) {
            $this->ticketRepository = new TicketRepository();
        }

        return $this->ticketRepository;
    }

    public function playbookRepository(): PlaybookRepository
    {
        if ($this->playbookRepository === null) {
            $this->playbookRepository = new PlaybookRepository();
        }

        return $this->playbookRepository;
    }
    public function formRepository(): FormRepository
    {
        if ($this->formRepository === null) {
            $this->formRepository = new FormRepository();
        }

        return $this->formRepository;
    }

    public function ticketPolicy(): TicketPolicy
    {
        if ($this->ticketPolicy === null) {
            $this->ticketPolicy = new TicketPolicy();
        }

        return $this->ticketPolicy;
    }

    public function ticketCreationPolicy(): TicketCreationPolicy
    {
        if ($this->ticketCreationPolicy === null) {
            $this->ticketCreationPolicy = new TicketCreationPolicy();
        }

        return $this->ticketCreationPolicy;
    }

    public function piiMasker(): PiiMasker
    {
        if ($this->piiMasker === null) {
            $this->piiMasker = new PiiMasker();
        }

        return $this->piiMasker;
    }

    public function authorization(): Authorization
    {
        if ($this->authorization === null) {
            $this->authorization = new Authorization();
        }

        return $this->authorization;
    }

    public function ticketService(): TicketService
    {
        if ($this->ticketService === null) {
            $this->ticketService = new TicketService(
                $this->ticketRepository(),
                $this->ticketPolicy(),
                $this->ticketCreationPolicy(),
                $this->auditLogger(),
                $this->piiMasker(),
                $this->authorization(),
                $this->configService()
            );
        }

        return $this->ticketService;
    }

    public function knowledgeBaseService(): KnowledgeBaseService
    {
        if ($this->knowledgeBaseService === null) {
            $this->knowledgeBaseService = new KnowledgeBaseService(
                $this->auditLogger(),
                $this->authorization()
            );
        }

        return $this->knowledgeBaseService;
    }
    public function formService(): FormService
    {
        if ($this->formService === null) {
            $this->formService = new FormService(
                $this->formRepository(),
                $this->authorization(),
                $this->auditLogger()
            );
        }

        return $this->formService;
    }

    public function chatbotService(): ChatbotService
    {
        if ($this->chatbotService === null) {
            $this->chatbotService = new ChatbotService(
                $this->ticketService(),
                $this->knowledgeBaseService(),
                $this->auditLogger(),
                $this->authorization(),
                $this->configService(),
                $this->portalModulePolicy(),
                $this->chatbotPlaybookService()
            );
        }

        return $this->chatbotService;
    }

    public function chatbotPlaybookService(): ChatbotPlaybookService
    {
        if ($this->chatbotPlaybookService === null) {
            $this->chatbotPlaybookService = new ChatbotPlaybookService(
                $this->ticketRepository(),
                $this->playbookRepository(),
                $this->auditLogger()
            );
        }

        return $this->chatbotPlaybookService;
    }

    public function configService(): ConfigService
    {
        if ($this->configService === null) {
            $this->configService = new ConfigService();
        }

        return $this->configService;
    }

    public function portalModulePolicy(): PortalModulePolicy
    {
        if ($this->portalModulePolicy === null) {
            $this->portalModulePolicy = new PortalModulePolicy($this->configService());
        }

        return $this->portalModulePolicy;
    }

    public function contextService(): ContextService
    {
        if ($this->contextService === null) {
            $this->contextService = new ContextService($this->auditLogger());
        }

        return $this->contextService;
    }
}
