<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

final class I18n
{
    public const DOMAIN = 'glpiacessivel';
    public const FALLBACK_LOCALE = 'pt_BR';

    public static function locale(): string
    {
        $candidates = [
            $_SESSION['glpilanguage'] ?? null,
            $_SESSION['glpi_language'] ?? null,
            $_SESSION['glpiactiveprofile']['language'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            $locale = self::normalizeLocale((string) $candidate);
            if ($locale !== '') {
                return $locale;
            }
        }

        return self::fallbackLocale();
    }

    public static function fallbackLocale(): string
    {
        $configured = self::configuredFallbackLocale();
        return $configured !== '' ? $configured : self::FALLBACK_LOCALE;
    }

    /** @return array<int, string> */
    public static function availableLocales(): array
    {
        $localesDir = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'locales';
        $available = [];
        foreach (glob($localesDir . DIRECTORY_SEPARATOR . '*.{po,mo}', GLOB_BRACE) ?: [] as $file) {
            $locale = self::normalizeLocale(pathinfo((string) $file, PATHINFO_FILENAME));
            if ($locale !== '') {
                $available[] = $locale;
            }
        }

        $available[] = self::FALLBACK_LOCALE;
        $available = array_values(array_unique($available));
        sort($available);

        return $available;
    }

    /** @return array<string, array{po:bool,mo:bool}> */
    public static function catalogStatus(): array
    {
        $localesDir = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'locales';
        $status = [];
        foreach (self::availableLocales() as $locale) {
            $status[$locale] = [
                'po' => is_file($localesDir . DIRECTORY_SEPARATOR . $locale . '.po'),
                'mo' => is_file($localesDir . DIRECTORY_SEPARATOR . $locale . '.mo'),
            ];
        }

        return $status;
    }

    public static function htmlLang(?string $locale = null): string
    {
        $locale = self::normalizeLocale($locale ?? self::locale());
        if ($locale === '') {
            $locale = self::FALLBACK_LOCALE;
        }

        return str_replace('_', '-', $locale);
    }

    public static function translate(string $text): string
    {
        return function_exists('__') ? __($text, self::DOMAIN) : $text;
    }

    public static function plural(string $single, string $plural, int $count): string
    {
        if (function_exists('_n')) {
            return _n($single, $plural, $count, self::DOMAIN);
        }

        return $count === 1 ? $single : $plural;
    }

    public static function context(string $context, string $text): string
    {
        if (function_exists('_x')) {
            return _x($context, $text, self::DOMAIN);
        }

        return $text;
    }

    /**
     * @return array{locale:string,htmlLang:string,fallbackLocale:string,messages:array<string,string>}
     */
    public static function javascriptCatalog(): array
    {
        $messages = [];
        foreach (self::javascriptMessageSources() as $key => $text) {
            $messages[$key] = self::translate($text);
        }

        return [
            'locale' => self::locale(),
            'htmlLang' => self::htmlLang(),
            'fallbackLocale' => self::fallbackLocale(),
            'messages' => $messages,
        ];
    }

    /** @return array<string,string> */
    public static function javascriptMessageSources(): array
    {
        return [
            'portal.open.label' => 'Abrir portal acessivel do GLPI',
            'portal.open.sr' => 'Abrir portal acessivel',
            'portal.embedded.label' => 'Ir para modo acessivel do GLPI',
            'portal.embedded.sr' => 'Ir para modo acessivel',
            'portal.open.title' => 'Abrir portal acessivel',
            'portal.embedded.title' => 'Ir para modo acessivel',
            'chatbot.open.label' => 'Abrir chatbot operacional do GLPI acessivel',
            'chatbot.open.sr' => 'Abrir chatbot operacional',
            'status.processing' => 'Processando acao, aguarde.',
            'status.opening_accessible_journey' => 'Abrindo jornada acessivel principal.',
            'status.opening_accessible_mode' => 'Abrindo modo acessivel.',
            'status.opening_chatbot' => 'Abrindo chatbot operacional.',
            'status.shortcut_executed' => 'Atalho executado: {shortcut}.',
            'status.theme_changed' => 'Tema alternado.',
            'status.contrast_changed' => 'Alto contraste alternado.',
            'status.help_opened' => 'Painel de ajuda aberto.',
            'status.help_closed' => 'Painel de ajuda fechado.',
            'status.focus_main' => 'Foco movido para o conteudo principal.',
            'status.focus_menu' => 'Foco movido para o menu.',
            'status.focus_search' => 'Foco movido para a busca ou formulario principal.',
            'status.opening_my_tickets' => 'Abrindo meus chamados.',
            'status.opening_all_tickets' => 'Abrindo todos os chamados permitidos.',
            'status.opening_new_ticket' => 'Abrindo novo chamado.',
            'status.opening_kb' => 'Abrindo base de conhecimento.',
            'status.opening_cockpit' => 'Abrindo cockpit operacional.',
            'status.opening_public_faq' => 'Abrindo FAQ publica acessivel.',
            'status.no_ticket_selected' => 'Nenhum chamado selecionado.',
            'status.ticket_ids_copied' => 'IDs dos chamados selecionados copiados.',
            'status.ticket_ids_selected' => 'IDs selecionados: {ids}.',
            'critical.required' => 'Confirmacao obrigatoria',
            'critical.title' => 'Confirmar acao critica',
            'critical.review' => 'Revise os dados antes de executar esta acao.',
            'critical.consequence' => 'Esta acao sera registrada no GLPI.',
            'critical.opened' => 'Confirmacao obrigatoria aberta. Revise a acao antes de continuar.',
            'critical.cancelled' => 'Acao critica cancelada.',
            'critical.confirmed' => 'Acao critica confirmada. Enviando formulario.',
            'critical.none_pending' => 'Nenhuma acao pendente para confirmar.',
            'button.cancel' => 'Cancelar',
            'button.confirm_action' => 'Confirmar acao',
            'shortcut.help' => 'Abrir ajuda de acessibilidade',
            'shortcut.theme' => 'Alternar tema claro e noturno',
            'shortcut.contrast' => 'Ativar ou desativar alto contraste',
            'shortcut.font_decrease' => 'Diminuir tamanho da fonte',
            'shortcut.font_reset' => 'Restaurar tamanho da fonte',
            'shortcut.font_increase' => 'Aumentar tamanho da fonte',
            'vlibras.ready' => 'VLibras carregado.',
            'vlibras.unavailable' => 'VLibras indisponivel no momento.',
            'vlibras.retrying' => 'Conexao restaurada. Tentando carregar VLibras.',
        ];
    }

    private static function configuredFallbackLocale(): string
    {
        global $DB;

        if (!isset($DB) || !method_exists($DB, 'request')) {
            return '';
        }

        try {
            $row = $DB->request([
                'SELECT' => ['value_text'],
                'FROM' => 'glpi_plugin_glpiacessivel_configs',
                'WHERE' => ['key_name' => 'plugin_fallback_locale'],
                'LIMIT' => 1,
            ])->current();
        } catch (\Throwable $e) {
            return '';
        }

        if (!$row) {
            return '';
        }

        return self::normalizeLocale((string) ($row['value_text'] ?? ''));
    }

    private static function normalizeLocale(string $locale): string
    {
        $locale = trim($locale);
        if ($locale === '') {
            return '';
        }

        $locale = str_replace('-', '_', $locale);
        if (!preg_match('/^[a-z]{2}_[A-Z]{2}$/', $locale)) {
            $parts = explode('_', $locale, 2);
            if (count($parts) === 2) {
                $locale = strtolower($parts[0]) . '_' . strtoupper($parts[1]);
            }
        }

        return preg_match('/^[a-z]{2}_[A-Z]{2}$/', $locale) ? $locale : '';
    }
}
