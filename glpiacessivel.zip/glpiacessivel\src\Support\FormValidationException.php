<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

final class FormValidationException extends \RuntimeException
{
    /** @var array<int, array{field:string, code:string, message:string}> */
    private array $errors;

    /** @var array<string, mixed> */
    private array $metadata;

    /**
     * @param mixed $errors
     * @param array<string, mixed> $metadata
     */
    public function __construct(mixed $errors, string $message = 'Dados invalidos.', array $metadata = [])
    {
        parent::__construct($message);
        $this->errors = ValidationErrorNormalizer::normalize($errors);
        $this->metadata = $metadata;
    }

    /**
     * @return array<int, array{field:string, code:string, message:string}>
     */
    public function errors(): array
    {
        return $this->errors;
    }

    /** @return array<string, mixed> */
    public function metadata(): array
    {
        return $this->metadata;
    }
}
