<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Repository;

use GlpiPlugin\Glpiacessivel\Domain\Ticket\TicketCreationPolicy;
use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;

final class TicketRepository
{
    private const PORTAL_FALLBACK_SCAN_LIMIT = 500;
    public function getTicketCreationContext(): array
    {
        $activeEntity = $this->getConcreteActiveEntityId();
        $defaultRequestSourceId = $this->getDefaultRequestSourceId();

        return [
            'entity_id' => $activeEntity,
            'entity_name' => $this->getEntityName($activeEntity),
            'requester_name' => $this->getCurrentUserName(),
            'opening_date_preview' => date('d/m/Y H:i'),
            'status_preview' => 'Novo',
            'requester_editable' => false,
            'categories' => $this->getTicketCategories(),
            'locations' => $this->getTicketLocations(),
            'assignable_users' => $this->getAssignableUsers(),
            'assignable_groups' => $this->getAssignableGroups(),
            'type_options' => $this->getTicketTypeOptions(),
            'urgency_options' => $this->getUrgencyOptions(),
            'impact_options' => $this->getImpactOptions(),
            'request_source_options' => $this->getRequestSourceOptions(),
            'request_source_supported' => $this->ticketSupportsRequestSource(),
            'default_request_source_id' => $defaultRequestSourceId,
            'default_request_source_label' => $this->resolveRequestSourceLabel($defaultRequestSourceId),
            'external_id_supported' => $this->ticketSupportsExternalId(),
            'group_assignment_supported' => $this->tableExists('glpi_groups'),
            'duration_total_help' => 'A duracao total passa a ser contabilizada pelo atendimento apos a abertura do chamado.',
            'priority_preview' => $this->computePriorityPreview(3, 3),
            'field_requirements' => $this->getTicketCreationFieldRequirements(),
            'ticket_templates' => $this->getTicketTemplates(),
            'service_catalog' => $this->getServiceCatalogContext(),
            'portal_limitations' => $this->getTicketCreatePortalLimitations(),
        ];
    }

    public function listTickets(array $filters): array
    {
        $page = max(1, (int) ($filters['page'] ?? 1));
        $pageSize = min(100, max(10, (int) ($filters['page_size'] ?? 20)));

        $sort = (string) ($filters['sort'] ?? 'date_mod');
        $direction = strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC';

        $searchApiResult = $this->listTicketsFromSearchApi($filters, $page, $pageSize, $sort, $direction);
        if ($searchApiResult !== null) {
            return $searchApiResult;
        }

        $fallbackRows = $this->getTicketRowsFromNativeFind($filters);
        $fallbackScanLimitHit = count($fallbackRows) >= self::PORTAL_FALLBACK_SCAN_LIMIT;
        $rows = [];
        foreach ($fallbackRows as $fields) {
            if (!$this->ticketMatchesPortalFilters($fields, $filters)) {
                continue;
            }

            $row = $this->mapTicketFieldsToListRow($fields);
            if ($row !== null) {
                $rows[] = $row;
            }
        }

        $this->sortTicketRows($rows, $sort, $direction);

        $total = count($rows);
        $pages = (int) ceil(max(1, $total) / $pageSize);
        $page = min($page, max(1, $pages));
        $offset = ($page - 1) * $pageSize;

        return [
            'items' => array_slice($rows, $offset, $pageSize),
            'total' => $total,
            'total_is_lower_bound' => $fallbackScanLimitHit,
            'partial_results' => $fallbackScanLimitHit,
            'page' => $page,
            'page_size' => $pageSize,
            'pages' => max(1, $pages),
            'backend' => 'native_find_fallback',
            'backend_reason' => $this->getSearchApiFallbackReason($filters),
            'backend_limit' => self::PORTAL_FALLBACK_SCAN_LIMIT,
            'backend_limited' => $fallbackScanLimitHit,
            'fallback_limit_hit' => $fallbackScanLimitHit,
            'limit_policy' => 'hard_cap_with_native_fallback',
            'assigned_group_search_option' => $this->getTicketAssignedGroupSearchOptionNumber(),
            'backend_diagnostics' => $this->ticketListBackendDiagnostics($filters, 'native_find_fallback', $fallbackScanLimitHit),
        ];
    }

    private function listTicketsFromSearchApi(array $filters, int $page, int $pageSize, string $sort, string $direction): ?array
    {
        if (!$this->canUseSearchApiForTicketList($filters)) {
            return null;
        }

        try {
            $itemtype = \Ticket::class;
            $forcedisplay = $this->getTicketSearchForcedDisplay();
            if ($forcedisplay === []) {
                return null;
            }

            $sortOption = $this->getTicketSearchOptionForSort($sort);
            if ($sortOption <= 0) {
                return null;
            }

            $criteria = $this->buildTicketSearchCriteria($filters);
            if ($criteria === null) {
                return null;
            }

            $params = [
                'is_deleted' => 0,
                'start' => ($page - 1) * $pageSize,
                'list_limit' => $pageSize,
                'sort' => [$sortOption],
                'order' => [$direction],
                'criteria' => $criteria,
            ];

            if (method_exists('\Search', 'manageParams')) {
                $params = \Search::manageParams($itemtype, $params, false, false);
            }

            $data = \Search::getDatas($itemtype, $params, $forcedisplay);
            if (!is_array($data)) {
                return null;
            }

            $rows = $this->extractSearchRows($data);
            if ($rows === []) {
                // A zero-row response cannot prove criteria equivalence across GLPI versions.
                // Re-run through the ACL-checked native fallback to avoid false empty lists.
                return null;
            }

            $items = [];
            foreach ($rows as $row) {
                $ticketId = $this->extractTicketIdFromSearchRow($row);
                if ($ticketId <= 0) {
                    return null;
                }

                $item = $this->getTicketListRowById($ticketId);
                if ($item === null || !$this->ticketMatchesPortalFilters($item, $filters)) {
                    return null;
                }

                $items[] = $item;
            }

            $total = $this->extractSearchTotal($data);
            if ($total < count($items)) {
                $total = count($items);
            }

            $pages = (int) ceil(max(1, $total) / $pageSize);

            return [
                'items' => $items,
                'total' => $total,
                'total_is_lower_bound' => false,
                'partial_results' => false,
                'page' => min($page, max(1, $pages)),
                'page_size' => $pageSize,
                'pages' => max(1, $pages),
                'backend' => 'search_api',
                'backend_reason' => 'native_search_api',
                'backend_limit' => 0,
                'backend_limited' => false,
                'fallback_limit_hit' => false,
                'assigned_group_search_option' => $this->getTicketAssignedGroupSearchOptionNumber(),
                'backend_diagnostics' => $this->ticketListBackendDiagnostics($filters, 'search_api', false),
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function canUseSearchApiForTicketList(array $filters): bool
    {
        if (!class_exists('\Search') || !class_exists('\Ticket') || !method_exists('\Search', 'getDatas')) {
            return false;
        }

        $scope = (string) ($filters['scope'] ?? 'all');
        $groupId = (int) ($filters['group_id'] ?? 0);
        if ($scope === 'mine') {
            return (int) ($_SESSION['glpiID'] ?? 0) > 0
                && $this->getTicketUserSearchOptionNumbersByType() !== [];
        }

        if ($scope === 'group') {
            if ($groupId > 0) {
                return $this->getTicketAssignedGroupSearchOptionNumber() > 0;
            }

            return $this->getCurrentUserGroupIds() !== []
                && $this->getTicketAssignedGroupSearchOptionNumber() > 0;
        }

        if ($scope !== 'all') {
            return false;
        }

        if ($groupId > 0) {
            return $this->getTicketAssignedGroupSearchOptionNumber() > 0;
        }

        return true;
    }

    /**
     * @return array<string, mixed>
     */
    private function ticketListBackendDiagnostics(array $filters, string $backend, bool $fallbackLimitHit): array
    {
        $query = trim((string) ($filters['q'] ?? ''));
        $assignedGroupOption = $this->getTicketAssignedGroupSearchOptionNumber();

        return [
            'backend' => $backend,
            'backend_reason' => $backend === 'search_api' ? 'native_search_api' : $this->getSearchApiFallbackReason($filters),
            'scope' => (string) ($filters['scope'] ?? 'all'),
            'group_id' => max(0, (int) ($filters['group_id'] ?? 0)),
            'status' => (string) ($filters['status'] ?? ''),
            'page' => max(1, (int) ($filters['page'] ?? 1)),
            'page_size' => min(100, max(10, (int) ($filters['page_size'] ?? 20))),
            'sort' => (string) ($filters['sort'] ?? 'date_mod'),
            'direction' => strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC',
            'query_len' => strlen($query),
            'assigned_group_search_option' => $assignedGroupOption,
            'current_user_group_count' => count($this->getCurrentUserGroupIds()),
            'fallback_scan_limit' => self::PORTAL_FALLBACK_SCAN_LIMIT,
            'fallback_limit_hit' => $fallbackLimitHit,
            'fallback_limit_policy' => 'explicit_beta_guard_before_native_search',
        ];
    }

    private function getSearchApiFallbackReason(array $filters): string
    {
        if (!class_exists('\Search') || !class_exists('\Ticket') || !method_exists('\Search', 'getDatas')) {
            return 'search_api_unavailable';
        }

        $scope = (string) ($filters['scope'] ?? 'all');
        $groupId = (int) ($filters['group_id'] ?? 0);
        if ($scope === 'mine' && $this->getTicketUserSearchOptionNumbersByType() === []) {
            return 'mine_scope_search_options_unavailable';
        }

        if (($scope === 'group' || $groupId > 0) && $this->getTicketAssignedGroupSearchOptionNumber() <= 0) {
            return 'assigned_group_search_option_unavailable';
        }

        if ($scope === 'group' && $groupId <= 0 && $this->getCurrentUserGroupIds() === []) {
            return 'group_scope_without_current_groups';
        }

        if ($scope !== 'all' && $scope !== 'group') {
            return 'scope_requires_portal_filter';
        }

        return 'search_api_response_unusable';
    }

    /**
     * @return int[]
     */
    private function getTicketSearchForcedDisplay(): array
    {
        $fields = ['id', 'name', 'status', 'priority', 'date', 'date_mod', 'content', 'entities_id', 'users_id_recipient'];
        $options = [];
        foreach ($fields as $field) {
            $option = $this->getTicketSearchOptionNumber($field);
            if ($option > 0) {
                $options[$option] = $option;
            }
        }

        return array_values($options);
    }

    private function getTicketSearchOptionForSort(string $sort): int
    {
        $allowed = ['id', 'name', 'status', 'priority', 'date', 'date_mod'];
        $field = in_array($sort, $allowed, true) ? $sort : 'date_mod';
        return $this->getTicketSearchOptionNumber($field);
    }

    private function getTicketSearchOptionNumber(string $field): int
    {
        if (method_exists('\Search', 'getOptionNumber')) {
            $option = (int) \Search::getOptionNumber(\Ticket::class, $field);
            if ($option > 0) {
                return $option;
            }
        }

        if (!method_exists('\Search', 'getOptions')) {
            return 0;
        }

        $ticketTable = method_exists('\Ticket', 'getTable') ? (string) \Ticket::getTable() : 'glpi_tickets';
        foreach ((array) \Search::getOptions(\Ticket::class) as $number => $option) {
            if (!is_numeric($number) || !is_array($option)) {
                continue;
            }

            if ((string) ($option['field'] ?? '') !== $field) {
                continue;
            }

            $table = (string) ($option['table'] ?? $ticketTable);
            if ($table === '' || $table === $ticketTable) {
                return (int) $number;
            }
        }

        return 0;
    }

    /**
     * @return array<int, array<string, mixed>>|null
     */
    private function buildTicketSearchCriteria(array $filters): ?array
    {
        $criteria = [];
        $status = (string) ($filters['status'] ?? '');
        if ($status !== '' && ctype_digit($status)) {
            $statusOption = $this->getTicketSearchOptionNumber('status');
            if ($statusOption <= 0) {
                return null;
            }
            $criteria[] = [
                'link' => 'AND',
                'field' => $statusOption,
                'searchtype' => 'equals',
                'value' => (string) ((int) $status),
            ];
        }

        $query = trim((string) ($filters['q'] ?? ''));
        if ($query !== '') {
            if (ctype_digit($query)) {
                $idOption = $this->getTicketSearchOptionNumber('id');
                if ($idOption <= 0) {
                    return null;
                }
                $criteria[] = [
                    'link' => 'AND',
                    'field' => $idOption,
                    'searchtype' => 'equals',
                    'value' => (string) ((int) $query),
                ];
            } else {
                $textCriteria = $this->buildTicketTextSearchCriteria($query);
                if ($textCriteria === null) {
                    return null;
                }
                foreach ($textCriteria as $criterion) {
                    $criteria[] = $criterion;
                }
            }
        }

        $groupCriteria = $this->buildTicketAssignedGroupSearchCriteria($filters);
        if ($groupCriteria === null) {
            return null;
        }

        foreach ($groupCriteria as $criterion) {
            $criteria[] = $criterion;
        }

        return $criteria;
    }

    /**
     * @return array<int, array<string, mixed>>|null
     */
    private function buildTicketAssignedGroupSearchCriteria(array $filters): ?array
    {
        $scope = (string) ($filters['scope'] ?? 'all');
        $groupId = (int) ($filters['group_id'] ?? 0);
        if ($scope !== 'group' && $groupId <= 0) {
            return $scope === 'mine' ? $this->buildTicketMineSearchCriteria() : [];
        }

        $option = $this->getTicketAssignedGroupSearchOptionNumber();
        if ($option <= 0) {
            return null;
        }

        $groups = $groupId > 0 ? [$groupId] : $this->getCurrentUserGroupIds();
        $groups = array_values(array_unique(array_filter(array_map('intval', $groups), static fn(int $id): bool => $id > 0)));
        if ($groups === []) {
            return null;
        }

        $alternatives = [];
        foreach ($groups as $index => $currentGroupId) {
            $alternatives[] = [
                'link' => $index === 0 ? 'AND' : 'OR',
                'field' => $option,
                'searchtype' => 'equals',
                'value' => (string) $currentGroupId,
            ];
        }

        return [[
            'link' => 'AND',
            'criteria' => $alternatives,
        ]];
    }

    /**
     * Require both title and content Search Options to preserve fallback semantics.
     *
     * @return array<int, array<string, mixed>>|null
     */
    private function buildTicketTextSearchCriteria(string $query): ?array
    {
        $nameOption = $this->getTicketSearchOptionNumber('name');
        $contentOption = $this->getTicketSearchOptionNumber('content');
        if ($nameOption <= 0 || $contentOption <= 0) {
            return null;
        }

        return [[
            'link' => 'AND',
            'criteria' => [
                ['link' => 'AND', 'field' => $nameOption, 'searchtype' => 'contains', 'value' => $query],
                ['link' => 'OR', 'field' => $contentOption, 'searchtype' => 'contains', 'value' => $query],
            ],
        ]];
    }

    /**
     * Detect requester, assigned and observer Search Options by their native link type.
     * No hard-coded option numbers are used because GLPI 10 and 11 differ.
     *
     * @return array<int, int> keyed by ITIL user type (1 requester, 2 assigned, 3 observer)
     */
    private function getTicketUserSearchOptionNumbersByType(): array
    {
        if (!method_exists('\Search', 'getOptions')) {
            return [];
        }

        $found = [];
        foreach ((array) \Search::getOptions(\Ticket::class) as $number => $option) {
            if (!is_numeric($number) || !is_array($option)) {
                continue;
            }
            $serialized = strtolower(json_encode($option, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '');
            $table = (string) ($option['table'] ?? '');
            $field = (string) ($option['field'] ?? '');
            if ($field !== 'users_id' && !str_contains($serialized, 'users_id')) {
                continue;
            }
            if ($table !== 'glpi_tickets_users' && !str_contains($serialized, 'glpi_tickets_users')) {
                continue;
            }
            for ($type = 1; $type <= 3; $type++) {
                if ($this->serializedSearchOptionContainsType($serialized, $type)) {
                    $found[$type] = (int) $number;
                }
            }
        }

        return count($found) === 3 ? $found : [];
    }

    /** @return array<int, array<string, mixed>>|null */
    private function buildTicketMineSearchCriteria(): ?array
    {
        $userId = (int) ($_SESSION['glpiID'] ?? 0);
        $options = $this->getTicketUserSearchOptionNumbersByType();
        if ($userId <= 0 || count($options) !== 3) {
            return null;
        }

        $alternatives = [];
        foreach ([1, 2, 3] as $index => $type) {
            $alternatives[] = [
                'link' => $index === 0 ? 'AND' : 'OR',
                'field' => $options[$type],
                'searchtype' => 'equals',
                'value' => (string) $userId,
            ];
        }

        return [[
            'link' => 'AND',
            'criteria' => $alternatives,
        ]];
    }

    private function serializedSearchOptionContainsType(string $serialized, int $type): bool
    {
        return preg_match('/(?:"type"|type|tickets_users\.type)[^0-9]{0,40}' . preg_quote((string) $type, '/') . '(?:[^0-9]|$)/', $serialized) === 1;
    }
    private function getTicketAssignedGroupSearchOptionNumber(): int
    {
        if (!method_exists('\Search', 'getOptions')) {
            return 0;
        }

        foreach ((array) \Search::getOptions(\Ticket::class) as $number => $option) {
            if (!is_numeric($number) || !is_array($option)) {
                continue;
            }

            if ($this->searchOptionLooksLikeAssignedGroup($option)) {
                return (int) $number;
            }
        }

        return 0;
    }

    /** @param array<string, mixed> $option */
    private function searchOptionLooksLikeAssignedGroup(array $option): bool
    {
        $table = (string) ($option['table'] ?? '');
        $field = (string) ($option['field'] ?? '');
        $linkfield = (string) ($option['linkfield'] ?? '');
        $serialized = strtolower(json_encode($option, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '');

        if ($table === 'glpi_groups_tickets' && in_array($field, ['groups_id', 'id'], true)) {
            return $this->serializedSearchOptionContainsAssignedGroupType($serialized);
        }

        if ($table === 'glpi_groups' && ($linkfield === 'groups_id' || str_contains($serialized, 'glpi_groups_tickets'))) {
            return $this->serializedSearchOptionContainsAssignedGroupType($serialized);
        }

        return false;
    }

    private function serializedSearchOptionContainsAssignedGroupType(string $serialized): bool
    {
        if ($serialized === '' || !str_contains($serialized, 'glpi_groups_tickets')) {
            return false;
        }

        return preg_match('/(?:type|\bglpi_groups_tickets\.type\b)[^0-9]{0,40}2/', $serialized) === 1
            || str_contains($serialized, 'groups_id_assign')
            || str_contains($serialized, '_groups_id_assign');
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function extractSearchRows(array $data): array
    {
        $rows = $data['data']['rows'] ?? $data['rows'] ?? [];
        if (!is_array($rows)) {
            return [];
        }

        return array_values(array_filter($rows, 'is_array'));
    }

    private function extractSearchTotal(array $data): int
    {
        foreach (['totalcount', 'count'] as $key) {
            if (isset($data['data'][$key]) && is_numeric($data['data'][$key])) {
                return max(0, (int) $data['data'][$key]);
            }
        }

        if (isset($data['totalcount']) && is_numeric($data['totalcount'])) {
            return max(0, (int) $data['totalcount']);
        }

        return count($this->extractSearchRows($data));
    }

    private function extractTicketIdFromSearchRow(array $row): int
    {
        foreach (['id', 'item_id', 'tickets_id'] as $key) {
            if (isset($row[$key]) && is_numeric($row[$key])) {
                return max(0, (int) $row[$key]);
            }
        }

        foreach (['raw', 'values'] as $containerKey) {
            if (isset($row[$containerKey]) && is_array($row[$containerKey])) {
                $ticketId = $this->extractTicketIdFromSearchValues($row[$containerKey]);
                if ($ticketId > 0) {
                    return $ticketId;
                }
            }
        }

        return 0;
    }

    private function extractTicketIdFromSearchValues(array $values): int
    {
        foreach ($values as $key => $value) {
            $key = (string) $key;
            if (is_numeric($value) && preg_match('/(?:^|_)Ticket_(?:id|2|80)$/i', $key)) {
                return max(0, (int) $value);
            }

            if (is_array($value)) {
                $nested = $this->extractTicketIdFromSearchValues($value);
                if ($nested > 0) {
                    return $nested;
                }
            }
        }

        return 0;
    }

    private function getTicketListRowById(int $ticketId): ?array
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return null;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId)) {
            return null;
        }

        return $this->mapTicketFieldsToListRow($ticket->fields);
    }

    /**
     * @param array<int, array<string, mixed>> $fallbackItems
     * @return array<int, array{id:int,label:string}>
     */
    public function getTicketGroupFilterOptions(array $fallbackItems = []): array
    {
        $map = [];
        foreach ($this->getCurrentUserGroupIds() as $groupId) {
            $label = $this->resolveGroupName((int) $groupId);
            if ($label !== '') {
                $map[(int) $groupId] = $label;
            }
        }

        foreach ($fallbackItems as $item) {
            foreach ((array) ($item['group_ids'] ?? []) as $index => $groupId) {
                $groupId = (int) $groupId;
                if ($groupId <= 0 || isset($map[$groupId])) {
                    continue;
                }
                $label = (string) (((array) ($item['group_names'] ?? []))[$index] ?? ('Grupo ' . $groupId));
                $map[$groupId] = $label;
            }
        }

        asort($map, SORT_NATURAL | SORT_FLAG_CASE);
        $options = [];
        foreach ($map as $id => $label) {
            $options[] = ['id' => (int) $id, 'label' => TextNormalizer::fromGlpi((string) $label)];
        }

        return $options;
    }

    public function getTicketById(int $ticketId): ?array
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return null;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId)) {
            return null;
        }

        $row = $ticket->fields;
        $requesterIds = $this->getTicketUserIdsByType($ticketId, 1);
        $requesterId = (int) ($requesterIds[0] ?? 0);
        $requester = $this->getUserContact($requesterId);

        $row['requester_id'] = $requesterId;
        $row['requester_firstname'] = $requester['firstname'] ?? '';
        $row['requester_realname'] = $requester['realname'] ?? '';
        $row['requester_email'] = '';
        $row['requester_phone'] = '';
        $row['requester_mobile'] = '';
        $row['requester_decision'] = $this->getTicketSatisfaction((int) $ticketId);
        $row['satisfaction_state'] = $this->getTicketSatisfactionState((int) $ticketId);
        $row['entity_name'] = $this->getEntityName((int) ($row['entities_id'] ?? 0));
        $row['category_name'] = $this->resolveTicketCategoryName((int) ($row['itilcategories_id'] ?? 0));
        $row['location_name'] = $this->resolveTicketLocationName((int) ($row['locations_id'] ?? 0));

        return $row;
    }

    /**
     * Return requester contact only after the caller has already established
     * ticket access. The application service masks these values by default and
     * reveals them only through the audited PII flow.
     *
     * @return array{firstname:string,realname:string,email:string,phone:string,mobile:string}
     */
    public function getTicketRequesterContact(int $ticketId): array
    {
        $empty = ['firstname' => '', 'realname' => '', 'email' => '', 'phone' => '', 'mobile' => ''];
        if (!$this->canReadTicket($ticketId)) {
            return $empty;
        }

        $requesterIds = $this->getTicketUserIdsByType($ticketId, 1);
        $requesterId = (int) ($requesterIds[0] ?? 0);
        if ($requesterId <= 0) {
            return $empty;
        }

        return $this->getUserContact($requesterId);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function getTicketRowsFromNativeFind(array $filters): array
    {
        $ticket = new \Ticket();
        $criteria = [];

        if ($this->ticketColumnExists('is_deleted')) {
            $criteria['is_deleted'] = 0;
        }

        $order = $this->nativeTicketOrder((string) ($filters['sort'] ?? 'date_mod'), (string) ($filters['direction'] ?? 'DESC'));
        $rows = $ticket->find($criteria, $order, self::PORTAL_FALLBACK_SCAN_LIMIT);
        return is_array($rows) ? array_values($rows) : [];
    }

    private function nativeTicketOrder(string $sort, string $direction): string
    {
        $direction = strtoupper($direction) === 'ASC' ? 'ASC' : 'DESC';
        $allowed = ['id', 'name', 'status', 'priority', 'date', 'date_mod'];
        $field = in_array($sort, $allowed, true) ? $sort : 'date_mod';
        return $field . ' ' . $direction;
    }

    private function ticketMatchesPortalFilters(array $fields, array $filters): bool
    {
        $ticketId = (int) ($fields['id'] ?? 0);
        if ($ticketId <= 0 || !$this->canReadTicket($ticketId)) {
            return false;
        }

        if (isset($fields['entities_id']) && !in_array((int) $fields['entities_id'], $this->getCurrentEntities(), true)) {
            return false;
        }

        $status = (string) ($filters['status'] ?? '');
        if ($status !== '' && ctype_digit($status) && (int) ($fields['status'] ?? 0) !== (int) $status) {
            return false;
        }

        $scope = (string) ($filters['scope'] ?? 'all');
        if ($scope === 'mine' && !$this->isCurrentUserTicketParticipant($ticketId)) {
            return false;
        }
        if ($scope === 'group' && !$this->isCurrentUserGroupTicket($ticketId)) {
            return false;
        }

        $groupId = (int) ($filters['group_id'] ?? 0);
        if ($groupId > 0 && !in_array($groupId, $this->getTicketGroupIdsByType($ticketId, 2), true)) {
            return false;
        }

        $search = trim((string) ($filters['q'] ?? ''));
        if ($search !== '') {
            $haystack = $this->normalizeSearchText(
                (string) ($fields['id'] ?? '') . ' ' .
                (string) ($fields['name'] ?? '') . ' ' .
                (string) ($fields['content'] ?? '')
            );
            if (!str_contains($haystack, $this->normalizeSearchText($search))) {
                return false;
            }
        }

        return true;
    }

    private function mapTicketFieldsToListRow(array $fields): ?array
    {
        $ticketId = (int) ($fields['id'] ?? 0);
        if ($ticketId <= 0) {
            return null;
        }

        $requesterNames = $this->getTicketUserNamesByType($ticketId, 1);
        $assigneeNames = $this->getTicketUserNamesByType($ticketId, 2);
        $groups = $this->getTicketAssignedGroups($ticketId);

        $groupNames = array_values(array_map(
            static fn(array $group): string => (string) ($group['name'] ?? ''),
            $groups
        ));
        $groupIds = array_values(array_map(
            static fn(array $group): int => (int) ($group['id'] ?? 0),
            $groups
        ));

        return [
            'id' => $ticketId,
            'name' => TextNormalizer::fromGlpi((string) ($fields['name'] ?? '')),
            'content' => TextNormalizer::fromGlpi((string) ($fields['content'] ?? '')),
            'status' => (int) ($fields['status'] ?? 0),
            'priority' => (int) ($fields['priority'] ?? 0),
            'urgency' => (int) ($fields['urgency'] ?? 0),
            'impact' => (int) ($fields['impact'] ?? 0),
            'date' => (string) ($fields['date'] ?? ''),
            'date_mod' => (string) ($fields['date_mod'] ?? ''),
            'entities_id' => (int) ($fields['entities_id'] ?? 0),
            'users_id_recipient' => (int) ($fields['users_id_recipient'] ?? 0),
            'requester_name' => TextNormalizer::fromGlpi(implode(', ', $requesterNames)),
            'assignee_name' => TextNormalizer::fromGlpi(implode(', ', $assigneeNames)),
            'group_names' => $groupNames,
            'group_ids' => $groupIds,
            'primary_group_name' => $groupNames[0] ?? 'Sem grupo',
            'primary_group_id' => $groupIds[0] ?? 0,
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     */
    private function sortTicketRows(array &$rows, string $sort, string $direction): void
    {
        $allowed = ['id', 'name', 'status', 'priority', 'date', 'date_mod'];
        $field = in_array($sort, $allowed, true) ? $sort : 'date_mod';
        $multiplier = strtoupper($direction) === 'ASC' ? 1 : -1;

        usort($rows, static function (array $left, array $right) use ($field, $multiplier): int {
            $leftValue = $left[$field] ?? '';
            $rightValue = $right[$field] ?? '';
            if (is_numeric($leftValue) && is_numeric($rightValue)) {
                return ((int) $leftValue <=> (int) $rightValue) * $multiplier;
            }

            return strcmp((string) $leftValue, (string) $rightValue) * $multiplier;
        });
    }

    private function isCurrentUserTicketParticipant(int $ticketId): bool
    {
        $userId = (int) ($_SESSION['glpiID'] ?? 0);
        if ($userId <= 0) {
            return false;
        }

        foreach ([1, 2, 3] as $type) {
            if (in_array($userId, $this->getTicketUserIdsByType($ticketId, $type), true)) {
                return true;
            }
        }

        return false;
    }

    private function isCurrentUserGroupTicket(int $ticketId): bool
    {
        $currentGroups = $this->getCurrentUserGroupIds();
        if ($currentGroups === []) {
            return false;
        }

        // Search API uses the native assigned-group relation (type=2).
        // Keep the compatibility backend semantically identical.
        if (array_intersect($currentGroups, $this->getTicketGroupIdsByType($ticketId, 2)) !== []) {
            return true;
        }

        return false;
    }

    /**
     * @return int[]
     */
    private function getTicketUserIdsByType(int $ticketId, int $type): array
    {
        if (!class_exists('\Ticket_User')) {
            return [];
        }

        $ticketUser = new \Ticket_User();
        $ids = [];
        foreach ($ticketUser->find(['tickets_id' => max(1, $ticketId), 'type' => $type]) as $row) {
            $id = (int) ($row['users_id'] ?? 0);
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }

        return array_values($ids);
    }

    /**
     * @return string[]
     */
    private function getTicketUserNamesByType(int $ticketId, int $type): array
    {
        $names = [];
        foreach ($this->getTicketUserIdsByType($ticketId, $type) as $userId) {
            $names[] = $this->resolveUserName($userId);
        }

        return $names;
    }

    /**
     * @return int[]
     */
    private function getTicketGroupIdsByType(int $ticketId, int $type): array
    {
        if (!class_exists('\Group_Ticket')) {
            return [];
        }

        $groupTicket = new \Group_Ticket();
        $ids = [];
        foreach ($groupTicket->find(['tickets_id' => max(1, $ticketId), 'type' => $type]) as $row) {
            $id = (int) ($row['groups_id'] ?? 0);
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }

        return array_values($ids);
    }

    /**
     * @return int[]
     */
    public function getCurrentUserGroupIds(): array
    {
        if (class_exists('\Session') && method_exists('\Session', 'getCurrentUserGroups')) {
            $groups = \Session::getCurrentUserGroups();
            if (is_array($groups)) {
                return array_values(array_unique(array_map('intval', $groups)));
            }
        }

        foreach (['glpigroups', 'glpigroups_assign'] as $sessionKey) {
            $groups = $_SESSION[$sessionKey] ?? null;
            if (is_array($groups)) {
                $ids = [];
                foreach ($groups as $key => $value) {
                    $candidate = is_numeric($value) ? (int) $value : (is_numeric($key) ? (int) $key : 0);
                    if ($candidate > 0) {
                        $ids[$candidate] = $candidate;
                    }
                }
                if ($ids !== []) {
                    return array_values($ids);
                }
            }
        }

        return [];
    }

    private function resolveUserName(int $userId): string
    {
        if ($userId <= 0 || !class_exists('\User')) {
            return $userId > 0 ? 'Usuario #' . $userId : '';
        }

        $user = new \User();
        if (!$user->getFromDB($userId)) {
            return 'Usuario #' . $userId;
        }

        return $this->formatUserName($user->fields, $userId);
    }

    private function formatUserName(array $fields, int $fallbackId): string
    {
        $name = trim((string) (($fields['firstname'] ?? '') . ' ' . ($fields['realname'] ?? '')));
        if ($name !== '') {
            return $name;
        }

        $login = trim((string) ($fields['name'] ?? ''));
        return $login !== '' ? $login : 'Usuario #' . $fallbackId;
    }

    private function resolveGroupName(int $groupId): string
    {
        if ($groupId <= 0 || !class_exists('\Group')) {
            return $groupId > 0 ? 'Grupo ' . $groupId : '';
        }

        $group = new \Group();
        if (!$group->getFromDB($groupId)) {
            return 'Grupo ' . $groupId;
        }

        return TextNormalizer::fromGlpi((string) ($group->fields['completename'] ?? $group->fields['name'] ?? ('Grupo ' . $groupId)));
    }

    /**
     * @return array{firstname:string,realname:string,email:string,phone:string,mobile:string}
     */
    private function getUserContact(int $userId): array
    {
        $contact = [
            'firstname' => '',
            'realname' => '',
            'email' => '',
            'phone' => '',
            'mobile' => '',
        ];

        if ($userId <= 0 || !class_exists('\User')) {
            return $contact;
        }

        $user = new \User();
        if (!$user->getFromDB($userId)) {
            return $contact;
        }

        $contact['firstname'] = (string) ($user->fields['firstname'] ?? '');
        $contact['realname'] = (string) ($user->fields['realname'] ?? '');
        $contact['phone'] = (string) ($user->fields['phone'] ?? '');
        $contact['mobile'] = (string) ($user->fields['mobile'] ?? '');
        $contact['email'] = (string) ($user->fields['email'] ?? '');

        if (class_exists('\UserEmail')) {
            $email = new \UserEmail();
            $rows = $email->find(['users_id' => $userId, 'is_default' => 1]);
            if ($rows === []) {
                $rows = $email->find(['users_id' => $userId]);
            }
            $first = is_array($rows) ? reset($rows) : false;
            if (is_array($first) && trim((string) ($first['email'] ?? '')) !== '') {
                $contact['email'] = (string) $first['email'];
            }
        }

        return $contact;
    }

    private function getTicketSatisfaction(int $ticketId): int
    {
        if (!class_exists('\TicketSatisfaction')) {
            return 0;
        }

        $satisfaction = new \TicketSatisfaction();
        $rows = $satisfaction->find(['tickets_id' => max(1, $ticketId)]);
        $first = is_array($rows) ? reset($rows) : false;
        return is_array($first) ? (int) ($first['satisfaction'] ?? 0) : 0;
    }

    public function getTicketSatisfactionState(int $ticketId): array
    {
        $ticketId = max(1, $ticketId);
        $state = [
            'exists' => false,
            'available' => false,
            'can_answer' => false,
            'is_closed' => false,
            'id' => 0,
            'score' => null,
            'comment' => '',
            'date_answered' => '',
        ];

        if (!class_exists('\Ticket') || !class_exists('\TicketSatisfaction') || !$this->canReadTicket($ticketId)) {
            return $state;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId)) {
            return $state;
        }

        $status = (int) ($ticket->fields['status'] ?? 0);
        $closedStatuses = method_exists(\Ticket::class, 'getClosedStatusArray') ? \Ticket::getClosedStatusArray() : [6];
        $state['is_closed'] = in_array($status, array_map('intval', (array) $closedStatuses), true);

        $satisfaction = new \TicketSatisfaction();
        $rows = $satisfaction->find(['tickets_id' => $ticketId]);
        $first = is_array($rows) ? reset($rows) : false;
        if (!is_array($first) || empty($first['id'])) {
            return $state;
        }

        $state['exists'] = true;
        $state['id'] = (int) $first['id'];
        $state['score'] = isset($first['satisfaction']) ? (int) $first['satisfaction'] : null;
        $state['comment'] = (string) ($first['comment'] ?? '');
        $state['date_answered'] = (string) ($first['date_answered'] ?? '');
        $state['available'] = (bool) $state['is_closed'];

        $current = new \TicketSatisfaction();
        if ($state['available'] && $current->getFromDB((int) $state['id'])) {
            $state['can_answer'] = method_exists($current, 'canUpdateItem')
                ? (bool) $current->canUpdateItem()
                : $this->canReadTicket($ticketId);
        }

        return $state;
    }

    public function getTicketActors(int $ticketId): array
    {
        if (!$this->canReadTicket($ticketId)) {
            return [];
        }

        $actors = [
            'requesters' => [],
            'assignees' => [],
            'watchers' => [],
        ];

        $ticketUser = new \Ticket_User();
        foreach ($ticketUser->find(['tickets_id' => max(1, $ticketId)]) as $row) {
            $type = (int) ($row['type'] ?? 0);
            $userId = (int) ($row['users_id'] ?? 0);
            if ($userId <= 0) {
                continue;
            }

            $item = [
                'id' => $userId,
                'name' => $this->resolveUserName($userId),
            ];

            if ($type === 1) {
                $actors['requesters'][] = $item;
            } elseif ($type === 2) {
                $actors['assignees'][] = $item;
            } elseif ($type === 3) {
                $actors['watchers'][] = $item;
            }
        }

        if (class_exists('\Group_Ticket')) {
            $groupTicket = new \Group_Ticket();
            foreach ($groupTicket->find(['tickets_id' => max(1, $ticketId)]) as $row) {
                $type = (int) ($row['type'] ?? 0);
                $groupId = (int) ($row['groups_id'] ?? 0);
                if ($groupId <= 0) {
                    continue;
                }
                $item = [
                    'id' => $groupId,
                    'name' => $this->resolveGroupName($groupId),
                ];

                if ($type === 1) {
                    $actors['requesters'][] = $item;
                } elseif ($type === 2) {
                    $actors['assignees'][] = $item;
                } elseif ($type === 3) {
                    $actors['watchers'][] = $item;
                }
            }
        }

        return $actors;
    }

    public function getTicketActionContext(int $ticketId): array
    {
        $ticketId = max(1, $ticketId);
        $canRead = $this->canReadTicket($ticketId);
        $canUpdate = $canRead && $this->canUpdateTicket($ticketId);
        $canAddFollowup = $canRead && $this->canAddFollowupToTicket($ticketId);
        $canAddTask = $canRead && $this->canAddTaskToTicket($ticketId);
        $canAddSolution = $canRead && $this->canAddSolutionToTicket($ticketId);
        $canChangeStatus = $canRead && $this->canChangeStatusToTicket($ticketId);
        $canRoute = $canRead && $this->canRouteTicket($ticketId);

        return [
            'can_read' => $canRead,
            'can_update' => $canUpdate,
            'can_add_followup' => $canAddFollowup,
            'can_add_task' => $canAddTask,
            'can_add_solution' => $canAddSolution,
            'can_change_status' => $canChangeStatus,
            'can_route' => $canRoute,
        ];
    }

    public function getTicketRoutingContext(int $ticketId): array
    {
        $ticketId = max(1, $ticketId);
        $actions = $this->getTicketActionContext($ticketId);
        $canUpdate = !empty($actions['can_update']);
        $canAddTask = !empty($actions['can_add_task']);
        $canRoute = !empty($actions['can_route']);
        $needsAssignmentOptions = $canAddTask || $canRoute;
        $context = $needsAssignmentOptions ? $this->getTicketCreationContext() : [];

        return [
            'can_update' => $canUpdate,
            'can_add_task' => $canAddTask,
            'can_route' => $canRoute,
            'assignable_users' => $needsAssignmentOptions ? ($context['assignable_users'] ?? []) : [],
            'assignable_groups' => $needsAssignmentOptions ? ($context['assignable_groups'] ?? []) : [],
            'task_categories' => $canAddTask ? $this->getTaskCategories() : [],
            'task_state_options' => $canAddTask ? $this->getTaskStateOptions() : [],
            'task_duration_options' => $canAddTask ? $this->getTaskDurationOptions() : [],
            'assigned_user_ids' => $this->getTicketUserIdsByType($ticketId, 2),
            'observer_user_ids' => $this->getTicketUserIdsByType($ticketId, 3),
            'assigned_group_ids' => $this->getTicketGroupIdsByType($ticketId, 2),
        ];
    }

    /**
     * @param string[] $expectedFilenames
     * @return array<string, mixed>
     */
    public function ticketDocumentLinkDiagnostics(
        int $ticketId,
        int $expectedLinks = 1,
        array $expectedFilenames = []
    ): array {
        return $this->documentItemLinkDiagnostics('Ticket', $ticketId, $expectedLinks, $expectedFilenames);
    }

    /**
     * @param string[] $expectedFilenames
     * @return array<string, mixed>
     */
    public function documentItemLinkDiagnostics(
        string $itemtype,
        int $itemId,
        int $expectedLinks = 1,
        array $expectedFilenames = []
    ): array {
        $expectedLinks = max(0, $expectedLinks);
        $itemtype = trim($itemtype);
        if ($itemId <= 0 || $itemtype === '' || $expectedLinks <= 0) {
            return [
                'available' => true,
                'expected' => $expectedLinks,
                'linked' => 0,
                'matched' => 0,
                'document_ids' => [],
                'filenames' => [],
                'complete' => true,
                'reason' => 'not_required',
            ];
        }
        if (!class_exists('\Document_Item') || !class_exists('\Document')) {
            return [
                'available' => false,
                'expected' => $expectedLinks,
                'linked' => 0,
                'matched' => 0,
                'document_ids' => [],
                'filenames' => [],
                'complete' => false,
                'reason' => 'document_item_api_unavailable',
            ];
        }

        $document = new \Document();
        $documentIds = [];
        $filenames = [];
        $link = new \Document_Item();
        foreach ((array) $link->find(['itemtype' => $itemtype, 'items_id' => $itemId]) as $row) {
            $documentId = (int) (((array) $row)['documents_id'] ?? 0);
            if ($documentId <= 0 || in_array($documentId, $documentIds, true)) {
                continue;
            }
            if (!$document->getFromDB($documentId)) {
                continue;
            }
            $documentIds[] = $documentId;
            $filenames[] = basename((string) ($document->fields['filename'] ?? $document->fields['name'] ?? ''));
        }

        $expectedFilenames = array_values(array_unique(array_filter(array_map(
            static fn(string $filename): string => basename(trim($filename)),
            array_map('strval', $expectedFilenames)
        ))));
        $normalizedLinked = array_map(
            static fn(string $filename): string => mb_strtolower($filename, 'UTF-8'),
            $filenames
        );
        $matched = 0;
        foreach ($expectedFilenames as $expectedFilename) {
            if (in_array(mb_strtolower($expectedFilename, 'UTF-8'), $normalizedLinked, true)) {
                $matched++;
            }
        }
        $complete = $expectedFilenames !== []
            ? $matched >= min($expectedLinks, count($expectedFilenames))
            : count($documentIds) >= $expectedLinks;

        return [
            'available' => true,
            'expected' => $expectedLinks,
            'linked' => count($documentIds),
            'matched' => $matched,
            'document_ids' => $documentIds,
            'filenames' => $filenames,
            'complete' => $complete,
            'reason' => $complete ? 'confirmed' : 'document_item_link_missing',
        ];
    }
    public function ticketHasDocumentLinks(int $ticketId, int $minimumLinks = 1): bool
    {
        $diagnostics = $this->ticketDocumentLinkDiagnostics($ticketId, $minimumLinks);
        return $diagnostics['available'] && $diagnostics['complete'];
    }

    public function getTicketDocuments(int $ticketId): array
    {
        if (!$this->canReadTicket($ticketId) || !class_exists('\Document_Item') || !class_exists('\Document')) {
            return [];
        }

        $documents = [];
        $link = new \Document_Item();
        $document = new \Document();
        foreach ($link->find(['itemtype' => 'Ticket', 'items_id' => max(1, $ticketId)]) as $row) {
            $documentId = (int) ($row['documents_id'] ?? 0);
            if ($documentId > 0 && $document->getFromDB($documentId)) {
                $documents[] = [
                    'id' => $documentId,
                    'name' => (string) ($document->fields['name'] ?? ''),
                    'filename' => (string) ($document->fields['filename'] ?? ''),
                    'date_mod' => (string) ($document->fields['date_mod'] ?? ''),
                ];
            }
        }

        usort($documents, static fn(array $left, array $right): int => strcmp((string) ($right['date_mod'] ?? ''), (string) ($left['date_mod'] ?? '')));

        return $documents;
    }

    public function applyRequesterDecision(int $ticketId, int $decision, string $comment): bool
    {
        if (!$this->canReadTicket($ticketId)) {
            return false;
        }

        $decision = max(1, min(5, $decision));
        $comment = trim($comment);
        $userId = (int) ($_SESSION['glpiID'] ?? 0);

        $satisfaction = new \TicketSatisfaction();
        $existing = $satisfaction->find([
            'tickets_id' => max(1, $ticketId),
        ]);

        if (!$existing) {
            throw new \RuntimeException('Nao ha pesquisa de satisfacao gerada para este chamado.');
        }

        $input = [
            'tickets_id' => max(1, $ticketId),
            'users_id' => $userId,
            'satisfaction' => $decision,
            'comment' => $comment,
            'date_answered' => date('Y-m-d H:i:s'),
        ];

        if ($existing) {
            $first = array_shift($existing);
            if (is_array($first) && isset($first['id'])) {
                $input['id'] = (int) $first['id'];
                $current = new \TicketSatisfaction();
                if ($current->getFromDB((int) $input['id']) && method_exists($current, 'canUpdateItem') && !$current->canUpdateItem()) {
                    throw new \RuntimeException('Sem permissao para responder a pesquisa de satisfacao.');
                }

                return (bool) $satisfaction->update($input);
            }
        }

        return false;
    }

    public function getTicketTimeline(int $ticketId): array
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return [];
        }

        $events = [];

        if (class_exists('\ITILFollowup')) {
            $followup = new \ITILFollowup();
            foreach ($followup->find(['itemtype' => 'Ticket', 'items_id' => $ticketId, 'is_private' => 0], 'date ASC') as $row) {
                $events[] = [
                    'type' => 'followup',
                    'date' => (string) ($row['date'] ?? ''),
                    'content' => (string) ($row['content'] ?? ''),
                    'users_id' => (int) ($row['users_id'] ?? 0),
                ];
            }
        }

        if (class_exists('\TicketTask')) {
            $task = new \TicketTask();
            foreach ($task->find(['tickets_id' => $ticketId, 'is_private' => 0], 'date ASC') as $row) {
                $events[] = [
                    'type' => 'task',
                    'date' => (string) ($row['date'] ?? ''),
                    'content' => (string) ($row['content'] ?? ''),
                    'users_id' => (int) ($row['users_id_tech'] ?? 0),
                ];
            }
        }

        if (class_exists('\ITILSolution')) {
            $solution = new \ITILSolution();
            foreach ($solution->find(['itemtype' => 'Ticket', 'items_id' => $ticketId], 'date_creation ASC') as $row) {
                $events[] = [
                    'type' => 'solution',
                    'date' => (string) ($row['date_creation'] ?? ''),
                    'content' => (string) ($row['content'] ?? ''),
                    'users_id' => (int) ($row['users_id'] ?? 0),
                ];
            }
        }

        usort($events, static fn(array $a, array $b): int => strcmp((string) $a['date'], (string) $b['date']));

        return $events;
    }

    public function canReadTicketHistory(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return false;
        }

        try {
            if (class_exists('\Log') && method_exists('\Log', 'canView') && (bool) \Log::canView()) {
                return true;
            }
        } catch (\Throwable $e) {
            return false;
        }

        if (class_exists('\Session') && method_exists('\Session', 'haveRight') && defined('READ')) {
            return (bool) \Session::haveRight('logs', READ)
                || (bool) \Session::haveRight('log', READ);
        }

        return false;
    }

    /**
     * @return array{can_view:bool,available:bool,limit:int,items:array<int,array<string,string|int>>}
     */
    public function getTicketHistoryContext(int $ticketId, int $limit = 50): array
    {
        $limit = min(100, max(10, $limit));
        $context = [
            'can_view' => $this->canReadTicketHistory($ticketId),
            'available' => false,
            'limit' => $limit,
            'items' => [],
        ];
        if (!$context['can_view']) {
            return $context;
        }

        $context['items'] = $this->getTicketHistory($ticketId, $limit);
        $context['available'] = class_exists('\Log') || $this->tableExists('glpi_logs');
        return $context;
    }

    /**
     * @return array<int, array<string, string|int>>
     */
    public function getTicketHistory(int $ticketId, int $limit = 50): array
    {
        $ticketId = max(1, $ticketId);
        $limit = min(100, max(10, $limit));
        if (!$this->canReadTicketHistory($ticketId)) {
            return [];
        }

        $fromNative = $this->getTicketHistoryFromNativeLog($ticketId, $limit);
        if ($fromNative !== []) {
            return $fromNative;
        }

        return $this->getTicketHistoryFromLogTable($ticketId, $limit);
    }

    /**
     * @return array<int, array<string, string|int>>
     */
    private function getTicketHistoryFromNativeLog(int $ticketId, int $limit): array
    {
        if (!class_exists('\Log') || !method_exists('\Log', 'getHistoryData') || !class_exists('\Ticket')) {
            return [];
        }

        try {
            $ticket = new \Ticket();
            if (!$ticket->getFromDB($ticketId)) {
                return [];
            }

            $data = \Log::getHistoryData($ticket, 0, $limit);
            if (!is_array($data)) {
                return [];
            }

            return $this->normalizeTicketHistoryRows($data, $limit);
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * @return array<int, array<string, string|int>>
     */
    private function getTicketHistoryFromLogTable(int $ticketId, int $limit): array
    {
        global $DB;
        if (!isset($DB) || !method_exists($DB, 'request') || !$this->tableExists('glpi_logs')) {
            return [];
        }

        $columns = $this->getTableColumns('glpi_logs');
        if ($columns === []) {
            return [];
        }

        try {
            $rows = $DB->request([
                'SELECT' => $columns,
                'FROM' => 'glpi_logs',
                'WHERE' => [
                    'itemtype' => 'Ticket',
                    'items_id' => $ticketId,
                ],
                'ORDER' => ['id DESC'],
                'LIMIT' => $limit,
            ]);
        } catch (\Throwable $e) {
            return [];
        }

        $history = [];
        foreach ($rows as $row) {
            $history[] = $this->normalizeTicketHistoryRow((array) $row);
        }

        return array_values(array_filter($history, static fn(array $row): bool => trim((string) ($row['summary'] ?? '')) !== ''));
    }

    /**
     * @param array<string, mixed> $data
     * @return array<int, array<string, string|int>>
     */
    private function normalizeTicketHistoryRows(array $data, int $limit): array
    {
        $candidateRows = $data['history'] ?? $data['data'] ?? $data['rows'] ?? $data;
        if (!is_array($candidateRows)) {
            return [];
        }

        $history = [];
        foreach ($candidateRows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $normalized = $this->normalizeTicketHistoryRow($row);
            if (trim((string) ($normalized['summary'] ?? '')) === '') {
                continue;
            }
            $history[] = $normalized;
            if (count($history) >= $limit) {
                break;
            }
        }

        return $history;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, string|int>
     */
    private function normalizeTicketHistoryRow(array $row): array
    {
        $id = (int) ($row['id'] ?? $row['logs_id'] ?? 0);
        $date = (string) ($row['date_mod'] ?? $row['date'] ?? $row['date_creation'] ?? '');
        $user = (string) ($row['user_name'] ?? $row['user'] ?? $row['username'] ?? '');
        $field = (string) ($row['field'] ?? $row['fieldname'] ?? $row['id_search_option'] ?? $row['itemtype_link'] ?? '');
        $action = (string) ($row['linked_action'] ?? $row['action'] ?? '');
        $summaryCandidates = [
            $row['change'] ?? null,
            $row['changes'] ?? null,
            $row['message'] ?? null,
            $row['display_history'] ?? null,
            $row['old_value'] ?? null,
            $row['new_value'] ?? null,
        ];
        $summaryParts = [];
        foreach ($summaryCandidates as $candidate) {
            if (is_array($candidate)) {
                $candidate = implode(' ', array_map(static fn($value): string => is_scalar($value) ? (string) $value : '', $candidate));
            }
            if (!is_scalar($candidate)) {
                continue;
            }
            $clean = $this->normalizeHistoryText((string) $candidate);
            if ($clean !== '' && !in_array($clean, $summaryParts, true)) {
                $summaryParts[] = $clean;
            }
        }

        $summary = implode(' -> ', $summaryParts);
        if ($summary === '' && $field !== '') {
            $summary = 'Alteracao registrada em ' . $this->normalizeHistoryText($field);
        }

        return [
            'id' => $id,
            'date' => $this->normalizeHistoryText($date),
            'user' => $this->normalizeHistoryText($user),
            'field' => $this->normalizeHistoryText($field),
            'action' => $this->normalizeHistoryText($action),
            'summary' => $summary,
        ];
    }

    private function normalizeHistoryText(string $value): string
    {
        $value = html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = preg_replace('/\s+/u', ' ', $value) ?? $value;
        return trim($value);
    }
    public function getCockpitMetrics(): array
    {
        $metrics = [
            'total_open' => 0,
            'pending' => 0,
            'solved_today' => 0,
            'mine_open' => 0,
            'group_open' => 0,
        ];

        $today = date('Y-m-d');
        foreach ($this->getTicketRowsFromNativeFind([]) as $row) {
            $ticketId = (int) ($row['id'] ?? 0);
            if ($ticketId <= 0 || !$this->canReadTicket($ticketId)) {
                continue;
            }

            $status = (int) ($row['status'] ?? 0);
            if (in_array($status, [1, 2, 3, 4], true)) {
                $metrics['total_open']++;
                if ($this->isCurrentUserTicketParticipant($ticketId)) {
                    $metrics['mine_open']++;
                }
                if ($this->isCurrentUserGroupTicket($ticketId)) {
                    $metrics['group_open']++;
                }
            }
            if ($status === 4) {
                $metrics['pending']++;
            }
            if ($status === 5 && str_starts_with((string) ($row['solvedate'] ?? ''), $today)) {
                $metrics['solved_today']++;
            }
        }

        return $metrics;
    }

    public function getKnowledgeArticles(string $query = '', int $limit = 30): array
    {
        $result = $this->searchKnowledgeArticles([
            'query' => $query,
            'public_only' => true,
            'page' => 1,
            'page_size' => $limit,
        ]);

        return $result['items'] ?? [];
    }

    public function searchKnowledgeArticles(array $filters): array
    {
        $query = trim((string) ($filters['query'] ?? ''));
        $categoryId = max(0, (int) ($filters['category_id'] ?? 0));
        $publicOnly = (bool) ($filters['public_only'] ?? false);
        $page = max(1, (int) ($filters['page'] ?? 1));
        $pageSize = min(20, max(1, (int) ($filters['page_size'] ?? 10)));

        if ($query === '' && $categoryId === 0) {
            return [
                'items' => [],
                'total' => 0,
                'page' => $page,
                'page_size' => $pageSize,
                'pages' => 1,
            ];
        }

        $items = $this->fetchKnowledgeCandidates([
            'query' => $query,
            'category_id' => $categoryId,
            'public_only' => $publicOnly,
            'limit' => max(50, $pageSize * 12),
            'order' => 'updated',
        ]);

        if ($query !== '') {
            usort($items, function (array $left, array $right) use ($query): int {
                $scoreDiff = $this->scoreKnowledgeArticle($right, $query) <=> $this->scoreKnowledgeArticle($left, $query);
                if ($scoreDiff !== 0) {
                    return $scoreDiff;
                }

                return strcmp((string) ($right['date_mod'] ?? ''), (string) ($left['date_mod'] ?? ''));
            });
        }

        $total = count($items);
        $pages = max(1, (int) ceil(max(1, $total) / $pageSize));
        $page = min($page, $pages);
        $offset = ($page - 1) * $pageSize;

        return [
            'items' => array_slice($items, $offset, $pageSize),
            'total' => $total,
            'page' => $page,
            'page_size' => $pageSize,
            'pages' => $pages,
        ];
    }

    public function getKnowledgeHomeLists(bool $publicOnly, int $limit = 5): array
    {
        $limit = min(10, max(1, $limit));

        return [
            'recentes' => array_slice($this->fetchKnowledgeCandidates([
                'public_only' => $publicOnly,
                'limit' => $limit,
                'order' => 'recent',
            ]), 0, $limit),
            'atualizadas' => array_slice($this->fetchKnowledgeCandidates([
                'public_only' => $publicOnly,
                'limit' => $limit,
                'order' => 'updated',
            ]), 0, $limit),
            'populares' => array_slice($this->fetchKnowledgeCandidates([
                'public_only' => $publicOnly,
                'limit' => $limit,
                'order' => 'popular',
            ]), 0, $limit),
        ];
    }

    public function getKnowledgeCategories(bool $publicOnly, int $limit = 200): array
    {
        $items = $this->fetchKnowledgeCandidates([
            'public_only' => $publicOnly,
            'limit' => max(40, min(300, $limit)),
            'order' => 'updated',
        ]);

        $categories = [];
        foreach ($items as $item) {
            $categoryId = (int) ($item['category_id'] ?? 0);
            $label = trim((string) ($item['category'] ?? ''));
            if ($categoryId <= 0 || $label === '') {
                continue;
            }

            $categories[$categoryId] = [
                'id' => $categoryId,
                'label' => $label,
            ];
        }

        uasort($categories, static fn(array $left, array $right): int => strcasecmp($left['label'], $right['label']));

        return array_values($categories);
    }

    public function getKnowledgeArticle(int $articleId, bool $publicOnly = false): ?array
    {
        $articleId = max(1, $articleId);
        $kb = new \KnowbaseItem();
        if (!$kb->can($articleId, READ) || !$kb->getFromDB($articleId)) {
            return null;
        }

        $item = $this->mapKnowledgeItem($kb);
        if ($publicOnly) {
            $columns = $this->getTableColumns('glpi_knowbaseitems');
            if (in_array('is_faq', $columns, true) && empty($item['is_faq'])) {
                return null;
            }
        }

        return $item;
    }

    /**
     * Varredura controlada para gerar sugestoes de roteiro do chatbot.
     * Mantem os mesmos filtros nativos usados nas telas de KB e limita o volume
     * para evitar carga indevida em homologacao/producao.
     *
     * @return array<int, array<string, mixed>>
     */
    public function scanKnowledgeArticles(bool $publicOnly, int $limit = 80): array
    {
        return $this->fetchKnowledgeCandidates([
            'public_only' => $publicOnly,
            'limit' => min(200, max(10, $limit)),
            'order' => 'updated',
        ]);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function fetchKnowledgeCandidates(array $filters): array
    {
        $columns = $this->getTableColumns('glpi_knowbaseitems');
        if ($columns === [] || !class_exists('\KnowbaseItem')) {
            return [];
        }

        $query = trim((string) ($filters['query'] ?? ''));
        $categoryId = max(0, (int) ($filters['category_id'] ?? 0));
        $publicOnly = (bool) ($filters['public_only'] ?? false);
        $limit = min(250, max(1, (int) ($filters['limit'] ?? 20)));
        $order = (string) ($filters['order'] ?? 'updated');

        $criteria = [];

        if ($publicOnly && in_array('is_faq', $columns, true)) {
            $criteria['is_faq'] = 1;
        }
        if (in_array('is_deleted', $columns, true)) {
            $criteria['is_deleted'] = 0;
        }
        if ($categoryId > 0 && in_array('knowbaseitemcategories_id', $columns, true)) {
            $criteria['knowbaseitemcategories_id'] = $categoryId;
        }
        if ($query !== '') {
            $searchable = [];
            foreach (['name', 'question', 'answer'] as $field) {
                if (in_array($field, $columns, true)) {
                    $searchable[$field] = ['LIKE', '%' . $query . '%'];
                }
            }
            if ($searchable !== []) {
                $criteria['OR'] = $searchable;
            }
        }

        $orderClause = $this->getKnowledgeNativeOrder($columns, $order);
        $items = [];
        $seen = [];
        $maxScan = min(100, max($limit * 2, $limit));
        $kbFinder = new \KnowbaseItem();
        $rows = $kbFinder->find($criteria, $orderClause, $maxScan);

        foreach ((array) $rows as $row) {
            $id = (int) ($row['id'] ?? 0);
            if ($id <= 0 || isset($seen[$id])) {
                continue;
            }
            $seen[$id] = true;

            $kb = new \KnowbaseItem();
            if (!$kb->can($id, READ) || !$kb->getFromDB($id)) {
                continue;
            }

            $item = $this->mapKnowledgeItem($kb);
            if ($publicOnly && empty($item['is_faq']) && in_array('is_faq', $columns, true)) {
                continue;
            }
            if ($categoryId > 0 && (int) ($item['category_id'] ?? 0) !== $categoryId) {
                continue;
            }
            if ($query !== '' && !$this->knowledgeMatchesQuery($item, $query)) {
                continue;
            }

            $items[] = $item;
            if (count($items) >= $limit) {
                break;
            }
        }

        return $items;
    }

    private function getKnowledgeNativeOrder(array $columns, string $order): string
    {
        $dateCreationField = in_array('date_creation', $columns, true) ? 'date_creation' : 'id';
        $dateModField = in_array('date_mod', $columns, true) ? 'date_mod' : $dateCreationField;
        $popularityField = null;

        foreach (['view', 'views', 'visits', 'numviews'] as $field) {
            if (in_array($field, $columns, true)) {
                $popularityField = $field;
                break;
            }
        }

        return match ($order) {
            'recent' => $dateCreationField . ' DESC, id DESC',
            'popular' => ($popularityField ?? $dateModField) . ' DESC, ' . $dateModField . ' DESC',
            default => $dateModField . ' DESC, id DESC',
        };
    }

    private function getKnowledgeOrderClause(array $columns, string $order): string
    {
        $dateCreationField = in_array('date_creation', $columns, true) ? 'k.date_creation' : 'k.id';
        $dateModField = in_array('date_mod', $columns, true) ? 'k.date_mod' : $dateCreationField;
        $popularityField = null;

        foreach (['view', 'views', 'visits', 'numviews'] as $field) {
            if (in_array($field, $columns, true)) {
                $popularityField = 'k.' . $field;
                break;
            }
        }

        return match ($order) {
            'recent' => $dateCreationField . ' DESC, k.id DESC',
            'popular' => ($popularityField ?? $dateModField) . ' DESC, ' . $dateModField . ' DESC',
            default => $dateModField . ' DESC, k.id DESC',
        };
    }

    /**
     * @return array<string, mixed>
     */
    private function mapKnowledgeItem(\KnowbaseItem $kb): array
    {
        $fields = $kb->fields;
        $title = trim((string) ($fields['name'] ?? ''));
        if ($title === '') {
            $title = trim((string) ($fields['question'] ?? ''));
        }
        if ($title === '') {
            $title = 'Artigo #' . (int) ($fields['id'] ?? 0);
        }

        $questionHtml = $this->sanitizeKnowledgeHtml((string) ($fields['question'] ?? ''));
        $answerHtml = $this->sanitizeKnowledgeHtml((string) ($fields['answer'] ?? ''));
        $bodyHtml = $answerHtml !== '' ? $answerHtml : $questionHtml;
        $questionText = $this->toKnowledgePlainText($questionHtml);
        $answerText = $this->toKnowledgePlainText($answerHtml);
        $bodyText = $this->toKnowledgePlainText($bodyHtml);
        $summary = $bodyText;
        if (mb_strlen($summary) > 220) {
            $summary = rtrim(mb_substr($summary, 0, 217)) . '...';
        }

        $categoryId = (int) ($fields['knowbaseitemcategories_id'] ?? 0);
        $associated = $this->getKnowledgeAssociatedElements((int) ($fields['id'] ?? 0));

        return [
            'id' => (int) ($fields['id'] ?? 0),
            'assunto' => $title,
            'question' => $questionText,
            'answer' => $answerText,
            'question_html' => $questionHtml,
            'answer_html' => $answerHtml,
            'summary' => $summary,
            'body' => $bodyText,
            'body_html' => $bodyHtml,
            'category_id' => $categoryId,
            'category' => $this->resolveKnowledgeCategoryName($categoryId),
            'associados' => $associated,
            'date_creation' => (string) ($fields['date_creation'] ?? ''),
            'date_mod' => (string) ($fields['date_mod'] ?? ''),
            'is_faq' => !empty($fields['is_faq']),
            'popularity' => (int) ($fields['view'] ?? $fields['views'] ?? $fields['visits'] ?? $fields['numviews'] ?? 0),
        ];
    }

    private function resolveKnowledgeCategoryName(int $categoryId): string
    {
        if ($categoryId <= 0) {
            return 'Sem categoria';
        }

        if (class_exists('\Dropdown') && method_exists('\Dropdown', 'getDropdownName')) {
            $label = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName('glpi_knowbaseitemcategories', $categoryId));
            if ($label !== '') {
                return $label;
            }
        }

        if (class_exists('\KnowbaseItemCategory')) {
            $category = new \KnowbaseItemCategory();
            if ($category->getFromDB($categoryId)) {
                return TextNormalizer::fromGlpi((string) ($category->fields['completename'] ?? $category->fields['name'] ?? ('Categoria ' . $categoryId)));
            }
        }

        return 'Categoria ' . $categoryId;
    }

    private function getKnowledgeAssociatedElements(int $articleId): string
    {
        global $DB;

        if ($articleId <= 0 || !$this->tableExists('glpi_items_knowbaseitems')) {
            return 'Nao informado';
        }

        $counts = [];
        foreach (
            $DB->request([
            'SELECT' => ['itemtype'],
            'FROM' => 'glpi_items_knowbaseitems',
            'WHERE' => ['knowbaseitems_id' => $articleId],
            ]) as $row
        ) {
            $itemtype = (string) ($row['itemtype'] ?? '');
            if ($itemtype === '') {
                continue;
            }
            $counts[$itemtype] = ($counts[$itemtype] ?? 0) + 1;
        }

        arsort($counts);

        $items = [];
        foreach (array_slice($counts, 0, 3, true) as $itemtype => $total) {
            $label = $this->resolveItemTypeLabel((string) $itemtype, (int) $total);
            if ($label !== '') {
                $items[] = $label;
            }
        }

        return $items === [] ? 'Nao informado' : implode(', ', $items);
    }

    private function resolveItemTypeLabel(string $itemtype, int $count): string
    {
        $itemtype = trim($itemtype);
        if ($itemtype === '') {
            return '';
        }

        if (class_exists($itemtype) && method_exists($itemtype, 'getTypeName')) {
            $label = (string) $itemtype::getTypeName($count);
            if ($label !== '') {
                return $label;
            }
        }

        $short = str_contains($itemtype, '\\') ? substr($itemtype, (int) strrpos($itemtype, '\\') + 1) : $itemtype;
        $short = preg_replace('/(?<!^)([A-Z])/', ' $1', $short) ?? $short;
        return trim($short);
    }

    private function knowledgeMatchesQuery(array $item, string $query): bool
    {
        $needle = $this->normalizeSearchText($query);
        if ($needle === '') {
            return true;
        }

        foreach ([$item['assunto'] ?? '', $item['summary'] ?? '', $item['body'] ?? '', $item['category'] ?? ''] as $haystack) {
            if (str_contains($this->normalizeSearchText((string) $haystack), $needle)) {
                return true;
            }
        }

        return false;
    }

    private function scoreKnowledgeArticle(array $item, string $query): int
    {
        $terms = array_values(array_filter(preg_split('/\s+/u', $this->normalizeSearchText($query)) ?: []));
        if ($terms === []) {
            return 0;
        }

        $title = $this->normalizeSearchText((string) ($item['assunto'] ?? ''));
        $summary = $this->normalizeSearchText((string) ($item['summary'] ?? ''));
        $body = $this->normalizeSearchText((string) ($item['body'] ?? ''));
        $category = $this->normalizeSearchText((string) ($item['category'] ?? ''));

        $score = 0;
        foreach ($terms as $term) {
            if ($term === '') {
                continue;
            }
            if (str_contains($title, $term)) {
                $score += 6;
            }
            if (str_contains($summary, $term)) {
                $score += 4;
            }
            if (str_contains($body, $term)) {
                $score += 2;
            }
            if (str_contains($category, $term)) {
                $score += 1;
            }
        }

        return $score;
    }

    private function normalizeSearchText(string $value): string
    {
        $value = mb_strtolower($value, 'UTF-8');
        $converted = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if ($converted !== false) {
            $value = $converted;
        }

        return trim(preg_replace('/\s+/', ' ', $value) ?? $value);
    }

    private function sanitizeKnowledgeHtml(string $value): string
    {
        $value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        $safeHtml = $this->sanitizeHtmlWithGlpiCore($value);
        if ($safeHtml !== null) {
            return $this->normalizeKnowledgeMediaHtml($safeHtml);
        }

        $value = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $value) ?? $value;
        $value = preg_replace('#<style(.*?)>(.*?)</style>#is', '', $value) ?? $value;
        $value = preg_replace('/\s+on[a-z]+\s*=\s*"[^"]*"/i', '', $value) ?? $value;
        $value = preg_replace("/\s+on[a-z]+\s*=\s*'[^']*'/i", '', $value) ?? $value;
        $value = preg_replace('/\s+on[a-z]+\s*=\s*[^\s>]+/i', '', $value) ?? $value;
        $value = preg_replace('/\s+style\s*=\s*"[^"]*"/i', '', $value) ?? $value;
        $value = preg_replace("/\s+style\s*=\s*'[^']*'/i", '', $value) ?? $value;
        $value = preg_replace('/\s+style\s*=\s*[^\s>]+/i', '', $value) ?? $value;
        $value = preg_replace('/\s+class\s*=\s*"[^"]*"/i', '', $value) ?? $value;
        $value = preg_replace("/\s+class\s*=\s*'[^']*'/i", '', $value) ?? $value;
        $value = preg_replace('/\s+class\s*=\s*[^\s>]+/i', '', $value) ?? $value;
        $value = preg_replace('/href\s*=\s*"javascript:[^"]*"/i', 'href="#"', $value) ?? $value;
        $value = preg_replace("/href\s*=\s*'javascript:[^']*'/i", 'href="#"', $value) ?? $value;

        $allowed = '<p><br><strong><b><em><i><u><ul><ol><li><a><h1><h2><h3><h4><h5><h6><blockquote><code><pre><img><figure><figcaption><table><thead><tbody><tfoot><tr><th><td>';
        $clean = strip_tags($value, $allowed);
        $clean = $this->normalizeKnowledgeMediaHtml($clean);
        $clean = preg_replace("/\r\n?/", "\n", $clean) ?? $clean;
        return trim($clean);
    }

    private function sanitizeHtmlWithGlpiCore(string $value): ?string
    {
        if (class_exists('\Glpi\RichText\RichText') && is_callable(['\Glpi\RichText\RichText', 'getSafeHtml'])) {
            return trim((string) \Glpi\RichText\RichText::getSafeHtml($value));
        }

        if (class_exists('\Html') && is_callable(['\Html', 'clean'])) {
            return trim((string) \Html::clean($value));
        }

        return null;
    }

    private function normalizeKnowledgeMediaHtml(string $value): string
    {
        $value = $this->rewriteKnowledgeUrlAttributes($value, 'src');
        $value = $this->rewriteKnowledgeUrlAttributes($value, 'href');
        $value = preg_replace('/<img\b(?![^>]*\balt=)/i', '<img alt="Imagem do artigo"', $value) ?? $value;
        $value = preg_replace('/<img\b(?![^>]*\bloading=)/i', '<img loading="lazy"', $value) ?? $value;
        $value = preg_replace('/<img\b(?![^>]*\bdecoding=)/i', '<img decoding="async"', $value) ?? $value;
        $value = preg_replace('/<a\b(?![^>]*\brel=)/i', '<a rel="noopener noreferrer"', $value) ?? $value;

        return $value;
    }

    private function rewriteKnowledgeUrlAttributes(string $value, string $attribute): string
    {
        return preg_replace_callback(
            '/\s' . preg_quote($attribute, '/') . '\s*=\s*(["\'])(.*?)\1/i',
            function (array $matches) use ($attribute): string {
                $url = html_entity_decode((string) ($matches[2] ?? ''), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $safeUrl = $this->normalizeKnowledgeAssetUrl($url, $attribute === 'src');
                if ($safeUrl === '') {
                    return $attribute === 'href' ? ' href="#"' : '';
                }

                return ' ' . $attribute . '="' . htmlspecialchars($safeUrl, ENT_QUOTES, 'UTF-8') . '"';
            },
            $value
        ) ?? $value;
    }

    private function normalizeKnowledgeAssetUrl(string $url, bool $isImage): string
    {
        global $CFG_GLPI;

        $url = trim($url);
        if ($url === '') {
            return '';
        }

        $decoded = html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (preg_match('/^\s*(javascript|vbscript):/i', $decoded)) {
            return '';
        }

        if ($isImage && preg_match('#^data:image/(png|gif|jpe?g|webp);base64,[a-z0-9+/=\s]+$#i', $decoded)) {
            return preg_replace('/\s+/', '', $decoded) ?? $decoded;
        }

        if (preg_match('#^https?://#i', $decoded)) {
            return $decoded;
        }

        $root = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/');
        if ($root === '') {
            $root = '';
        }

        if (str_starts_with($decoded, '/')) {
            return $root !== '' && !str_starts_with($decoded, $root . '/') ? $root . $decoded : $decoded;
        }

        $trimmedRelative = preg_replace('#^(\./|\.\./)+#', '', $decoded) ?? $decoded;
        if (str_starts_with($trimmedRelative, 'front/') || str_starts_with($trimmedRelative, 'ajax/') || str_starts_with($trimmedRelative, 'plugins/')) {
            return $root . '/' . $trimmedRelative;
        }

        if (str_starts_with($decoded, 'front/') || str_starts_with($decoded, 'ajax/') || str_starts_with($decoded, 'plugins/')) {
            return $root . '/' . $decoded;
        }

        if (str_starts_with($decoded, './')) {
            return $root . '/' . ltrim(substr($decoded, 2), '/');
        }

        return $isImage ? '' : $decoded;
    }

    private function toKnowledgePlainText(string $value): string
    {
        $value = str_replace(
            ['<br>', '<br/>', '<br />', '</p>', '</div>', '</li>', '<li>'],
            ["\n", "\n", "\n", "\n\n", "\n\n", "\n", "- "],
            $value
        );
        $value = html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = preg_replace("/\r\n?/", "\n", $value) ?? $value;
        $value = preg_replace("/\n{3,}/", "\n\n", $value) ?? $value;
        $value = preg_replace('/[ \t]+/', ' ', $value) ?? $value;
        return trim($value);
    }

    /**
     * @return string[]
     */
    private function getTableColumns(string $table): array
    {
        global $DB;

        $knownColumns = [
            'glpi_tickets' => [
                'id', 'name', 'content', 'status', 'type', 'urgency', 'impact', 'priority',
                'entities_id', 'itilcategories_id', 'locations_id', 'requesttypes_id',
                'externalid', 'date', 'date_mod', 'date_creation', 'is_deleted',
            ],
            'glpi_knowbaseitems' => [
                'id', 'name', 'answer', 'is_faq', 'is_recursive', 'view',
                'knowbaseitemcategories_id', 'date_mod', 'date_creation',
            ],
            'glpi_users' => ['id', 'name', 'firstname', 'realname', 'is_deleted', 'is_active'],
            'glpi_groups' => ['id', 'name', 'completename', 'is_deleted', 'is_active', 'entities_id', 'is_recursive'],
            'glpi_requesttypes' => ['id', 'name', 'is_active'],
            'glpi_taskcategories' => ['id', 'name', 'completename', 'is_deleted', 'is_active', 'entities_id', 'is_recursive'],
            'glpi_logs' => [
                'id', 'itemtype', 'items_id', 'itemtype_link', 'linked_action',
                'id_search_option', 'user_name', 'date_mod', 'old_value', 'new_value',
            ],
        ];

        $columns = $knownColumns[$table] ?? [];
        if ($columns === [] || !method_exists($DB, 'fieldExists')) {
            return $columns;
        }

        return array_values(array_filter(
            $columns,
            static fn(string $column): bool => (bool) $DB->fieldExists($table, $column)
        ));
    }

    private function columnExists(string $table, string $column): bool
    {
        global $DB;

        if (method_exists($DB, 'fieldExists')) {
            return (bool) $DB->fieldExists($table, $column);
        }

        return in_array($column, $this->getTableColumns($table), true);
    }

    private function ticketColumnExists(string $column): bool
    {
        return $this->columnExists('glpi_tickets', $column);
    }

    private function tableExists(string $table): bool
    {
        global $DB;

        if (method_exists($DB, 'tableExists')) {
            return (bool) $DB->tableExists($table);
        }

        return in_array($table, [
            'glpi_tickets',
            'glpi_knowbaseitems',
            'glpi_items_knowbaseitems',
            'glpi_users',
            'glpi_groups',
            'glpi_requesttypes',
            'glpi_taskcategories',
            'glpi_logs',
        ], true);
    }

    /**
     * @return array<int, array{id:int,name:string,content:string,is_private:int,requesttypes_id:int}>
     */
    public function getFollowupTemplatesForTicket(int $ticketId): array
    {
        if (!$this->canReadTicket($ticketId) || !class_exists('\ITILFollowupTemplate')) {
            return [];
        }

        $template = new \ITILFollowupTemplate();
        $table = \ITILFollowupTemplate::getTable();
        if (!$this->tableExists($table)) {
            return [];
        }

        $criteria = [];
        if ($this->columnExists($table, 'is_active')) {
            $criteria['is_active'] = 1;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB(max(1, $ticketId))) {
            return [];
        }

        $templates = [];
        foreach ($template->find($criteria, 'name ASC', 200) as $row) {
            $templateId = (int) ($row['id'] ?? 0);
            $name = trim((string) ($row['name'] ?? ''));
            if ($templateId <= 0 || $name === '') {
                continue;
            }

            $entityId = (int) ($row['entities_id'] ?? 0);
            $recursive = (bool) ($row['is_recursive'] ?? false);
            $targetEntityId = (int) ($ticket->fields['entities_id'] ?? 0);
            if (!$this->canUseTemplateEntity($entityId, $recursive, $targetEntityId)) {
                continue;
            }

            $loaded = new \ITILFollowupTemplate();
            if (!$loaded->getFromDB($templateId)) {
                continue;
            }

            $templates[] = [
                'id' => $templateId,
                'name' => $name,
                'content' => $this->renderFollowupTemplateContentFromItem($loaded, $ticket),
                'is_private' => (int) ($loaded->fields['is_private'] ?? 0),
                'requesttypes_id' => (int) ($loaded->fields['requesttypes_id'] ?? 0),
            ];
        }

        return $templates;
    }

    public function renderFollowupTemplateContent(int $ticketId, int $templateId): string
    {
        if ($templateId <= 0 || !$this->canReadTicket($ticketId) || !class_exists('\ITILFollowupTemplate')) {
            return '';
        }

        $ticket = new \Ticket();
        $template = new \ITILFollowupTemplate();
        if (!$ticket->getFromDB(max(1, $ticketId)) || !$template->getFromDB($templateId)) {
            return '';
        }

        $entityId = (int) ($template->fields['entities_id'] ?? 0);
        $recursive = !empty($template->fields['is_recursive']);
        $targetEntityId = (int) ($ticket->fields['entities_id'] ?? 0);
        if (!$this->canUseTemplateEntity($entityId, $recursive, $targetEntityId)) {
            return '';
        }

        return $this->renderFollowupTemplateContentFromItem($template, $ticket);
    }

    private function canUseFollowupTemplateForTicket(int $ticketId, int $templateId): bool
    {
        if ($templateId <= 0 || !$this->canReadTicket($ticketId) || !class_exists('\ITILFollowupTemplate')) {
            return false;
        }

        $ticket = new \Ticket();
        $template = new \ITILFollowupTemplate();
        if (!$ticket->getFromDB(max(1, $ticketId)) || !$template->getFromDB($templateId)) {
            return false;
        }

        return $this->canUseTemplateEntity(
            (int) ($template->fields['entities_id'] ?? 0),
            !empty($template->fields['is_recursive']),
            (int) ($ticket->fields['entities_id'] ?? 0)
        );
    }

    private function renderFollowupTemplateContentFromItem(\ITILFollowupTemplate $template, \Ticket $ticket): string
    {
        if (method_exists($template, 'getRenderedContent')) {
            return (string) $template->getRenderedContent($ticket);
        }

        return (string) ($template->fields['content'] ?? '');
    }

    private function canUseTemplateEntity(int $entityId, bool $recursive, ?int $targetEntityId = null): bool
    {
        if (class_exists('\Session') && method_exists('\Session', 'haveAccessToEntity')) {
            if (!(bool) \Session::haveAccessToEntity($entityId, $recursive)) {
                return false;
            }
        } elseif (!in_array($entityId, $this->getCurrentEntities(), true)) {
            return false;
        }

        $targetEntityId = $targetEntityId ?? (int) ($_SESSION['glpiactive_entity'] ?? 0);
        if ($targetEntityId === $entityId) {
            return true;
        }
        if (!$recursive || !function_exists('getSonsOf')) {
            return false;
        }

        $descendants = array_map('intval', (array) getSonsOf('glpi_entities', $entityId));
        return in_array($targetEntityId, $descendants, true);
    }

    public function addFollowup(
        int $ticketId,
        string $content,
        array $filesPayload = [],
        int $followupTemplateId = 0
    ): int {
        if (!$this->canAddFollowupToTicket($ticketId)) {
            return 0;
        }

        $payload = [
            'itemtype' => 'Ticket',
            'items_id' => $ticketId,
            'content' => $content,
            'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
        ];

        if ($followupTemplateId > 0 && class_exists('\ITILFollowupTemplate')) {
            if (!$this->canUseFollowupTemplateForTicket($ticketId, $followupTemplateId)) {
                return 0;
            }

            $rendered = $this->renderFollowupTemplateContent($ticketId, $followupTemplateId);
            $payload['_itilfollowuptemplates_id'] = $followupTemplateId;
            if (trim($content) === '') {
                $payload['content'] = $rendered;
            }
        }

        if (trim((string) $payload['content']) === '') {
            return 0;
        }

        foreach (['_filename', '_tag_filename', '_prefix_filename'] as $key) {
            if (!empty($filesPayload[$key]) && is_array($filesPayload[$key])) {
                $payload[$key] = array_values($filesPayload[$key]);
            }
        }

        $followup = new \ITILFollowup();
        return (int) $followup->add($payload);
    }

    public function addTask(int $ticketId, string $content, array $taskInput = [], array $filesPayload = []): int
    {
        if (!$this->canAddTaskToTicket($ticketId)) {
            return 0;
        }

        $currentUserId = (int) ($_SESSION['glpiID'] ?? 0);
        $payload = [
            'tickets_id' => $ticketId,
            'content' => $content,
            'users_id_tech' => max(0, (int) ($taskInput['users_id_tech'] ?? $currentUserId)),
            'state' => max(1, (int) ($taskInput['state'] ?? $this->getDefaultTaskState())),
            'actiontime' => max(0, (int) ($taskInput['actiontime'] ?? 0)),
        ];

        if ($this->columnExists('glpi_tickettasks', 'users_id')) {
            $payload['users_id'] = $currentUserId;
        }
        if ($this->columnExists('glpi_tickettasks', 'groups_id_tech')) {
            $payload['groups_id_tech'] = max(0, (int) ($taskInput['groups_id_tech'] ?? 0));
        }
        if ($this->columnExists('glpi_tickettasks', 'taskcategories_id')) {
            $payload['taskcategories_id'] = max(0, (int) ($taskInput['taskcategories_id'] ?? 0));
        }
        if ($this->columnExists('glpi_tickettasks', 'is_private')) {
            $payload['is_private'] = !empty($taskInput['is_private']) ? 1 : 0;
        }

        $begin = $this->normalizeDateTime((string) ($taskInput['begin'] ?? ''));
        $end = $this->normalizeDateTime((string) ($taskInput['end'] ?? ''));
        if ($begin !== '' && $end === '' && $payload['actiontime'] > 0) {
            $end = date('Y-m-d H:i:s', strtotime($begin) + (int) $payload['actiontime']);
        }
        if ($begin !== '' && $this->columnExists('glpi_tickettasks', 'begin')) {
            $payload['begin'] = $begin;
        }
        if ($end !== '' && $this->columnExists('glpi_tickettasks', 'end')) {
            $payload['end'] = $end;
        }

        foreach (['_filename', '_tag_filename', '_prefix_filename'] as $key) {
            if (!empty($filesPayload[$key]) && is_array($filesPayload[$key])) {
                $payload[$key] = array_values($filesPayload[$key]);
            }
        }

        $task = new \TicketTask();
        return (int) $task->add($payload);
    }

    public function addSolution(int $ticketId, string $content): bool
    {
        if (!$this->canAddSolutionToTicket($ticketId)) {
            return false;
        }

        $solution = new \ITILSolution();
        $ok = (bool) $solution->add([
            'itemtype' => 'Ticket',
            'items_id' => $ticketId,
            'content' => $content,
            'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
        ]);

        if (!$ok) {
            return false;
        }

        $ticket = new \Ticket();
        if ($this->canChangeStatusToTicket($ticketId) && $ticket->getFromDB($ticketId)) {
            return (bool) $ticket->update([
                'id' => $ticketId,
                'status' => $this->solvedStatus(),
            ]);
        }

        return true;
    }

    public function approveSolution(int $ticketId, string $comment = '', array $filesPayload = []): bool
    {
        $this->markLatestSolution($ticketId, $this->acceptedSolutionStatus());

        if (trim($comment) !== '') {
            $this->addFollowup($ticketId, $comment, $filesPayload, 0);
        }

        return $this->updateTicketStatus($ticketId, $this->closedStatus());
    }

    public function refuseSolution(int $ticketId, string $comment, array $filesPayload = []): bool
    {
        $this->markLatestSolution($ticketId, $this->refusedSolutionStatus());
        $this->addFollowup($ticketId, 'Solucao recusada: ' . trim($comment), $filesPayload, 0);

        return $this->updateTicketStatus($ticketId, $this->assignedStatus());
    }

    public function changeStatus(int $ticketId, int $status): bool
    {
        return $this->updateTicketStatus($ticketId, $status, true);
    }

    private function updateTicketStatus(int $ticketId, int $status, bool $requireUpdateRight = false): bool
    {
        $ticket = new \Ticket();
        if (!$ticket->getFromDB(max(1, $ticketId)) || !$ticket->canViewItem()) {
            return false;
        }
        if ($requireUpdateRight && !$this->canChangeStatusToTicket($ticketId)) {
            return false;
        }

        $payload = [
            'id' => $ticketId,
            'status' => $status,
        ];
        if (method_exists($ticket, 'enforceReadonlyFields')) {
            $payload = $ticket->enforceReadonlyFields($payload);
        }

        return (bool) $ticket->update($payload);
    }

    private function markLatestSolution(int $ticketId, int $status): void
    {
        if (!class_exists('\ITILSolution')) {
            return;
        }

        $solution = new \ITILSolution();
        $rows = $solution->find(
            [
                'itemtype' => 'Ticket',
                'items_id' => max(1, $ticketId),
            ],
            'id DESC',
            1
        );
        $row = is_array($rows) ? reset($rows) : false;
        $solutionId = is_array($row) ? (int) ($row['id'] ?? 0) : 0;
        if ($solutionId <= 0) {
            return;
        }

        $payload = [
            'id' => $solutionId,
            'status' => $status,
            'users_id_approval' => (int) ($_SESSION['glpiID'] ?? 0),
            'date_approval' => date('Y-m-d H:i:s'),
        ];

        $solution->update($payload);
    }

    private function solvedStatus(): int
    {
        return defined('\CommonITILObject::SOLVED') ? (int) \CommonITILObject::SOLVED : 5;
    }

    private function closedStatus(): int
    {
        return defined('\CommonITILObject::CLOSED') ? (int) \CommonITILObject::CLOSED : 6;
    }

    private function assignedStatus(): int
    {
        return defined('\CommonITILObject::ASSIGNED') ? (int) \CommonITILObject::ASSIGNED : 2;
    }

    private function acceptedSolutionStatus(): int
    {
        return defined('\ITILSolution::ACCEPTED') ? (int) \ITILSolution::ACCEPTED : 3;
    }

    private function refusedSolutionStatus(): int
    {
        return defined('\ITILSolution::REFUSED') ? (int) \ITILSolution::REFUSED : 4;
    }

    public function updateTicketFields(int $ticketId, array $fields): bool
    {
        $ticketId = max(1, $ticketId);
        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId) || !$ticket->canViewItem()) {
            return false;
        }

        $routingFields = ['_users_id_assign', '_users_id_observer', '_groups_id_assign'];
        $containsRoutingFields = false;
        foreach ($routingFields as $routingField) {
            if (array_key_exists($routingField, $fields)) {
                $containsRoutingFields = true;
                break;
            }
        }
        if ($containsRoutingFields) {
            if (!$this->canRouteTicket($ticketId)) {
                return false;
            }
        } elseif (!\Ticket::canUpdate()) {
            return false;
        }

        $payload = ['id' => $ticketId];

        if (isset($fields['urgency'])) {
            $payload['urgency'] = max(1, min(5, (int) $fields['urgency']));
        }
        if (isset($fields['impact'])) {
            $payload['impact'] = max(1, min(5, (int) $fields['impact']));
        }
        if (isset($fields['type'])) {
            $payload['type'] = max(1, (int) $fields['type']);
        }
        if (isset($fields['itilcategories_id'])) {
            $payload['itilcategories_id'] = max(0, (int) $fields['itilcategories_id']);
        }
        if (isset($fields['_users_id_assign']) && is_array($fields['_users_id_assign'])) {
            $payload['_users_id_assign'] = array_values(array_map('intval', $fields['_users_id_assign']));
        }
        if (isset($fields['_users_id_observer']) && is_array($fields['_users_id_observer'])) {
            $payload['_users_id_observer'] = array_values(array_map('intval', $fields['_users_id_observer']));
        }
        if (isset($fields['_groups_id_assign']) && is_array($fields['_groups_id_assign'])) {
            $payload['_groups_id_assign'] = array_values(array_map('intval', $fields['_groups_id_assign']));
        }

        if (count($payload) === 1) {
            return true;
        }

        if (method_exists($ticket, 'enforceReadonlyFields')) {
            $payload = $ticket->enforceReadonlyFields($payload);
        }

        return (bool) $ticket->update($payload);
    }

    public function canReadTicket(int $ticketId): bool
    {
        $ticket = new \Ticket();
        return $ticket->can(max(1, $ticketId), READ);
    }

    public function canUpdateTicket(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        $ticket = new \Ticket();
        try {
            if (method_exists($ticket, 'can')) {
                return (bool) $ticket->can($ticketId, UPDATE);
            }

            return $ticket->getFromDB($ticketId)
                && $ticket->canViewItem()
                && \Ticket::canUpdate();
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function canRouteTicket(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return false;
        }

        $ticket = new \Ticket();
        try {
            if (!$ticket->getFromDB($ticketId) || !$ticket->canViewItem()) {
                return false;
            }
            if (method_exists($ticket, 'canAssign')) {
                return defined('\Ticket::ASSIGN')
                    ? (((int) ($_SESSION['glpiactiveprofile']['ticket'] ?? 0) & (int) \Ticket::ASSIGN) === (int) \Ticket::ASSIGN)
                    : false;
            }
            if (class_exists('\Session') && method_exists('\Session', 'haveRight')) {
                if (defined('\Ticket::ASSIGN')) {
                    return (bool) \Session::haveRight('ticket', \Ticket::ASSIGN);
                }
                if (defined('\CommonITILObject::ASSIGN')) {
                    return (bool) \Session::haveRight('ticket', \CommonITILObject::ASSIGN);
                }
            }
        } catch (\Throwable $e) {
            return false;
        }

        return false;
    }

    public function canAddFollowupToTicket(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId) || !class_exists('\ITILFollowup')) {
            return false;
        }

        try {
            $followup = new \ITILFollowup();
            $input = [
                'itemtype' => 'Ticket',
                'items_id' => $ticketId,
                'content' => 'Verificacao de permissao',
                'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
            ];
            $followup->input = $input;
            $followup->fields = $input;

            if (method_exists($followup, 'can')) {
                return (bool) $followup->can(-1, CREATE, $input);
            }
            if (method_exists($followup, 'canCreateItem')) {
                return (bool) $followup->canCreateItem();
            }
        } catch (\Throwable $e) {
            return false;
        }

        return class_exists('\Session')
            && method_exists('\Session', 'haveRight')
            && defined('CREATE')
            && (bool) \Session::haveRight('followup', CREATE);
    }

    public function canAddTaskToTicket(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId) || !class_exists('\TicketTask')) {
            return false;
        }

        try {
            $task = new \TicketTask();
            $input = [
                'tickets_id' => $ticketId,
                'content' => 'Verificacao de permissao',
                'users_id_tech' => (int) ($_SESSION['glpiID'] ?? 0),
            ];
            $task->input = $input;
            $task->fields = $input;

            if (method_exists($task, 'can')) {
                return (bool) $task->can(-1, CREATE, $input);
            }
            if (method_exists($task, 'canCreateItem')) {
                return (bool) $task->canCreateItem();
            }
        } catch (\Throwable $e) {
            return false;
        }

        return $this->canUpdateTicket($ticketId);
    }

    public function canAddSolutionToTicket(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId) || !class_exists('\ITILSolution')) {
            return false;
        }

        try {
            $solution = new \ITILSolution();
            $input = [
                'itemtype' => 'Ticket',
                'items_id' => $ticketId,
                'content' => 'Verificacao de permissao',
                'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
            ];
            $solution->input = $input;
            $solution->fields = $input;

            if (method_exists($solution, 'can')) {
                return (bool) $solution->can(-1, CREATE, $input);
            }
            if (method_exists($solution, 'canCreateItem')) {
                return (bool) $solution->canCreateItem();
            }
        } catch (\Throwable $e) {
            return false;
        }

        return $this->canUpdateTicket($ticketId);
    }

    public function canChangeStatusToTicket(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canUpdateTicket($ticketId)) {
            return false;
        }

        if (!class_exists('\Ticket') || !method_exists('\Ticket', 'canUpdate') || !\Ticket::canUpdate()) {
            return false;
        }

        return $this->getAllowedStatusTransitions($ticketId) !== [];
    }

    /**
     * Return only transitions accepted by the native GLPI status matrix.
     *
     * @return int[]
     */
    public function getAllowedStatusTransitions(int $ticketId): array
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return [];
        }

        $ticket = new \Ticket();
        try {
            if (!$ticket->getFromDB($ticketId)) {
                return [];
            }
            $currentStatus = (int) ($ticket->fields['status'] ?? 0);
            if ($currentStatus <= 0 || !class_exists('\Ticket') || !method_exists('\Ticket', 'getAllowedStatusArray')) {
                return [];
            }

            $allowed = (array) \Ticket::getAllowedStatusArray($currentStatus);
            $transitions = [];
            foreach ($allowed as $key => $value) {
                $candidate = is_int($key) || ctype_digit((string) $key) ? (int) $key : (int) $value;
                if ($candidate > 0 && $candidate !== $currentStatus) {
                    $transitions[] = $candidate;
                }
            }

            return array_values(array_unique($transitions));
        } catch (\Throwable $e) {
            return [];
        }
    }

    public function isStatusTransitionAllowed(int $ticketId, int $newStatus): bool
    {
        $ticketId = max(1, $ticketId);
        $newStatus = (int) $newStatus;
        if ($newStatus <= 0 || !$this->canChangeStatusToTicket($ticketId)) {
            return false;
        }

        return in_array($newStatus, $this->getAllowedStatusTransitions($ticketId), true);
    }

    /**
     * @return array<int, array{id:int,name:string}>
     */
    private function getTicketAssignedGroups(int $ticketId): array
    {
        if (!class_exists('\Group_Ticket')) {
            return [];
        }

        $ticketId = max(1, $ticketId);
        $groups = [];
        $groupTicket = new \Group_Ticket();
        foreach ($groupTicket->find(['tickets_id' => $ticketId, 'type' => 2]) as $row) {
            $groupId = (int) ($row['groups_id'] ?? 0);
            if ($groupId > 0) {
                $groups[] = [
                    'id' => $groupId,
                    'name' => $this->resolveGroupName($groupId),
                ];
            }
        }

        usort($groups, static fn(array $left, array $right): int => strcasecmp((string) ($left['name'] ?? ''), (string) ($right['name'] ?? '')));

        return $groups;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function getTicketCreationFieldRequirements(): array
    {
        $fields = [];
        foreach (TicketCreationPolicy::SUPPORTED_CREATE_FIELDS as $field) {
            $fields[$field] = [
                'label' => TicketCreationPolicy::fieldLabel($field),
                'required' => in_array($field, ['name', 'content', 'type', 'urgency', 'impact'], true),
                'visible' => true,
                'readonly' => false,
                'source' => 'portal_default',
            ];
        }

        return $fields;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function getTicketTemplates(): array
    {
        if (!class_exists('\TicketTemplate')) {
            return [];
        }

        $template = new \TicketTemplate();
        $table = method_exists('\TicketTemplate', 'getTable') ? (string) \TicketTemplate::getTable() : 'glpi_tickettemplates';
        if (!$this->tableExists($table)) {
            return [];
        }

        $criteria = [];
        if ($this->columnExists($table, 'is_active')) {
            $criteria['is_active'] = 1;
        }

        $templates = [];
        foreach ($template->find($criteria, 'name ASC', 80) as $row) {
            $id = (int) ($row['id'] ?? 0);
            $name = trim((string) ($row['name'] ?? ''));
            if ($id <= 0 || $name === '') {
                continue;
            }
            $entityId = (int) ($row['entities_id'] ?? 0);
            $recursive = (bool) ($row['is_recursive'] ?? false);
            if (!$this->canUseTemplateEntity($entityId, $recursive)) {
                continue;
            }

            $metadata = $this->getTicketTemplateMetadata($id);
            if ($metadata !== null) {
                $templates[] = $metadata;
            }
        }

        return $templates;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getTicketTemplateMetadata(int $templateId): ?array
    {
        if ($templateId <= 0 || !class_exists('\TicketTemplate')) {
            return null;
        }

        try {
            $template = new \TicketTemplate();
            $loaded = method_exists($template, 'getFromDBWithData')
                ? $template->getFromDBWithData($templateId)
                : $template->getFromDB($templateId);
            if (!$loaded) {
                return null;
            }

            $entityId = (int) ($template->fields['entities_id'] ?? 0);
            $recursive = !empty($template->fields['is_recursive']);
            if (!$this->canUseTemplateEntity($entityId, $recursive)) {
                return null;
            }

            $mandatory = $this->normalizeTicketTemplateFieldList($template->mandatory ?? []);
            $hidden = $this->normalizeTicketTemplateFieldList($template->hidden ?? []);
            $readonly = $this->normalizeTicketTemplateFieldList($template->readonly ?? []);
            $predefined = $this->normalizeTicketTemplatePredefinedFields((array) ($template->predefined ?? []));
            $policy = new TicketCreationPolicy();
            $unsupportedRequired = $policy->unsupportedMandatoryFields($mandatory);
            $fieldRequirements = [];
            foreach ($mandatory as $field) {
                $fieldRequirements[$field] = [
                    'label' => TicketCreationPolicy::fieldLabel($field),
                    'required' => true,
                    'visible' => !in_array($field, $hidden, true),
                    'readonly' => in_array($field, $readonly, true),
                    'source' => 'ticket_template',
                ];
            }

            $supportedPredefined = [];
            $supported = array_fill_keys(TicketCreationPolicy::SUPPORTED_CREATE_FIELDS, true);
            foreach ($predefined as $field => $value) {
                if (isset($supported[(string) $field])) {
                    $supportedPredefined[(string) $field] = $value;
                }
            }

            return [
                'id' => $templateId,
                'label' => TextNormalizer::fromGlpi((string) ($template->fields['name'] ?? ('Modelo #' . $templateId))),
                'field_requirements' => $fieldRequirements,
                'mandatory_fields' => $mandatory,
                'hidden_fields' => $hidden,
                'readonly_fields' => $readonly,
                'predefined' => $supportedPredefined,
                'unsupported_required' => $unsupportedRequired,
                'requires_native_fallback' => $unsupportedRequired !== [],
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * @return string[]
     */
    private function normalizeTicketTemplateFieldList(mixed $fields): array
    {
        if (!is_array($fields)) {
            return [];
        }

        $normalized = [];
        foreach ($fields as $key => $value) {
            $field = '';
            if (is_string($key) && !ctype_digit($key)) {
                $field = $key;
            } elseif (is_array($value)) {
                foreach (['field', 'name', 'num'] as $candidateKey) {
                    if (isset($value[$candidateKey]) && is_scalar($value[$candidateKey])) {
                        $field = $this->resolveTicketTemplateFieldName($value[$candidateKey]);
                        break;
                    }
                }
            } elseif (is_scalar($value)) {
                $field = $this->resolveTicketTemplateFieldName($value);
            }

            $field = trim($field);
            if ($field !== '') {
                $normalized[$field] = $field;
            }
        }

        return array_values($normalized);
    }

    /**
     * @param array<string|int, mixed> $predefined
     * @return array<string, mixed>
     */
    private function normalizeTicketTemplatePredefinedFields(array $predefined): array
    {
        $normalized = [];
        foreach ($predefined as $field => $value) {
            $resolved = $this->resolveTicketTemplateFieldName($field);
            if ($resolved === '') {
                continue;
            }
            $normalized[$resolved] = $value;
        }

        return $normalized;
    }

    private function resolveTicketTemplateFieldName(mixed $field): string
    {
        if (!is_scalar($field)) {
            return '';
        }

        $field = trim((string) $field);
        if ($field === '') {
            return '';
        }

        if (ctype_digit($field)) {
            $resolved = $this->ticketSearchOptionToCreateField((int) $field);
            return $resolved !== '' ? $resolved : 'search_option_' . $field;
        }

        return $field;
    }

    private function ticketSearchOptionToCreateField(int $optionNumber): string
    {
        if ($optionNumber <= 0 || !class_exists('\Search') || !class_exists('\Ticket') || !method_exists('\Search', 'getOptions')) {
            return '';
        }

        $supported = array_fill_keys(TicketCreationPolicy::SUPPORTED_CREATE_FIELDS, true);
        $tableMap = [
            'glpi_itilcategories' => 'itilcategories_id',
            'glpi_locations' => 'locations_id',
            'glpi_requesttypes' => 'requesttypes_id',
            'glpi_groups' => '_groups_id_assign',
            'glpi_users' => '_users_id_assign',
        ];

        $options = (array) \Search::getOptions(\Ticket::class);
        $option = is_array($options[$optionNumber] ?? null) ? $options[$optionNumber] : null;
        if ($option === null) {
            return '';
        }

        foreach (['linkfield', 'field'] as $key) {
            $candidate = trim((string) ($option[$key] ?? ''));
            if ($candidate !== '' && isset($supported[$candidate])) {
                return $candidate;
            }
        }

        $table = trim((string) ($option['table'] ?? ''));
        if ($table !== '' && isset($tableMap[$table])) {
            return $tableMap[$table];
        }

        return '';
    }

    /**
     * @return array<string, mixed>
     */
    private function getServiceCatalogContext(): array
    {
        global $CFG_GLPI;

        $available = class_exists('\Glpi\Form\ServiceCatalog\ServiceCatalog')
            || class_exists('\Glpi\Controller\ServiceCatalog\IndexController');
        $enabled = false;
        $entityId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        if ($available && class_exists('\Entity') && $entityId >= 0) {
            try {
                $entity = new \Entity();
                if ($entity->getFromDB($entityId) && method_exists($entity, 'isServiceCatalogEnabled')) {
                    $enabled = (bool) $entity->isServiceCatalogEnabled();
                }
            } catch (\Throwable $e) {
                $enabled = false;
            }
        }

        return [
            'available' => $available,
            'enabled' => $enabled,
            'url' => (string) ($CFG_GLPI['root_doc'] ?? '') . '/ServiceCatalog',
            'message' => $available
                ? 'O GLPI 11 possui Catalogo de Servicos. Use o fluxo nativo quando a solicitacao exigir formulario dinamico ainda nao representado aqui.'
                : 'Catalogo de Servicos nao disponivel nesta versao/instalacao do GLPI.',
        ];
    }

    /**
     * @return array<int, string>
     */
    private function getTicketCreatePortalLimitations(): array
    {
        return [
            'Campos dinamicos de catalogo GLPI 11 ainda usam fallback para o fluxo nativo.',
            'Modelos ITIL com campos obrigatorios fora do formulario acessivel sao bloqueados e encaminhados ao GLPI nativo.',
        ];
    }

    public function createTicket(array $input): int
    {
        $ticket = new \Ticket();

        if (!$ticket::canCreate()) {
            throw new \RuntimeException('Usuario sem permissao para criar chamado.');
        }

        $payload = [
            'name' => (string) ($input['name'] ?? ''),
            'content' => (string) ($input['content'] ?? ''),
            'type' => (int) ($input['type'] ?? $this->getDefaultTicketType()),
            'itilcategories_id' => max(0, (int) ($input['itilcategories_id'] ?? 0)),
            'locations_id' => max(0, (int) ($input['locations_id'] ?? 0)),
            'urgency' => (int) ($input['urgency'] ?? 3),
            'impact' => (int) ($input['impact'] ?? 3),
            'entities_id' => $this->getConcreteActiveEntityId(),
            '_users_id_requester' => [(int) ($_SESSION['glpiID'] ?? 0)],
        ];

        if (!empty($input['_users_id_assign']) && is_array($input['_users_id_assign'])) {
            $payload['_users_id_assign'] = array_values(array_map('intval', $input['_users_id_assign']));
        }
        if (!empty($input['_users_id_observer']) && is_array($input['_users_id_observer'])) {
            $payload['_users_id_observer'] = array_values(array_map('intval', $input['_users_id_observer']));
        }
        if (!empty($input['_groups_id_assign']) && is_array($input['_groups_id_assign'])) {
            $payload['_groups_id_assign'] = array_values(array_map('intval', $input['_groups_id_assign']));
        }
        if (!empty($input['requesttypes_id']) && $this->ticketSupportsRequestSource()) {
            $payload['requesttypes_id'] = (int) $input['requesttypes_id'];
        }
        if (isset($input['externalid']) && trim((string) $input['externalid']) !== '' && $this->ticketSupportsExternalId()) {
            $payload['externalid'] = trim((string) $input['externalid']);
        }
        if (!empty($input['tickettemplates_id']) && class_exists('\TicketTemplate')) {
            $templateId = (int) $input['tickettemplates_id'];
            if ($this->getTicketTemplateMetadata($templateId) === null) {
                throw new \RuntimeException('Modelo de chamado invalido para a entidade ativa.');
            }

            $templateField = method_exists('\TicketTemplate', 'getForeignKeyField') ? \TicketTemplate::getForeignKeyField() : 'tickettemplates_id';
            $payload[$templateField] = $templateId;
        }
        $filePayload = [];
        foreach (['_filename', '_tag_filename', '_prefix_filename'] as $key) {
            if (!empty($input[$key]) && is_array($input[$key])) {
                $filePayload[$key] = array_values($input[$key]);
                $payload[$key] = $filePayload[$key];
            }
        }

        if (method_exists($ticket, 'check')) {
            $ticket->check(-1, CREATE, $payload);
        }

        if (method_exists($ticket, 'enforceReadonlyFields')) {
            $payload = $ticket->enforceReadonlyFields($payload, true);
            foreach ($filePayload as $key => $value) {
                $payload[$key] = $value;
            }
        }

        $newId = $ticket->add($payload);
        if (!$newId) {
            throw new \RuntimeException('Nao foi possivel registrar o chamado no GLPI.');
        }

        return (int) $newId;
    }

    /**
     * @return int[]
     */
    private function getCurrentEntities(): array
    {
        $activeEntities = $_SESSION['glpiactiveentities'] ?? null;
        if (is_array($activeEntities)) {
            $entities = [];
            foreach ($activeEntities as $key => $value) {
                $candidate = is_int($value) || ctype_digit((string) $value) ? (int) $value : (is_int($key) || ctype_digit((string) $key) ? (int) $key : 0);
                if ($candidate >= 0) {
                    $entities[$candidate] = $candidate;
                }
            }
            if ($entities !== []) {
                return array_values($entities);
            }
        } elseif (is_string($activeEntities) && trim($activeEntities) !== '') {
            $entities = array_values(array_unique(array_filter(array_map('intval', preg_split('/[;,]/', $activeEntities) ?: []))));
            if ($entities !== []) {
                return $entities;
            }
        }

        $activeEntity = $this->getConcreteActiveEntityId();
        $recursive = !empty($_SESSION['glpiactive_entity_recursive']);
        if ($recursive && function_exists('getSonsOf')) {
            $entities = array_map('intval', (array) getSonsOf('glpi_entities', $activeEntity));
            if ($entities !== []) {
                return array_values(array_unique($entities));
            }
        }

        return [$activeEntity];
    }

    private function getConcreteActiveEntityId(): int
    {
        $entityId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        if (class_exists('\Session') && method_exists('\Session', 'haveAccessToEntity')) {
            if (!(bool) \Session::haveAccessToEntity($entityId, false)) {
                throw new \RuntimeException('Selecione uma entidade concreta permitida antes de criar ou consultar chamados.');
            }
        }

        if (class_exists('\Entity')) {
            $entity = new \Entity();
            if (!$entity->getFromDB($entityId)) {
                throw new \RuntimeException('A entidade ativa nao existe ou nao esta disponivel neste contexto.');
            }
        }

        return $entityId;
    }

    private function getEntityName(int $entityId): string
    {
        if (class_exists('\Entity')) {
            $entity = new \Entity();
            if ($entity->getFromDB($entityId)) {
                return TextNormalizer::fromGlpi((string) ($entity->fields['completename'] ?? $entity->fields['name'] ?? ('Entidade ' . $entityId)));
            }
        }

        return 'Entidade ' . $entityId;
    }

    private function getCurrentUserName(): string
    {
        $userId = (int) ($_SESSION['glpiID'] ?? 0);
        if ($userId <= 0 || !class_exists('\User')) {
            return (string) ($_SESSION['glpiname'] ?? 'Usuario atual');
        }

        $user = new \User();
        if (!$user->getFromDB($userId)) {
            return (string) ($_SESSION['glpiname'] ?? 'Usuario atual');
        }

        $parts = array_filter([
            trim((string) ($user->fields['firstname'] ?? '')),
            trim((string) ($user->fields['realname'] ?? '')),
        ]);

        if ($parts !== []) {
            return implode(' ', $parts);
        }

        return (string) ($user->fields['name'] ?? $_SESSION['glpiname'] ?? 'Usuario atual');
    }

    private function getTicketTypeOptions(): array
    {
        return [
            ['id' => $this->getIncidentTicketType(), 'label' => 'Incidente'],
            ['id' => $this->getDemandTicketType(), 'label' => 'Requisicao'],
        ];
    }

    private function getUrgencyOptions(): array
    {
        return [
            ['id' => 1, 'label' => 'Muito baixa'],
            ['id' => 2, 'label' => 'Baixa'],
            ['id' => 3, 'label' => 'Media'],
            ['id' => 4, 'label' => 'Alta'],
            ['id' => 5, 'label' => 'Muito alta'],
        ];
    }

    private function getImpactOptions(): array
    {
        return [
            ['id' => 1, 'label' => 'Muito baixo'],
            ['id' => 2, 'label' => 'Baixo'],
            ['id' => 3, 'label' => 'Medio'],
            ['id' => 4, 'label' => 'Alto'],
            ['id' => 5, 'label' => 'Muito alto'],
        ];
    }

    private function nativeDropdownCriteria(string $table): array
    {
        $criteria = [];
        if ($this->columnExists($table, 'is_deleted')) {
            $criteria['is_deleted'] = 0;
        }

        return $criteria;
    }

    private function dropdownVisibleInCurrentEntity(array $row): bool
    {
        if (!isset($row['entities_id'])) {
            return true;
        }

        $entityId = (int) ($row['entities_id'] ?? 0);
        if (in_array($entityId, $this->getCurrentEntities(), true)) {
            return true;
        }

        return !empty($row['is_recursive']);
    }

    /**
     * @return array<int, array{id:int,label:string}>
     */
    public function getTaskCategories(): array
    {
        if (!class_exists('\TaskCategory') || !$this->tableExists('glpi_taskcategories')) {
            return [];
        }

        $category = new \TaskCategory();
        $criteria = $this->nativeDropdownCriteria('glpi_taskcategories');
        $rows = [];
        foreach ($category->find($criteria, 'completename ASC, name ASC') as $row) {
            if (!$this->dropdownVisibleInCurrentEntity($row)) {
                continue;
            }

            $id = (int) ($row['id'] ?? 0);
            $label = TextNormalizer::fromGlpi((string) ($row['completename'] ?? $row['name'] ?? ''));
            if ($id > 0 && $label !== '') {
                $rows[] = ['id' => $id, 'label' => $label];
            }
        }

        return $rows;
    }

    /**
     * @return array<int, array{id:int,label:string}>
     */
    public function getTaskStateOptions(): array
    {
        $states = [];
        $candidates = [
            'INFO' => 'Informacao',
            'TODO' => 'A fazer',
            'DONE' => 'Feita',
        ];

        if (class_exists('\Planning')) {
            foreach ($candidates as $constant => $fallback) {
                $constantName = \Planning::class . '::' . $constant;
                if (!defined($constantName)) {
                    continue;
                }

                $value = (int) constant($constantName);
                $label = $fallback;
                if (method_exists('\Planning', 'getState')) {
                    $nativeLabel = trim((string) \Planning::getState($value));
                    if ($nativeLabel !== '') {
                        $label = $nativeLabel;
                    }
                }
                $states[] = ['id' => $value, 'label' => $label];
            }
        }

        return $states !== []
            ? $states
            : [
                ['id' => 1, 'label' => 'Informacao'],
                ['id' => 2, 'label' => 'A fazer'],
                ['id' => 3, 'label' => 'Feita'],
            ];
    }

    /**
     * @return array<int, array{id:int,label:string}>
     */
    public function getTaskDurationOptions(): array
    {
        return [
            ['id' => 0, 'label' => 'Nao informar'],
            ['id' => 900, 'label' => '15 minutos'],
            ['id' => 1800, 'label' => '30 minutos'],
            ['id' => 3600, 'label' => '1 hora'],
            ['id' => 7200, 'label' => '2 horas'],
            ['id' => 14400, 'label' => '4 horas'],
            ['id' => 28800, 'label' => '8 horas'],
        ];
    }

    private function getDefaultTaskState(): int
    {
        return defined(\Planning::class . '::TODO') ? (int) \Planning::TODO : 2;
    }

    private function normalizeDateTime(string $value): string
    {
        $value = trim(str_replace('T', ' ', $value));
        if ($value === '') {
            return '';
        }

        $timestamp = strtotime($value);
        if ($timestamp === false) {
            return '';
        }

        return date('Y-m-d H:i:s', $timestamp);
    }

    private function getTicketCategories(): array
    {
        if (!class_exists('\ITILCategory')) {
            return [];
        }

        $category = new \ITILCategory();
        $criteria = $this->nativeDropdownCriteria('glpi_itilcategories');
        $rows = [];
        foreach ($category->find($criteria, 'completename ASC') as $row) {
            if (!$this->dropdownVisibleInCurrentEntity($row)) {
                continue;
            }

            $rows[] = [
                'id' => (int) ($row['id'] ?? 0),
                'label' => TextNormalizer::fromGlpi((string) ($row['completename'] ?? $row['name'] ?? '')),
                'is_incident' => !isset($row['is_incident']) || (int) $row['is_incident'] === 1,
                'is_request' => !isset($row['is_request']) || (int) $row['is_request'] === 1,
            ];
        }

        return $rows;
    }

    private function getTicketLocations(): array
    {
        if (!class_exists('\Location')) {
            return [];
        }

        $location = new \Location();
        $criteria = $this->nativeDropdownCriteria('glpi_locations');
        $rows = [];
        foreach ($location->find($criteria, 'completename ASC') as $row) {
            if (!$this->dropdownVisibleInCurrentEntity($row)) {
                continue;
            }

            $rows[] = [
                'id' => (int) ($row['id'] ?? 0),
                'label' => TextNormalizer::fromGlpi((string) ($row['completename'] ?? $row['name'] ?? '')),
            ];
        }

        return $rows;
    }

    private function resolveTicketCategoryName(int $categoryId): string
    {
        if ($categoryId <= 0) {
            return 'Nao informado';
        }

        if (class_exists('\Dropdown') && method_exists('\Dropdown', 'getDropdownName')) {
            $label = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName('glpi_itilcategories', $categoryId));
            if ($label !== '') {
                return $label;
            }
        }

        return 'Categoria ' . $categoryId;
    }

    private function resolveTicketLocationName(int $locationId): string
    {
        if ($locationId <= 0) {
            return 'Nao informado';
        }

        if (class_exists('\Dropdown') && method_exists('\Dropdown', 'getDropdownName')) {
            $label = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName('glpi_locations', $locationId));
            if ($label !== '') {
                return $label;
            }
        }

        return 'Localizacao ' . $locationId;
    }

    private function getIncidentTicketType(): int
    {
        return defined(\Ticket::class . '::INCIDENT_TYPE') ? (int) \Ticket::INCIDENT_TYPE : 1;
    }

    private function getDemandTicketType(): int
    {
        return defined(\Ticket::class . '::DEMAND_TYPE') ? (int) \Ticket::DEMAND_TYPE : 2;
    }

    private function getDefaultTicketType(): int
    {
        return $this->getIncidentTicketType();
    }

    private function getAssignableUsers(): array
    {
        if (!class_exists('\User')) {
            return [];
        }

        $user = new \User();
        $criteria = [];
        if ($this->columnExists('glpi_users', 'is_deleted')) {
            $criteria['is_deleted'] = 0;
        }
        if ($this->columnExists('glpi_users', 'is_active')) {
            $criteria['is_active'] = 1;
        }

        $rows = [];
        foreach ($user->find($criteria, 'realname ASC, firstname ASC, name ASC', 250) as $row) {
            $id = (int) ($row['id'] ?? 0);
            if ($id <= 0) {
                continue;
            }
            if (method_exists($user, 'can') && !$user->can($id, READ)) {
                continue;
            }

            $rows[] = [
                'id' => $id,
                'label' => $this->formatUserName($row, $id),
            ];
        }

        return $rows;
    }

    private function getAssignableGroups(): array
    {
        if (!class_exists('\Group')) {
            return [];
        }

        $group = new \Group();
        $criteria = [];
        if ($this->columnExists('glpi_groups', 'is_deleted')) {
            $criteria['is_deleted'] = 0;
        }
        if ($this->columnExists('glpi_groups', 'is_active')) {
            $criteria['is_active'] = 1;
        }

        $rows = [];
        foreach ($group->find($criteria, 'completename ASC', 150) as $row) {
            if (!$this->dropdownVisibleInCurrentEntity($row)) {
                continue;
            }

            $rows[] = [
                'id' => (int) ($row['id'] ?? 0),
                'label' => TextNormalizer::fromGlpi((string) ($row['completename'] ?? $row['name'] ?? '')),
            ];
        }

        return $rows;
    }

    private function getRequestSourceOptions(): array
    {
        if (class_exists('\RequestType')) {
            $requestType = new \RequestType();
            $rows = [];
            $criteria = [];
            if ($this->columnExists('glpi_requesttypes', 'is_active')) {
                $criteria['is_active'] = 1;
            }
            foreach ($requestType->find($criteria, 'name ASC') as $row) {
                $id = (int) ($row['id'] ?? 0);
                $label = trim((string) ($row['name'] ?? ''));
                if ($id > 0 && $label !== '') {
                    $rows[] = ['id' => $id, 'label' => $label];
                }
            }
            if ($rows !== []) {
                return $rows;
            }
        }

        return [
            ['id' => 1, 'label' => 'Helpdesk / Interface GLPI'],
            ['id' => 2, 'label' => 'Email'],
            ['id' => 3, 'label' => 'Telefone'],
            ['id' => 4, 'label' => 'Fax'],
            ['id' => 6, 'label' => 'Outro'],
        ];
    }

    private function getDefaultRequestSourceId(): int
    {
        return 1;
    }

    private function resolveRequestSourceLabel(int $requestSourceId): string
    {
        foreach ($this->getRequestSourceOptions() as $option) {
            if ((int) ($option['id'] ?? 0) === $requestSourceId) {
                return (string) ($option['label'] ?? 'Helpdesk / Interface GLPI');
            }
        }

        return 'Helpdesk / Interface GLPI';
    }

    private function computePriorityPreview(int $urgency, int $impact): array
    {
        $urgency = max(1, min(5, $urgency));
        $impact = max(1, min(5, $impact));
        $score = $urgency + $impact;

        $label = match (true) {
            $score <= 3 => 'Muito baixa',
            $score <= 5 => 'Baixa',
            $score <= 7 => 'Media',
            $score <= 9 => 'Alta',
            default => 'Muito alta',
        };

        return [
            'score' => $score,
            'label' => $label,
        ];
    }

    private function ticketSupportsExternalId(): bool
    {
        if (!$this->tableExists('glpi_tickets')) {
            return false;
        }

        return in_array('externalid', $this->getTableColumns('glpi_tickets'), true);
    }

    private function ticketSupportsRequestSource(): bool
    {
        if (!$this->tableExists('glpi_tickets')) {
            return false;
        }

        return in_array('requesttypes_id', $this->getTableColumns('glpi_tickets'), true);
    }
}
