# Inventario de assets de voz

Versao: 0.1.57-beta.

Politica recomendada para producao: `local_only`. O modo `local_preferred` e aceitavel em homologacao controlada. CDN externa deve ser excecao documentada, com CSP explicita e aceite de seguranca.

## Arquivos inventariados

| Arquivo | Tamanho | SHA256 | Origem/licenca | Politica |
| --- | ---: | --- | --- | --- |
| public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx | 63201294 | 858555E3A064209C57088FE6BD70C4C3DC54D03EAA00C45D5ECAF43A33F95AA7 | Modelo Piper pt-BR Faber Medium; confirmar licenca da fonte antes de piloto amplo | local_only |
| public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx.json | 4855 | 7E694DE195AE3FC36DD732C445EB04FB49B649854893CB5506B978F0D50A1D6F | Metadados do modelo Piper; mesma licenca do modelo | local_only |
| public/assets/voice/vosk/pt-BR/vosk-model-small-pt-0.3.zip | 32453112 | 6E1CE909032E1AFA7A88E68A3D628ECAFFF302BDF195BEFAB308826C395E93B7 | Modelo Vosk pt-BR small 0.3; confirmar licenca/distribuicao da fonte | local_only |
| public/assets/vendor/onnxruntime-web/1.18.0/ort.min.js | 540650 | 74C89B285A56F2EF03AEEF133E74738DA163B1C5978B490FC9C9AD6BDA23B2C1 | ONNX Runtime Web 1.18.0 | local_only |
| public/assets/vendor/onnxruntime-web/1.18.0/ort.esm.js | 540650 | 74C89B285A56F2EF03AEEF133E74738DA163B1C5978B490FC9C9AD6BDA23B2C1 | ONNX Runtime Web 1.18.0 | local_only |
| public/assets/vendor/onnxruntime-web/1.18.0/ort.min.mjs | 540650 | 74C89B285A56F2EF03AEEF133E74738DA163B1C5978B490FC9C9AD6BDA23B2C1 | ONNX Runtime Web 1.18.0 | local_only |
| public/assets/vendor/onnxruntime-web/1.18.0/ort-wasm.wasm | 9758086 | EBE7EC327F83AABC07E3B58487522481CCFF10941F24182AB0428D0123652FF2 | ONNX Runtime Web 1.18.0 | local_only |
| public/assets/vendor/onnxruntime-web/1.18.0/ort-wasm-simd.wasm | 10595041 | F533B5F21790563D7556C611C3835AC65848EE326DA2689AAC54ED7D9CC8C6A4 | ONNX Runtime Web 1.18.0 | local_only |
| public/assets/vendor/onnxruntime-web/1.18.0/ort-wasm-threaded.wasm | 9841732 | 54C445435526AF7138C6A2438B2E8103C87D4EB3E972649F2EB5FD713FADFA5C | ONNX Runtime Web 1.18.0 | local_only |
| public/assets/vendor/onnxruntime-web/1.18.0/ort-wasm-simd-threaded.wasm | 10684943 | 86E907409C5A79B7475B6CA690E404FA5C5F5714054A3926F3B0BF40559D7D2E | ONNX Runtime Web 1.18.0 | local_only |
| public/assets/vendor/piper/piper-tts-web.js | 22352 | 588C4B93C550A78EAAF6226DA4F4999E6BF21C063EF7615CFDB1046076DC9BC9 | Piper TTS Web local; fonte mantida em source zip | local_only |
| public/assets/vendor/piper/piper-o91UDS6e.js | 158217 | B5AC96981729547606FD026B8E3829AAD81E9E3C22308869D50473259C563283 | Bundle auxiliar Piper TTS Web | local_only |
| public/assets/vendor/piper/voices_static-D_OtJDHM.js | 147377 | 72CBD46FECAA067A09ED9455CA04B970D722810905D90BB2421E0911A5C4D758 | Bundle estatico de vozes Piper | local_only |
| public/assets/vendor/piper/source/piper-tts-web-main-source.zip | 101530 | EA72A001B8456ED5F60D0032FBCE456CCBDE2A024BDDA6861C374F074DCF1F6E | Fonte de referencia do bundle Piper | nao carregar em runtime |
| public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.data | 18077249 | 29F1025EB23A5B5C192CD14A6EFBCE4509402FF265405072EE6F7D1A09B78F8C | @diffusionstudio/piper-wasm 1.0.0 | local_only |
| public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.wasm | 635212 | B777CD107A91D2BCC6A1EA46F2C26A662A7407394FE84589198AEAA83DD7A9D6 | @diffusionstudio/piper-wasm 1.0.0 | local_only |
| public/assets/vendor/vosklet/Vosklet.js | 26048 | D87507343B7595D7AEBAF078A09B7BA033441B3DB2EE7A48AA892942544FE6C9 | Vosklet local; ver LICENSE no diretorio | local_only |
| public/assets/vendor/vosklet/Vosklet.wasm | 2331938 | 2A4924A15A0CE592E98A89D55165FB6548DCCF24E87A48480486F6A41259B6D7 | Vosklet local; ver LICENSE no diretorio | local_only |
| public/assets/vendor/vosklet/LICENSE | 1067 | 682A3AFDF180FF625A7EAC5994114E1FCC6EC3B69E88C252FE52D19F389C143A | Licenca do Vosklet local | documentacao |

## CSP minima esperada

- `script-src`: origem propria para JS local; CDN apenas se modo externo for aprovado.
- `connect-src`: origem propria para baixar modelos locais; dominios externos somente em `local_preferred` com aceite.
- `worker-src`: origem propria para workers WASM quando usados.
- `wasm-unsafe-eval` ou politica equivalente: validar conforme navegador/GLPI/proxy institucional.
- `media-src`: origem propria para audio sintetizado quando aplicavel.

## Pendencias antes de piloto amplo

- Confirmar licenca de redistribuicao do modelo Piper Faber e do modelo Vosk pt-BR.
- Recalcular hashes no pipeline final e comparar com este inventario.
- Validar cache, permissao de microfone, bloqueios de proxy e CSP em GLPI 10 e 11 reais.
- Garantir que voz e opcional, sem autoplay, com parar captura/fala e status em live region.
