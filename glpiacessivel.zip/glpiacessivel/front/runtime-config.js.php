<?php

$SECURITY_STRATEGY = 'no_check';

require '../../../inc/includes.php';
require_once dirname(__DIR__) . '/hook.php';

header('Content-Type: application/javascript; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$sessionStatus = (new \GlpiPlugin\Glpiacessivel\Security\SessionContextGuard())->status();

$config = [
    'accessibilityMode' => plugin_glpiacessivel_get_accessibility_mode(),
    'chatbotEnabled' => plugin_glpiacessivel_is_chatbot_enabled(),
    'portalModules' => plugin_glpiacessivel_get_portal_module_states(),
    'chatbotFloatingScope' => plugin_glpiacessivel_get_chatbot_floating_scope(),
    'isLogged' => !empty($sessionStatus['is_authenticated']),
    'sessionReady' => !empty($sessionStatus['session_ready']),
    'contextValid' => !empty($sessionStatus['context_valid']),
    'sessionIssueCode' => (string) ($sessionStatus['issue_code'] ?? 'unknown'),
    'activeProfileId' => (int) ($sessionStatus['profile_id'] ?? 0),
    'activeEntityId' => (int) ($sessionStatus['entity_id'] ?? 0),
    'locale' => \GlpiPlugin\Glpiacessivel\Support\I18n::locale(),
    'htmlLang' => \GlpiPlugin\Glpiacessivel\Support\I18n::htmlLang(),
    'fallbackLocale' => \GlpiPlugin\Glpiacessivel\Support\I18n::fallbackLocale(),
    'vlibrasScope' => function_exists('plugin_glpiacessivel_get_vlibras_scope') ? plugin_glpiacessivel_get_vlibras_scope() : 'plugin_pages',
    'vlibrasEnabled' => function_exists('plugin_glpiacessivel_is_vlibras_enabled_for_context')
        ? plugin_glpiacessivel_is_vlibras_enabled_for_context(true, empty($sessionStatus['is_authenticated']))
        : false,
];
$i18n = \GlpiPlugin\Glpiacessivel\Support\I18n::javascriptCatalog();
?>
window.__glpiacessivelRuntimeConfig = <?= glpiacessivel_json_for_script($config) ?>;
window.__glpiacessivelRuntimeConfigLoaded = true;
window.__glpiacessivelI18n = <?= glpiacessivel_json_for_script($i18n) ?>;
window.__glpiacessivelI18nLoaded = true;
