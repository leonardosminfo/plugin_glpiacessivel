## 0.2.24-beta

- reposiciona a nota `Portal Acessivel disponivel apos o login.` imediatamente depois do botao `Entrar` no formulario nativo;
- preserva a ordem real do DOM e de leitura, sem posicionamento absoluto, alteracao de foco ou anuncio `aria-live`;
- limita o seletor ao formulario oficial que contem `#login_name` e ao submit nomeado, sem ler credenciais ou interceptar a autenticacao;
- mantem a nota na area nativa do hook quando a estrutura do login nao for reconhecida, em vez de ocultar ou aproximar silenciosamente;
- usa o hook oficial `add_javascript_anonymous_page` para carregar um ativo externo pequeno e de mesma origem, mantendo o aviso sem links, campos, botoes ou rota alternativa;
- adiciona largura fluida e quebra segura do texto apos a movimentacao para reflow e ampliacao;
- cobre estruturas equivalentes ao GLPI 10 e 11, fallback e idempotencia com testes unitarios e de navegador.

## 0.2.23-beta

- reformula o aviso pre-login como nota semantica `role="note"` com nome acessivel proprio;
- simplifica a mensagem para `Portal Acessivel disponivel apos o login.`;
- usa classes visuais nativas do GLPI para manter caixa informativa, espacamento e alinhamento mesmo quando o CSS anonimo do plugin nao e carregado;
- reduz o icone decorativo para 32 px sem alterar o logotipo usado nas demais telas;
- mantem o aviso fora da ordem de Tab, sem `aria-live`, link, botao, formulario, campo ou JavaScript;
- amplia as regressoes para semantica, rotulo, tamanho do icone, classes nativas e ausencia de anuncios intrusivos.

## 0.2.22-beta

- adiciona a preferencia `show_login_accessibility_notice`, desativada por padrao, para exibir um aviso estatico na area auxiliar do login nativo;
- mantem o aviso sem link, formulario, campo, JavaScript ou rota alternativa e evita duplicidade com `accessible_bridge`;
- registra o hook pre-login somente quando a ponte compativel ou o aviso opcional estiverem ativos;
- passa a identificar o usuario autenticado como `login — primeiro nome`, usando `glpiname` e `glpifirstname` da sessao oficial do GLPI 10/11;
- recua para somente o login quando o primeiro nome estiver vazio e deixa de usar o sobrenome no rotulo do cabecalho;
- persiste e audita a nova preferencia na tabela chave/valor existente, sem criar tabela ou alterar esquema;
- documenta a restricao de posicionamento do hook nativo e preserva a superficie de autenticacao exclusiva do GLPI em `native_only`;
- amplia testes de configuracao, HTML pre-login nao interativo e identidade de sessao.

## 0.2.21-beta

- adiciona `authentication_entry_mode` como politica unica da entrada pre-autenticacao;
- adota `native_only` como padrao seguro e redireciona acessos anonimos ao login oficial do GLPI;
- deixa de registrar e renderizar o botao pre-login quando o login unificado esta ativo;
- preserva `accessible_bridge` como compatibilidade e rollback administrativo;
- reserva `strict_authenticated_portal` para uma versao futura, sem exibi-lo ou aceita-lo antes da separacao real das rotas;
- registra alteracoes de modo na auditoria sem dados sensiveis e inclui o estado no diagnostico operacional;
- mantem o atalho autenticado do portal separado da politica de login e preserva GLPI 10 e 11;
- consolida o gate em 368 testes PHPUnit e 2.052 assercoes, PHPStan aprovado, PHPCS em 169 de 169 arquivos, 3 de 3 testes de navegador e 560 mensagens i18n;

## 0.2.20-beta

- separa grupos tecnicos e grupos observadores na criacao e no roteamento de chamados;
- filtra os grupos por `is_assign` ou `is_watcher`, estado ativo, exclusao e entidade real do chamado;
- rejeita grupos recursivos de ramos alheios e revalida no servidor todos os IDs enviados;
- substitui grupos com o contrato nativo do GLPI, usando IDs de relacao nas exclusoes e preservando os demais atores;
- permite limpar um papel e preserva grupos existentes que deixaram de estar disponiveis no catalogo;
- aplica no GLPI 10 um fallback acessivel e tolerante a falhas para exibir `logo.png` no cartao do plugin ativo;
- reconhece instalacoes em `/plugins` e `/marketplace`, preservando o logotipo nativo do GLPI 11;
- consolida o gate em 361 testes PHPUnit e 2.025 assercoes, PHPStan aprovado, PHPCS em 169 de 169 arquivos, 3 de 3 testes de navegador e 555 mensagens i18n;
## 0.2.19-beta

- corrige o resultado `aria-prohibited-attr` reproduzido com os filtros avancados abertos;
- declara como grupos nomeados os botoes de adicao de regras e as acoes de pesquisas salvas;
- preserva os nomes acessiveis e a operacao por teclado sem alterar filtros, ACLs ou persistencia;
- adiciona regressao automatizada para impedir atributos de nomeacao sobre esses conteineres com papel generico;
- mantem `logo.png`, a documentacao tecnologica e funcional e a compatibilidade declarada com GLPI 10 e 11;
- consolida o gate em 351 testes PHPUnit e 1.944 assercoes, PHPStan aprovado e PHPCS em 168 de 168 arquivos.

## 0.2.18-beta

- substitui as iniciais `GA` pelo simbolo visual do GLPI Acessivel no gerenciador de plugins;
- adiciona `logo.png` quadrado, otimizado e reconhecido localmente pelo Marketplace do GLPI;
- mantem a imagem original em alta resolucao e aponta os metadados publicos para o novo icone;
- torna `logo.png` obrigatorio no empacotamento e adiciona regressao de formato, dimensoes, tamanho e inclusao no ZIP;
- nao altera banco de dados, permissoes ou funcionalidades e preserva a compatibilidade declarada com GLPI 10 e 11;
- inclui os documentos tecnologico, funcional e a nota especifica da versao no pacote de distribuicao;
- consolida o gate em 350 testes PHPUnit e 1.935 assercoes, PHPStan aprovado e PHPCS em 168 de 168 arquivos.

## 0.2.17-beta

- corrige a pesquisa por texto ou escopo sem regras avançadas, normalizando com segurança a submissão HTML real;
- torna o resumo fiel a metacritérios modernos e preserva o estado ativo de pesquisas salvas compostas apenas por ordenação, colunas ou excluídos;
- aproxima a aplicação de pesquisas salvas do GLPI 10 e 11, recuperando `list_limit` e tratando `all` e `view` somente quando autorizados;
- move o foco para os painéis abertos, fecha com Escape, devolve o foco e restaura as seis colunas padrão reais;
- remove duplicação e anúncios excessivos do resumo e esclarece rótulos, conectores e a ação Limpar filtros;
- limita a varredura do catálogo, filtra nomes no banco, trata cursor inválido, reforça o rate limit global e corrige `empty`/`notempty` remotos;
- inclui documentação tecnológica e funcional permanente no pacote;
- consolida o gate em 348 testes PHPUnit e 1.924 asserções, PHPStan aprovado, PHPCS em 167 de 167 arquivos e 2 de 2 testes de navegador;
- mantém a classificação beta e exige homologação externa em GLPI 10 e 11 com leitores de tela, teclado, perfis, entidades e volumes representativos.

## 0.2.16-beta

- mantém o seletor de escopo como atalho explícito para todos os chamados permitidos, meus chamados e chamados dos grupos, sem alterar as ACLs nativas do GLPI;
- deixa de apresentar o escopo padrão como filtro escolhido no resumo da consulta em edição e no resumo da pesquisa aplicada;
- continua narrando os escopos não padrão para que leitores de tela reconheçam quando a consulta foi restringida pelo usuário;
- normaliza nomes hierárquicos de entidade vindos da sessão do GLPI e corrige mensagens como `JF2R &#62; InternoTi` para `JF2R > InternoTi`, mantendo escape seguro no HTML;
- consolida o gate em 331 testes PHPUnit e 1.843 asserções, PHPStan aprovado, PHPCS em 167 de 167 arquivos, 2 de 2 testes de navegador e 555 mensagens i18n;
- mantém a classificação beta e exige homologação externa em GLPI 10 e 11 antes de produção.
## 0.2.15-beta

- apresenta um resumo fiel e acessível da pesquisa efetivamente aplicada, incluindo critérios, metacritérios, ordenações, registros excluídos, colunas e paginação sem publicar IDs ou metadados internos;
- preserva a AST versão 3 e recupera diretamente do `SavedSearch` do GLPI as pesquisas compatíveis, sem cópia ou persistência paralela;
- adapta os parâmetros nativos do GLPI 10 e 11 por lista permitida semântica, preservando `forcetoview` e descartando `table`, `users_id` e chaves arbitrárias;
- classifica como `native_only` as definições que não podem ser representadas com fidelidade e mantém o caminho explícito para abrir a pesquisa completa no GLPI;
- reorganiza a pesquisa de chamados em uma barra compacta com controles textuais para pesquisar, abrir pesquisas salvas, salvar, configurar resultados, escolher registros ativos ou excluídos e limpar;
- implementa painéis de divulgação exclusivos com `aria-expanded`, `aria-controls`, Escape, devolução de foco, reflow a 320 px e botões que não submetem o formulário ao apenas abrir opções;
- mantém registros excluídos como dois radios autorizados por `allow_deleted` e protege mutações de SavedSearch com POST, CSRF, confirmação, idempotência e ACL nativa;
- consolida o gate em 329 testes PHPUnit e 1.838 asserções, PHPStan aprovado, PHPCS em 167 de 167 arquivos, 2 de 2 testes de navegador e 555 mensagens i18n;
- mantém a classificação beta e exige homologação externa em GLPI 10 e 11 com leitores de tela, teclado, perfis, entidades e volumes representativos antes de produção.
## 0.2.14-beta

- introduz contratos de valor por combinação de campo e operador, derivados das Search Options autorizadas do GLPI 10 e 11;
- trata Título e Descrição como texto livre e apresenta Status, Prioridade, Urgência e Impacto com domínios locais nativos quando comprovados;
- valida e canonicaliza no servidor valores vazios, texto, inteiros, decimais, datas, booleanos, listas locais e identificadores remotos;
- falha de forma fechada para tipos, campos, operadores e valores sem contrato homologado, sem expor tabela, linkfield, condição ou metadados de autorização ao navegador;
- exige operador e revisão contextual no endpoint de valores e distingue respostas `403`, `409`, `422`, `429` e `503`;
- revalida cada ID remoto no contexto atual de ACL, perfil, entidade e recursividade antes de emitir o token opaco do fluxo PRG;
- separa os limites de requisição do autocomplete e da autorização final, evitando que uma jornada normal bloqueie a submissão;
- corrige associação de erro e foco no combobox visível e acrescenta estados recuperáveis de carregamento, timeout, repetição, fim de lista e carregamento adicional;
- mantém SavedSearch do GLPI como fonte de verdade, preserva a AST versão 3 e não requer migração de banco;
- identifica explicitamente o pacote como beta para homologação externa, ainda dependente da matriz real GLPI 10/11 e de ensaios com tecnologias assistivas antes de produção.

## 0.2.13-beta

- aproxima os valores dos filtros avançados do comportamento nativo observado no GLPI;
- abre a primeira página das opções autorizadas ao focar campos remotos com os operadores `é`, `não é`, `sob` e `não sob`;
- mantém pesquisa textual a partir de dois caracteres, paginação de 25 itens e carregamento adicional explícito;
- preserva ACL, entidade, recursividade, metadados nativos, IDOR, CSRF e limite por sessão em toda consulta de valores;
- alinha ordem e rótulos agregados de Status com a pesquisa nativa do GLPI;
- mantém o combobox acessível com setas, Home, End, Enter, Escape, foco e anúncios de carregamento;
- amplia a regressão automatizada para 280 testes e 1.420 asserções.
## 0.2.12-beta

- unifica busca textual, escopo, critérios avançados e opções de resultado em uma experiência próxima à pesquisa nativa do GLPI;
- deriva campos, operadores, valores, metacritérios e colunas disponíveis das Search Options autorizadas do GLPI 10 e 11;
- permite escolher, ordenar e remover colunas da lista com diálogo acessível, mantendo ID e título como colunas obrigatórias;
- aplica busca textual e escopo na mesma consulta nativa dos critérios, sem cópia local, pós-filtro ou limite artificial de varredura;
- cria, recupera e administra pesquisas salvas diretamente em `SavedSearch`, sem banco paralelo do plugin;
- melhora teclado, foco, anúncios, resumo dos filtros aplicados, reflow a 320 px, alto contraste e `forced-colors`;
- preserva o fluxo POST/CSRF/PRG, token opaco, listas permitidas contextuais e revalidação de ACL;
- amplia a regressão automatizada para 280 testes e 1.413 asserções.
## 0.2.11-beta

- adiciona autocomplete acessível por nome para valores remotos dos filtros nativos de chamados;
- recupera o rótulo autorizado dos valores de pesquisas salvas diretamente no GLPI, sem cópia ou cache persistente;
- usa os provedores de dropdown e IDOR do GLPI 10/11 com direito, condição, entidade e recursividade da Search Option;
- separa o rótulo apresentado do identificador técnico enviado à pesquisa;
- inclui teclado completo, anúncios, paginação, cancelamento de requisições, reflow e alto contraste;
- protege o endpoint com POST, autenticação, autorização, CSRF, parâmetros fechados e limite por sessão;
- amplia a regressão automatizada para 272 testes e 1.314 asserções.
## 0.2.10-beta

- reorganiza a listagem para apresentar os filtros antes das pesquisas salvas e dos resultados;
- torna a busca avancada o modo inicial, mantendo os filtros rapidos como alternativa explicita;
- organiza criterios por categoria, campo, condicao e valor usando os grupos das Search Options nativas;
- adiciona adaptacao de catalogo para as APIs de pesquisa do GLPI 10 e 11;
- remove o metadado interno `searchopt` no servidor e no cliente e rejeita operadores desconhecidos;
- agrupa ordenacao, paginacao e colunas em opcoes progressivamente expansiveis dos resultados;
- melhora sequencia visual, foco, anuncios, reflow, alto contraste e forced-colors;
- preserva o SavedSearch do GLPI como unica fonte das pesquisas salvas, sem copias locais;
- amplia a regressao automatizada para 227 testes e 1.128 assercoes.

## 0.2.9-beta

- adiciona busca avancada acessivel de chamados com criterios aninhados, regras globais, multiplas ordenacoes, colunas, paginacao e lixeira autorizada;
- deriva campos, operadores, tipos de valor, metacriterios e capacidade de exclusao diretamente do catalogo contextual da Search API do GLPI;
- traduz o formulario para uma AST nativa versionada, validada por listas permitidas do perfil e da entidade ativos;
- aplica a pesquisa por POST protegido com CSRF e PRG, mantendo a definicao na sessao e expondo somente um token opaco e temporario na URL;
- recupera pesquisas autorizadas ja salvas no GLPI para o construtor e salva novas pesquisas avancadas somente em SavedSearch, sem persistencia local;
- executa criterios, metacriterios e todas as ordenacoes pela Search API, sem pos-filtro, truncamento ou aproximacao silenciosa;
- falha de forma fechada quando catalogo, contexto, token, autorizacao ou Search API nao permitem execucao fiel;
- melhora teclado, foco, anuncios, resumo em linguagem natural, validacao de erros, reflow, alto contraste e forced-colors para leitores de tela.

## 0.2.8-beta

- torna `SavedSearch` e `SavedSearch_User` do GLPI as unicas fontes de verdade para pesquisas e padrao de chamados;
- remove copia, importacao, CRUD e persistencia local de filtros, inclusive o modelo e a criacao de `ticketviews`;
- remove a tabela legada somente quando o preflight com lock confirma que ela esta vazia;
- adiciona catalogo nativo pesquisavel e paginado em 25 itens, lookup direto e pesquisa padrao fora da pagina atual;
- cria, renomeia, exclui e define padrao diretamente no GLPI conforme ACL, entidade e capacidade do objeto;
- preserva criterios, metacriterios, multiplas ordenacoes e lixeira pela Search API, sem aproximacao silenciosa;
- elimina a varredura de ate 500 chamados da listagem e falha com lista vazia quando a Search API fica indisponivel;
- protege mutacoes com CSRF, fingerprint e ledger idempotente no mesmo limite transacional da operacao nativa;
- limita a query final a 48 KiB e bloqueia definicoes nao homologadas com a opcao `Abrir no GLPI`;
- entrega catalogo e exclusao acessiveis com busca explicita, teclado, foco deterministico, anuncios e `forced-colors`.
## 0.2.7-beta

- recupera pesquisas privadas e publicas de chamados ja salvas no GLPI, respeitando usuario, perfil e entidade;
- classifica pesquisas nativas como compativeis, copiaveis ou disponiveis somente no GLPI;
- executa criterios homologados pela Search API e bloqueia fallback que perderia filtros;
- permite criar copias editaveis, salvar pesquisas privadas e definir uma pesquisa padrao no portal;
- salva escopo, status, texto, grupo, agrupamento, paginacao, ordenacao e colunas visiveis;
- adiciona gerenciamento por controles HTML nativos, sem depender de arrastar, e mensagens anunciaveis;
- adiciona persistencia versionada, auditoria sem termos livres, testes e roteiro de homologacao assistiva;
- bloqueia chaves removidas ou sem autorizacao, parametros truncados, tipos nativos diferentes de pesquisa e escopo de lixeira;
- restringe copias a traducoes comprovadamente equivalentes e impede salvamento generico de pesquisas nativas;
- torna a troca de pesquisa padrao transacional, contextualiza nomes acessiveis e localiza a interface em pt_BR e en_GB.

## 0.2.6-beta

- apresenta documentos do chamado como links de download acessiveis, com nome, formato, tamanho, origem, data e visibilidade;
- inclui anexos de acompanhamentos e tarefas no evento correspondente da timeline;
- preserva ACL do chamado, direito de leitura do item pai, privacidade, relacionamento `Document_Item` e autorizacao nativa do documento;
- delega o download ao endpoint oficial do GLPI 10/11 sem expor caminho, hash ou armazenamento interno;
- adiciona selecao de arquivos anunciavel e operavel por teclado para acompanhamentos e tarefas;
- preserva sucesso parcial quando a acao ITIL e registrada, mas o vinculo do anexo nao pode ser confirmado;
- amplia os testes de regressao, internacionaliza as novas mensagens e recompila os catalogos gettext.

## 0.2.5-beta

- exige explicitamente `SEEPRIVATE` para consultar acompanhamentos e tarefas privados na timeline;
- filtra itens privados antes da consulta e revalida cada linha antes de copiar conteudo ou metadados;
- mantem a ACL nativa `item->can(READ)` como segunda camada de autorizacao;
- adota bloqueio conservador quando classe, constante, sessao ou permissao privada nao estiver disponivel;
- corrige o vazamento observado no GLPI 10 quando o autor Self-Service conseguia reler a propria nota privada;
- preserva os controles privados para perfis autorizados e o fluxo exclusivamente publico para Self-Service.
## 0.2.4-beta

- separa o direito de criar acompanhamentos e tarefas do direito SEEPRIVATE exigido para itens privados;
- bloqueia no servidor POST forjado de nota ou tarefa privada para perfis sem permissao;
- oculta opcoes e modelos privados quando a ACL nativa nao os permite;
- mantem o envio publico disponivel para Self-Service conforme a permissao do chamado;
- evita pagina vazia ao trocar para perfil ou entidade sem acesso ao chamado;
- melhora rotulos, descricoes, foco e percepcao visual da opcao de visibilidade selecionada;
- amplia a regressao de ACL, seguranca e acessibilidade para os cenarios encontrados na homologacao.
## 0.2.3-beta

- adiciona escolha explicita entre resposta publica e nota interna privada nos acompanhamentos;
- substitui a opcao ambigua de tarefa privada por radios acessiveis para tarefa publica ou interna;
- usa as preferencias nativas do GLPI como valor inicial e preserva a privacidade definida por modelos de acompanhamento;
- revalida a privacidade na autorizacao e na persistencia, inclusive contra alteracao maliciosa do POST;
- delega a leitura de cada item da timeline para a ACL nativa de ITILFollowup, TicketTask e ITILSolution;
- identifica em texto a visibilidade e o autor dos eventos que o perfil atual pode consultar;
- mantem anexos com a mesma visibilidade do acompanhamento ou tarefa;
- internacionaliza os novos rotulos e amplia as regressoes de seguranca, ACL e acessibilidade.
## 0.2.2-beta

- mantem disponivel a opcao Todas as entidades quando o GLPI ativa o escopo recursivo, mesmo com uma unica raiz permitida;
- confirma que a entrada direta pelo portal acessivel carrega os perfis nativos e preserva o perfil padrao escolhido pelo GLPI;
- evita uma area de acoes vazia quando ACL e politica de modulos nao liberam nenhuma funcionalidade;
- orienta o usuario a trocar para outro perfil permitido ou solicitar revisao administrativa, sem expor diagnosticos tecnicos;
- preserva as ACLs, entidades e estados de modulo nativos no GLPI 10 e 11.
## 0.2.1-beta

- corrige o retorno do login acessivel, evitando dupla codificacao e redirecionamentos inesperados;
- torna a recuperacao pos-login uma etapa controlada e bloqueia paginas operacionais com sessao parcial;
- separa a troca de perfil da troca de entidade e valida o resultado efetivo das APIs nativas;
- corrige o escopo de todas as entidades e restringe o retorno a rotas locais do plugin;
- limpa memoria e confirmacoes pendentes quando perfil ou entidade muda;
- melhora foco, anuncio de progresso e isolamento do dialogo de ajuda no login;
- adiciona regressao de autenticacao/contexto e corrige as rotas da auditoria autenticada;
- inclui gerador local idempotente de massa sintetica `[A11Y-QA]` para ensaios com tecnologias assistivas.

## 0.2-beta

- consolida a primeira beta publica para GitHub, preservando compatibilidade declarada com GLPI 10 e 11;
- sincroniza metadados, URL de download, catalogos gettext e documentacao da release;
- corrige o namespace dos auxiliares SQL de instalacao e desinstalacao;
- adiciona politica de seguranca, guia de contribuicao, avisos de terceiros e licenca GPL integral;
- endurece a higiene do repositorio e a verificacao automatica do pacote;
- amplia o CI para PHPUnit, PHPStan, PHPCS, Composer Audit e validacao de i18n;
- documenta axe-core 4.10.3, MPL-2.0, fonte correspondente, hash e avisos transitivos;
- adota DCO 1.1 e sign-off para a procedencia de contribuicoes;
- explicita politica de licenciamento, marcas e checklist de propriedade intelectual;
- faz o gate de release validar documentos juridicos e o hash do axe-core.
- publica o pacote principal no perfil enxuto, sem binarios de voz com redistribuicao pendente;
- documenta explicitamente limites de homologacao assistiva, formularios dinamicos e traducao en-GB.
## 0.1.112-beta

- adiciona liberacao gradual por funcionalidade com estados disponivel, oculto e indisponivel;
- mantem ACL, perfil, entidade e permissoes nativas do GLPI como autoridade final;
- bloqueia rotas GET/POST e intents do chatbot para modulos indisponiveis, inclusive conversas ja iniciadas;
- inclui presets administrativos para apresentacao, demonstracao, piloto Self-Service e piloto tecnico;
- ajusta menus, cards, ajuda, atalhos e botao flutuante conforme a configuracao efetiva;
- preserva configuracoes legadas de Formularios e Chatbot durante atualizacao;
- adiciona auditoria, diagnostico, traducoes e regressao automatizada para a politica de modulos.

## 0.1.111-beta

- permite definir o nome publico do chatbot nas configuracoes gerais, mantendo Assistente como padrao;
- propaga o nome para interface, respostas, voz, ARIA e curadoria de roteiros com escape contextual;
- normaliza HTML, controles, marcadores bidirecionais, espacos e comprimento antes de persistir;
- corrige os rotulos ARIA da leitura automatica e internacionaliza as frases com placeholders;
- adiciona migracao idempotente, auditoria sem registrar o nome e testes unitarios de seguranca e fallback.
## 0.1.110-beta

- corrige o fundo preto herdado pelos textos dentro da resposta amarela da Assistente no alto contraste;
- torna transparentes os fundos internos da bolha, preservando texto preto sobre amarelo e o selo independente;
- valida a cascata completa nos modos normal e alto contraste.

## 0.1.109-beta

- corrige o contraste das respostas da Assistente no tema normal e noturno;
- substitui o gradiente por fundo solido `#005a9c` com texto branco, atingindo aproximadamente 7,14:1;
- isola a regra de cor da bolha para impedir sobrescrita pelas regras globais, preservando o selo e o alto contraste.

## 0.1.108-beta

- fecha a equivalencia da Search API no GLPI 11 para mine, busca textual, group_id, grupo unico e multiplos grupos com criterios OR aninhados;
- preserva o fallback seguro quando a Search API nao representa o filtro ou retorna resultado vazio inconclusivo;
- valida entidade ativa concreta e aplica recursividade somente quando o contexto nativo autoriza;
- pagina todo o Service Catalog GLPI 11 e respeita ServiceCatalog::canView() na exibicao do menu;
- correlaciona anexos da criacao, acompanhamento e tarefa com o item recem-criado, nome original e vinculo final Document_Item;
- amplia a auditoria local para resultados que exigem revisao manual e a automacao Pa11y/Axe para WCAG 2.2 A/AA;
- melhora reflow dos botoes flutuantes e respeita prefers-reduced-motion nos controles de voz.
## 0.1.107-beta

- publica o Axe local em uma rota web compativel com GLPI 11 e permite nova tentativa apos falha de carregamento;
- corrige a negacao de acesso a configuracao com HTTP 403 e pagina acessivel, sem excecao bruta;
- usa os rotulos nativos e traduzidos de status do GLPI, incluindo o status de aprovacao do GLPI 11;
- corrige os erros formais bloqueantes do PHPCS e adiciona testes de regressao.
## 0.1.106-beta

- adiciona a opcao geral `Mascarar contatos pessoais`, desativada por padrao;
- preserva a exibicao dos contatos conforme ACL nativa do chamado quando a opcao esta desativada;
- mantem mascaramento, revelacao temporaria, justificativa e auditoria quando a opcao esta ativada;
- registra a configuracao nos diagnosticos e na auditoria administrativa;
- amplia a regressao para validar os estados visivel e mascarado.
## 0.1.105-beta

- reforca isolamento por entidade e ACL nativa em tickets, templates ITIL, auditoria e roteiros;
- elimina a descoberta recursiva de fonte de login por HTTP e usa o seletor nativo do GLPI em memoria;
- valida novamente templates, artigos KB e permissoes imediatamente antes de operacoes sensiveis;
- protege uploads temporarios com ownership, descarte automatico e commit somente apos sucesso nativo;
- mascara dados pessoais por padrao e adiciona revelacao temporaria, justificada e auditada;
- torna aprovacao/rejeicao de roteiros resistente a replay e concorrencia;
- reduz o fallback de listagem para 500 chamados e comunica resultados parciais sem expor diagnosticos tecnicos a usuarios comuns;
- adiciona testes de regressao para fronteiras de entidade, template, login, upload e dados pessoais.

## 0.1.104-beta

- Corrige ACL de roteamento e mudanca de status por chamado, respeitando Ticket::canAssign() e a matriz nativa de transicoes.
- Bloqueia bypass de roteamento por UPDATE generico e remove aprovacao implicita quando o requisitante nao esta identificado.

## 0.1.102-beta

- implementa os contratos P1 de fallback Search API, com grupo atribuido alinhado ao GLPI e sinalizacao explicita de resultados parciais no limite de 5.000 chamados;
- endurece a confirmacao de anexos com `Document`/`Document_Item` e informa sucesso parcial sem permitir reenvio duplicado;
- melhora a submissao delegada de formularios GLPI 11/Formcreator, tratando redirecionamentos nativos e respostas inesperadas;
- normaliza erros de formulario e torna o resumo de validacao navegavel por teclado e leitor de tela;
- documenta o escopo homologado e os limites beta da paridade de formularios.
## 0.1.101-beta

- normaliza perfil, entidade e grupos pelo contexto nativo antes das telas autenticadas;
- preserva ACL e fallback nativo ao detectar contexto operacional incompleto.
## 0.1.100-beta

- corrige o retorno de foco quando condicoes dinamicas ocultam o campo ativo;
- adiciona reflow assistivo para controles de voz, formularios e iframe nativo;
- adiciona suporte visual a forced-colors para foco e bordas;
- mantem a validacao e a submissao sob o motor nativo homologado.
- detecta iframe nativo sem formulario e oferece foco no link de pagina completa;
- bloqueia temporariamente o envio convertido quando o motor de condicoes falha.
## 0.1.99-beta

- refina o alto contraste dos cards de sugestao do chatbot;
- mantem fundo preto no estado normal, hover e foco;
- usa titulo amarelo, descricao branca e anel de foco branco;
- evita que o foco pareca um estado selecionado permanente.
## 0.1.98-beta

- corrige o contraste dos atalhos do chatbot no alto contraste;
- remove a cascata preto sobre preto dos textos secundarios `small`;
- garante foco visivel com contorno branco e faixa preta de separacao;
- sincroniza o CSS publico durante a geracao do pacote.
## 0.1.97-beta

- adiciona contrato centralizado de capacidades para separar renderizacao acessivel, delegacao nativa e submissao propria;
- adiciona gate de submissao que bloqueia qualquer tentativa propria sem homologacao explicita de ACL, condicoes, destinos, validacoes e anexos;
- expõe diagnostico estruturado de fallback nativo para Service Catalog GLPI 11 e Formcreator GLPI 10;
- corrige a limpeza de `aria-describedby` para remover referencias de erros antigos apos nova validacao;
- amplia a regressao automatizada para 68 testes e 370 assercoes.
## 0.1.96-beta

- Normaliza erros de validacao no servidor e no renderer para `{field, code, message}`, sem depender de busca por substring.
- Atualiza o renderer convertido para consumir mapas nativos de obrigatoriedade e bloqueio, mantendo `required`, `aria-required` e `disabled` sincronizados antes da validacao.
- Endurece a verificacao de anexos de tickets: conta documentos distintos e confirma sua existencia antes de considerar o vinculo `Document_Item` completo.
- Mantem campos nativos de usuario, grupo, dispositivo, ativo, LDAP e tag no fallback ate homologacao real de seletores e ACL por perfil/entidade.
- Formaliza o limite beta de 5.000 chamados e a necessidade de comparacao por IDs reais para `mine`, `group` e `group_id`.
## 0.1.95-beta

- Elimina os 89 achados do PHPStan com stubs de desenvolvimento para a API global do GLPI/Formcreator, sem incluir esses stubs no pacote.
- Corrige o prefixo duplicado do autoloader e documenta a excecao legitima dos doubles globais no PHPCS.
- Remove 821 violacoes mecanicas do PHPCS; permanecem avisos historicos de linhas longas para saneamento incremental.
- Mantem a regressao verde: 62 testes e 360 assercoes.

- Endurece Search API para grupos multiplos e papeis ITIL quando os Search Options reais estao disponiveis.
- Mantem fallback textual quando titulo e conteudo nao podem ser representados nativamente.
- Bloqueia conversao propria diante de condicoes nativas nao normalizadas.
- Confirma um vinculo Document_Item por anexo enviado e formaliza o limite beta de 5.000 chamados.
- Corrige o contrato de excecoes de validacao e a descoberta de APIs do Formcreator.
- Torna explicito o contraste dos placeholders dos campos de pergunta e descricao nos modos claro, noturno e alto contraste.

# Changelog

## 0.1.92-beta

- Corrige os quatro achados de contraste identificados na auditoria Pa11y autenticada.
- Define cores explícitas para campos principais e avatar no tema claro, noturno e alto contraste.
## 0.1.91-beta

- Restringe mensagens tecnicas de fallback e identificacao do backend da listagem de chamados a administradores ou perfis com config/UPDATE.
- Mantem a listagem, os filtros e as validacoes de ACL disponiveis para usuarios comuns sem expor detalhes internos da Search API.
## 0.1.87-beta

- Adiciona auditoria local Axe, restrita a configuradores GLPI, sem telemetria ou persistencia.
- Adiciona ferramentas Pa11y com captura manual de sessao local para homologacao autenticada.
- Inclui assets locais Axe, documentacao e exclusoes de sessao no Git.

## 0.1.86-beta

- Migra os namespaces de runtime para `GlpiPlugin\\Glpiacessivel`.
- Padroniza metadados, XML de catalogo e pacote Marketplace/offline.
- Adiciona pipeline de qualidade, compilacao gettext e checksum de release.
- Mantem Search API e formularios sob gates de equivalencia e homologacao real.

## 0.1.85-beta

- Suporta multiplos targets de ticket delegados ao Formcreator 2.13.11.
