<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

final class I18n
{
    public const DOMAIN = 'glpiacessivel';
    public const FALLBACK_LOCALE = 'pt_BR';

    public static function locale(): string
    {
        $candidates = [
            $_SESSION['glpilanguage'] ?? null,
            $_SESSION['glpi_language'] ?? null,
            $_SESSION['glpiactiveprofile']['language'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            $locale = self::normalizeLocale((string) $candidate);
            if ($locale !== '') {
                return $locale;
            }
        }

        return self::fallbackLocale();
    }

    public static function fallbackLocale(): string
    {
        $configured = self::configuredFallbackLocale();
        return $configured !== '' ? $configured : self::FALLBACK_LOCALE;
    }

    /** @return array<int, string> */
    public static function availableLocales(): array
    {
        $localesDir = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'locales';
        $available = [];
        foreach (glob($localesDir . DIRECTORY_SEPARATOR . '*.{po,mo}', GLOB_BRACE) ?: [] as $file) {
            $locale = self::normalizeLocale(pathinfo((string) $file, PATHINFO_FILENAME));
            if ($locale !== '') {
                $available[] = $locale;
            }
        }

        $available[] = self::FALLBACK_LOCALE;
        $available = array_values(array_unique($available));
        sort($available);

        return $available;
    }

    /** @return array<string, array{po:bool,mo:bool}> */
    public static function catalogStatus(): array
    {
        $localesDir = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'locales';
        $status = [];
        foreach (self::availableLocales() as $locale) {
            $status[$locale] = [
                'po' => is_file($localesDir . DIRECTORY_SEPARATOR . $locale . '.po'),
                'mo' => is_file($localesDir . DIRECTORY_SEPARATOR . $locale . '.mo'),
            ];
        }

        return $status;
    }

    public static function htmlLang(?string $locale = null): string
    {
        $locale = self::normalizeLocale($locale ?? self::locale());
        if ($locale === '') {
            $locale = self::FALLBACK_LOCALE;
        }

        return str_replace('_', '-', $locale);
    }

    public static function translate(string $text): string
    {
        return function_exists('__') ? __($text, self::DOMAIN) : $text;
    }

    public static function plural(string $single, string $plural, int $count): string
    {
        if (function_exists('_n')) {
            return _n($single, $plural, $count, self::DOMAIN);
        }

        return $count === 1 ? $single : $plural;
    }

    public static function context(string $context, string $text): string
    {
        if (function_exists('_x')) {
            return _x($context, $text, self::DOMAIN);
        }

        return $text;
    }

    /**
     * @return array{locale:string,htmlLang:string,fallbackLocale:string,messages:array<string,string>}
     */
    public static function javascriptCatalog(): array
    {
        $messages = [];
        foreach (self::javascriptMessageSources() as $key => $text) {
            $messages[$key] = self::translate($text);
        }

        return [
            'locale' => self::locale(),
            'htmlLang' => self::htmlLang(),
            'fallbackLocale' => self::fallbackLocale(),
            'messages' => $messages,
        ];
    }

    /** @return array<string,string> */
    public static function javascriptMessageSources(): array
    {
        return [
            'portal.open.label' => 'Abrir portal acessível do GLPI',
            'portal.open.sr' => 'Abrir portal acessível',
            'portal.embedded.label' => 'Ir para modo acessível do GLPI',
            'portal.embedded.sr' => 'Ir para modo acessível',
            'portal.open.title' => 'Abrir portal acessível',
            'portal.embedded.title' => 'Ir para modo acessível',
            'chatbot.open.label' => 'Abrir chatbot operacional do GLPI acessível',
            'chatbot.open.sr' => 'Abrir chatbot operacional',
            'status.processing' => 'Processando ação, aguarde.',
            'status.opening_accessible_journey' => 'Abrindo jornada acessível principal.',
            'status.opening_accessible_mode' => 'Abrindo modo acessível.',
            'status.opening_chatbot' => 'Abrindo chatbot operacional.',
            'status.shortcut_executed' => 'Atalho executado: {shortcut}.',
            'status.theme_night_enabled' => 'Tema noturno ativado.',
            'status.theme_light_enabled' => 'Tema claro ativado.',
            'status.contrast_enabled' => 'Alto contraste ativado.',
            'status.contrast_disabled' => 'Alto contraste desativado.',
            'status.help_opened' => 'Painel de ajuda aberto.',
            'status.help_closed' => 'Painel de ajuda fechado.',
            'status.focus_main' => 'Foco movido para o conteúdo principal.',
            'status.focus_menu' => 'Foco movido para o menu.',
            'status.focus_search' => 'Foco movido para a busca ou formulário principal.',
            'status.opening_my_tickets' => 'Abrindo meus chamados.',
            'status.opening_all_tickets' => 'Abrindo todos os chamados permitidos.',
            'status.opening_new_ticket' => 'Abrindo novo chamado.',
            'status.opening_kb' => 'Abrindo base de conhecimento.',
            'status.opening_cockpit' => 'Abrindo cockpit operacional.',
            'status.opening_public_faq' => 'Abrindo FAQ pública acessível.',
            'status.no_ticket_selected' => 'Nenhum chamado selecionado.',
            'status.ticket_ids_copied' => 'IDs dos chamados selecionados copiados.',
            'status.ticket_ids_selected' => 'IDs selecionados: {ids}.',
            'status.ticket_count_selected' => '{count} chamados selecionados.',
            'ticket.column.id' => 'ID',
            'ticket.column.title' => 'Título',
            'ticket.column.status' => 'Status',
            'ticket.column.priority' => 'Prioridade',
            'ticket.column.group' => 'Grupo responsável',
            'ticket.column.requester' => 'Requisitante',
            'ticket.column.assignee' => 'Técnico',
            'ticket.column.category' => 'Categoria',
            'ticket.column.entity' => 'Entidade',
            'ticket.column.location' => 'Localização',
            'ticket.column.opened_at' => 'Data de abertura',
            'ticket.column.updated_at' => 'Última atualização',
            'ticket.column.resolve_by' => 'Prazo para solução',
            'ticket.column.action' => 'Ação',
            'ticket.action.open' => 'Abrir',
            'ticket.action.open_named' => 'Abrir chamado {id}: {title}',
            'ticket.action.select' => 'Selecionar chamado {id}',
            'ticket.action.select_short' => 'Selecionar',
            'ticket.action.open_native_list' => 'Abrir a listagem do GLPI',
            'ticket.value.no_group' => 'Sem grupo',
            'ticket.table.label' => 'Tabela de chamados',
            'ticket.table.caption' => 'Chamados encontrados para os filtros atuais',
            'ticket.results.empty' => 'Nenhum chamado encontrado para os filtros informados.',
            'ticket.results.group_scope_without_current_groups' => 'Você não pertence a nenhum grupo no perfil e na entidade atuais. Por isso, não há chamados de grupos responsáveis para exibir.',
            'ticket.results.loading' => 'Consultando a lista autorizada do GLPI. Aguarde.',
            'ticket.results.loading_summary' => 'Carregando os chamados autorizados pelo GLPI.',
            'ticket.results.range' => 'Exibindo {first}–{last} de {total} chamados.',
            'ticket.results.none_visible' => 'Nenhum chamado visível para a consulta atual.',
            'ticket.error.session_expired' => 'Sua sessão expirou. Entre novamente no GLPI para consultar os chamados.',
            'ticket.error.forbidden' => 'Seu perfil não pode executar esta consulta.',
            'ticket.error.context_stale' => 'O perfil ou a entidade mudou. Atualize a página antes de consultar novamente.',
            'ticket.error.state_expired' => 'A consulta expirou. Atualize a página para gerar uma nova consulta segura.',
            'ticket.error.invalid_request' => 'A consulta não pode ser executada com os dados atuais.',
            'ticket.error.rate_limited' => 'Foram feitas muitas consultas em pouco tempo. Aguarde e tente novamente.',
            'ticket.error.unavailable' => 'A lista de chamados está temporariamente indisponível.',
            'ticket.error.origin_not_allowed' => 'A origem desta página não foi reconhecida pelo GLPI.',
            'ticket.error.timed_out' => 'A consulta demorou mais que o limite seguro.',
            'ticket.error.config_invalid' => 'A configuração da lista não pode ser carregada com segurança.',
            'ticket.error.config_missing' => 'O módulo da lista não recebeu sua configuração.',
            'ticket.error.unexpected_content_type' => 'O servidor retornou uma resposta inesperada.',
            'ticket.error.invalid_response' => 'O servidor retornou uma resposta que não pode ser confirmada.',
            'ticket.error.generic' => 'Não foi possível carregar a lista com segurança.',
            'ticket.error.native_fallback_help' => 'Use a listagem do GLPI se necessário.',
            'pagination.page_of' => 'Página {page} de {pages}',
            'pagination.first' => 'Primeira',
            'pagination.previous' => 'Anterior',
            'pagination.next' => 'Próxima',
            'pagination.last' => 'Última',
            'button.retry' => 'Tentar novamente',
            'button.clear' => 'Limpar',
            'button.remove' => 'Remover',
            'selector.value.option' => 'opção',
            'selector.placeholder.choose_or_type' => 'Selecione ou digite para pesquisar',
            'selector.placeholder.type' => 'Digite para pesquisar',
            'selector.action.clear' => 'Limpar {label}',
            'selector.suggestions_for' => 'Sugestões para {label}',
            'selector.action.load_more' => 'Carregar mais resultados',
            'selector.minimum_characters' => 'Digite pelo menos {count} caracteres.',
            'selector.keyboard_help' => 'Use as setas para percorrer as sugestões e Enter para confirmar.',
            'selector.action.open_glpi_flow' => 'Abrir a página completa do GLPI.',
            'selector.selected_list' => '{label} selecionados',
            'selector.status.cleared_by_context' => '{label} foi limpo porque o contexto mudou.',
            'selector.status.one_selected' => '1 item selecionado em {label}.',
            'selector.status.many_selected' => '{count} itens selecionados em {label}.',
            'selector.status.none_selected' => 'Nenhum item selecionado em {label}.',
            'selector.action.remove_named' => 'Remover {label}: {value}',
            'selector.status.selected' => '{value} selecionado.',
            'selector.status.removed' => '{value} removido. Permanecem {count} itens selecionados.',
            'selector.status.selection_cleared' => 'Seleção de {label} removida.',
            'selector.error.unavailable' => 'Pesquisa indisponível. Use o fluxo do GLPI.',
            'selector.status.loading_more' => 'Carregando mais resultados.',
            'selector.status.loading' => 'Carregando resultados.',
            'selector.error.context_changed' => 'O contexto do GLPI mudou. Recarregue a página antes de continuar.',
            'selector.status.no_results' => 'Nenhum resultado encontrado.',
            'selector.status.more_loaded' => '{added} novos resultados carregados; {total} no total.',
            'selector.status.has_more' => 'Há mais resultados.',
            'selector.status.end' => 'Fim da lista.',
            'selector.status.one_available' => '{count} resultado disponível.',
            'selector.status.many_available' => '{count} resultados disponíveis.',
            'selector.status.choose_help' => 'Use as setas e Enter para selecionar.',
            'selector.error.timeout' => 'A consulta demorou mais que o esperado. Tente novamente.',
            'selector.error.session_or_permission' => 'A sessão ou a permissão mudou. Recarregue a página.',
            'selector.error.context_changed_short' => 'O contexto do GLPI mudou. Recarregue a página.',
            'selector.error.rate_limited' => 'Muitas consultas foram feitas. Aguarde um momento e tente novamente.',
            'selector.error.query_invalid' => 'A pesquisa contém caracteres inválidos ou excede o tamanho permitido.',
            'selector.error.invalid' => 'A pesquisa não é válida para este seletor.',
            'selector.error.generic' => 'Não foi possível carregar resultados. Use o fluxo do GLPI se necessário.',
            'selector.validation.confirm_or_clear' => 'Confirme uma sugestão em {label} ou apague o texto digitado.',
            'selector.validation.required' => 'Selecione {label}.',
            'search.option.other' => 'Outros',
            'search.saved.group' => 'Pesquisa salva',
            'search.saved.field' => 'Campo salvo no GLPI: {value}',
            'search.saved.value' => 'Valor salvo no GLPI: {value}',
            'search.value.label' => 'Valor',
            'search.value.none_required' => 'Esta condição não exige valor.',
            'search.value.yes' => 'Sim',
            'search.value.no' => 'Não',
            'search.value.clear' => 'Limpar valor',
            'search.value.clear_selected' => 'Limpar valor selecionado',
            'search.value.select' => 'Selecionar valor',
            'search.value.search' => 'Pesquisar valor',
            'search.value.results' => 'Resultados da pesquisa de valor',
            'search.value.help_browse' => 'Ao abrir, as primeiras opções autorizadas são carregadas. Digite pelo menos {count} caracteres para filtrar. Use as setas e Enter para selecionar.',
            'search.value.help_search' => 'Digite pelo menos {count} caracteres. Use as setas para percorrer os resultados e Enter para selecionar.',
            'search.value.retry_ready' => 'Você pode tentar carregar os resultados novamente.',
            'search.value.selection_removed' => 'Seleção removida.',
            'search.value.native_new_tab' => 'Pesquisar diretamente no GLPI (abre em nova guia).',
            'search.value.fallback_label' => 'Valor (identificador no GLPI)',
            'search.value.fallback_help' => 'A pesquisa por nome está indisponível. Informe o identificador numérico usado pelo GLPI.',
            'search.value.saved_id_preserved' => 'Identificador salvo preservado.',
            'search.value.format' => 'Use o formato {format}.',
            'search.value.loading_saved' => 'Carregando o valor salvo.',
            'search.value.saved_name_missing' => 'O identificador salvo foi preservado, mas o nome não foi localizado.',
            'search.value.name_missing' => 'Não foi possível carregar o nome; o identificador foi preservado.',
            'search.value.session_or_permission' => 'Sua sessão expirou ou você não tem mais permissão para este valor. Recarregue a página para atualizar o acesso.',
            'search.value.context_changed' => 'Os campos disponíveis no GLPI mudaram desde que a página foi aberta. Recarregue a página antes de continuar.',
            'search.value.invalid_condition' => 'O campo ou a condição deixou de ser válido. Revise a condição selecionada.',
            'search.value.rate_limited_wait' => 'Muitas consultas foram feitas em pouco tempo. Aguarde um momento antes de tentar novamente.',
            'search.value.rate_limited_seconds' => 'Muitas consultas foram feitas em pouco tempo. Aguarde {seconds} segundo.',
            'search.value.rate_limited_seconds_plural' => 'Muitas consultas foram feitas em pouco tempo. Aguarde {seconds} segundos.',
            'search.value.service_unavailable' => 'O serviço de valores está temporariamente indisponível. Tente novamente.',
            'button.reload_page' => 'Recarregar página',
            'button.review_condition' => 'Revisar condição',
            'search.column.choose' => 'Selecione uma coluna',
            'search.column.choose_available' => 'Selecione uma coluna disponível.',
            'search.column.move_up' => 'Mover coluna {label} para cima, {position}',
            'search.column.move_down' => 'Mover coluna {label} para baixo, {position}',
            'search.column.moved' => 'Coluna {label} movida para a {position}.',
            'search.column.remove' => 'Remover coluna {label}, {position}',
            'search.column.removed' => 'Coluna {label} removida. Restam {count} colunas.',
            'search.column.dialog_opened' => 'Escolha de colunas aberta com {count} colunas selecionadas.',
            'search.column.already_selected' => 'A coluna {label} já está na lista.',
            'search.column.added' => 'Coluna {label} adicionada na {position}.',
            'search.column.defaults_restored' => 'Colunas restauradas. Permanecem {count} colunas padrão.',
            'search.column.applied' => '{count} colunas aplicadas à consulta em edição. A pesquisa ainda não foi executada.',
            'search.column.position' => 'Posição {position} de {total}',
            'search.column.required' => 'Obrigatória',
            'search.action.move_up' => 'Mover para cima',
            'search.action.move_down' => 'Mover para baixo',
            'search.action.remove' => 'Remover',
            'search.action.move_item_up' => 'Mover {item} para cima',
            'search.action.move_item_down' => 'Mover {item} para baixo',
            'search.action.remove_item' => 'Remover {item}',
            'search.item.criterion' => 'Critério',
            'search.item.global_rule' => 'Regra global',
            'search.item.group' => 'Grupo',
            'search.item.sort' => 'Ordenação',
            'search.item.first_rule' => 'Primeira regra',
            'search.item.relation_criterion' => 'Relação lógica do critério',
            'search.item.relation_global' => 'Relação lógica da regra global',
            'search.item.relation_group' => 'Relação lógica do grupo',
            'search.item.related_type' => 'Tipo relacionado',
            'search.item.field' => 'Campo',
            'search.item.field_grouped' => 'Campo agrupado por categoria',
            'search.item.condition' => 'Condição',
            'search.item.sort_field' => 'Campo de ordenação',
            'search.item.sort_direction' => 'Direção',
            'search.item.sort_ascending' => 'Crescente',
            'search.item.sort_descending' => 'Decrescente',
            'search.item.sort_increase_priority' => 'Aumentar prioridade',
            'search.item.sort_decrease_priority' => 'Diminuir prioridade',
            'search.item.generic' => 'Item',
            'search.item.criterion_number' => 'Critério {position} de {total}',
            'search.item.global_number' => 'Regra global {position} de {total}',
            'search.item.group_number' => 'Grupo {position}, nível {depth}',
            'search.item.sort_number' => 'Ordenação {position} de {total}',
            'search.relation.and' => 'E',
            'search.relation.or' => 'OU',
            'search.relation.and_not' => 'E NÃO',
            'search.relation.or_not' => 'OU NÃO',
            'search.item.group_criteria' => 'Critérios do grupo',
            'search.item.add_criterion_group' => 'Adicionar critério ao grupo',
            'search.item.add_nested_group' => 'Adicionar grupo aninhado',
            'search.item.move_group_up' => 'Mover grupo para cima',
            'search.item.move_group_down' => 'Mover grupo para baixo',
            'search.item.remove_group' => 'Remover grupo',
            'search.item.remove_criterion' => 'Remover critério',
            'search.item.remove_global' => 'Remover regra global',
            'search.item.remove_sort' => 'Remover ordenação',
            'search.status.criterion_added' => 'Critério adicionado.',
            'search.status.global_added' => 'Regra global adicionada.',
            'search.status.group_added' => 'Grupo adicionado no nível {depth}. O grupo contém um critério inicial.',
            'search.status.sort_added' => 'Ordenação adicionada. Foco movido para o campo de ordenação.',
            'search.status.criterion_removed' => 'Critério removido.',
            'search.status.global_removed' => 'Regra global removida.',
            'search.status.group_removed' => 'Grupo removido.',
            'search.status.sort_removed' => 'Ordenação removida.',
            'search.status.field_changed' => 'Campo alterado. Os operadores e o controle de valor foram atualizados.',
            'search.status.related_type_changed' => 'Tipo relacionado alterado. Os campos disponíveis foram atualizados.',
            'search.status.condition_changed' => 'Condição alterada para {condition}{instruction}',
            'search.status.moved' => '{item} movido para a posição {position} de {total}. Foco movido para o título da regra.',
            'search.status.removed' => '{item} removido. Restam {count} itens neste nível.',
            'search.status.removed_empty' => '{item} removido. A lista ficou vazia.',
            'search.status.rule_added_position' => '{item}. Posição {position} de {total}. Foco movido para o título da regra.',
            'search.instruction.value' => '. Informe o valor correspondente.',
            'search.instruction.none' => '. Este operador não exige valor.',
            'search.instruction.remote' => '. Selecione um valor no campo Valor.',
            'search.limit.criteria' => 'Limite de {count} critérios atingido.',
            'search.limit.global_rules' => 'Limite de {count} regras globais atingido.',
            'search.limit.sorts' => 'Limite de {count} ordenações atingido.',
            'search.limit.depth' => 'Profundidade máxima de grupos atingida.',
            'search.disclosure.advanced' => 'Filtros avançados, {count} {rules}',
            'search.disclosure.one_rule' => 'regra configurada',
            'search.disclosure.many_rules' => 'regras configuradas',
            'search.disclosure.one_rule_short' => 'regra',
            'search.disclosure.many_rules_short' => 'regras',
            'search.summary.configured' => '{count} configurados',
            'search.summary.options' => '{count} opções',
            'search.summary.filters' => 'Filtros. {count} configurados{detail}',
            'search.summary.scope_lower' => 'escopo {value}',
            'search.summary.status_lower' => 'status {value}',
            'search.summary.group_lower' => 'grupo {value}',
            'search.summary.first_rule' => 'Primeira regra:',
            'search.summary.group_expression' => 'grupo ({value})',
            'search.summary.result_options' => 'Ordenação e exibição (campos de ordenação: {sorts}; itens por página: {page_size}; agrupamento: {grouping}; registros: {records}; colunas: {columns})',
            'search.summary.result_options_aria' => 'Opções dos resultados. {summary}',
            'search.summary.none_grouping' => 'Sem agrupamento',
            'search.summary.active_tickets' => 'chamados ativos',
            'search.summary.deleted_tickets' => 'chamados excluídos',
            'search.summary.text' => 'Texto: {value}',
            'search.summary.scope' => 'Escopo: {value}',
            'search.summary.status' => 'Status: {value}',
            'search.summary.group' => 'Grupo responsável: {value}',
            'search.summary.global_rules' => 'Regras globais: {value}',
            'search.summary.sort' => 'Ordenação: {value}',
            'search.summary.grouping' => 'Agrupamento: {value}',
            'search.summary.page_size' => 'Itens por página: {value}',
            'search.summary.columns' => 'Colunas selecionadas: {count}',
            'search.summary.only_deleted' => 'Somente chamados excluídos',
            'search.summary.none' => 'Nenhum filtro configurado na consulta em edição.',
            'search.validation.criteria_limit' => 'O limite de critérios foi excedido.',
            'search.validation.global_limit' => 'O limite de regras globais foi excedido.',
            'search.validation.sort_limit' => 'O limite de ordenações foi excedido.',
            'search.validation.context_criterion' => 'Critério {number}',
            'search.validation.context_global' => 'Regra global {number}',
            'search.validation.field' => '{context}: selecione o campo.',
            'search.validation.condition' => '{context}: selecione a condição.',
            'search.validation.remote_value' => '{context}: selecione um valor da lista de resultados.',
            'search.validation.value' => '{context}: informe o valor.',
            'search.validation.numeric_id' => '{context}: informe um identificador numérico válido do GLPI.',
            'search.validation.empty_group' => 'Um grupo não pode ficar vazio.',
            'search.validation.one_error' => 'A busca avançada contém 1 erro. Revise o resumo de erros.',
            'search.validation.many_errors' => 'A busca avançada contém {count} erros. Revise o resumo de erros.',
            'search.validation.not_editable' => 'Esta pesquisa não pode ser editada fielmente neste portal.',
            'search.validation.submitting' => 'Pesquisa avançada validada. Enviando a consulta ao GLPI.',
            'search.validation.catalog_unavailable' => 'O catálogo de campos do GLPI não está disponível neste contexto.',
            'a11y.audit.running' => 'Auditoria em execução.',
            'a11y.audit.failed' => 'Não foi possível executar a auditoria local.',
            'a11y.audit.complete_one' => 'Foi encontrada 1 regra com violação.',
            'a11y.audit.complete_many' => 'Foram encontradas {count} regras com violação.',
            'a11y.audit.none' => 'Nenhuma violação automatizada foi encontrada nesta página.',
            'a11y.audit.incomplete_one' => 'A auditoria encontrou 1 regra que exige revisão manual.',
            'a11y.audit.incomplete_many' => 'A auditoria encontrou {count} regras que exigem revisão manual.',
            'a11y.audit.limit' => 'O resultado é local e não substitui avaliação manual.',
            'a11y.audit.affected_one' => '1 elemento afetado.',
            'a11y.audit.affected_many' => '{count} elementos afetados.',
            'a11y.audit.rule' => 'Ver regra {rule}.',
            'a11y.audit.review' => 'Revisar regra {rule}.',
            'a11y.audit.impact_unknown' => 'Impacto não classificado',
            'a11y.audit.impact.critical' => 'crítico',
            'a11y.audit.impact.serious' => 'grave',
            'a11y.audit.impact.moderate' => 'moderado',
            'a11y.audit.impact.minor' => 'leve',
            'a11y.audit.target.element' => 'elemento',
            'a11y.audit.target.attributes' => 'atributos: {attributes}',
            'a11y.audit.target.local' => 'Alvo local {index}: {target}.',
            'a11y.audit.aria.references' => 'Atributo ARIA a revisar: {attribute}; IDs referenciados: #{references}.',
            'a11y.audit.aria.omitted' => 'Atributo ARIA a revisar: {attribute}. O valor foi omitido.',
            'a11y.audit.contrast.calculated' => 'Contraste calculado pelo Axe: {ratio}:1.',
            'a11y.audit.contrast.minimum' => 'Mínimo esperado: {expected}.',
            'a11y.audit.contrast.bg_image' => 'O Axe não determinou a cor de fundo por causa de uma imagem.',
            'a11y.audit.contrast.bg_gradient' => 'O Axe não determinou a cor de fundo por causa de um gradiente.',
            'a11y.audit.contrast.bg_overlap' => 'O Axe não determinou o contraste por causa de sobreposição de elementos.',
            'a11y.audit.contrast.text_shadows' => 'O Axe não determinou o contraste por causa de sombras de texto complexas.',
            'a11y.audit.contrast.partially_obscured' => 'O elemento está parcialmente encoberto; o contraste exige revisão manual.',
            'a11y.audit.contrast.partially_obscuring' => 'O elemento encobre parcialmente outro conteúdo; o contraste exige revisão manual.',
            'a11y.audit.contrast.alpha' => 'A transparência da cor do texto impede o cálculo automático do contraste.',
            'a11y.audit.contrast.outside_viewport' => 'O elemento está fora da área visível e exige revisão manual de contraste.',
            'a11y.audit.contrast.pseudo_content' => 'Um pseudo-elemento impede a determinação automática do contraste.',
            'a11y.audit.contrast.short_text' => 'O conteúdo é curto demais para o Axe confirmar que se trata de texto.',
            'a11y.audit.contrast.equal_ratio' => 'O Axe encontrou razão de contraste 1:1 e exige confirmação manual.',
            'a11y.audit.technical_summary' => 'Resumo técnico do Axe: {summary}',
            'a11y.audit.technical_checks' => 'Verificações técnicas: {checks}.',
            'a11y.audit.node_details' => 'Detalhes locais por elemento ({shown} de {total}).',
            'a11y.audit.one_node_omitted' => '1 elemento adicional omitido para limitar o diagnóstico.',
            'a11y.audit.many_nodes_omitted' => '{count} elementos adicionais omitidos para limitar o diagnóstico.',
            'a11y.audit.confirmed_classification' => 'Violação automatizada confirmada pelo Axe.',
            'a11y.audit.manual_classification' => 'Revisão manual: o Axe não confirmou uma violação.',
            'a11y.audit.review_rule' => 'Consulte a regra para revisar o resultado.',
            'a11y.audit.one_rule_omitted' => '1 regra adicional omitida para limitar o diagnóstico local.',
            'a11y.audit.many_rules_omitted' => '{count} regras adicionais omitidas para limitar o diagnóstico local.',
            'a11y.audit.confirmed_heading' => 'Violações automatizadas confirmadas',
            'a11y.audit.manual_heading' => 'Itens para revisão manual (não confirmados)',
            'create.file.selection_cleared' => 'Seleção de anexos limpa.',
            'create.file.none_selected' => 'Nenhum anexo selecionado.',
            'create.file.one_selected' => '1 anexo selecionado.',
            'create.file.many_selected' => '{count} anexos selecionados.',
            'create.template.none' => 'Nenhum modelo de chamado selecionado.',
            'create.template.unsupported_fields' => 'campos obrigatórios não suportados',
            'create.template.requires_native' => 'O modelo {label} exige {unsupported}. Abra o formulário em página completa para concluir.',
            'create.template.required_fields' => ' Campos obrigatórios: {fields}.',
            'create.template.selected' => 'Modelo {label} selecionado.{required} Título e descrição não serão sobrescritos.',
            'create.actor.default_kind' => 'ator',
            'create.actor.add' => 'Adicionar {kind}',
            'create.actor.filter' => 'Filtrar {kind}',
            'create.actor.none_selected' => 'Nenhum {kind} selecionado.',
            'create.actor.option_to_add' => 'Opção para adicionar em {kind}',
            'create.actor.add_selected' => '{action} selecionado',
            'create.actor.clear' => 'Limpar seleção de {kind}',
            'create.actor.none_available' => 'Nenhuma opção disponível',
            'create.actor.no_results' => 'Nenhum resultado disponível',
            'create.actor.one_selected' => '1 item selecionado em {kind}.',
            'create.actor.many_selected' => '{count} itens selecionados em {kind}.',
            'create.actor.remove_from' => 'Remover {actor} de {kind}',
            'create.actor.removed_from' => '{actor} removido de {kind}.',
            'create.actor.none_to_add' => 'Nenhuma opção disponível para adicionar em {kind}.',
            'create.actor.added_to' => '{actor} adicionado em {kind}.',
            'create.actor.selection_cleared' => 'Seleção de {kind} limpa.',
            'create.priority.very_low' => 'Muito baixa',
            'create.priority.low' => 'Baixa',
            'create.priority.medium' => 'Média',
            'create.priority.high' => 'Alta',
            'create.priority.very_high' => 'Muito alta',
            'create.priority.updated' => 'Prioridade prevista atualizada para {priority}.',
            'create.category.remote_context' => 'A pesquisa de categorias usará o tipo de chamado selecionado.',
            'create.category.updated' => 'Categorias atualizadas para o tipo selecionado. {count} opção(ões) disponível(is).',
            'create.request_source.default' => 'Central de atendimento',
            'create.request_source.updated' => 'Origem da requisição atualizada.',
            'create.form.cleared' => 'Formulário limpo.',
            'status.opening_forms' => 'Abrindo formulários.',
            'status.dynamic_form_updated' => 'Regras dinâmicas do formulário atualizadas.',
            'status.dynamic_form_visibility_failed' => 'Não foi possível atualizar a visibilidade dinâmica do formulário.',
            'status.form_validation_failed' => 'Corrija os campos indicados antes de enviar.',
            'status.form_field_invalid' => 'Campo inválido.',
            'status.form_submitted' => 'Formulário enviado com sucesso pelo GLPI.',
            'status.form_submitted_with_links' => 'Formulário enviado com sucesso. Itens criados: {links}.',
            'status.form_submit_failed' => 'Não foi possível enviar o formulário nesta página. Abra-o em página completa ou contate o administrador.',
            'status.form_unexpected_response' => 'O servidor retornou uma resposta inesperada. Abra o formulário em página completa para concluir.',
            'status.native_form_loading' => 'Carregando o formulário…',
            'status.native_form_loaded' => 'Formulário carregado.',
            'status.native_form_loaded_minimal' => 'Formulário carregado.',
            'status.native_form_full_chrome' => 'Formulário carregado.',
            'status.native_form_session_expired' => 'Sua sessão terminou. Abra o formulário em página completa para entrar novamente.',
            'status.native_form_navigated' => 'O formulário avançou para outra etapa. Confira o conteúdo exibido.',
            'status.native_form_unverified' => 'Não foi possível abrir o formulário nesta página. Abra-o em página completa para continuar.',
            'status.native_form_timeout' => 'O formulário está demorando para carregar. Você pode tentar novamente ou abri-lo em página completa.',
            'critical.required' => 'Confirmação obrigatória',
            'critical.title' => 'Confirmar ação crítica',
            'critical.review' => 'Revise os dados antes de executar esta ação.',
            'critical.consequence' => 'Esta ação será registrada no GLPI.',
            'critical.opened' => 'Confirmação obrigatória aberta. Revise a ação antes de continuar.',
            'critical.cancelled' => 'Ação crítica cancelada.',
            'critical.confirmed' => 'Ação crítica confirmada. Enviando formulário.',
            'critical.none_pending' => 'Nenhuma ação pendente para confirmar.',
            'button.cancel' => 'Cancelar',
            'button.confirm_action' => 'Confirmar ação',
            'shortcut.help' => 'Abrir ajuda de acessibilidade',
            'shortcut.theme' => 'Alternar tema claro e noturno',
            'shortcut.contrast' => 'Ativar ou desativar alto contraste',
            'shortcut.font_decrease' => 'Diminuir tamanho da fonte',
            'shortcut.font_reset' => 'Restaurar tamanho da fonte',
            'shortcut.font_increase' => 'Aumentar tamanho da fonte',
            'vlibras.ready' => 'VLibras carregado.',
            'vlibras.unavailable' => 'VLibras indisponível no momento.',
            'vlibras.retrying' => 'Conexão restaurada. Tentando carregar VLibras.',
        ];
    }

    private static function configuredFallbackLocale(): string
    {
        global $DB;

        if (!isset($DB) || !method_exists($DB, 'request')) {
            return '';
        }

        try {
            $row = $DB->request([
                'SELECT' => ['value_text'],
                'FROM' => 'glpi_plugin_glpiacessivel_configs',
                'WHERE' => ['key_name' => 'plugin_fallback_locale'],
                'LIMIT' => 1,
            ])->current();
        } catch (\Throwable $e) {
            return '';
        }

        if (!$row) {
            return '';
        }

        return self::normalizeLocale((string) ($row['value_text'] ?? ''));
    }

    private static function normalizeLocale(string $locale): string
    {
        $locale = trim($locale);
        if ($locale === '') {
            return '';
        }

        $locale = str_replace('-', '_', $locale);
        if (!preg_match('/^[a-z]{2}_[A-Z]{2}$/', $locale)) {
            $parts = explode('_', $locale, 2);
            if (count($parts) === 2) {
                $locale = strtolower($parts[0]) . '_' . strtoupper($parts[1]);
            }
        }

        return preg_match('/^[a-z]{2}_[A-Z]{2}$/', $locale) ? $locale : '';
    }
}
