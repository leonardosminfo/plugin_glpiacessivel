<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Application\DynamicForm\DynamicFormFacade;
use GlpiPlugin\Glpiacessivel\Domain\Pii\PiiMasker;
use GlpiPlugin\Glpiacessivel\Domain\Security\Authorization;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\TicketCreationPolicy;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\TicketPolicy;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\TicketRepository;
use GlpiPlugin\Glpiacessivel\Support\FormValidationException;
use GlpiPlugin\Glpiacessivel\Support\UploadedFileMapper;

final class TicketService
{
    /** @var TicketRepository */
    private $repository;
    /** @var TicketPolicy */
    private $policy;
    /** @var TicketCreationPolicy */
    private $creationPolicy;
    /** @var AuditLogger */
    private $auditLogger;
    /** @var PiiMasker */
    private $piiMasker;
    /** @var Authorization */
    private $authorization;
    /** @var ConfigService */
    private $configService;

    public function __construct(
        TicketRepository $repository,
        TicketPolicy $policy,
        TicketCreationPolicy $creationPolicy,
        AuditLogger $auditLogger,
        PiiMasker $piiMasker,
        Authorization $authorization,
        ConfigService $configService
    ) {
        $this->repository = $repository;
        $this->policy = $policy;
        $this->creationPolicy = $creationPolicy;
        $this->auditLogger = $auditLogger;
        $this->piiMasker = $piiMasker;
        $this->authorization = $authorization;
        $this->configService = $configService;
    }

    public function list(array $filters): array
    {
        $this->ensureCanView();
        $data = $this->repository->listTickets($filters);

        $this->auditLogger->log('ticket.list', [
            'scope' => (string) ($filters['scope'] ?? 'all'),
            'status' => (string) ($filters['status'] ?? ''),
            'page' => (int) ($filters['page'] ?? 1),
            'page_size' => (int) ($data['page_size'] ?? ($filters['page_size'] ?? 20)),
            'sort' => (string) ($filters['sort'] ?? 'date_mod'),
            'direction' => strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC',
            'count' => count($data['items']),
            'total' => (int) ($data['total'] ?? 0),
            'backend' => (string) ($data['backend'] ?? 'unknown'),
            'backend_reason' => (string) ($data['backend_reason'] ?? ''),
            'filters' => [
                'scope' => (string) ($filters['scope'] ?? 'all'),
                'status' => (string) ($filters['status'] ?? ''),
                'q_len' => strlen((string) ($filters['q'] ?? '')),
                'group_id' => (int) ($filters['group_id'] ?? 0),
                'group_by' => (string) ($filters['group_by'] ?? 'none'),
            ],
        ]);

        return $data;
    }

    /**
     * @param array<int, array<string, mixed>> $fallbackItems
     * @return array<int, array{id:int,label:string}>
     */
    public function groupFilterOptions(array $fallbackItems = []): array
    {
        $this->ensureCanView();
        return $this->repository->getTicketGroupFilterOptions($fallbackItems);
    }

    public function creationContext(array $input = []): array
    {
        if (!$this->authorization->canCreateTickets()) {
            throw new \RuntimeException('Usuario sem permissao para criar chamados.');
        }

        $context = $this->repository->getTicketCreationContext();
        $templateId = max(0, (int) ($input['tickettemplates_id'] ?? 0));
        if ($templateId > 0) {
            $template = $this->repository->getTicketTemplateMetadata($templateId);
            if ($template !== null) {
                $context['selected_ticket_template'] = $template;
                $context['field_requirements'] = array_merge(
                    (array) ($context['field_requirements'] ?? []),
                    (array) ($template['field_requirements'] ?? [])
                );
                if (!empty($template['requires_native_fallback'])) {
                    $context['requires_native_fallback'] = true;
                    $unsupported = array_values(array_map('strval', (array) ($template['unsupported_required'] ?? [])));
                    $context['native_fallback_reasons'][] = $unsupported === []
                        ? 'O modelo selecionado exige campos ainda nao suportados neste formulario acessivel. Use o formulario nativo do GLPI.'
                        : 'O modelo selecionado exige campos nao suportados neste formulario acessivel: ' . implode(', ', $unsupported) . '. Use o formulario nativo do GLPI.';
                }
            }
        }

        $context['dynamic_form_schema'] = (new DynamicFormFacade())->ticketCreationSchema($context)->toArray();

        return $context;
    }

    public function create(array $input): int
    {
        if (!$this->authorization->canCreateTickets()) {
            throw new \RuntimeException('Usuario sem permissao para criar chamados.');
        }

        $context = $this->creationContext($input);
        $templateId = max(0, (int) ($input['tickettemplates_id'] ?? 0));
        $template = is_array($context['selected_ticket_template'] ?? null) ? $context['selected_ticket_template'] : null;
        if ($templateId > 0 && $template === null) {
            throw new FormValidationException([[
                'field' => 'tickettemplates_id',
                'code' => 'invalid_template',
                'message' => 'Modelo de chamado invalido para o contexto atual.',
            ]]);
        }
        if ($template !== null) {
            $input = $this->enforceTemplatePolicy($input, $template);
        }

        $name = trim((string) ($input['name'] ?? ''));
        if ($name === '') {
            throw new \RuntimeException('Informe o titulo do chamado.');
        }

        $content = trim((string) ($input['content'] ?? ''));
        if ($content === '') {
            throw new \RuntimeException('Informe a descricao do chamado.');
        }

        $dynamicErrors = (new DynamicFormFacade())->validateTicketCreation($context, $input);
        if ($dynamicErrors !== []) {
            throw new FormValidationException($dynamicErrors);
        }

        $categoryId = (int) ($input['itilcategories_id'] ?? 0);
        if ($categoryId > 0) {
            $categories = $context['categories'] ?? [];
            $selectedCategory = null;
            foreach ($categories as $category) {
                if ((int) ($category['id'] ?? 0) === $categoryId) {
                    $selectedCategory = $category;
                    break;
                }
            }

            if ($selectedCategory === null) {
                throw new \RuntimeException('Categoria invalida para o contexto atual.');
            }

            $type = (int) ($input['type'] ?? 0);
            $isIncident = !empty($selectedCategory['is_incident']);
            $isRequest = !empty($selectedCategory['is_request']);
            if (($type === 1 && !$isIncident) || ($type === 2 && !$isRequest)) {
                throw new \RuntimeException('A categoria selecionada nao pode ser usada com esse tipo de chamado.');
            }
        }

        $locationId = (int) ($input['locations_id'] ?? 0);
        if ($locationId > 0) {
            $locations = $context['locations'] ?? [];
            $selectedLocation = null;
            foreach ($locations as $location) {
                if ((int) ($location['id'] ?? 0) === $locationId) {
                    $selectedLocation = $location;
                    break;
                }
            }

            if ($selectedLocation === null) {
                throw new \RuntimeException('Localizacao invalida para a entidade ativa.');
            }
        }

        $assignableUsers = [];
        foreach (($context['assignable_users'] ?? []) as $user) {
            $assignableUsers[(int) ($user['id'] ?? 0)] = true;
        }

        foreach (['_users_id_assign', '_users_id_observer'] as $actorField) {
            $ids = array_values(array_filter(array_map('intval', (array) ($input[$actorField] ?? []))));
            foreach ($ids as $id) {
                if (!isset($assignableUsers[$id])) {
                    throw new \RuntimeException('Ator selecionado invalido para o contexto atual.');
                }
            }
            $input[$actorField] = $ids;
        }

        $groupFields = [
            '_groups_id_assign' => [
                'context' => 'assignable_groups',
                'error' => 'Grupo tecnico invalido para o contexto atual.',
            ],
            '_groups_id_observer' => [
                'context' => 'observer_groups',
                'error' => 'Grupo observador invalido para o contexto atual.',
            ],
        ];
        foreach ($groupFields as $field => $contract) {
            $allowedGroups = [];
            foreach ((array) ($context[$contract['context']] ?? []) as $group) {
                $id = (int) ($group['id'] ?? 0);
                if ($id > 0) {
                    $allowedGroups[$id] = true;
                }
            }
            $groupIds = array_values(array_unique(array_filter(
                array_map('intval', (array) ($input[$field] ?? [])),
                static fn(int $id): bool => $id > 0
            )));
            foreach ($groupIds as $groupId) {
                if (!isset($allowedGroups[$groupId])) {
                    throw new \RuntimeException($contract['error']);
                }
            }
            $input[$field] = $groupIds;
        }

        $requestSourceId = (int) ($input['requesttypes_id'] ?? 0);
        if ($requestSourceId > 0 && !empty($context['request_source_supported'])) {
            $allowedSources = [];
            foreach (($context['request_source_options'] ?? []) as $source) {
                $allowedSources[(int) ($source['id'] ?? 0)] = true;
            }
            if (!isset($allowedSources[$requestSourceId])) {
                throw new \RuntimeException('Origem da requisicao invalida.');
            }
        }

        $externalId = trim((string) ($input['externalid'] ?? ''));
        if ($externalId !== '' && mb_strlen($externalId) > 255) {
            throw new \RuntimeException('ID externo deve ter no maximo 255 caracteres.');
        }
        $input['externalid'] = $externalId;

        $ticketId = $this->repository->createTicket($input);
        UploadedFileMapper::commit($input);
        $attachmentsCount = count((array) ($input['_filename'] ?? []));
        if ($attachmentsCount > 0) {
            $attachmentDiagnostics = $this->repository->ticketDocumentLinkDiagnostics(
                $ticketId,
                $attachmentsCount,
                $this->expectedAttachmentNames($input)
            );
            if (empty($attachmentDiagnostics['available']) || empty($attachmentDiagnostics['complete'])) {
                $this->auditLogger->log('ticket.create.attachment_unverified', [
                    'attachments_count' => $attachmentsCount,
                    'diagnostic_reason' => (string) ($attachmentDiagnostics['reason'] ?? 'unknown'),
                    'linked_count' => (int) ($attachmentDiagnostics['linked'] ?? 0),
                ], $ticketId);

                throw new FormValidationException([[
                    'field' => 'filename',
                    'code' => 'document_link_unverified',
                    'message' => 'Chamado criado, mas o vinculo do anexo ainda nao foi confirmado pelo GLPI. Nao reenvie o arquivo; abra o chamado para verificar.',
                ]], 'Vinculo do anexo pendente.', [
                    'partial_success' => true,
                    'created_ticket_id' => $ticketId,
                    'attachment_diagnostics' => $attachmentDiagnostics,
                ]);
            }
        }

        $this->auditLogger->log('ticket.create', [
            'type' => (int) ($input['type'] ?? 0),
            'itilcategories_id' => (int) ($input['itilcategories_id'] ?? 0),
            'locations_id' => $locationId,
            'urgency' => (int) ($input['urgency'] ?? 0),
            'impact' => (int) ($input['impact'] ?? 0),
            'assignees_count' => count((array) ($input['_users_id_assign'] ?? [])),
            'watchers_count' => count((array) ($input['_users_id_observer'] ?? [])),
            'groups_count' => count((array) ($input['_groups_id_assign'] ?? [])),
            'observer_groups_count' => count((array) ($input['_groups_id_observer'] ?? [])),
            'attachments_count' => count((array) ($input['_filename'] ?? [])),
            'requesttypes_id' => (int) ($input['requesttypes_id'] ?? 0),
            'externalid_informed' => $externalId !== '',
        ], $ticketId);

        return $ticketId;
    }

    /**
     * @param array<string, mixed> $input
     * @param array<string, mixed> $template
     * @return array<string, mixed>
     */
    private function enforceTemplatePolicy(array $input, array $template): array
    {
        $predefined = (array) ($template['predefined'] ?? []);
        $protected = array_unique(array_merge(
            (array) ($template['hidden_fields'] ?? []),
            (array) ($template['readonly_fields'] ?? [])
        ));

        $errors = [];
        foreach (TicketCreationPolicy::SUPPORTED_CREATE_FIELDS as $field) {
            if ($field === '_filename' || !array_key_exists($field, $input)) {
                continue;
            }

            if (array_key_exists($field, $predefined) && !$this->templateValuesEqual($input[$field], $predefined[$field])) {
                $errors[] = [
                    'field' => $field,
                    'code' => 'template_value_mismatch',
                    'message' => TicketCreationPolicy::fieldLabel($field) . ' deve manter o valor definido pelo modelo.',
                ];
                continue;
            }

            if (in_array($field, $protected, true) && !array_key_exists($field, $predefined) && $this->hasTemplateValue($input[$field])) {
                $errors[] = [
                    'field' => $field,
                    'code' => 'template_protected_field',
                    'message' => TicketCreationPolicy::fieldLabel($field) . ' nao pode ser alterado neste modelo.',
                ];
            }
        }
        if ($errors !== []) {
            throw new FormValidationException($errors);
        }

        foreach ($protected as $field) {
            $field = (string) $field;
            if (!in_array($field, TicketCreationPolicy::SUPPORTED_CREATE_FIELDS, true) || $field === '_filename') {
                continue;
            }

            if (array_key_exists($field, $predefined)) {
                $input[$field] = $predefined[$field];
            } else {
                unset($input[$field]);
            }
        }

        foreach (TicketCreationPolicy::SUPPORTED_CREATE_FIELDS as $field) {
            if ($field === '_filename' || !array_key_exists($field, $predefined)) {
                continue;
            }

            $input[$field] = $predefined[$field];
        }

        return $input;
    }

    private function templateValuesEqual(mixed $left, mixed $right): bool
    {
        if (is_array($left) || is_array($right)) {
            $normalize = static function (mixed $value): array {
                $items = array_map('strval', (array) $value);
                sort($items);
                return $items;
            };

            return $normalize($left) === $normalize($right);
        }

        return trim((string) $left) === trim((string) $right);
    }

    private function hasTemplateValue(mixed $value): bool
    {
        if (is_array($value)) {
            return array_values(array_filter($value, static fn(mixed $item): bool => trim((string) $item) !== '')) !== [];
        }

        $value = trim((string) $value);
        return $value !== '' && $value !== '0';
    }

    /**
     * @param string[] $revealedFields
     */
    public function detail(int $ticketId, array $revealedFields = []): ?array
    {
        $this->ensureCanView();
        $ticket = $this->repository->getTicketById($ticketId);
        if ($ticket === null) {
            return null;
        }

        $contact = $this->repository->getTicketRequesterContact($ticketId);
        $maskContacts = $this->configService->isPiiMaskingEnabled();
        $canReveal = $maskContacts
            && $this->authorization->canRevealPii()
            && $this->repository->canUpdateTicket($ticketId);
        $ticket['requester_email'] = (string) ($contact['email'] ?? '');
        $ticket['requester_phone'] = (string) ($contact['phone'] ?? '');
        $ticket['requester_mobile'] = (string) ($contact['mobile'] ?? '');
        $revealedFields = array_values(array_intersect(
            $revealedFields,
            ['requester_email', 'requester_phone', 'requester_mobile']
        ));
        if ($maskContacts) {
            $ticket['requester_email'] = $this->piiMasker->maskEmail($ticket['requester_email']);
            $ticket['requester_phone'] = $this->piiMasker->maskPhone($ticket['requester_phone']);
            $ticket['requester_mobile'] = $this->piiMasker->maskPhone($ticket['requester_mobile']);
            if ($canReveal) {
                foreach ($revealedFields as $field) {
                    $contactField = substr($field, strlen('requester_'));
                    $ticket[$field] = (string) ($contact[$contactField] ?? '');
                }
            }
        }
        $ticket['pii_masking_enabled'] = $maskContacts;
        $ticket['can_reveal_pii'] = $canReveal;
        $ticket['revealed_pii_fields'] = $maskContacts ? $revealedFields : [];

        $ticket['timeline'] = $this->repository->getTicketTimeline($ticketId);
        $ticket['history_context'] = $this->repository->getTicketHistoryContext($ticketId);
        $ticket['actors'] = $this->repository->getTicketActors($ticketId);
        $ticket['documents'] = $this->repository->getTicketDocuments($ticketId);
        $ticket['allowed_transitions'] = method_exists($this->repository, 'getAllowedStatusTransitions')
            ? $this->repository->getAllowedStatusTransitions($ticketId)
            : $this->policy->getAllowedTransitions((int) ($ticket['status'] ?? 0));
        $ticket['itil_actions'] = $this->repository->getTicketActionContext($ticketId);
        $ticket['routing_context'] = $this->repository->getTicketRoutingContext($ticketId);
        $ticket['satisfaction_state'] = $this->repository->getTicketSatisfactionState($ticketId);
        $ticket['followup_templates'] = !empty($ticket['itil_actions']['can_add_followup'])
            ? $this->repository->getFollowupTemplatesForTicket($ticketId)
            : [];

        $this->auditLogger->log('ticket.detail', [
            'can_add_followup' => !empty($ticket['itil_actions']['can_add_followup']),
            'can_add_task' => !empty($ticket['itil_actions']['can_add_task']),
            'routing_can_update' => !empty($ticket['routing_context']['can_update']),
            'satisfaction_available' => !empty($ticket['satisfaction_state']['available']),
            'followup_templates_count' => count((array) ($ticket['followup_templates'] ?? [])),
            'history_can_view' => !empty($ticket['history_context']['can_view']),
            'history_available' => !empty($ticket['history_context']['available']),
            'history_count' => count((array) ($ticket['history_context']['items'] ?? [])),
        ], $ticketId);

        return $ticket;
    }

    public function revealPii(int $ticketId, string $field, ?string $reason): void
    {
        if (!$this->configService->isPiiMaskingEnabled()) {
            throw new \RuntimeException('O mascaramento de contatos pessoais esta desativado.');
        }

        if (!$this->authorization->canRevealPii()) {
            throw new \RuntimeException('Sem permissao para revelar PII.');
        }

        if ($this->repository->getTicketById($ticketId) === null) {
            throw new \RuntimeException('Chamado nao encontrado ou sem acesso.');
        }

        if (!$this->repository->canUpdateTicket($ticketId)) {
            throw new \RuntimeException('Sem permissao no chamado para revelar PII.');
        }

        if (trim((string) $reason) === '') {
            throw new \RuntimeException('Informe o motivo da revelacao de PII.');
        }

        $this->auditLogger->logPiiReveal($ticketId, $field, $reason);
    }

    public function resolveFollowupPrivacy(
        int $ticketId,
        int $followupTemplateId,
        int $requestedPrivacy
    ): int {
        $isPrivate = $requestedPrivacy === 1 ? 1 : 0;
        if (method_exists($this->repository, 'resolveFollowupPrivacy')) {
            return (int) $this->repository->resolveFollowupPrivacy(
                $ticketId,
                $followupTemplateId,
                $isPrivate
            );
        }

        return $isPrivate;
    }

    public function addFollowup(
        int $ticketId,
        string $content,
        array $filesPayload = [],
        int $followupTemplateId = 0,
        int $isPrivate = 0
    ): bool {
        $isPrivate = $this->resolveFollowupPrivacy($ticketId, $followupTemplateId, $isPrivate);
        if (!$this->repository->canAddFollowupToTicket($ticketId, $isPrivate)) {
            throw new \RuntimeException('Sem permissao para adicionar acompanhamento neste chamado.');
        }
        $this->ensureOperationalActionAllowed($ticketId);

        if (trim($content) === '' && $followupTemplateId > 0) {
            $content = $this->repository->renderFollowupTemplateContent($ticketId, $followupTemplateId);
        }

        $created = $this->repository->addFollowup(
            $ticketId,
            $content,
            $filesPayload,
            $followupTemplateId,
            $isPrivate
        );
        $ok = (bool) $created;
        if ($ok) {
            UploadedFileMapper::commit($filesPayload);
            $attachmentsCount = count((array) ($filesPayload['_filename'] ?? []));
            $this->confirmOperationAttachments(
                'ITILFollowup',
                is_int($created) ? $created : 0,
                $attachmentsCount,
                $filesPayload,
                'followup_document',
                'ticket.followup.attachment_unverified',
                $ticketId
            );
            $this->auditLogger->log('ticket.followup.add', [
                'length' => strlen($content),
                'attachments_count' => $attachmentsCount,
                'itilfollowuptemplates_id' => max(0, $followupTemplateId),
                'is_private' => $isPrivate,
            ], $ticketId);
        }

        return $ok;
    }

    public function addTask(int $ticketId, string $content, array $taskInput = [], array $filesPayload = []): bool
    {
        $taskInput['is_private'] = !empty($taskInput['is_private']) ? 1 : 0;
        if (!$this->repository->canAddTaskToTicket($ticketId, (int) $taskInput['is_private'])) {
            throw new \RuntimeException('Sem permissao para adicionar tarefa neste chamado.');
        }
        $this->ensureOperationalActionAllowed($ticketId);
        if (trim($content) === '') {
            throw new \RuntimeException('Informe a descricao da tarefa.');
        }

        $routing = $this->repository->getTicketRoutingContext($ticketId);
        $this->assertOptionAllowed((int) ($taskInput['users_id_tech'] ?? 0), (array) ($routing['assignable_users'] ?? []), 'Tecnico invalido para este perfil ou entidade.');
        $this->assertOptionAllowed((int) ($taskInput['groups_id_tech'] ?? 0), (array) ($routing['assignable_groups'] ?? []), 'Grupo tecnico invalido para este perfil ou entidade.');
        $this->assertOptionAllowed((int) ($taskInput['taskcategories_id'] ?? 0), (array) ($routing['task_categories'] ?? []), 'Categoria de tarefa invalida para este perfil ou entidade.');
        $this->assertOptionAllowed((int) ($taskInput['state'] ?? 0), (array) ($routing['task_state_options'] ?? []), 'Estado da tarefa invalido.');
        $this->assertOptionAllowed((int) ($taskInput['actiontime'] ?? 0), (array) ($routing['task_duration_options'] ?? []), 'Duracao da tarefa invalida.');

        $begin = trim((string) ($taskInput['begin'] ?? ''));
        $end = trim((string) ($taskInput['end'] ?? ''));
        if ($begin !== '' && strtotime(str_replace('T', ' ', $begin)) === false) {
            throw new \RuntimeException('Data inicial da tarefa invalida.');
        }
        if ($end !== '' && strtotime(str_replace('T', ' ', $end)) === false) {
            throw new \RuntimeException('Data final da tarefa invalida.');
        }
        if (
            $begin !== ''
            && $end !== ''
            && strtotime(str_replace('T', ' ', $end)) <= strtotime(str_replace('T', ' ', $begin))
        ) {
            throw new \RuntimeException('A data final da tarefa deve ser posterior a data inicial.');
        }

        $created = $this->repository->addTask($ticketId, $content, $taskInput, $filesPayload);
        $ok = (bool) $created;
        if ($ok) {
            UploadedFileMapper::commit($filesPayload);
            $attachmentsCount = count((array) ($filesPayload['_filename'] ?? []));
            $this->confirmOperationAttachments(
                'TicketTask',
                is_int($created) ? $created : 0,
                $attachmentsCount,
                $filesPayload,
                'task_document',
                'ticket.task.attachment_unverified',
                $ticketId
            );
            $this->auditLogger->log('ticket.task.add', [
                'length' => strlen($content),
                'state' => (int) ($taskInput['state'] ?? 0),
                'taskcategories_id' => (int) ($taskInput['taskcategories_id'] ?? 0),
                'users_id_tech' => (int) ($taskInput['users_id_tech'] ?? 0),
                'groups_id_tech' => (int) ($taskInput['groups_id_tech'] ?? 0),
                'is_private' => !empty($taskInput['is_private']) ? 1 : 0,
                'attachments_count' => $attachmentsCount,
            ], $ticketId);
        }

        return $ok;
    }
    public function addSolution(int $ticketId, string $content): bool
    {
        if (!$this->repository->canAddSolutionToTicket($ticketId)) {
            throw new \RuntimeException('Sem permissao para adicionar solucao neste chamado.');
        }
        $this->ensureOperationalActionAllowed($ticketId);

        $ok = $this->repository->addSolution($ticketId, $content);
        if ($ok) {
            $this->auditLogger->log('ticket.solution.add', ['length' => strlen($content)], $ticketId);
        }

        return $ok;
    }

    public function changeStatus(int $ticketId, int $newStatus): bool
    {
        if (!$this->repository->canChangeStatusToTicket($ticketId)) {
            throw new \RuntimeException('Sem permissao para alterar status neste chamado.');
        }
        $this->ensureOperationalActionAllowed($ticketId);

        $current = $this->repository->getTicketById($ticketId);
        if ($current === null) {
            return false;
        }

        $currentStatus = (int) ($current['status'] ?? 0);
        $transitionAllowed = method_exists($this->repository, 'isStatusTransitionAllowed')
            ? $this->repository->isStatusTransitionAllowed($ticketId, $newStatus)
            : $this->policy->isTransitionAllowed($currentStatus, $newStatus);
        if (!$transitionAllowed) {
            throw new \RuntimeException('Status alvo invalido para o fluxo atual.');
        }

        $ok = $this->repository->changeStatus($ticketId, $newStatus);
        if ($ok) {
            $this->auditLogger->log('ticket.status.change', [
                'from' => $currentStatus,
                'to' => $newStatus,
            ], $ticketId);
        }

        return $ok;
    }

    public function approveSolution(int $ticketId, string $comment = '', array $filesPayload = []): bool
    {
        $this->ensureCanDecideSolution($ticketId);

        $ok = $this->repository->approveSolution($ticketId, $comment, $filesPayload);
        if ($ok) {
            UploadedFileMapper::commit($filesPayload);
            $this->auditLogger->log('ticket.solution.approve', [
                'comment_len' => strlen(trim($comment)),
                'attachments_count' => count((array) ($filesPayload['_filename'] ?? [])),
            ], $ticketId);
        }

        return $ok;
    }

    public function refuseSolution(int $ticketId, string $comment, array $filesPayload = []): bool
    {
        $this->ensureCanDecideSolution($ticketId);
        if (trim($comment) === '') {
            throw new \RuntimeException('Informe o motivo da recusa da solucao.');
        }

        $ok = $this->repository->refuseSolution($ticketId, $comment, $filesPayload);
        if ($ok) {
            UploadedFileMapper::commit($filesPayload);
            $this->auditLogger->log('ticket.solution.refuse', [
                'comment_len' => strlen(trim($comment)),
                'attachments_count' => count((array) ($filesPayload['_filename'] ?? [])),
            ], $ticketId);
        }

        return $ok;
    }

    public function registerRequesterDecision(int $ticketId, int $decision, string $comment): bool
    {
        $ticket = $this->repository->getTicketById($ticketId);
        if ($ticket === null) {
            throw new \RuntimeException('Chamado nao encontrado ou sem acesso.');
        }

        $requesterId = (int) ($ticket['requester_id'] ?? 0);
        $currentUser = (int) ($_SESSION['glpiID'] ?? 0);
        if ($requesterId <= 0 || ($requesterId !== $currentUser && !$this->authorization->canUpdateTickets())) {
            throw new \RuntimeException('Apenas o requisitante ou perfis tecnicos podem registrar a decisao.');
        }

        if ($decision < 1 || $decision > 5) {
            throw new \RuntimeException('Nota de satisfacao invalida.');
        }

        $satisfactionState = $this->repository->getTicketSatisfactionState($ticketId);
        if (empty($satisfactionState['available']) || empty($satisfactionState['can_answer'])) {
            throw new \RuntimeException('Pesquisa de satisfacao indisponivel para este chamado.');
        }

        $ok = $this->repository->applyRequesterDecision($ticketId, $decision, $comment);
        if ($ok) {
            $this->auditLogger->log('ticket.requester_decision', [
                'decision' => $decision,
                'comment_len' => strlen($comment),
            ], $ticketId);
        }

        return $ok;
    }

    public function escalateTicketRouting(
        int $ticketId,
        array $assignees,
        array $watchers,
        string $reason = '',
        array $groups = [],
        array $observerGroups = []
    ): bool {
        if (!method_exists($this->repository, 'canRouteTicket') || !$this->repository->canRouteTicket($ticketId)) {
            throw new \RuntimeException('Sem permissao no chamado para escalonamento.');
        }
        $this->ensureOperationalActionAllowed($ticketId);

        $ticket = $this->repository->getTicketById($ticketId);
        if ($ticket === null) {
            throw new \RuntimeException('Chamado nao encontrado ou sem acesso.');
        }

        $assignees = array_values(array_unique(array_filter(array_map('intval', $assignees), static fn(int $id): bool => $id > 0)));
        $watchers = array_values(array_unique(array_filter(array_map('intval', $watchers), static fn(int $id): bool => $id > 0)));
        $groups = array_values(array_unique(array_filter(array_map('intval', $groups), static fn(int $id): bool => $id > 0)));
        $observerGroups = array_values(array_unique(array_filter(
            array_map('intval', $observerGroups),
            static fn(int $id): bool => $id > 0
        )));
        $routingContext = $this->repository->getTicketRoutingContext($ticketId);

        $allowedUsers = [];
        foreach (($routingContext['assignable_users'] ?? []) as $user) {
            $allowedUsers[(int) ($user['id'] ?? 0)] = true;
        }

        foreach ([$assignees, $watchers] as $bucket) {
            foreach ($bucket as $id) {
                if (!isset($allowedUsers[$id])) {
                    throw new \RuntimeException('Ator invalido para a entidade ativa.');
                }
            }
        }

        $allowedGroups = [];
        foreach (($routingContext['assignable_groups'] ?? []) as $group) {
            $allowedGroups[(int) ($group['id'] ?? 0)] = true;
        }
        foreach ($groups as $id) {
            if (!isset($allowedGroups[$id])) {
                throw new \RuntimeException('Grupo tecnico invalido para a entidade ativa.');
            }
        }

        $allowedObserverGroups = [];
        foreach (($routingContext['observer_groups'] ?? []) as $group) {
            $allowedObserverGroups[(int) ($group['id'] ?? 0)] = true;
        }
        foreach ($observerGroups as $id) {
            if (!isset($allowedObserverGroups[$id])) {
                throw new \RuntimeException('Grupo observador invalido para a entidade ativa.');
            }
        }

        $ok = $this->repository->updateTicketFields($ticketId, [
            '_users_id_assign' => $assignees,
            '_users_id_observer' => $watchers,
            '_groups_id_assign' => $groups,
            '_groups_id_observer' => $observerGroups,
        ]);
        if ($ok) {
            $this->auditLogger->log('ticket.routing.escalate', [
                'assignees_count' => count($assignees),
                'watchers_count' => count($watchers),
                'groups_count' => count($groups),
                'observer_groups_count' => count($observerGroups),
                'reason_len' => strlen(trim($reason)),
            ], $ticketId);
        }

        return $ok;
    }

    public function reclassifyTicket(int $ticketId, int $categoryId, ?int $type = null, string $reason = ''): bool
    {
        if (!$this->authorization->canUpdateTickets()) {
            throw new \RuntimeException('Sem permissao para reclassificar chamado.');
        }
        if (!$this->repository->canUpdateTicket($ticketId)) {
            throw new \RuntimeException('Sem permissao no chamado para reclassificacao.');
        }
        $this->ensureOperationalActionAllowed($ticketId);

        $ticket = $this->repository->getTicketById($ticketId);
        if ($ticket === null) {
            throw new \RuntimeException('Chamado nao encontrado ou sem acesso.');
        }

        if ($categoryId <= 0) {
            throw new \RuntimeException('Informe uma categoria valida.');
        }

        $context = $this->repository->getTicketCreationContext();
        $selectedCategory = null;
        foreach (($context['categories'] ?? []) as $category) {
            if ((int) ($category['id'] ?? 0) === $categoryId) {
                $selectedCategory = $category;
                break;
            }
        }
        if ($selectedCategory === null) {
            throw new \RuntimeException('Categoria invalida para o contexto atual.');
        }

        if ($type !== null) {
            $incidentType = 1;
            $requestType = 2;
            foreach (($context['type_options'] ?? []) as $option) {
                $label = mb_strtolower((string) ($option['label'] ?? ''), 'UTF-8');
                if (str_contains($label, 'incidente')) {
                    $incidentType = (int) ($option['id'] ?? $incidentType);
                }
                if (str_contains($label, 'requis')) {
                    $requestType = (int) ($option['id'] ?? $requestType);
                }
            }

            $isIncident = !empty($selectedCategory['is_incident']);
            $isRequest = !empty($selectedCategory['is_request']);
            if (($type === $incidentType && !$isIncident) || ($type === $requestType && !$isRequest)) {
                throw new \RuntimeException('Categoria nao compativel com o tipo informado.');
            }
        }

        $payload = ['itilcategories_id' => $categoryId];
        if ($type !== null) {
            $payload['type'] = $type;
        }

        $ok = $this->repository->updateTicketFields($ticketId, $payload);
        if ($ok) {
            $this->auditLogger->log('ticket.reclassify', [
                'itilcategories_id' => $categoryId,
                'type' => $type ?? 0,
                'reason_len' => strlen(trim($reason)),
            ], $ticketId);
        }

        return $ok;
    }

    public function reprioritizeTicket(int $ticketId, int $urgency, int $impact, string $reason = ''): bool
    {
        if (!$this->authorization->canUpdateTickets()) {
            throw new \RuntimeException('Sem permissao para priorizar chamado.');
        }
        if (!$this->repository->canUpdateTicket($ticketId)) {
            throw new \RuntimeException('Sem permissao no chamado para priorizacao.');
        }
        $this->ensureOperationalActionAllowed($ticketId);

        $ticket = $this->repository->getTicketById($ticketId);
        if ($ticket === null) {
            throw new \RuntimeException('Chamado nao encontrado ou sem acesso.');
        }

        if ($urgency < 1 || $urgency > 5 || $impact < 1 || $impact > 5) {
            throw new \RuntimeException('Urgencia e impacto devem estar entre 1 e 5.');
        }

        $ok = $this->repository->updateTicketFields($ticketId, [
            'urgency' => $urgency,
            'impact' => $impact,
        ]);
        if ($ok) {
            $this->auditLogger->log('ticket.reprioritize', [
                'urgency' => $urgency,
                'impact' => $impact,
                'reason_len' => strlen(trim($reason)),
            ], $ticketId);
        }

        return $ok;
    }

    public function cockpitMetrics(): array
    {
        $this->ensureCanView();
        $metrics = $this->repository->getCockpitMetrics();
        $this->auditLogger->log('cockpit.view', $metrics);
        return $metrics;
    }

    /**
     * @return string[]
     */
    private function expectedAttachmentNames(array $payload): array
    {
        $storedNames = array_values(array_map('strval', (array) ($payload['_filename'] ?? [])));
        $prefixes = array_values(array_map('strval', (array) ($payload['_prefix_filename'] ?? [])));
        $names = [];
        foreach ($storedNames as $index => $storedName) {
            $storedName = basename($storedName);
            $prefix = (string) ($prefixes[$index] ?? '');
            $name = $prefix !== '' && str_starts_with($storedName, $prefix)
                ? substr($storedName, strlen($prefix))
                : $storedName;
            if ($name !== '') {
                $names[] = $name;
            }
        }

        return array_values(array_unique($names));
    }

    private function confirmOperationAttachments(
        string $itemtype,
        int $itemId,
        int $attachmentsCount,
        array $filesPayload,
        string $field,
        string $auditEvent,
        int $ticketId
    ): void {
        if ($attachmentsCount <= 0) {
            return;
        }

        $diagnostics = $itemId > 0 && method_exists($this->repository, 'documentItemLinkDiagnostics')
            ? $this->repository->documentItemLinkDiagnostics(
                $itemtype,
                $itemId,
                $attachmentsCount,
                $this->expectedAttachmentNames($filesPayload)
            )
            : [
                'available' => false,
                'complete' => false,
                'reason' => 'created_item_id_unavailable',
                'linked' => 0,
            ];

        if (!empty($diagnostics['available']) && !empty($diagnostics['complete'])) {
            return;
        }

        $this->auditLogger->log($auditEvent, [
            'attachments_count' => $attachmentsCount,
            'diagnostic_reason' => (string) ($diagnostics['reason'] ?? 'unknown'),
            'linked_count' => (int) ($diagnostics['linked'] ?? 0),
            'created_itemtype' => $itemtype,
            'created_item_id' => $itemId,
        ], $ticketId);

        throw new FormValidationException([[
            'field' => $field,
            'code' => 'document_link_unverified',
            'message' => 'A acao foi registrada, mas o vinculo do anexo ainda nao foi confirmado pelo GLPI. '
                . 'Nao reenvie o arquivo; atualize o chamado para verificar.',
        ]], 'Vinculo do anexo pendente.', [
            'partial_success' => true,
            'created_itemtype' => $itemtype,
            'created_item_id' => $itemId,
            'ticket_id' => $ticketId,
            'attachment_diagnostics' => $diagnostics,
        ]);
    }
    private function ensureCanView(): void
    {
        if (!$this->authorization->canViewTickets()) {
            throw new \RuntimeException('Usuario sem permissao para visualizar chamados.');
        }
    }

    private function ensureOperationalActionAllowed(int $ticketId): void
    {
        $ticket = $this->repository->getTicketById($ticketId);
        if ($ticket === null) {
            throw new \RuntimeException('Chamado nao encontrado ou sem acesso.');
        }

        $status = (int) ($ticket['status'] ?? 0);
        if ($status === $this->solvedStatus() || $status === $this->closedStatus()) {
            throw new \RuntimeException('Este chamado ja esta solucionado ou fechado. Use o fluxo de aprovacao ou recusa da solucao quando disponivel.');
        }
    }

    private function ensureCanDecideSolution(int $ticketId): void
    {
        $ticket = $this->repository->getTicketById($ticketId);
        if ($ticket === null) {
            throw new \RuntimeException('Chamado nao encontrado ou sem acesso.');
        }

        if ((int) ($ticket['status'] ?? 0) !== $this->solvedStatus()) {
            throw new \RuntimeException('A aprovacao da solucao esta disponivel apenas para chamados solucionados.');
        }

        $requesterId = (int) ($ticket['requester_id'] ?? 0);
        $currentUser = (int) ($_SESSION['glpiID'] ?? 0);
        if ($requesterId <= 0 || ($requesterId !== $currentUser && !$this->authorization->canUpdateTickets())) {
            throw new \RuntimeException('Apenas o requisitante ou perfil tecnico permitido pode aprovar ou recusar a solucao.');
        }
    }

    private function solvedStatus(): int
    {
        return defined('\CommonITILObject::SOLVED') ? (int) \CommonITILObject::SOLVED : 5;
    }

    private function closedStatus(): int
    {
        return defined('\CommonITILObject::CLOSED') ? (int) \CommonITILObject::CLOSED : 6;
    }

    /**
     * @param array<int, array{id:int}> $options
     */
    private function assertOptionAllowed(int $selectedId, array $options, string $message): void
    {
        if ($selectedId <= 0) {
            return;
        }

        foreach ($options as $option) {
            if ((int) ($option['id'] ?? 0) === $selectedId) {
                return;
            }
        }

        throw new \RuntimeException($message);
    }

    private function maskTimelineContent(string $content): string
    {
        $content = preg_replace_callback(
            '/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i',
            fn(array $matches): string => $this->piiMasker->maskEmail((string) $matches[0]),
            $content
        ) ?? $content;

        return preg_replace_callback(
            '/(?<!\d)(?:\+?\d[\d\s().-]{7,}\d)/',
            fn(array $matches): string => $this->piiMasker->maskPhone((string) $matches[0]),
            $content
        ) ?? $content;
    }
}
