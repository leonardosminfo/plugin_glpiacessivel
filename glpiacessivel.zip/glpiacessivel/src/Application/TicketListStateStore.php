<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/**
 * Short-lived, session-bound description of one ticket result request.
 * The browser receives an opaque token and never receives native criteria.
 */
final class TicketListStateStore
{
    private const SESSION_KEY = 'glpiacessivel_ticket_list_states_v1';
    private const TTL_SECONDS = 300;
    private const MAX_STATES = 5;

    /** @param array<string, mixed> $filters */
    public function issue(array $filters, string $contextRevision): string
    {
        if (preg_match('/\A[a-f0-9]{64}\z/D', $contextRevision) !== 1) {
            throw new \InvalidArgumentException('ticket_list_context_invalid');
        }

        $this->prune();
        $token = bin2hex(random_bytes(24));
        $states = $this->states();
        $states[$token] = [
            'filters' => $filters,
            'context_revision' => $contextRevision,
            'created_at' => time(),
        ];
        while (count($states) > self::MAX_STATES) {
            array_shift($states);
        }
        $_SESSION[self::SESSION_KEY] = $states;

        return $token;
    }

    /** @return array<string, mixed>|null */
    public function resolve(string $token, string $contextRevision): ?array
    {
        if (
            preg_match('/\A[a-f0-9]{48}\z/D', $token) !== 1
            || preg_match('/\A[a-f0-9]{64}\z/D', $contextRevision) !== 1
        ) {
            return null;
        }

        $this->prune();
        $state = $this->states()[$token] ?? null;
        if (
            !is_array($state)
            || !is_array($state['filters'] ?? null)
            || !is_string($state['context_revision'] ?? null)
            || !hash_equals($state['context_revision'], $contextRevision)
        ) {
            return null;
        }

        return $state['filters'];
    }

    private function prune(): void
    {
        $now = time();
        $states = array_filter(
            $this->states(),
            static fn($state): bool => is_array($state)
                && is_int($state['created_at'] ?? null)
                && ($state['created_at'] + self::TTL_SECONDS) >= $now
        );
        $_SESSION[self::SESSION_KEY] = array_slice($states, -self::MAX_STATES, null, true);
    }

    /** @return array<string, array<string, mixed>> */
    private function states(): array
    {
        $states = $_SESSION[self::SESSION_KEY] ?? [];
        return is_array($states) ? $states : [];
    }
}
