<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/**
 * Session-bound, short-lived state for an applied advanced ticket search.
 *
 * The browser receives only an unpredictable token. The native criteria stay
 * in the authenticated GLPI session and are revalidated by the service before
 * every execution. This avoids truncated nested query strings during paging.
 */
final class TicketSearchStateStore
{
    private const SESSION_KEY = 'glpiacessivel_ticket_search_states_v2';
    private const TTL_SECONDS = 900;
    // Cockpit issues up to five drilldown tokens in one render. Keep enough
    // recent states so this does not immediately evict the user's advanced
    // searches while retaining a conservative, session-local memory bound.
    private const MAX_STATES = 20;

    /**
     * @param array<string,mixed> $definition
     */
    public function issue(array $definition, string $contextRevision): string
    {
        $this->prune();
        $token = bin2hex(random_bytes(24));
        $states = $this->states();
        $states[$token] = [
            'definition' => $definition,
            'context_revision' => $contextRevision,
            'created_at' => time(),
        ];

        while (count($states) > self::MAX_STATES) {
            array_shift($states);
        }
        $_SESSION[self::SESSION_KEY] = $states;

        return $token;
    }

    /**
     * @return array<string,mixed>|null
     */
    public function resolve(string $token, string $contextRevision): ?array
    {
        if (preg_match('/\A[a-f0-9]{48}\z/D', $token) !== 1) {
            return null;
        }

        $this->prune();
        $state = $this->states()[$token] ?? null;
        if (
            !is_array($state)
            || !is_array($state['definition'] ?? null)
            || !is_string($state['context_revision'] ?? null)
            || !hash_equals($state['context_revision'], $contextRevision)
        ) {
            return null;
        }

        return $state['definition'];
    }

    public function clear(): void
    {
        unset($_SESSION[self::SESSION_KEY]);
    }

    private function prune(): void
    {
        $now = time();
        $states = array_filter(
            $this->states(),
            static fn($state): bool => is_array($state)
                && is_int($state['created_at'] ?? null)
                && ($state['created_at'] + self::TTL_SECONDS) >= $now
        );
        $_SESSION[self::SESSION_KEY] = array_slice($states, -self::MAX_STATES, null, true);
    }

    /** @return array<string,array<string,mixed>> */
    private function states(): array
    {
        $states = $_SESSION[self::SESSION_KEY] ?? [];
        return is_array($states) ? $states : [];
    }
}
