<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;

final class ContextService
{
    private AuditLogger $auditLogger;

    public function __construct(AuditLogger $auditLogger)
    {
        $this->auditLogger = $auditLogger;
    }

    /**
     * @return array{
     *   current_entity_id:int,
     *   current_entity_name:string,
     *   current_entity_value:string,
     *   is_all_entities:bool,
     *   current_profile_id:int,
     *   current_profile_name:string,
     *   user_label:string,
     *   is_valid:bool,
     *   summary:string,
     *   profiles:array<int,array{id:int,name:string}>,
     *   entities:array<int|string,array{id:int|string,name:string,recursive:bool}>
     * }
     */
    public function getContext(): array
    {
        $currentEntityId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        $currentProfileId = (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0);
        $isAllEntities = $this->isAllEntitiesScope();
        $entityName = $isAllEntities ? 'Todas as entidades permitidas' : $this->currentEntityName($currentEntityId);
        $profileName = $this->profileName($currentProfileId);
        $isValid = $this->isCurrentContextValid($currentProfileId);

        return [
            'current_entity_id' => $currentEntityId,
            'current_entity_name' => $entityName,
            'current_entity_value' => $isAllEntities ? 'all' : (string) $currentEntityId,
            'is_all_entities' => $isAllEntities,
            'current_profile_id' => $currentProfileId,
            'current_profile_name' => $profileName,
            'user_label' => $this->currentUserLabel(),
            'is_valid' => $isValid,
            'summary' => $isValid
                ? sprintf('Consultando como %s na entidade %s.', $profileName, $entityName)
                : 'Contexto de entidade ou perfil nao definido.',
            'profiles' => $this->profileOptions(),
            'entities' => $this->entityOptions(),
        ];
    }

    public function hasValidContext(): bool
    {
        return !empty($this->getContext()['is_valid']);
    }

    /**
     * @return array<string, mixed>
     */
    public function switchContext(int $profileId, string $entityValue, string $returnTo = ''): array
    {
        $before = [
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
            'all_entities' => $this->isAllEntitiesScope(),
        ];

        $profileChanged = false;
        $entitySelectionAdjusted = false;
        if ($profileId > 0 && $profileId !== $before['profile_id']) {
            $profile = $_SESSION['glpiprofiles'][$profileId] ?? null;
            if (!is_array($profile) || empty($profile['entities'])) {
                throw new \RuntimeException('Perfil invalido ou sem entidade para o usuario atual.');
            }

            \Session::changeProfile($profileId);
            $this->clearContextBoundSessionState();
            if ((int) ($_SESSION['glpiactiveprofile']['id'] ?? 0) !== $profileId) {
                throw new \RuntimeException('O GLPI nao confirmou a troca de perfil.');
            }
            $profileChanged = true;
        }

        $entityValue = trim($entityValue);
        if ($profileChanged && !$this->isEntityValueAllowed($entityValue)) {
            // The form listed entities from the previous profile. Keep the
            // entity selected natively by GLPI and let the next page reload
            // the valid entity options for the new profile.
            $entitySelectionAdjusted = true;
        } else {
            if ($entityValue === '' || $entityValue === 'current') {
                $entityValue = $this->isAllEntitiesScope()
                    ? 'all'
                    : (string) ($_SESSION['glpiactive_entity'] ?? 0);
            }

            $changed = false;
            if ($entityValue === 'all') {
                $changed = \Session::changeActiveEntities('all');
            } else {
                $entityId = max(0, (int) $entityValue);
                $recursive = $this->recursiveForEntity($entityId);
                $changed = \Session::changeActiveEntities($entityId, $recursive);
            }

            $this->clearContextBoundSessionState();
            if (!$changed) {
                throw new \RuntimeException('Entidade invalida para o perfil selecionado.');
            }
        }

        $status = (new \GlpiPlugin\Glpiacessivel\Security\SessionContextGuard())->status();
        if (empty($status['session_ready'])) {
            throw new \RuntimeException('O GLPI nao confirmou um contexto operacional completo.');
        }

        $after = [
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
            'all_entities' => $this->isAllEntitiesScope(),
        ];

        $this->clearContextBoundSessionState();
        $this->auditLogger->log('context.switch', [
            'before' => $before,
            'after' => $after,
            'profile_changed' => $profileChanged ? 1 : 0,
            'entity_selection_adjusted' => $entitySelectionAdjusted ? 1 : 0,
            'return_to_len' => strlen($returnTo),
        ]);

        $context = $this->getContext();
        $context['profile_changed'] = $profileChanged;
        $context['entity_selection_adjusted'] = $entitySelectionAdjusted;

        return $context;
    }

    public function safeReturnTo(string $returnTo): string
    {
        $fallback = \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/acessivel.php');
        $returnTo = trim($returnTo);
        if ($returnTo === '' || preg_match('/[\\x00-\\x1F\\x7F]/', $returnTo) === 1) {
            return $fallback;
        }

        $parts = parse_url($returnTo);
        if (!is_array($parts)) {
            return $fallback;
        }

        foreach (['scheme', 'host', 'port', 'user', 'pass'] as $externalPart) {
            if (array_key_exists($externalPart, $parts)) {
                return $fallback;
            }
        }

        $path = (string) ($parts['path'] ?? '');
        $allowedPrefix = \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/');
        if ($path === '' || !str_starts_with($path, $allowedPrefix) || str_contains($path, '/..')) {
            return $fallback;
        }

        return $returnTo;
    }

    /**
     * @return array<int,array{id:int,name:string}>
     */
    private function profileOptions(): array
    {
        $profiles = [];
        foreach ((array) ($_SESSION['glpiprofiles'] ?? []) as $id => $profile) {
            $id = (int) $id;
            if ($id <= 0) {
                continue;
            }

            $profiles[] = [
                'id' => $id,
                'name' => $this->profileName($id, is_array($profile) ? $profile : []),
            ];
        }

        usort($profiles, static fn (array $a, array $b): int => strcasecmp($a['name'], $b['name']));

        return $profiles;
    }

    /**
     * @return array<int|string,array{id:int|string,name:string,recursive:bool}>
     */
    private function entityOptions(): array
    {
        $entities = [];
        $allowedScopes = $this->allowedEntityScopes();

        if ($this->isAllEntitiesScope() || count($allowedScopes) > 1) {
            $entities['all'] = [
                'id' => 'all',
                'name' => 'Todas as entidades permitidas',
                'recursive' => true,
            ];
        }

        foreach ($allowedScopes as $id => $recursive) {
            $entities[$id] = [
                'id' => $id,
                'name' => $this->entityName($id) . ($recursive ? ' (arvore)' : ''),
                'recursive' => $recursive,
            ];
        }

        $activeId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        if ($activeId >= 0 && !isset($entities[$activeId])) {
            $entities[$activeId] = [
                'id' => $activeId,
                'name' => $this->currentEntityName($activeId),
                'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
            ];
        }

        return $entities;
    }

    private function recursiveForEntity(int $entityId): bool
    {
        $allowedScopes = $this->allowedEntityScopes();
        if (array_key_exists($entityId, $allowedScopes)) {
            return $allowedScopes[$entityId];
        }

        return !empty($_SESSION['glpiactive_entity_recursive']);
    }

    private function isEntityValueAllowed(string $entityValue): bool
    {
        $entityValue = trim($entityValue);
        $allowedScopes = $this->allowedEntityScopes();

        if ($entityValue === 'all') {
            return $allowedScopes !== [];
        }

        if ($entityValue === '' || $entityValue === 'current') {
            return true;
        }

        if (preg_match('/^\d+$/D', $entityValue) !== 1) {
            return false;
        }

        return array_key_exists((int) $entityValue, $allowedScopes);
    }

    /** @return array<int,bool> */
    private function allowedEntityScopes(): array
    {
        $scopes = [];
        foreach ((array) ($_SESSION['glpiactiveprofile']['entities'] ?? []) as $entity) {
            if (!is_array($entity)) {
                continue;
            }

            $entityId = (int) ($entity['id'] ?? -1);
            if ($entityId < 0) {
                continue;
            }

            $recursive = !empty($entity['is_recursive']);
            $scopes[$entityId] = !empty($scopes[$entityId]) || $recursive;
            if (!$recursive || !function_exists('getSonsOf')) {
                continue;
            }

            foreach ((array) getSonsOf('glpi_entities', $entityId) as $descendantId) {
                $descendantId = (int) $descendantId;
                if ($descendantId >= 0) {
                    $scopes[$descendantId] = true;
                }
            }
        }

        ksort($scopes, SORT_NUMERIC);

        return $scopes;
    }

    private function clearContextBoundSessionState(): void
    {
        foreach (
            [
            'glpiacessivel_chatbot_context',
            'glpiacessivel_chatbot_conversation_id',
            'glpiacessivel_ticket_critical_confirmations',
            'glpiacessivel_playbook_critical_confirmations',
            'glpiacessivel_pii_reveal',
            ] as $key
        ) {
            unset($_SESSION[$key]);
        }
    }

    private function isCurrentContextValid(int $currentProfileId): bool
    {
        if ($currentProfileId <= 0) {
            return false;
        }

        if (!isset($_SESSION['glpiactive_entity']) && !$this->isAllEntitiesScope()) {
            return false;
        }

        return true;
    }

    private function isAllEntitiesScope(): bool
    {
        return !empty($_SESSION['glpientity_fullstructure'])
            || ($_SESSION['glpiactive_entity'] ?? null) === 'all';
    }

    private function profileName(int $profileId, array $profileData = []): string
    {
        $name = trim((string) ($profileData['name'] ?? ''));
        if ($name !== '') {
            return $name;
        }

        if ($profileId > 0 && class_exists('\Profile')) {
            $profile = new \Profile();
            if ($profile->getFromDB($profileId)) {
                return (string) ($profile->fields['name'] ?? ('Perfil ' . $profileId));
            }
        }

        return $profileId > 0 ? ('Perfil ' . $profileId) : 'Perfil atual';
    }

    private function currentEntityName(int $entityId): string
    {
        $name = TextNormalizer::fromGlpi(
            (string) ($_SESSION['glpiactive_entity_name'] ?? '')
        );
        if ($name !== '') {
            return $name;
        }

        return $this->entityName($entityId);
    }

    private function entityName(int $entityId): string
    {
        if (class_exists('\Dropdown')) {
            $name = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName('glpi_entities', $entityId));
            if (trim($name) !== '') {
                return $name;
            }
        }

        if (class_exists('\Entity')) {
            $entity = new \Entity();
            if ($entity->getFromDB($entityId)) {
                $rawName = (string) ($entity->fields['completename']
                    ?? $entity->fields['name']
                    ?? ('Entidade ' . $entityId));
                return TextNormalizer::fromGlpi($rawName);
            }
        }

        return $entityId === 0 ? 'Entidade raiz' : ('Entidade ' . $entityId);
    }

    private function currentUserLabel(): string
    {
        $login = trim(TextNormalizer::fromGlpi((string) ($_SESSION['glpiname'] ?? '')));
        $firstName = trim(TextNormalizer::fromGlpi((string) ($_SESSION['glpifirstname'] ?? '')));

        if ($firstName !== '' && $login !== '') {
            return $login . ' — ' . $firstName;
        }

        if ($login !== '') {
            return $login;
        }

        if ($firstName !== '') {
            return $firstName;
        }

        return 'Usuario atual';
    }
}
