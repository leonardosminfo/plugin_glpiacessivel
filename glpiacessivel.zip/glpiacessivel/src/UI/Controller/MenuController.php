<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Support\Container;
use GlpiPlugin\Glpiacessivel\Support\Url;

final class MenuController extends \CommonGLPI
{
    public static function getTypeName($nb = 0): string
    {
        return __('Portal Acessível', 'glpiacessivel');
    }

    public static function canView(): bool
    {
        return Container::get()->authorization()->canViewPortal();
    }

    public static function getMenuName(): string
    {
        return __('Portal Acessível', 'glpiacessivel');
    }

    public static function getMenuContent(): array
    {
        if (!self::canView()) {
            return [];
        }

        $authorization = Container::get()->authorization();
        $modulePolicy = Container::get()->portalModulePolicy();
        $options = [
            'portal' => [
                'title' => __('Entrada acessível', 'glpiacessivel'),
                'page' => Url::plugin('front/acessivel.php'),
            ],
        ];

        if ($modulePolicy->isVisible(ConfigService::MODULE_TICKETS) && $authorization->canViewTickets()) {
            $options['tickets'] = [
                'title' => __('Chamados', 'glpiacessivel'),
                'page' => Url::plugin('front/tickets.php'),
            ];
        }

        if ($modulePolicy->isVisible(ConfigService::MODULE_COCKPIT) && $authorization->canViewCockpit()) {
            $options['cockpit'] = [
                'title' => __('Cockpit', 'glpiacessivel'),
                'page' => Url::plugin('front/cockpit.php'),
            ];
        }
        if ($modulePolicy->isVisible(ConfigService::MODULE_FORMS) && $authorization->canUseForms()) {
            $options['forms'] = [
                'title' => __('Formulários', 'glpiacessivel'),
                'page' => Url::plugin('front/forms.php'),
            ];
        }

        if ($modulePolicy->isVisible(ConfigService::MODULE_KNOWLEDGE) && $authorization->canViewKnowledgeBase()) {
            $options['knowledge'] = [
                'title' => __('Base de conhecimento', 'glpiacessivel'),
                'page' => Url::plugin('front/knowledge.php'),
            ];
        }

        if ($modulePolicy->isVisible(ConfigService::MODULE_CHATBOT) && $authorization->canUseChatbot()) {
            $options['chatbot'] = [
                'title' => __('Chatbot operacional', 'glpiacessivel'),
                'page' => Url::plugin('front/chatbot.php'),
            ];
        }

        if ($modulePolicy->isVisible(ConfigService::MODULE_PLAYBOOKS) && \Session::haveRight('config', UPDATE)) {
            $options['playbooks'] = [
                'title' => __('Roteiros do chatbot', 'glpiacessivel'),
                'page' => Url::plugin('front/playbooks.php'),
            ];
        }

        return [
            'title' => self::getMenuName(),
            'page' => Url::plugin('front/acessivel.php'),
            'icon' => self::menuIcon(),
            'options' => $options,
        ];
    }

    private static function menuIcon(): string
    {
        if (function_exists('plugin_glpiacessivel_is_glpi11') && \plugin_glpiacessivel_is_glpi11()) {
            return 'ti ti-universal-access';
        }

        return 'fas fa-universal-access';
    }
}
