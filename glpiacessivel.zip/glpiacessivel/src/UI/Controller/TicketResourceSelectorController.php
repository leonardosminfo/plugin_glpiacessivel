<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiResourceSelectorProvider;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiResourceSelectorRegistry;
use GlpiPlugin\Glpiacessivel\Security\SessionContextGuard;

final class TicketResourceSelectorController extends BaseController
{
    private const MAX_BODY_BYTES = 8192;

    public static function search(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            if (!headers_sent()) {
                header('Allow: POST');
            }
            self::respond(405, 'method_not_allowed');
            return;
        }
        if (!self::isJsonContentType()) {
            self::respond(415, 'unsupported_media_type');
            return;
        }
        if (!self::isSameOrigin()) {
            self::respond(403, 'origin_not_allowed');
            return;
        }

        $guard = new SessionContextGuard();
        $status = $guard->ensureReady();
        if (empty($status['is_authenticated'])) {
            self::respond(401, 'session_expired');
            return;
        }
        if (empty($status['session_ready'])) {
            self::respond(409, 'context_stale');
            return;
        }

        if (
            !self::container()->portalModulePolicy()->isEnabled(ConfigService::MODULE_TICKETS)
            || (
                !self::container()->authorization()->canCreateTickets()
                && !self::container()->authorization()->canUpdateTickets()
            )
        ) {
            self::respond(403, 'forbidden');
            return;
        }

        try {
            $request = self::request();
        } catch (\InvalidArgumentException $e) {
            self::respond(422, 'invalid_request');
            return;
        }

        $config = self::container()->configService();
        $isRoutingRequest = (int) ($request['dependencies']['ticket_id'] ?? 0) > 0;
        $flowEnabled = $isRoutingRequest
            ? $config->isResourceSelectorRoutingEnabled()
            : $config->isResourceSelectorCreateEnabled();
        $flowAuthorized = $isRoutingRequest
            ? self::container()->authorization()->canUpdateTickets()
            : self::container()->authorization()->canCreateTickets();
        if (!$flowAuthorized) {
            self::respond(403, 'forbidden');
            return;
        }
        if (!$config->isResourceSelectorEnabled() || !$flowEnabled) {
            self::respond(503, 'feature_disabled');
            return;
        }

        try {
            self::csrf()->validateRequest(true);
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('csrf.failed', [
                'endpoint' => 'ticket.resource-selector',
                'exception' => get_class($e),
            ]);
            self::respond(403, 'invalid_security_token');
            return;
        }

        $rate = self::container()->searchValueRateLimiter()->consume(1, 'resource_autocomplete');
        if (!$rate['allowed']) {
            if ($rate['reason'] === 'rate_limited' && !headers_sent()) {
                header('Retry-After: ' . (string) $rate['retry_after']);
            }
            self::respond(
                $rate['reason'] === 'rate_limited' ? 429 : 403,
                $rate['reason'] === 'rate_limited' ? 'rate_limited' : 'forbidden'
            );
            return;
        }

        try {
            $result = self::container()->resourceSelectorProvider()->search(
                $request['purpose'],
                $request['q'],
                $request['cursor'],
                $request['selected_ids'],
                $request['dependencies'],
                $request['context_revision']
            );
            self::respond(200, '', $result);
        } catch (\InvalidArgumentException $e) {
            $code = $e->getMessage();
            if ($code === 'resource_selector_context_stale') {
                self::respond(409, 'context_stale');
                return;
            }
            if ($code === 'resource_selector_cursor_invalid') {
                self::respond(422, 'cursor_invalid');
                return;
            }
            if ($code === 'resource_selector_query_too_short') {
                self::respond(422, 'query_too_short', null, [
                    'minimum_length' => self::container()
                        ->resourceSelectorProvider()
                        ->minimumQueryLength($request['purpose']),
                ]);
                return;
            }
            if ($code === 'resource_selector_query_invalid') {
                self::respond(422, 'query_invalid');
                return;
            }
            self::container()->auditLogger()->log('ticket.resource_selector.validation_failed', [
                'purpose' => $request['purpose'],
                'error_code' => self::safeErrorCode($e),
            ]);
            self::respond(422, 'invalid_request');
        } catch (\RuntimeException $e) {
            if ($e->getMessage() === 'session_context_unavailable') {
                self::respond(409, 'context_stale');
                return;
            }
            self::container()->auditLogger()->log('ticket.resource_selector.failed', [
                'purpose' => $request['purpose'],
                'exception' => get_class($e),
            ]);
            if (!headers_sent()) {
                header('Retry-After: 5');
            }
            self::respond(503, 'temporarily_unavailable');
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('ticket.resource_selector.failed', [
                'purpose' => $request['purpose'],
                'exception' => get_class($e),
            ]);
            if (!headers_sent()) {
                header('Retry-After: 5');
            }
            self::respond(503, 'temporarily_unavailable');
        }
    }

    /**
     * @return array{
     *   purpose:string,
     *   q:string,
     *   cursor:?string,
     *   selected_ids:int[],
     *   dependencies:array<string,mixed>,
     *   context_revision:?string
     * }
     */
    private static function request(): array
    {
        $contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
        if ($contentLength < 0 || $contentLength > self::MAX_BODY_BYTES) {
            throw new \InvalidArgumentException('resource_selector_body_invalid');
        }
        $raw = file_get_contents('php://input', false, null, 0, self::MAX_BODY_BYTES + 1);
        if (!is_string($raw) || $raw === '' || strlen($raw) > self::MAX_BODY_BYTES) {
            throw new \InvalidArgumentException('resource_selector_body_invalid');
        }
        $payload = json_decode($raw, true, 16, JSON_BIGINT_AS_STRING);
        if (!is_array($payload) || array_is_list($payload)) {
            throw new \InvalidArgumentException('resource_selector_body_invalid');
        }
        $allowed = [
            'contract',
            'version',
            'purpose',
            'q',
            'cursor',
            'selected_ids',
            'dependencies',
            'context_revision',
        ];
        foreach (array_keys($payload) as $key) {
            if (!is_string($key) || !in_array($key, $allowed, true)) {
                throw new \InvalidArgumentException('resource_selector_parameter_not_allowed');
            }
        }
        if (
            ($payload['contract'] ?? null) !== GlpiResourceSelectorProvider::CONTRACT
            || ($payload['version'] ?? null) !== GlpiResourceSelectorProvider::VERSION
            || !is_string($payload['purpose'] ?? null)
            || !in_array($payload['purpose'], GlpiResourceSelectorRegistry::PURPOSES, true)
            || !is_string($payload['q'] ?? '')
            || (!is_null($payload['cursor'] ?? null) && !is_string($payload['cursor']))
            || !is_array($payload['selected_ids'] ?? [])
            || !array_is_list($payload['selected_ids'] ?? [])
            || !is_array($payload['dependencies'] ?? [])
            || array_is_list($payload['dependencies'] ?? []) && ($payload['dependencies'] ?? []) !== []
            || (
                !is_null($payload['context_revision'] ?? null)
                && (
                    !is_string($payload['context_revision'])
                    || preg_match('/\A[a-f0-9]{64}\z/D', $payload['context_revision']) !== 1
                )
            )
        ) {
            throw new \InvalidArgumentException('resource_selector_request_invalid');
        }

        return [
            'purpose' => $payload['purpose'],
            'q' => $payload['q'] ?? '',
            'cursor' => $payload['cursor'] ?? null,
            'selected_ids' => $payload['selected_ids'] ?? [],
            'dependencies' => $payload['dependencies'] ?? [],
            'context_revision' => $payload['context_revision'] ?? null,
        ];
    }

    private static function isJsonContentType(): bool
    {
        $contentType = strtolower(trim((string) ($_SERVER['CONTENT_TYPE'] ?? '')));
        return preg_match('/\Aapplication\/json(?:\s*;\s*charset=utf-8)?\z/D', $contentType) === 1;
    }

    private static function isSameOrigin(): bool
    {
        $fetchSite = strtolower(trim((string) ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '')));
        if ($fetchSite !== '' && !in_array($fetchSite, ['same-origin', 'none'], true)) {
            return false;
        }
        $origin = trim((string) ($_SERVER['HTTP_ORIGIN'] ?? ''));
        if ($origin === '') {
            return true;
        }
        $parts = parse_url($origin);
        if (!is_array($parts) || !is_string($parts['host'] ?? null)) {
            return false;
        }
        $originHost = strtolower($parts['host']);
        if (isset($parts['port'])) {
            $originHost .= ':' . (int) $parts['port'];
        }
        $requestHost = strtolower(trim((string) ($_SERVER['HTTP_HOST'] ?? '')));
        if ($requestHost === '' || !hash_equals($requestHost, $originHost)) {
            return false;
        }
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $requestIsHttps = !empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off';
        return $scheme === ($requestIsHttps ? 'https' : 'http');
    }

    /**
     * @param array<string,mixed>|null $result
     * @param array<string,int|string|bool> $errorDetails
     */
    private static function respond(
        int $status,
        string $errorCode = '',
        ?array $result = null,
        array $errorDetails = []
    ): void {
        if (!headers_sent()) {
            http_response_code($status);
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: private, no-store');
            header('Pragma: no-cache');
            header('X-Content-Type-Options: nosniff');
        }
        $payload = $result ?? [
            'contract' => GlpiResourceSelectorProvider::CONTRACT,
            'version' => GlpiResourceSelectorProvider::VERSION,
            'results' => [],
            'pagination' => ['more' => false, 'cursor' => null],
        ];
        $payload['success'] = $status >= 200 && $status < 300;
        if ($errorCode !== '') {
            $payload['error'] = ['code' => $errorCode];
            if ($errorDetails !== []) {
                $payload['error']['details'] = $errorDetails;
            }
        }
        $json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        echo is_string($json)
            ? $json
            : '{"contract":"resource_selector","version":1,"success":false,'
                . '"results":[],"pagination":{"more":false,"cursor":null},'
                . '"error":{"code":"encoding_failed"}}';
    }

    private static function safeErrorCode(\Throwable $exception): string
    {
        $reason = $exception->getMessage();
        return preg_match('/\Aresource_selector_[a-z0-9_]{1,80}\z/D', $reason) === 1
            ? $reason
            : 'resource_selector_invalid_request';
    }
}
