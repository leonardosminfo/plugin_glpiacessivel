<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\TicketListStateStore;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\TicketListRateLimiter;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\GlpiSessionContextSnapshot;
use GlpiPlugin\Glpiacessivel\Security\SessionContextGuard;
use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\Support\TicketStatusLabels;
use GlpiPlugin\Glpiacessivel\Support\Url;

final class TicketResultController extends BaseController
{
    public static function fetch(): void
    {
        if (!self::isSameOrigin()) {
            self::respond(403, 'origin_not_allowed');
            return;
        }

        $session = (new SessionContextGuard())->ensureReady();
        if (empty($session['is_authenticated'])) {
            self::respond(401, 'session_expired');
            return;
        }
        if (empty($session['session_ready'])) {
            self::respond(409, 'context_stale');
            return;
        }
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            if (!headers_sent()) {
                header('Allow: POST');
            }
            self::respond(405, 'method_not_allowed');
            return;
        }
        $contentType = strtolower(trim((string) ($_SERVER['CONTENT_TYPE'] ?? '')));
        if (preg_match('/\Aapplication\/json(?:\s*;\s*charset=utf-8)?\z/D', $contentType) !== 1) {
            self::respond(415, 'unsupported_media_type');
            return;
        }

        $config = self::container()->configService();
        if (
            !$config->isTicketAsyncListEnabled()
            || !self::container()->portalModulePolicy()->isEnabled(ConfigService::MODULE_TICKETS)
            || !self::container()->authorization()->canViewTickets()
        ) {
            self::respond(403, 'forbidden');
            return;
        }

        try {
            self::csrf()->validateRequest(true);
        } catch (\InvalidArgumentException $e) {
            self::respond(422, 'invalid_request');
            return;
        } catch (\Throwable $e) {
            self::respond(403, 'invalid_security_token');
            return;
        }

        $rate = (new TicketListRateLimiter())->consume();
        if (!$rate['allowed']) {
            if (!headers_sent()) {
                header('Retry-After: ' . (string) $rate['retry_after']);
            }
            self::respond(429, 'rate_limited');
            return;
        }

        try {
            try {
                $request = self::request();
            } catch (\InvalidArgumentException | \JsonException $e) {
                self::respond(422, 'invalid_request');
                return;
            }
            $snapshot = (new GlpiSessionContextSnapshot())->snapshot();
            if (!hash_equals($snapshot['revision'], $request['context_revision'])) {
                self::respond(409, 'context_stale', ['request_id' => $request['request_id']]);
                return;
            }
            $filters = (new TicketListStateStore())->resolve(
                $request['state_token'],
                $snapshot['revision']
            );
            if ($filters === null) {
                self::respond(422, 'state_expired', ['request_id' => $request['request_id']]);
                return;
            }

            $startedAt = microtime(true);
            $result = self::container()->ticketService()->list($filters);
            $items = [];
            foreach ((array) ($result['items'] ?? []) as $item) {
                if (!is_array($item)) {
                    continue;
                }
                $ticketId = (int) ($item['id'] ?? 0);
                $priority = (int) ($item['priority'] ?? 0);
                $status = (int) ($item['status'] ?? 0);
                $item['detail_url'] = Url::plugin('front/tickets.php?id=' . $ticketId);
                $item['status_label'] = TicketStatusLabels::label($status);
                $item['status_class'] = self::statusClass($status);
                $item['priority_label'] = self::priorityLabel($priority);
                $item['priority_class'] = self::priorityClass($priority);
                $items[] = self::projectResultItem($item, $filters);
            }
            $result['items'] = $items;

            self::container()->auditLogger()->log('ticket.results.async', [
                'request_id' => $request['request_id'],
                'count' => count($items),
                'duration_ms' => (int) round((microtime(true) - $startedAt) * 1000),
                'backend' => (string) ($result['backend'] ?? 'unknown'),
            ]);
            self::respond(200, '', [
                'request_id' => $request['request_id'],
                'context_revision' => $snapshot['revision'],
                'result' => $result,
            ]);
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('ticket.results.async_failed', [
                'exception' => get_class($e),
            ]);
            if (!headers_sent()) {
                header('Retry-After: 5');
            }
            self::respond(503, 'temporarily_unavailable');
        }
    }

    /** @return array{state_token:string,context_revision:string,request_id:string} */
    private static function request(): array
    {
        $raw = file_get_contents('php://input');
        if (!is_string($raw) || strlen($raw) > 4096) {
            throw new \InvalidArgumentException('invalid_request');
        }
        $input = json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
        if (!is_array($input)) {
            throw new \InvalidArgumentException('invalid_request');
        }
        $allowed = ['contract', 'version', 'state_token', 'context_revision', 'request_id'];
        foreach (array_keys($input) as $key) {
            if (!is_string($key) || !in_array($key, $allowed, true)) {
                throw new \InvalidArgumentException('invalid_request');
            }
        }
        if (($input['contract'] ?? null) !== 'ticket_results' || ($input['version'] ?? null) !== 1) {
            throw new \InvalidArgumentException('invalid_contract');
        }
        $stateToken = is_string($input['state_token'] ?? null) ? $input['state_token'] : '';
        $contextRevision = is_string($input['context_revision'] ?? null) ? $input['context_revision'] : '';
        $requestId = is_string($input['request_id'] ?? null) ? $input['request_id'] : '';
        if (
            preg_match('/\A[a-f0-9]{48}\z/D', $stateToken) !== 1
            || preg_match('/\A[a-f0-9]{64}\z/D', $contextRevision) !== 1
            || preg_match('/\A[a-zA-Z0-9_-]{8,80}\z/D', $requestId) !== 1
        ) {
            throw new \InvalidArgumentException('invalid_request');
        }

        return [
            'state_token' => $stateToken,
            'context_revision' => $contextRevision,
            'request_id' => $requestId,
        ];
    }

    private static function isSameOrigin(): bool
    {
        $fetchSite = strtolower(trim((string) ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '')));
        if ($fetchSite !== '' && !in_array($fetchSite, ['same-origin', 'none'], true)) {
            return false;
        }
        $origin = trim((string) ($_SERVER['HTTP_ORIGIN'] ?? ''));
        if ($origin === '') {
            return true;
        }
        $originParts = parse_url($origin);
        if (!is_array($originParts) || !is_string($originParts['host'] ?? null)) {
            return false;
        }
        $originHost = strtolower((string) $originParts['host']);
        if (isset($originParts['port'])) {
            $originHost .= ':' . (int) $originParts['port'];
        }
        $requestHost = strtolower(trim((string) ($_SERVER['HTTP_HOST'] ?? '')));
        if ($requestHost === '' || !hash_equals($requestHost, $originHost)) {
            return false;
        }
        $requestIsHttps = !empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off';
        return strtolower((string) ($originParts['scheme'] ?? '')) === ($requestIsHttps ? 'https' : 'http');
    }

    /** @param array<string, mixed> $data */
    private static function respond(int $status, string $error = '', array $data = []): void
    {
        if (!headers_sent()) {
            http_response_code($status);
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: private, no-store');
            header('Pragma: no-cache');
            header('X-Content-Type-Options: nosniff');
        }
        $payload = [
            'contract' => 'ticket_results',
            'version' => 1,
            'success' => $status >= 200 && $status < 300,
        ] + $data;
        if ($error !== '') {
            $payload['error'] = $error;
        }
        $json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        echo is_string($json)
            ? $json
            : '{"contract":"ticket_results","version":1,"success":false,"error":"encoding_failed"}';
    }

    private static function statusClass(int $status): string
    {
        return [1 => 'new', 2 => 'assigned', 3 => 'planned', 4 => 'pending', 5 => 'solved', 6 => 'closed'][$status]
            ?? 'neutral';
    }

    private static function priorityLabel(int $priority): string
    {
        $labels = [
            1 => I18n::translate('Muito baixa'),
            2 => I18n::translate('Baixa'),
            3 => I18n::translate('Média'),
            4 => I18n::translate('Alta'),
            5 => I18n::translate('Muito alta'),
            6 => I18n::translate('Crítica'),
        ];
        return $labels[$priority]
            ?? sprintf(I18n::translate('Prioridade %d'), $priority);
    }

    private static function priorityClass(int $priority): string
    {
        if ($priority >= 5) {
            return 'critical';
        }
        if ($priority === 4) {
            return 'high';
        }
        return $priority === 3 ? 'medium' : 'low';
    }

    /**
     * Keep the HTTP response aligned with the columns the user is authorised
     * to display. Batch hydration may use additional relations internally, but
     * unrequested actors, labels, relational IDs and ticket content must not
     * cross the JSON boundary.
     *
     * @param array<string,mixed> $item
     * @param array<string,mixed> $filters
     * @return array<string,mixed>
     */
    private static function projectResultItem(array $item, array $filters): array
    {
        $columns = array_values(array_filter(
            array_map(
                static fn($column): string => is_scalar($column) ? trim((string) $column) : '',
                (array) ($filters['columns'] ?? [])
            ),
            static fn(string $column): bool => $column !== ''
        ));
        if ($columns === []) {
            $columns = ['id', 'name', 'status', 'priority', 'group', 'date_mod'];
        }
        $selected = array_fill_keys($columns, true);
        $projected = [
            'id' => (int) ($item['id'] ?? 0),
            'name' => (string) ($item['name'] ?? ''),
            'detail_url' => (string) ($item['detail_url'] ?? ''),
        ];

        $mappings = [
            'date' => ['date'],
            'date_mod' => ['date_mod'],
            'time_to_resolve' => ['time_to_resolve'],
            'requester' => ['requester_name'],
            'assignee' => ['assignee_name'],
            'category' => ['category_name'],
            'entity' => ['entity_name'],
            'location' => ['location_name'],
            'status' => ['status', 'status_label', 'status_class'],
            'priority' => ['priority', 'priority_label', 'priority_class'],
        ];
        foreach ($mappings as $column => $fields) {
            if (!isset($selected[$column])) {
                continue;
            }
            foreach ($fields as $field) {
                $projected[$field] = $item[$field] ?? '';
            }
        }

        $needsGroup = isset($selected['group'])
            || (
                ($filters['group_by'] ?? '') === 'group'
                && in_array((string) ($filters['scope'] ?? ''), ['mine', 'group'], true)
            );
        if ($needsGroup) {
            $projected['primary_group_name'] = (string) ($item['primary_group_name'] ?? 'Sem grupo');
        }

        return $projected;
    }
}
