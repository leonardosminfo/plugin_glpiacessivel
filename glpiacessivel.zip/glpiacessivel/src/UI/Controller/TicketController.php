<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\AdvancedTicketSearchRequest;
use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\TicketSearchStateStore;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchValidationException;
use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\Support\UploadedFileMapper;
use GlpiPlugin\Glpiacessivel\Support\FormValidationException;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\Presenter\TicketSearchSummaryPresenter;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class TicketController extends BaseController
{
    private const ADVANCED_SEARCH_ERROR_SESSION_KEY = 'glpiacessivel_advanced_search_error_v2';
    private const PII_REVEAL_TTL_SECONDS = 300;
    private const CRITICAL_CONFIRM_TTL_SECONDS = 300;
    private const CRITICAL_CONFIRM_SESSION_KEY = 'glpiacessivel_ticket_critical_confirmations';

    public static function index(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            self::processAdvancedSearchPost();
            return;
        }

        $sanitizer = new InputSanitizer();
        $savedSearchState = SavedTicketSearchController::indexState($_GET);
        $savedFilters = (array) ($savedSearchState['filters'] ?? []);
        $savedSearchService = self::container()->savedTicketSearchService();
        $advancedSearchCatalog = [];
        $advancedContextRevision = '';
        $advancedSearchState = [];
        $advancedSearchToken = '';
        $appliedSearchSummary = [
            'active' => false,
            'source' => '',
            'heading' => '',
            'saved_search_name' => '',
            'sections' => [],
            'warnings' => [],
            'plain_text' => '',
        ];
        $advancedErrorCode = self::consumeAdvancedSearchError();

        try {
            $advancedSearchCatalog = $savedSearchService->searchCatalog();
            $advancedContextRevision = self::advancedCatalogRevision($advancedSearchCatalog);
        } catch (\Throwable $e) {
            $advancedErrorCode = self::advancedFailureCode(
                $e,
                'native_search_catalog_unavailable'
            );
            self::auditAdvancedFailure('get_catalog', $advancedErrorCode, $e);
        }

        $filters = [
            'scope' => $sanitizer->enum($_GET['scope'] ?? ($savedFilters['scope'] ?? 'all'), ['all', 'mine', 'group'], 'all'),
            'status' => $sanitizer->text($_GET['status'] ?? ($savedFilters['status'] ?? ''), 4),
            'q' => $sanitizer->text($_GET['q'] ?? ($savedFilters['q'] ?? ''), 120),
            'group_id' => max(0, $sanitizer->int($_GET['group_id'] ?? ($savedFilters['group_id'] ?? 0), 0)),
            'group_by' => $sanitizer->enum($_GET['group_by'] ?? ($savedFilters['group_by'] ?? 'none'), ['none', 'group'], 'none'),
            'page' => max(1, $sanitizer->int($_GET['page'] ?? 1, 1)),
            'page_size' => $sanitizer->int($_GET['page_size'] ?? ($savedFilters['page_size'] ?? 20), 20),
            'sort' => $sanitizer->enum($_GET['sort'] ?? ($savedFilters['sort'] ?? 'date_mod'), ['id', 'name', 'status', 'priority', 'date', 'date_mod'], 'date_mod'),
            'direction' => $sanitizer->enum($_GET['direction'] ?? ($savedFilters['direction'] ?? 'DESC'), ['ASC', 'DESC'], 'DESC'),
            'columns' => \GlpiPlugin\Glpiacessivel\Infrastructure\Repository\SavedTicketSearchRepository::normalizePortalFilters([
                'columns' => $_GET['columns'] ?? ($savedFilters['columns'] ?? []),
            ])['columns'],
        ];
        $filters['columns'] = self::validatedPresentationColumns(
            (array) $filters['columns'],
            $advancedSearchCatalog
        );
        foreach (
            [
            'native_criteria',
            'native_metacriteria',
            'native_sort',
            'native_order',
            'native_is_deleted',
            'native_saved_search_id',
            'native_parameters',
            ] as $nativeKey
        ) {
            if (array_key_exists($nativeKey, $savedFilters)) {
                $filters[$nativeKey] = $savedFilters[$nativeKey];
            }
        }
        if (is_array($savedSearchState['active'] ?? null)) {
            $filters['scope'] = (string) ($savedFilters['scope'] ?? 'all');
            $filters['status'] = '';
            $filters['q'] = (string) ($savedFilters['q'] ?? '');
            $filters['group_id'] = 0;
            $filters['group_by'] = 'none';
            $filters['sort'] = 'date_mod';
            $filters['direction'] = 'DESC';
            $savedColumns = array_key_exists('columns', $savedFilters)
                ? (array) $savedFilters['columns']
                : (array) \GlpiPlugin\Glpiacessivel\Infrastructure\Repository\SavedTicketSearchRepository::normalizePortalFilters([])['columns'];
            $filters['columns'] = self::validatedPresentationColumns(
                $savedColumns,
                $advancedSearchCatalog
            );
        }
        if (!empty($savedSearchState['invalid'])) {
            $filters['saved_search_invalid'] = true;
        }

        $requestedAdvancedToken = is_string($_GET['advanced_search_token'] ?? null)
            ? trim((string) $_GET['advanced_search_token'])
            : '';
        if ($requestedAdvancedToken !== '') {
            try {
                if ($advancedContextRevision === '') {
                    throw new NativeSearchValidationException(
                        'native_search_context_stale',
                        'catalog.context_revision'
                    );
                }
                $storedState = (new TicketSearchStateStore())->resolve(
                    $requestedAdvancedToken,
                    $advancedContextRevision
                );
                if ($storedState === null) {
                    throw new NativeSearchValidationException(
                        'native_search_token_invalid',
                        'advanced_search_token'
                    );
                }
                $wrapper = self::advancedStateWrapper($storedState);
                $definition = $savedSearchService->validateDefinition($wrapper['definition']);
                $filters = self::applyAdvancedDefinitionToFilters(
                    $filters,
                    $definition,
                    $wrapper['page_size']
                );
                $focusResults = is_string($_GET['focus'] ?? null)
                    && $_GET['focus'] === 'results';
                $advancedSearchState = self::advancedBuilderState(
                    $definition,
                    true,
                    $focusResults
                );
                $appliedSearchSummary = (new TicketSearchSummaryPresenter())->present(
                    $definition,
                    $advancedSearchCatalog,
                    [],
                    $filters
                );
                $advancedSearchState['summary'] = $appliedSearchSummary['plain_text'];
                $advancedSearchToken = $requestedAdvancedToken;
                $advancedErrorCode = '';
                $savedSearchState['selected'] = '';
                $savedSearchState['active'] = null;
                $savedSearchState['invalid'] = false;
            } catch (\Throwable $e) {
                $advancedErrorCode = self::advancedFailureCode(
                    $e,
                    'native_search_token_invalid'
                );
                self::auditAdvancedFailure('get_token', $advancedErrorCode, $e);
            }
        } elseif (
            $advancedErrorCode === ''
            && $advancedContextRevision !== ''
            && is_array($savedSearchState['active'] ?? null)
            && in_array(
                (string) ($savedSearchState['active']['capability'] ?? ''),
                ['editable', 'executable_read_only'],
                true
            )
        ) {
            try {
                $definition = (array) ($savedSearchState['active']['definition'] ?? []);
                if (!array_key_exists('columns', $definition)) {
                    $definition['columns'] = (array) ($filters['columns'] ?? []);
                }
                $definition = $savedSearchService->validateDefinition($definition);
                $nativePageSize = (int) ($filters['page_size'] ?? 20);
                $filters['page_size'] = in_array($nativePageSize, [10, 20, 50, 100], true)
                    ? $nativePageSize
                    : 20;
                $filters['columns'] = (array) ($definition['columns'] ?? $filters['columns'] ?? []);
                $editable = (string) ($savedSearchState['active']['capability'] ?? '') === 'editable';
                $advancedSearchState = self::advancedBuilderState($definition, $editable, false);
                $appliedSearchSummary = (new TicketSearchSummaryPresenter())->present(
                    $definition,
                    $advancedSearchCatalog,
                    (array) $savedSearchState['active'],
                    $filters
                );
                $advancedSearchState['summary'] = $appliedSearchSummary['plain_text'];
            } catch (\Throwable $e) {
                self::auditAdvancedFailure(
                    'native_builder',
                    'native_search_saved_builder_unavailable',
                    $e
                );
            }
        }

        if ($advancedErrorCode !== '') {
            $advancedSearchState = [
                'error_codes' => [$advancedErrorCode],
                'errors' => [self::advancedErrorMessage($advancedErrorCode)],
                'focus_results' => false,
                'editable' => true,
            ];
            $advancedSearchToken = '';
        }
        $filters['saved_search'] = (string) ($savedSearchState['selected'] ?? '');

        $service = self::container()->ticketService();
        $result = $service->list($filters);
        $groupOptions = $service->groupFilterOptions((array) ($result['items'] ?? []));
        $groupedItems = self::groupTicketsByGroup((array) ($result['items'] ?? []), (string) $filters['scope'], (string) $filters['group_by']);

        View::render('tickets/list', [
            'title' => __('Chamados', 'glpiacessivel'),
            'result' => $result,
            'filters' => $filters,
            'group_options' => $groupOptions,
            'grouped_items' => $groupedItems,
            'saved_search_catalog' => (array) ($savedSearchState['catalog'] ?? []),
            'selected_saved_search' => (string) ($savedSearchState['selected'] ?? ''),
            'active_saved_search' => is_array($savedSearchState['active'] ?? null) ? $savedSearchState['active'] : null,
            'saved_search_invalid' => !empty($savedSearchState['invalid']),
            'showOperationalDiagnostics' => self::container()->authorization()->canViewOperationalDiagnostics(),
            'advanced_search_catalog' => $advancedSearchCatalog,
            'advanced_search_state' => $advancedSearchState,
            'advanced_search_token' => $advancedSearchToken,
            'applied_search_summary' => $appliedSearchSummary,
            'csrf_token' => self::csrf()->token(),
        ]);
    }

    public static function create(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKET_CREATE)) {
            return;
        }

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            self::csrf()->validateRequest(true);
            self::storeCreate();
            return;
        }

        self::renderCreateForm(self::defaultCreateValues(), []);
    }

    public static function detail(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }

        $sanitizer = new InputSanitizer();
        $ticketId = max(1, $sanitizer->int($_GET['id'] ?? 0));

        $service = self::container()->ticketService();
        $ticket = $service->detail($ticketId, self::getRevealedFields($ticketId));
        if ($ticket === null) {
            self::container()->auditLogger()->log('ticket.detail.denied', [
                'reason' => 'not_found_or_not_authorized',
            ], $ticketId);
            self::setMessage(
                'error',
                __('Chamado nao encontrado ou sem acesso no perfil e entidade atuais.', 'glpiacessivel')
            );
            \Html::redirect(Url::plugin('front/ticket.php?scope=mine'));
            return;
        }

        View::render('tickets/detail', [
            'title' => __('Detalhe do chamado', 'glpiacessivel'),
            'ticket' => $ticket,
            'csrf_token' => self::csrf()->token(true),
            'csrf_tokens' => [
                'followup' => self::csrf()->token(true),
                'task' => self::csrf()->token(true),
                'solution' => self::csrf()->token(true),
                'status' => self::csrf()->token(true),
                'routing' => self::csrf()->token(true),
                'requester_decision' => self::csrf()->token(true),
                'solution_decision' => self::csrf()->token(true),
                'pii_reveal' => self::csrf()->token(true),
            ],
            'critical_confirmations' => self::ticketCriticalConfirmationTokens($ticketId),
        ]);
    }

    public static function action(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }

        $sanitizer = new InputSanitizer();
        $ticketId = $sanitizer->int($_POST['ticket_id'] ?? 0);

        $redirectAnchor = '';
        try {
            self::csrf()->validateRequest(true);
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('csrf.failed', [
                'endpoint' => 'ticket.action',
                'exception' => get_class($e),
                'action_name' => (string) ($_POST['action'] ?? ''),
            ], $ticketId);

            self::setMessage(
                'error',
                __('Sua sessao expirou ou o token de seguranca venceu. Recarregue o chamado e tente novamente.', 'glpiacessivel')
            );
            \Html::redirect(Url::plugin('front/ticket.php?id=' . $ticketId));
            return;
        }

        if ($ticketId < 1) {
            self::container()->auditLogger()->log('ticket.action.blocked', [
                'reason' => 'invalid_ticket_id',
                'action_name' => (string) ($_POST['action'] ?? ''),
            ]);
            self::setMessage('error', __('Chamado invalido. Reabra o chamado e tente novamente.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/ticket.php'));
            return;
        }

        $action = $sanitizer->enum($_POST['action'] ?? '', ['followup', 'task', 'solution', 'status', 'routing', 'requester_decision', 'solution_approve', 'solution_refuse', 'pii_reveal'], '');
        $content = $sanitizer->text($_POST['content'] ?? '', 16000);
        $status = $sanitizer->int($_POST['status'] ?? 0);
        $decision = $sanitizer->int($_POST['decision'] ?? 0, 0);
        $routingReason = $sanitizer->text($_POST['routing_reason'] ?? '', 255);
        $followupTemplateId = max(0, $sanitizer->int($_POST['itilfollowuptemplates_id'] ?? 0, 0));
        $followupIsPrivate = $sanitizer->enum(
            $_POST['followup_is_private'] ?? '0',
            ['0', '1'],
            '0'
        ) === '1' ? 1 : 0;
        $piiField = $sanitizer->enum(
            $_POST['pii_field'] ?? '',
            ['requester_email', 'requester_phone', 'requester_mobile'],
            ''
        );
        $piiReason = $sanitizer->text($_POST['pii_reason'] ?? '', 255);
        $taskInput = [
            'state' => max(0, $sanitizer->int($_POST['task_state'] ?? 0, 0)),
            'taskcategories_id' => max(0, $sanitizer->int($_POST['taskcategories_id'] ?? 0, 0)),
            'users_id_tech' => max(0, $sanitizer->int($_POST['task_users_id_tech'] ?? 0, 0)),
            'groups_id_tech' => max(0, $sanitizer->int($_POST['task_groups_id_tech'] ?? 0, 0)),
            'actiontime' => max(0, $sanitizer->int($_POST['task_actiontime'] ?? 0, 0)),
            'begin' => $sanitizer->text($_POST['task_begin'] ?? '', 32),
            'end' => $sanitizer->text($_POST['task_end'] ?? '', 32),
            'is_private' => $sanitizer->enum(
                $_POST['task_is_private'] ?? '0',
                ['0', '1'],
                '0'
            ) === '1' ? 1 : 0,
        ];

        if (self::isCriticalTicketAction($action)) {
            try {
                self::validateTicketCriticalConfirmation($ticketId, $action, $_POST);
            } catch (\Throwable $e) {
                self::container()->auditLogger()->log('ticket.critical_confirmation.blocked', [
                    'action' => $action,
                    'reason' => $e->getMessage(),
                ], $ticketId);
                self::setMessage('error', __('Confirme a acao critica na tela antes de executar.', 'glpiacessivel'));
                \Html::redirect(Url::plugin('front/ticket.php?id=' . $ticketId));
                return;
            }
        }

        $service = self::container()->ticketService();

        try {
            $ok = false;
            $successMessage = __('Acao executada com sucesso.', 'glpiacessivel');
            switch ($action) {
                case 'followup':
                    $followupIsPrivate = $service->resolveFollowupPrivacy(
                        $ticketId,
                        $followupTemplateId,
                        $followupIsPrivate
                    );
                    $ok = $service->addFollowup(
                        $ticketId,
                        $content,
                        UploadedFileMapper::map('followup_filename'),
                        $followupTemplateId,
                        $followupIsPrivate
                    );
                    $successMessage = $followupIsPrivate === 1
                        ? sprintf(__('Nota interna privada adicionada ao chamado #%d.', 'glpiacessivel'), $ticketId)
                        : sprintf(__('Resposta publica adicionada ao chamado #%d.', 'glpiacessivel'), $ticketId);
                    break;
                case 'task':
                    $ok = $service->addTask($ticketId, $content, $taskInput, UploadedFileMapper::map('task_filename'));
                    $successMessage = !empty($taskInput['is_private'])
                        ? sprintf(__('Tarefa interna privada adicionada ao chamado #%d.', 'glpiacessivel'), $ticketId)
                        : sprintf(__('Tarefa publica adicionada ao chamado #%d.', 'glpiacessivel'), $ticketId);
                    break;
                case 'solution':
                    $ok = $service->addSolution($ticketId, $content);
                    break;
                case 'status':
                    $ok = $service->changeStatus($ticketId, $status);
                    break;
                case 'routing':
                    $ok = $service->escalateTicketRouting(
                        $ticketId,
                        array_values(array_filter(array_map('intval', (array) ($_POST['_users_id_assign'] ?? [])))),
                        array_values(array_filter(array_map('intval', (array) ($_POST['_users_id_observer'] ?? [])))),
                        $routingReason,
                        array_values(array_filter(array_map('intval', (array) ($_POST['_groups_id_assign'] ?? [])))),
                        array_values(array_filter(array_map('intval', (array) ($_POST['_groups_id_observer'] ?? []))))
                    );
                    break;
                case 'requester_decision':
                    $ok = $service->registerRequesterDecision($ticketId, $decision, $content);
                    break;
                case 'solution_approve':
                    $ok = $service->approveSolution($ticketId, $content, UploadedFileMapper::map('solution_decision_filename'));
                    break;
                case 'solution_refuse':
                    $ok = $service->refuseSolution($ticketId, $content, UploadedFileMapper::map('solution_decision_filename'));
                    break;
                case 'pii_reveal':
                    if ($piiField === '') {
                        throw new \RuntimeException('Selecione o dado que precisa ser revelado.');
                    }
                    $service->revealPii($ticketId, $piiField, $piiReason);
                    self::grantTemporaryReveal($ticketId, $piiField);
                    $ok = true;
                    break;
            }

            self::setMessage(
                $ok ? 'success' : 'error',
                $ok ? $successMessage : __('Nao foi possivel executar a acao.', 'glpiacessivel')
            );
        } catch (FormValidationException $e) {
            $metadata = $e->metadata();
            $partialSuccess = !empty($metadata['partial_success']);
            $messages = array_values(array_unique(array_filter(array_map(
                static fn(array $error): string => trim((string) ($error['message'] ?? '')),
                $e->errors()
            ))));
            $message = implode(' ', $messages);
            if ($message === '') {
                $message = $partialSuccess
                    ? __('A acao foi registrada, mas um ou mais anexos nao foram confirmados. Nao envie a acao novamente.', 'glpiacessivel')
                    : __('Nao foi possivel concluir a acao. Revise os dados e tente novamente.', 'glpiacessivel');
            }

            self::container()->auditLogger()->log('ticket.action.validation_failed', [
                'action' => $action,
                'partial_success' => $partialSuccess,
                'created_itemtype' => (string) ($metadata['created_itemtype'] ?? ''),
                'created_item_id' => (int) ($metadata['created_item_id'] ?? 0),
                'error_codes' => array_values(array_unique(array_map(
                    static fn(array $error): string => (string) ($error['code'] ?? 'validation_failed'),
                    $e->errors()
                ))),
            ], $ticketId);
            self::setMessage('error', $message);
            $redirectAnchor = $partialSuccess ? '#timeline-ticket' : '';
        } catch (\Throwable $e) {
            self::setMessage('error', $e->getMessage());
        }

        \Html::redirect(Url::plugin('front/ticket.php?id=' . $ticketId) . $redirectAnchor);
    }

    /**
     * @return array<string, string>
     */
    private static function ticketCriticalConfirmationTokens(int $ticketId): array
    {
        self::purgeExpiredTicketCriticalConfirmations();
        $actions = ['solution', 'status', 'requester_decision', 'solution_approve', 'solution_refuse'];
        $tokens = [];
        foreach ($actions as $action) {
            $token = bin2hex(random_bytes(16));
            $tokens[$action] = $token;
            $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY][$token] = [
                'ticket_id' => $ticketId,
                'action' => $action,
                'user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'expires_at' => time() + self::CRITICAL_CONFIRM_TTL_SECONDS,
            ];
        }

        return $tokens;
    }

    private static function isCriticalTicketAction(string $action): bool
    {
        return in_array($action, ['solution', 'status', 'requester_decision', 'solution_approve', 'solution_refuse'], true);
    }

    /**
     * @param array<string, mixed> $post
     */
    private static function validateTicketCriticalConfirmation(int $ticketId, string $action, array $post): void
    {
        if ((string) ($post['critical_confirmed'] ?? '') !== '1') {
            throw new \RuntimeException('missing_confirmation_flag');
        }

        $token = (string) ($post['critical_confirmation_token'] ?? '');
        $state = is_array($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] ?? null)
            ? $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY]
            : [];
        $confirmation = is_array($state[$token] ?? null) ? $state[$token] : null;
        unset($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY][$token]);

        if ($token === '' || $confirmation === null) {
            throw new \RuntimeException('invalid_confirmation_token');
        }
        if ((int) ($confirmation['expires_at'] ?? 0) < time()) {
            throw new \RuntimeException('expired_confirmation_token');
        }
        if ((int) ($confirmation['ticket_id'] ?? 0) !== $ticketId || (string) ($confirmation['action'] ?? '') !== $action) {
            throw new \RuntimeException('confirmation_scope_mismatch');
        }
        if ((int) ($confirmation['user_id'] ?? 0) !== (int) ($_SESSION['glpiID'] ?? 0)) {
            throw new \RuntimeException('confirmation_user_mismatch');
        }
    }

    private static function purgeExpiredTicketCriticalConfirmations(): void
    {
        $state = is_array($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] ?? null)
            ? $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY]
            : [];
        $now = time();
        foreach ($state as $token => $confirmation) {
            if (!is_array($confirmation) || (int) ($confirmation['expires_at'] ?? 0) < $now) {
                unset($state[$token]);
            }
        }
        $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] = $state;
    }

    /**
     * @return string[]
     */
    private static function getRevealedFields(int $ticketId): array
    {
        $state = $_SESSION['glpiacessivel_pii_reveal'] ?? [];
        $ticketState = $state[$ticketId] ?? null;
        if (!is_array($ticketState)) {
            return [];
        }

        $expiresAt = (int) ($ticketState['expires_at'] ?? 0);
        if ($expiresAt < time()) {
            unset($_SESSION['glpiacessivel_pii_reveal'][$ticketId]);
            return [];
        }

        $fields = $ticketState['fields'] ?? [];
        if (!is_array($fields)) {
            return [];
        }

        return array_values(array_intersect($fields, ['requester_email', 'requester_phone', 'requester_mobile']));
    }

    private static function grantTemporaryReveal(int $ticketId, string $field): void
    {
        if (!isset($_SESSION['glpiacessivel_pii_reveal']) || !is_array($_SESSION['glpiacessivel_pii_reveal'])) {
            $_SESSION['glpiacessivel_pii_reveal'] = [];
        }

        $entry = $_SESSION['glpiacessivel_pii_reveal'][$ticketId] ?? ['fields' => []];
        if (!is_array($entry)) {
            $entry = ['fields' => []];
        }

        $fields = $entry['fields'] ?? [];
        if (!is_array($fields)) {
            $fields = [];
        }
        if (!in_array($field, $fields, true)) {
            $fields[] = $field;
        }

        $_SESSION['glpiacessivel_pii_reveal'][$ticketId] = [
            'fields' => $fields,
            'expires_at' => time() + self::PII_REVEAL_TTL_SECONDS,
        ];
    }

    private static function processAdvancedSearchPost(): void
    {
        try {
            self::csrf()->validateRequest(true);
        } catch (\Throwable $e) {
            self::storeAdvancedFailure('post_csrf', 'native_search_csrf_failed', $e);
            \Html::redirect(Url::plugin('front/ticket.php?search_mode=advanced'));
            return;
        }

        try {
            $advanced = self::advancedPostPayload($_POST);
            $service = self::container()->savedTicketSearchService();
            $catalogRevision = self::advancedCatalogRevision($service->searchCatalog());
            $translated = (new AdvancedTicketSearchRequest())->translate($advanced);
            if (!hash_equals($catalogRevision, (string) $translated['context_revision'])) {
                throw new NativeSearchValidationException(
                    'native_search_context_stale',
                    'advanced.context_revision'
                );
            }

            $definition = $service->validateDefinition((array) $translated['definition']);
            self::container()->remoteSearchValueAuthorizer()->authorize(
                $definition,
                $catalogRevision
            );
            $token = (new TicketSearchStateStore())->issue([
                'definition' => $definition,
                'page_size' => (int) $translated['page_size'],
            ], $catalogRevision);
            unset($_SESSION[self::ADVANCED_SEARCH_ERROR_SESSION_KEY]);
            \Html::redirect(Url::plugin('front/ticket.php?' . http_build_query([
                'advanced_search_token' => $token,
                'focus' => 'results',
            ], '', '&', PHP_QUERY_RFC3986)));
        } catch (\Throwable $e) {
            $code = self::advancedFailureCode($e, 'native_search_request_invalid');
            self::storeAdvancedFailure('post_validate', $code, $e);
            \Html::redirect(Url::plugin('front/ticket.php?search_mode=advanced'));
        }
    }

    /**
     * @param array<string,mixed> $post
     * @return array<string,mixed>
     */
    private static function advancedPostPayload(array $post): array
    {
        $allowedKeys = [
            '_glpi_csrf_token',
            'search_mode',
            'advanced_schema_version',
            'advanced_request_complete',
            'advanced',
            'q',
            'scope',
        ];
        foreach (array_keys($post) as $key) {
            if (!is_string($key) || !in_array($key, $allowedKeys, true)) {
                throw new NativeSearchValidationException(
                    'native_search_parameter_unsupported',
                    'request'
                );
            }
        }

        if (($post['search_mode'] ?? null) !== 'advanced') {
            throw new NativeSearchValidationException(
                'native_search_mode_unsupported',
                'search_mode'
            );
        }
        $schemaVersion = $post['advanced_schema_version'] ?? null;
        if (!is_string($schemaVersion) || !in_array($schemaVersion, ['2', '3'], true)) {
            throw new NativeSearchValidationException(
                'native_search_schema_unsupported',
                'advanced_schema_version'
            );
        }
        if (($post['advanced_request_complete'] ?? null) !== '1') {
            throw new NativeSearchValidationException(
                'native_search_request_incomplete',
                'advanced_request_complete'
            );
        }
        if (!is_array($post['advanced'] ?? null)) {
            throw new NativeSearchValidationException(
                'native_search_request_invalid',
                'advanced'
            );
        }
        if ($schemaVersion === '3' && (!array_key_exists('q', $post) || !array_key_exists('scope', $post))) {
            throw new NativeSearchValidationException(
                'native_search_request_incomplete',
                'request'
            );
        }

        $query = $post['q'] ?? '';
        $validUtf8 = is_string($query) && (
            function_exists('mb_check_encoding')
                ? mb_check_encoding($query, 'UTF-8')
                : preg_match('//u', $query) === 1
        );
        if (
            !$validUtf8
            || mb_strlen((string) $query, 'UTF-8') > 120
            || preg_match('/[\x00-\x1F\x7F]/u', (string) $query) === 1
        ) {
            throw new NativeSearchValidationException(
                'native_search_text_invalid',
                'q'
            );
        }
        $scope = $post['scope'] ?? 'all';
        if (!is_string($scope) || !in_array($scope, ['all', 'mine', 'group'], true)) {
            throw new NativeSearchValidationException(
                'native_search_scope_unsupported',
                'scope'
            );
        }

        $advanced = $post['advanced'];
        $advanced['text'] = trim((string) $query);
        $advanced['scope'] = $scope;
        return $advanced;
    }

    /**
     * @param string[] $selected
     * @param array<string,mixed> $catalog
     * @return string[]
     */
    private static function validatedPresentationColumns(array $selected, array $catalog): array
    {
        $allowed = [];
        $required = [];
        foreach ((array) ($catalog['columns'] ?? []) as $column) {
            if (!is_array($column) || empty($column['available'])) {
                continue;
            }
            $identifier = trim((string) ($column['identifier'] ?? $column['key'] ?? ''));
            if ($identifier === '' || preg_match('/\A[a-z][a-z0-9_]{0,63}\z/D', $identifier) !== 1) {
                continue;
            }
            $allowed[$identifier] = true;
            if (!empty($column['required'])) {
                $required[$identifier] = true;
            }
        }

        $normalized = [];
        foreach ($selected as $column) {
            $identifier = is_scalar($column) ? trim((string) $column) : '';
            if ($identifier !== '' && isset($allowed[$identifier]) && !in_array($identifier, $normalized, true)) {
                $normalized[] = $identifier;
            }
        }
        foreach (array_keys($required) as $identifier) {
            if (!in_array($identifier, $normalized, true)) {
                array_unshift($normalized, $identifier);
            }
        }
        if ($normalized === []) {
            foreach (['id', 'name'] as $identifier) {
                if (isset($allowed[$identifier])) {
                    $normalized[] = $identifier;
                }
            }
        }
        return $normalized;
    }

    /** @param array<string,mixed> $catalog */
    private static function advancedCatalogRevision(array $catalog): string
    {
        $revision = $catalog['context_revision'] ?? null;
        if (
            !is_string($revision)
            || preg_match('/\A[a-f0-9]{64}\z/D', $revision) !== 1
        ) {
            throw new NativeSearchValidationException(
                'native_search_context_stale',
                'catalog.context_revision'
            );
        }
        return $revision;
    }

    /**
     * @param array<string,mixed> $state
     * @return array{definition:array<string,mixed>,page_size:int}
     */
    private static function advancedStateWrapper(array $state): array
    {
        if (
            array_keys($state) !== ['definition', 'page_size']
            || !is_array($state['definition'] ?? null)
            || !is_int($state['page_size'] ?? null)
            || !in_array($state['page_size'], [10, 20, 50, 100], true)
        ) {
            throw new NativeSearchValidationException(
                'native_search_token_invalid',
                'advanced_search_token'
            );
        }
        return [
            'definition' => $state['definition'],
            'page_size' => $state['page_size'],
        ];
    }

    /**
     * @param array<string,mixed> $filters
     * @param array<string,mixed> $definition
     * @return array<string,mixed>
     */
    private static function applyAdvancedDefinitionToFilters(
        array $filters,
        array $definition,
        int $pageSize
    ): array {
        foreach (['criteria', 'metacriteria', 'sort', 'order', 'columns'] as $key) {
            if (!is_array($definition[$key] ?? null)) {
                throw new NativeSearchValidationException(
                    'native_search_definition_invalid',
                    'definition.' . $key
                );
            }
        }
        $text = $definition['text'] ?? null;
        $scope = $definition['scope'] ?? null;
        if (!is_string($text) || !is_string($scope) || !in_array($scope, ['all', 'mine', 'group'], true)) {
            throw new NativeSearchValidationException(
                'native_search_definition_invalid',
                'definition.scope'
            );
        }
        $isDeleted = $definition['is_deleted'] ?? null;
        if (!is_int($isDeleted) || !in_array($isDeleted, [0, 1], true)) {
            throw new NativeSearchValidationException(
                'native_search_definition_invalid',
                'definition.is_deleted'
            );
        }
        if (!in_array($pageSize, [10, 20, 50, 100], true)) {
            throw new NativeSearchValidationException(
                'native_search_page_size_unsupported',
                'page_size'
            );
        }

        unset(
            $filters['native_saved_search_id'],
            $filters['native_parameters'],
            $filters['saved_search_invalid']
        );
        $filters['scope'] = $scope;
        $filters['status'] = '';
        $filters['q'] = $text;
        $filters['group_id'] = 0;
        $filters['group_by'] = 'none';
        $filters['sort'] = 'date_mod';
        $filters['direction'] = 'DESC';
        $filters['native_criteria'] = $definition['criteria'];
        $filters['native_metacriteria'] = $definition['metacriteria'];
        $filters['native_sort'] = $definition['sort'];
        $filters['native_order'] = $definition['order'];
        $filters['native_is_deleted'] = $isDeleted;
        $filters['columns'] = $definition['columns'];
        $filters['page_size'] = $pageSize;

        return $filters;
    }

    /**
     * @param array<string,mixed> $definition
     * @return array<string,mixed>
     */
    private static function advancedBuilderState(
        array $definition,
        bool $editable,
        bool $focusResults
    ): array {
        return [
            'text' => (string) ($definition['text'] ?? ''),
            'scope' => (string) ($definition['scope'] ?? 'all'),
            'criteria' => (array) ($definition['criteria'] ?? []),
            'metacriteria' => (array) ($definition['metacriteria'] ?? []),
            'sort' => (array) ($definition['sort'] ?? []),
            'order' => (array) ($definition['order'] ?? []),
            'is_deleted' => (int) ($definition['is_deleted'] ?? 0),
            'columns' => (array) ($definition['columns'] ?? []),
            'editable' => $editable,
            'focus_results' => $focusResults,
        ];
    }

    private static function advancedFailureCode(\Throwable $exception, string $fallback): string
    {
        if ($exception instanceof NativeSearchValidationException) {
            $reason = $exception->reasonCode();
            if (preg_match('/\Anative_search_[a-z0-9_]{1,80}\z/D', $reason) === 1) {
                return $reason;
            }
        }
        return $fallback;
    }

    private static function advancedErrorMessage(string $code): string
    {
        $messages = [
            'native_search_csrf_failed' => __(
                'Sua sessao expirou. Recarregue a lista antes de aplicar a busca avancada.',
                'glpiacessivel'
            ),
            'native_search_request_incomplete' => __(
                'A busca avancada nao foi recebida por completo. Revise os criterios e tente novamente.',
                'glpiacessivel'
            ),
            'native_search_context_stale' => __(
                'Os campos de pesquisa mudaram para o perfil ou entidade atual. Recarregue e revise a busca.',
                'glpiacessivel'
            ),
            'native_search_remote_value_not_authorized' => __(
                'Um valor selecionado nao esta disponivel para o perfil ou entidade atual. Revise a busca.',
                'glpiacessivel'
            ),
            'native_search_remote_context_unavailable' => __(
                'Nao foi possivel confirmar os valores selecionados no contexto atual. Recarregue e tente novamente.',
                'glpiacessivel'
            ),
            'native_search_remote_rate_limited' => __(
                'Muitos valores foram confirmados em pouco tempo. Aguarde e tente aplicar a busca novamente.',
                'glpiacessivel'
            ),
            'native_search_remote_values_limit_exceeded' => __(
                'A busca possui valores selecionados demais para uma unica aplicacao. Reduza os criterios.',
                'glpiacessivel'
            ),
            'native_search_token_invalid' => __(
                'A busca avancada expirou ou pertence a outro contexto. Aplique os criterios novamente.',
                'glpiacessivel'
            ),
            'native_search_catalog_unavailable' => __(
                'A busca avancada esta temporariamente indisponivel neste contexto.',
                'glpiacessivel'
            ),
        ];
        return $messages[$code] ?? __(
            'Nao foi possivel aplicar a busca avancada. Revise os campos indicados e tente novamente.',
            'glpiacessivel'
        );
    }

    private static function storeAdvancedFailure(
        string $phase,
        string $code,
        \Throwable $exception
    ): void {
        $_SESSION[self::ADVANCED_SEARCH_ERROR_SESSION_KEY] = $code;
        self::auditAdvancedFailure($phase, $code, $exception);
    }

    private static function consumeAdvancedSearchError(): string
    {
        $code = $_SESSION[self::ADVANCED_SEARCH_ERROR_SESSION_KEY] ?? '';
        unset($_SESSION[self::ADVANCED_SEARCH_ERROR_SESSION_KEY]);
        return is_string($code)
            && preg_match('/\Anative_search_[a-z0-9_]{1,80}\z/D', $code) === 1
                ? $code
                : '';
    }

    private static function auditAdvancedFailure(
        string $phase,
        string $code,
        \Throwable $exception
    ): void {
        self::container()->auditLogger()->log('ticket.advanced_search.failed', [
            'phase' => $phase,
            'error_code' => $code,
            'exception' => get_class($exception),
        ]);
    }

    private static function storeCreate(): void
    {
        $sanitizer = new InputSanitizer();
        $values = [
            'name' => $sanitizer->text($_POST['name'] ?? '', 255),
            'content' => $sanitizer->text($_POST['content'] ?? '', 16000),
            'type' => $sanitizer->int($_POST['type'] ?? self::incidentType(), self::incidentType()),
            'itilcategories_id' => max(0, $sanitizer->int($_POST['itilcategories_id'] ?? 0, 0)),
            'locations_id' => max(0, $sanitizer->int($_POST['locations_id'] ?? 0, 0)),
            'requesttypes_id' => max(0, $sanitizer->int($_POST['requesttypes_id'] ?? 1, 1)),
            'externalid' => $sanitizer->text($_POST['externalid'] ?? '', 255),
            'tickettemplates_id' => max(0, $sanitizer->int($_POST['tickettemplates_id'] ?? 0, 0)),
            'urgency' => $sanitizer->int($_POST['urgency'] ?? 3, 3),
            'impact' => $sanitizer->int($_POST['impact'] ?? 3, 3),
            '_users_id_assign' => array_values(array_filter(array_map('intval', (array) ($_POST['_users_id_assign'] ?? [])))),
            '_users_id_observer' => array_values(array_filter(array_map('intval', (array) ($_POST['_users_id_observer'] ?? [])))),
            '_groups_id_assign' => array_values(array_filter(array_map('intval', (array) ($_POST['_groups_id_assign'] ?? [])))),
            '_groups_id_observer' => array_values(array_filter(array_map('intval', (array) ($_POST['_groups_id_observer'] ?? [])))),
        ];

        $errors = [];
        try {
            $values = UploadedFileMapper::mergeInto($values, UploadedFileMapper::map('filename'));
        } catch (\Throwable $e) {
            $errors[] = self::formError('filename', 'upload_error', $e->getMessage());
        }
        if ($values['name'] === '') {
            $errors[] = self::formError('name', 'required', 'Informe o titulo do chamado.');
        }
        if ($values['content'] === '') {
            $errors[] = self::formError('content', 'required', 'Informe a descricao do chamado.');
        }
        if (!in_array($values['type'], [self::incidentType(), self::demandType()], true)) {
            $errors[] = self::formError('type', 'invalid', 'Tipo de chamado invalido.');
        }
        if (!in_array($values['urgency'], [1, 2, 3, 4, 5], true)) {
            $errors[] = self::formError('urgency', 'invalid', 'Urgencia invalida.');
        }
        if (!in_array($values['impact'], [1, 2, 3, 4, 5], true)) {
            $errors[] = self::formError('impact', 'invalid', 'Impacto invalido.');
        }

        if ($errors !== []) {
            self::renderCreateForm($values, $errors);
            return;
        }

        try {
            $ticketId = self::container()->ticketService()->create($values);
            self::setMessage('success', 'Chamado registrado com sucesso.');
            \Html::redirect(Url::plugin('front/ticket.php?id=' . $ticketId));
        } catch (FormValidationException $e) {
            self::renderCreateForm($values, $e->errors(), $e->metadata());
        } catch (\Throwable $e) {
            self::renderCreateForm($values, [self::formError('', 'create_failed', 'Nao foi possivel registrar o chamado. Revise os dados e tente novamente.')]);
        }
    }

    /**
     * @return array{field:string, code:string, message:string}
     */
    private static function formError(string $field, string $code, string $message): array
    {
        return [
            'field' => $field,
            'code' => $code,
            'message' => $message,
        ];
    }

    private static function renderCreateForm(array $values, array $errors, array $submissionMetadata = []): void
    {
        $context = self::container()->ticketService()->creationContext($values);

        View::render('tickets/create', [
            'title' => __('Novo chamado', 'glpiacessivel'),
            'csrf_token' => self::csrf()->token(true),
            'values' => $values,
            'errors' => $errors,
            'submission_metadata' => $submissionMetadata,
            'context' => $context,
            'native_create_ticket_url' => self::nativeCreateTicketUrl(),
        ]);
    }

    private static function defaultCreateValues(): array
    {
        return [
            'name' => '',
            'content' => '',
            'type' => self::incidentType(),
            'itilcategories_id' => 0,
            'locations_id' => 0,
            'requesttypes_id' => 1,
            'externalid' => '',
            'tickettemplates_id' => 0,
            'urgency' => 3,
            'impact' => 3,
            '_users_id_assign' => [],
            '_users_id_observer' => [],
            '_groups_id_assign' => [],
            '_groups_id_observer' => [],
        ];
    }

    private static function incidentType(): int
    {
        return defined(\Ticket::class . '::INCIDENT_TYPE') ? (int) \Ticket::INCIDENT_TYPE : 1;
    }

    private static function demandType(): int
    {
        return defined(\Ticket::class . '::DEMAND_TYPE') ? (int) \Ticket::DEMAND_TYPE : 2;
    }

    private static function nativeCreateTicketUrl(): string
    {
        if (class_exists('\Ticket') && method_exists('\Ticket', 'getFormURL')) {
            return (string) \Ticket::getFormURL(false);
        }

        return Url::core('front/ticket.form.php');
    }

    /**
     * @param array<int, array<string, mixed>> $items
     * @return array<int, array{id:int,label:string}>
     */
    private static function extractGroupOptions(array $items): array
    {
        $map = [];
        foreach ($items as $item) {
            foreach ((array) ($item['group_ids'] ?? []) as $index => $id) {
                $id = (int) $id;
                if ($id <= 0) {
                    continue;
                }
                $name = (string) (((array) ($item['group_names'] ?? []))[$index] ?? ('Grupo ' . $id));
                $map[$id] = $name;
            }
        }

        asort($map);
        $options = [];
        foreach ($map as $id => $label) {
            $options[] = ['id' => (int) $id, 'label' => (string) $label];
        }

        return $options;
    }

    /**
     * @param array<int, array<string, mixed>> $items
     * @return array<string, array<int, array<string, mixed>>>
     */
    private static function groupTicketsByGroup(array $items, string $scope, string $groupBy): array
    {
        if (!in_array($scope, ['mine', 'group'], true) || $groupBy !== 'group') {
            return [];
        }

        $grouped = [];
        foreach ($items as $item) {
            $key = trim((string) ($item['primary_group_name'] ?? ''));
            if ($key === '') {
                $key = 'Sem grupo';
            }
            if (!isset($grouped[$key])) {
                $grouped[$key] = [];
            }
            $grouped[$key][] = $item;
        }

        ksort($grouped, SORT_NATURAL | SORT_FLAG_CASE);
        return $grouped;
    }
}
