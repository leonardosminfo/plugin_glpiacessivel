<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Infrastructure\FormCatalog\FormCatalogRequest;
use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\Presenter\FormExperiencePresenter;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class FormController extends BaseController
{
    public static function index(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_FORMS)) {
            return;
        }

        if (!self::container()->configService()->isFormsEnabled()) {
            self::setMessage('error', __('Os formulários estão desativados nas configurações do portal.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/acessivel.php'));
            return;
        }

        $sanitizer = new InputSanitizer();
        $rawQuery = $_GET['q'] ?? '';
        $rawCursor = $_GET['form_cursor'] ?? '';
        $query = $sanitizer->text(is_scalar($rawQuery) ? $rawQuery : '', 120);
        $cursor = $sanitizer->text(is_scalar($rawCursor) ? $rawCursor : '', 4000);
        $catalogRequest = new FormCatalogRequest($query, $cursor, 24);
        $service = self::container()->formService();
        $forms = $service->listAvailableForms($catalogRequest);
        $administrator = self::container()->authorization()->canViewFormDiagnostics();
        $catalogView = (new FormExperiencePresenter())->presentCatalog($forms, $administrator);

        View::render('forms/index', [
            'title' => __('Formulários', 'glpiacessivel'),
            'catalogView' => $catalogView,
            'formsNativeFlowMode' => self::container()->configService()->getFormsNativeFlowMode(),
            'showOperationalDiagnostics' => $administrator,
            'focusFormResults' => array_key_exists('q', $_GET) || array_key_exists('form_cursor', $_GET),
        ]);
    }


    public static function renderAccessible(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_FORMS)) {
            return;
        }

        if (!self::container()->configService()->isFormsEnabled()) {
            self::setMessage('error', __('Os formulários estão desativados nas configurações do portal.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/acessivel.php'));
            return;
        }

        $sanitizer = new InputSanitizer();
        $source = $sanitizer->enum($_GET['source'] ?? '', ['glpi11_service_catalog', 'formcreator_glpi10'], '');
        $id = max(0, $sanitizer->int($_GET['id'] ?? 0, 0));

        if ($source === '' || $id <= 0) {
            self::setMessage('error', __('Este formulário é inválido ou não está disponível.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/forms.php'));
            return;
        }

        $form = self::container()->formService()->resolveForm($source, $id);
        if ($form === null) {
            self::setMessage('error', __('Não foi possível abrir este formulário no perfil e na entidade atuais.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/forms.php'));
            return;
        }

        $schema = is_array($form['dynamic_form_schema'] ?? null) ? $form['dynamic_form_schema'] : [];
        $config = self::container()->configService();
        $administrator = self::container()->authorization()->canViewFormDiagnostics();
        $glpiVersion = defined('GLPI_VERSION') ? (string) constant('GLPI_VERSION') : '';
        $formcreatorVersion = defined('PLUGIN_FORMCREATOR_VERSION')
            ? (string) constant('PLUGIN_FORMCREATOR_VERSION')
            : '';
        $formView = (new FormExperiencePresenter())->presentForm(
            $form,
            $schema,
            $administrator,
            $glpiVersion,
            $formcreatorVersion
        );
        View::render('forms/render', [
            'title' => (string) ($formView['form']['name'] ?? __('Formulário', 'glpiacessivel')),
            'formView' => $formView,
            'formsNativeFlowMode' => $config->getFormsNativeFlowMode(),
            'formcreatorMinimalEmbedEnabled' => $config->isFormcreatorMinimalEmbedEnabled(),
            'glpiVersion' => $glpiVersion,
            'formcreatorVersion' => $formcreatorVersion,
            'showOperationalDiagnostics' => $administrator,
            'csrf_token' => self::csrf()->token(true),
        ]);
    }
    public static function open(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_FORMS)) {
            return;
        }

        if (!self::container()->configService()->isFormsEnabled()) {
            self::setMessage('error', __('Os formulários estão desativados nas configurações do portal.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/acessivel.php'));
            return;
        }

        $sanitizer = new InputSanitizer();
        $source = $sanitizer->enum($_GET['source'] ?? '', ['glpi11_service_catalog', 'formcreator_glpi10'], '');
        $id = max(0, $sanitizer->int($_GET['id'] ?? 0, 0));

        if ($source === '' || $id <= 0) {
            self::setMessage('error', __('Este formulário é inválido ou não está disponível.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/forms.php'));
            return;
        }

        $form = self::container()->formService()->resolveForm($source, $id);
        if ($form === null) {
            self::setMessage('error', __('Não foi possível abrir este formulário no perfil e na entidade atuais.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/forms.php'));
            return;
        }

        \Html::redirect((string) ($form['native_url'] ?? Url::plugin('front/forms.php')));
    }
}
