<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class ConfigController extends BaseController
{
    public static function index(): void
    {
        self::requireLogin();

        if (!\Session::haveRight('config', UPDATE)) {
            self::denyAccess(
                __('Sem permissão', 'glpiacessivel'),
                __('Seu perfil atual não possui permissão para acessar esta funcionalidade.', 'glpiacessivel'),
                'config.permission_denied',
                ['required_right' => 'config_update']
            );
            return;
        }

        $sanitizer = new InputSanitizer();
        $saved = false;
        $config = self::container()->configService();
        $config->migrateLegacyVoiceDefaults();
        $config->migrateLegacyVoiceAssetPaths();
        $previousChatbotDisplayName = $config->getChatbotDisplayName();
        $previousModuleStates = $config->getPortalModuleStates();
        $previousAuthenticationEntryMode = $config->getAuthenticationEntryMode();
        $previousLoginAccessibilityNotice = $config->isLoginAccessibilityNoticeEnabled();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (
                !self::validateCsrfOrRedirect(
                    \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/config.php'),
                    'config.csrf_rejected'
                )
            ) {
                return;
            }

            $moduleStates = $config->sanitizePortalModuleStates(
                is_array($_POST['module_states'] ?? null)
                    ? $_POST['module_states']
                    : $config->getPortalModuleStates()
            );
            $chatbotEnabled = $moduleStates[ConfigService::MODULE_CHATBOT] === ConfigService::MODULE_STATE_DISABLED
                ? '0'
                : '1';
            $chatbotDisplayName = $config->sanitizeChatbotDisplayName(
                $sanitizer->text(
                    $_POST['chatbot_display_name'] ?? $config->getChatbotDisplayName(),
                    ConfigService::CHATBOT_DISPLAY_NAME_MAX_LENGTH
                )
            );
            $chatbotFloatingScope = $sanitizer->enum(
                $_POST['chatbot_floating_scope'] ?? $config->getChatbotFloatingScope(),
                ConfigService::CHATBOT_FLOATING_SCOPES,
                $config->getChatbotFloatingScope()
            );
            $chatbotVoiceEnabled = $sanitizer->enum($_POST['chatbot_voice_enabled'] ?? '1', ['0', '1'], '1');
            $pluginFallbackLocale = $sanitizer->enum(
                $_POST['plugin_fallback_locale'] ?? $config->getPluginFallbackLocale(),
                ConfigService::SUPPORTED_LOCALES,
                $config->getPluginFallbackLocale()
            );
            $vlibrasScope = $sanitizer->enum(
                $_POST['vlibras_scope'] ?? $config->getVlibrasScope(),
                ConfigService::VLIBRAS_SCOPES,
                $config->getVlibrasScope()
            );
            $formsEnabled = $moduleStates[ConfigService::MODULE_FORMS] === ConfigService::MODULE_STATE_DISABLED
                ? '0'
                : '1';
            $piiMaskingEnabled = $sanitizer->enum(
                $_POST['pii_masking_enabled'] ?? ($config->isPiiMaskingEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isPiiMaskingEnabled() ? '1' : '0'
            );
            $formsNativeFlowMode = $sanitizer->enum(
                $_POST['forms_native_flow_mode'] ?? $config->getFormsNativeFlowMode(),
                ConfigService::FORMS_NATIVE_FLOW_MODES,
                $config->getFormsNativeFlowMode()
            );
            $formcreatorMinimalEmbedEnabled = $sanitizer->enum(
                $_POST['formcreator_minimal_embed_enabled']
                    ?? ($config->isFormcreatorMinimalEmbedEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isFormcreatorMinimalEmbedEnabled() ? '1' : '0'
            );
            $ticketAsyncListEnabled = $sanitizer->enum(
                $_POST['ticket_async_list_enabled'] ?? ($config->isTicketAsyncListEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isTicketAsyncListEnabled() ? '1' : '0'
            );
            $resourceSelectorEnabled = $sanitizer->enum(
                $_POST['resource_selector_enabled'] ?? ($config->isResourceSelectorEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isResourceSelectorEnabled() ? '1' : '0'
            );
            $resourceSelectorCreateEnabled = $sanitizer->enum(
                $_POST['resource_selector_create_enabled'] ?? ($config->isResourceSelectorCreateEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isResourceSelectorCreateEnabled() ? '1' : '0'
            );
            $resourceSelectorRoutingEnabled = $sanitizer->enum(
                $_POST['resource_selector_routing_enabled'] ?? ($config->isResourceSelectorRoutingEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isResourceSelectorRoutingEnabled() ? '1' : '0'
            );
            $formCatalogV2Enabled = $sanitizer->enum(
                $_POST['form_catalog_v2_enabled'] ?? ($config->isFormCatalogV2Enabled() ? '1' : '0'),
                ['0', '1'],
                $config->isFormCatalogV2Enabled() ? '1' : '0'
            );
            $accessibilityMode = $sanitizer->enum(
                $_POST['accessibility_mode'] ?? ConfigService::ACCESSIBILITY_MODE_HYBRID,
                [
                    ConfigService::ACCESSIBILITY_MODE_PORTAL,
                    ConfigService::ACCESSIBILITY_MODE_EMBEDDED,
                    ConfigService::ACCESSIBILITY_MODE_HYBRID,
                ],
                ConfigService::ACCESSIBILITY_MODE_HYBRID
            );
            $authenticationEntryMode = $config->sanitizeAuthenticationEntryMode(
                $sanitizer->text(
                    $_POST['authentication_entry_mode'] ?? $config->getAuthenticationEntryMode(),
                    64
                )
            );
            $showLoginAccessibilityNotice = $sanitizer->enum(
                $_POST['show_login_accessibility_notice']
                    ?? ($config->isLoginAccessibilityNoticeEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isLoginAccessibilityNoticeEnabled() ? '1' : '0'
            );
            $auditRetentionDays = min(3650, max(30, $sanitizer->int($_POST['audit_retention_days'] ?? 365, 365)));
            $requestedIntents = array_values(array_unique(array_map(
                static fn($value): string => $sanitizer->text($value, 80),
                (array) ($_POST['chatbot_enabled_intents'] ?? [])
            )));
            $chatbotVoiceLocale = $sanitizer->text($_POST['chatbot_voice_locale'] ?? 'pt-BR', 8);
            $chatbotVoiceAssetMode = $sanitizer->enum(
                $_POST['chatbot_voice_asset_mode'] ?? 'local_preferred',
                ConfigService::CHATBOT_VOICE_ASSET_MODES,
                'local_preferred'
            );
            $chatbotSttEngine = $sanitizer->enum(
                $_POST['chatbot_stt_engine'] ?? 'vosklet',
                ConfigService::CHATBOT_STT_ENGINES,
                'vosklet'
            );
            $chatbotTtsEngine = $sanitizer->enum(
                $_POST['chatbot_tts_engine'] ?? 'browser_native',
                ConfigService::CHATBOT_TTS_ENGINES,
                'browser_native'
            );
            $chatbotSttScriptUrl = $config->sanitizeChatbotExternalVoiceUrl(
                $sanitizer->text($_POST['chatbot_stt_script_url'] ?? '', 500),
                $config->getChatbotSttScriptUrl()
            );
            $chatbotSttModelUrl = $config->sanitizeChatbotExternalVoiceUrl(
                $sanitizer->text($_POST['chatbot_stt_model_url'] ?? '', 500),
                $config->getChatbotSttModelUrl()
            );
            $chatbotSttModelLabel = $sanitizer->text($_POST['chatbot_stt_model_label'] ?? '', 120);
            $chatbotSttModelCacheId = $sanitizer->text($_POST['chatbot_stt_model_cache_id'] ?? '', 120);
            $chatbotSttModelCacheId = preg_replace('/[^a-z0-9\-_]/i', '-', $chatbotSttModelCacheId) ?? 'glpi-vosk-ptbr';
            $chatbotTtsScriptUrl = $config->sanitizeChatbotExternalVoiceUrl(
                $sanitizer->text($_POST['chatbot_tts_script_url'] ?? '', 500),
                $config->getChatbotTtsScriptUrl()
            );
            $chatbotTtsVoiceId = $sanitizer->text($_POST['chatbot_tts_voice_id'] ?? '', 120);
            $chatbotSttScriptLocalPath = $config->sanitizeChatbotSttScriptLocalPath(
                $sanitizer->text($_POST['chatbot_stt_script_local_path'] ?? '', 300)
            );
            $chatbotSttModelLocalPath = $config->sanitizeChatbotSttModelLocalPath(
                $sanitizer->text($_POST['chatbot_stt_model_local_path'] ?? '', 300)
            );
            $chatbotTtsScriptLocalPath = $config->sanitizeChatbotTtsScriptLocalPath(
                $sanitizer->text($_POST['chatbot_tts_script_local_path'] ?? '', 300)
            );
            $chatbotTtsOnnxRuntimeLocalPath = $config->sanitizeChatbotTtsOnnxRuntimeLocalPath(
                $sanitizer->text($_POST['chatbot_tts_onnx_runtime_local_path'] ?? '', 300)
            );
            $chatbotTtsOnnxWasmLocalPath = $config->sanitizeChatbotTtsOnnxWasmLocalPath(
                $sanitizer->text($_POST['chatbot_tts_onnx_wasm_local_path'] ?? '', 300)
            );
            $chatbotTtsPiperWasmLocalPath = $config->sanitizeChatbotTtsPiperWasmLocalPath(
                $sanitizer->text($_POST['chatbot_tts_piper_wasm_local_path'] ?? '', 300)
            );
            $chatbotTtsPiperDataLocalPath = $config->sanitizeChatbotTtsPiperDataLocalPath(
                $sanitizer->text($_POST['chatbot_tts_piper_data_local_path'] ?? '', 300)
            );
            $chatbotTtsVoiceModelLocalPath = $config->sanitizeChatbotTtsVoiceModelLocalPath(
                $sanitizer->text($_POST['chatbot_tts_voice_model_local_path'] ?? '', 300)
            );
            $chatbotTtsVoiceConfigLocalPath = $config->sanitizeChatbotTtsVoiceConfigLocalPath(
                $sanitizer->text($_POST['chatbot_tts_voice_config_local_path'] ?? '', 300)
            );

            $config->setPortalModuleStates($moduleStates);
            $config->setValue('chatbot_display_name', $chatbotDisplayName);
            $config->setValue('chatbot_floating_scope', $chatbotFloatingScope);
            $config->setValue('chatbot_floating_button_enabled', $chatbotFloatingScope === 'disabled' ? '0' : '1');
            $config->setValue('chatbot_voice_enabled', $chatbotVoiceEnabled);
            $config->setValue('plugin_fallback_locale', $pluginFallbackLocale);
            $config->setValue('vlibras_scope', $vlibrasScope);
            $config->setValue('pii_masking_enabled', $piiMaskingEnabled);
            $config->setValue('forms_native_flow_mode', $formsNativeFlowMode);
            $config->setValue('formcreator_minimal_embed_enabled', $formcreatorMinimalEmbedEnabled);
            $config->setValue('ticket_async_list_enabled', $ticketAsyncListEnabled);
            $config->setValue('resource_selector_enabled', $resourceSelectorEnabled);
            $config->setValue('resource_selector_create_enabled', $resourceSelectorCreateEnabled);
            $config->setValue('resource_selector_routing_enabled', $resourceSelectorRoutingEnabled);
            $config->setValue('form_catalog_v2_enabled', $formCatalogV2Enabled);
            $config->setValue('accessibility_mode', $accessibilityMode);
            $config->setValue('authentication_entry_mode', $authenticationEntryMode);
            $config->setValue('show_login_accessibility_notice', $showLoginAccessibilityNotice);
            $config->setValue('audit_retention_days', (string) $auditRetentionDays);
            $config->setValue('chatbot_voice_locale', $chatbotVoiceLocale);
            $config->setValue('chatbot_voice_asset_mode', $chatbotVoiceAssetMode);
            $config->setValue('chatbot_stt_engine', $chatbotSttEngine);
            $config->setValue('chatbot_tts_engine', $chatbotTtsEngine);
            $config->setValue('chatbot_stt_script_local_path', $chatbotSttScriptLocalPath);
            $config->setValue('chatbot_stt_model_local_path', $chatbotSttModelLocalPath);
            $config->setValue('chatbot_tts_script_local_path', $chatbotTtsScriptLocalPath);
            $config->setValue('chatbot_tts_onnx_runtime_local_path', $chatbotTtsOnnxRuntimeLocalPath);
            $config->setValue('chatbot_tts_onnx_wasm_local_path', $chatbotTtsOnnxWasmLocalPath);
            $config->setValue('chatbot_tts_piper_wasm_local_path', $chatbotTtsPiperWasmLocalPath);
            $config->setValue('chatbot_tts_piper_data_local_path', $chatbotTtsPiperDataLocalPath);
            $config->setValue('chatbot_tts_voice_model_local_path', $chatbotTtsVoiceModelLocalPath);
            $config->setValue('chatbot_tts_voice_config_local_path', $chatbotTtsVoiceConfigLocalPath);
            $config->setValue('chatbot_stt_script_url', $chatbotSttScriptUrl);
            $config->setValue('chatbot_stt_model_url', $chatbotSttModelUrl);
            $config->setValue('chatbot_stt_model_label', $chatbotSttModelLabel);
            $config->setValue('chatbot_stt_model_cache_id', $chatbotSttModelCacheId);
            $config->setValue('chatbot_tts_script_url', $chatbotTtsScriptUrl);
            $config->setValue('chatbot_tts_voice_id', $chatbotTtsVoiceId);
            $config->setChatbotEnabledIntents($requestedIntents);

            self::container()->auditLogger()->log('config.update', [
                'chatbot_enabled' => $chatbotEnabled,
                'chatbot_display_name_changed' => $chatbotDisplayName !== $previousChatbotDisplayName,
                'chatbot_display_name_length' => mb_strlen($chatbotDisplayName, 'UTF-8'),
                'chatbot_floating_scope' => $chatbotFloatingScope,
                'chatbot_voice_enabled' => $chatbotVoiceEnabled,
                'plugin_fallback_locale' => $pluginFallbackLocale,
                'vlibras_scope' => $vlibrasScope,
                'forms_enabled' => $formsEnabled,
                'module_states' => $moduleStates,
                'pii_masking_enabled' => $piiMaskingEnabled,
                'forms_native_flow_mode' => $formsNativeFlowMode,
                'formcreator_minimal_embed_enabled' => $formcreatorMinimalEmbedEnabled,
                'ticket_async_list_enabled' => $ticketAsyncListEnabled,
                'resource_selector_enabled' => $resourceSelectorEnabled,
                'resource_selector_create_enabled' => $resourceSelectorCreateEnabled,
                'resource_selector_routing_enabled' => $resourceSelectorRoutingEnabled,
                'form_catalog_v2_enabled' => $formCatalogV2Enabled,
                'accessibility_mode' => $accessibilityMode,
                'authentication_entry_mode' => $authenticationEntryMode,
                'show_login_accessibility_notice' => $showLoginAccessibilityNotice,
                'audit_retention_days' => $auditRetentionDays,
                'chatbot_voice_locale' => $chatbotVoiceLocale,
                'chatbot_voice_asset_mode' => $chatbotVoiceAssetMode,
                'chatbot_stt_engine' => $chatbotSttEngine,
                'chatbot_tts_engine' => $chatbotTtsEngine,
                'chatbot_enabled_intents_count' => count($config->getChatbotEnabledIntents()),
            ]);
            if ($moduleStates !== $previousModuleStates) {
                self::container()->auditLogger()->log('config.modules_updated', [
                    'previous' => $previousModuleStates,
                    'current' => $moduleStates,
                ]);
            }
            if ($authenticationEntryMode !== $previousAuthenticationEntryMode) {
                self::container()->auditLogger()->log('config.authentication_entry_mode_updated', [
                    'previous' => $previousAuthenticationEntryMode,
                    'current' => $authenticationEntryMode,
                ]);
            }
            if (($showLoginAccessibilityNotice === '1') !== $previousLoginAccessibilityNotice) {
                self::container()->auditLogger()->log('config.login_accessibility_notice_updated', [
                    'previous' => $previousLoginAccessibilityNotice ? '1' : '0',
                    'current' => $showLoginAccessibilityNotice,
                ]);
            }
            unset($_SESSION['glpimenu']);
            $saved = true;
        }

        View::render('config/index', [
            'title' => __('Configuração do plugin', 'glpiacessivel'),
            'saved' => $saved,
            'csrf_token' => self::csrf()->token(),
            'chatbot_enabled' => $config->isChatbotEnabled() ? '1' : '0',
            'chatbot_display_name' => $config->getChatbotDisplayName(),
            'chatbot_floating_scope' => $config->getChatbotFloatingScope(),
            'chatbot_floating_scopes' => ConfigService::CHATBOT_FLOATING_SCOPES,
            'chatbot_voice_enabled' => $config->isChatbotVoiceEnabled() ? '1' : '0',
            'plugin_fallback_locale' => $config->getPluginFallbackLocale(),
            'supported_locales' => ConfigService::SUPPORTED_LOCALES,
            'vlibras_scope' => $config->getVlibrasScope(),
            'vlibras_scopes' => ConfigService::VLIBRAS_SCOPES,
            'forms_enabled' => $config->isFormsEnabled() ? '1' : '0',
            'portal_modules' => ConfigService::PORTAL_MODULES,
            'portal_module_states' => $config->getPortalModuleStates(),
            'portal_module_effective_states' => self::container()->portalModulePolicy()->getEffectiveStates(),
            'portal_module_labels' => self::portalModuleLabels(),
            'portal_module_descriptions' => self::portalModuleDescriptions(),
            'portal_module_state_labels' => self::portalModuleStateLabels(),
            'portal_module_state_descriptions' => self::portalModuleStateDescriptions(),
            'portal_module_presets' => ConfigService::MODULE_PRESETS,
            'portal_module_preset_labels' => self::portalModulePresetLabels(),
            'pii_masking_enabled' => $config->isPiiMaskingEnabled() ? '1' : '0',
            'forms_native_flow_mode' => $config->getFormsNativeFlowMode(),
            'forms_native_flow_modes' => ConfigService::FORMS_NATIVE_FLOW_MODES,
            'formcreator_minimal_embed_enabled' => $config->isFormcreatorMinimalEmbedEnabled() ? '1' : '0',
            'ticket_async_list_enabled' => $config->isTicketAsyncListEnabled() ? '1' : '0',
            'resource_selector_enabled' => $config->isResourceSelectorEnabled() ? '1' : '0',
            'resource_selector_create_enabled' => $config->isResourceSelectorCreateEnabled() ? '1' : '0',
            'resource_selector_routing_enabled' => $config->isResourceSelectorRoutingEnabled() ? '1' : '0',
            'form_catalog_v2_enabled' => $config->isFormCatalogV2Enabled() ? '1' : '0',
            'i18n_diagnostics' => $config->getI18nDiagnostics(),
            'operational_diagnostics' => $config->getOperationalDiagnostics(),
            'accessibility_mode' => $config->getAccessibilityMode(),
            'authentication_entry_mode' => $config->getAuthenticationEntryMode(),
            'authentication_entry_supported_modes' => ConfigService::AUTHENTICATION_ENTRY_SUPPORTED_MODES,
            'show_login_accessibility_notice' => $config->isLoginAccessibilityNoticeEnabled() ? '1' : '0',
            'audit_retention_days' => $config->getAuditRetentionDays(),
            'chatbot_intents' => ConfigService::CHATBOT_INTENTS,
            'chatbot_enabled_intents' => $config->getChatbotEnabledIntents(),
            'chatbot_intent_labels' => self::chatbotIntentLabels(),
            'chatbot_voice_locale' => $config->getChatbotVoiceLocale(),
            'chatbot_voice_asset_modes' => ConfigService::CHATBOT_VOICE_ASSET_MODES,
            'chatbot_voice_asset_mode' => $config->getChatbotVoiceAssetMode(),
            'chatbot_stt_engines' => ConfigService::CHATBOT_STT_ENGINES,
            'chatbot_tts_engines' => ConfigService::CHATBOT_TTS_ENGINES,
            'chatbot_stt_engine' => $config->getChatbotSttEngine(),
            'chatbot_tts_engine' => $config->getChatbotTtsEngine(),
            'chatbot_stt_script_local_path' => $config->getChatbotSttScriptLocalPath(),
            'chatbot_stt_model_local_path' => $config->getChatbotSttModelLocalPath(),
            'chatbot_tts_script_local_path' => $config->getChatbotTtsScriptLocalPath(),
            'chatbot_tts_onnx_runtime_local_path' => $config->getChatbotTtsOnnxRuntimeLocalPath(),
            'chatbot_tts_onnx_wasm_local_path' => $config->getChatbotTtsOnnxWasmLocalPath(),
            'chatbot_tts_piper_wasm_local_path' => $config->getChatbotTtsPiperWasmLocalPath(),
            'chatbot_tts_piper_data_local_path' => $config->getChatbotTtsPiperDataLocalPath(),
            'chatbot_tts_voice_model_local_path' => $config->getChatbotTtsVoiceModelLocalPath(),
            'chatbot_tts_voice_config_local_path' => $config->getChatbotTtsVoiceConfigLocalPath(),
            'chatbot_stt_script_url' => $config->getChatbotSttScriptUrl(),
            'chatbot_stt_model_url' => $config->getChatbotSttModelUrl(),
            'chatbot_stt_model_label' => $config->getChatbotSttModelLabel(),
            'chatbot_stt_model_cache_id' => $config->getChatbotSttModelCacheId(),
            'chatbot_tts_script_url' => $config->getChatbotTtsScriptUrl(),
            'chatbot_tts_voice_id' => $config->getChatbotTtsVoiceId(),
        ]);
    }

    /** @return array<string, string> */
    private static function portalModuleLabels(): array
    {
        return [
            ConfigService::MODULE_TICKET_CREATE => __('Abrir chamado', 'glpiacessivel'),
            ConfigService::MODULE_FORMS => __('Formulários', 'glpiacessivel'),
            ConfigService::MODULE_TICKETS => __('Chamados', 'glpiacessivel'),
            ConfigService::MODULE_COCKPIT => __('Cockpit', 'glpiacessivel'),
            ConfigService::MODULE_KNOWLEDGE => __('Base de conhecimento', 'glpiacessivel'),
            ConfigService::MODULE_CHATBOT => __('Chatbot operacional', 'glpiacessivel'),
            ConfigService::MODULE_PLAYBOOKS => __('Roteiros do chatbot', 'glpiacessivel'),
        ];
    }

    /** @return array<string, string> */
    private static function portalModuleDescriptions(): array
    {
        return [
            ConfigService::MODULE_TICKET_CREATE => __('Criação direta de chamados pelo portal acessível.', 'glpiacessivel'),
            ConfigService::MODULE_FORMS => __('Catálogo de formulários do GLPI 11 ou Formcreator do GLPI 10.', 'glpiacessivel'),
            ConfigService::MODULE_TICKETS => __('Listagem, detalhes e interações permitidas nos chamados.', 'glpiacessivel'),
            ConfigService::MODULE_COCKPIT => __('Indicadores operacionais derivados dos chamados visíveis.', 'glpiacessivel'),
            ConfigService::MODULE_KNOWLEDGE => __('Pesquisa e leitura da base de conhecimento.', 'glpiacessivel'),
            ConfigService::MODULE_CHATBOT => __('Assistente operacional com intenções limitadas pelos demais módulos e pelas permissões do GLPI.', 'glpiacessivel'),
            ConfigService::MODULE_PLAYBOOKS => __('Administração e curadoria dos roteiros do chatbot.', 'glpiacessivel'),
        ];
    }

    /** @return array<string, string> */
    private static function portalModuleStateLabels(): array
    {
        return [
            ConfigService::MODULE_STATE_AVAILABLE => __('Disponível no portal', 'glpiacessivel'),
            ConfigService::MODULE_STATE_HIDDEN => __('Oculto da navegação', 'glpiacessivel'),
            ConfigService::MODULE_STATE_DISABLED => __('Indisponível', 'glpiacessivel'),
        ];
    }

    /** @return array<string, string> */
    private static function portalModuleStateDescriptions(): array
    {
        return [
            ConfigService::MODULE_STATE_AVAILABLE => __('Aparece nos menus e atalhos quando as permissões do GLPI permitirem.', 'glpiacessivel'),
            ConfigService::MODULE_STATE_HIDDEN => __('Não aparece na navegação, mas o acesso direto continua sujeito às permissões do GLPI.', 'glpiacessivel'),
            ConfigService::MODULE_STATE_DISABLED => __('Não aparece e suas rotas de consulta e alteração ficam bloqueadas.', 'glpiacessivel'),
        ];
    }

    /** @return array<string, string> */
    private static function portalModulePresetLabels(): array
    {
        return [
            'complete' => __('Experiência completa', 'glpiacessivel'),
            'presentation_basic' => __('Apresentação básica', 'glpiacessivel'),
            'read_only_demo' => __('Demonstração de consulta', 'glpiacessivel'),
            'self_service_pilot' => __('Piloto Self-Service', 'glpiacessivel'),
            'technical_pilot' => __('Piloto técnico', 'glpiacessivel'),
        ];
    }
    private static function chatbotIntentLabels(): array
    {
        return [
            'mine_tickets' => __('Listar meus chamados', 'glpiacessivel'),
            'ticket_lookup' => __('Consultar chamado por número', 'glpiacessivel'),
            'ticket_criar_guiado' => __('Criar chamado guiado', 'glpiacessivel'),
            'ticket_triagem_inicial' => __('Triagem inicial', 'glpiacessivel'),
            'ticket_escalonar' => __('Encaminhar chamado', 'glpiacessivel'),
            'ticket_reclassificar' => __('Alterar categoria ou tipo', 'glpiacessivel'),
            'ticket_priorizar' => __('Priorizar por urgência e impacto', 'glpiacessivel'),
            'ticket_sla_status' => __('Consultar risco de prazo', 'glpiacessivel'),
            'ticket_followup_operacional' => __('Registrar acompanhamento operacional', 'glpiacessivel'),
            'ticket_encerrar_com_validacao' => __('Encerrar com validação', 'glpiacessivel'),
            'kb_recomendar_contextual' => __('Recomendar artigos da base', 'glpiacessivel'),
            'comunicacao_usuario' => __('Sugerir comunicação ao requisitante', 'glpiacessivel'),
            'auditoria_consulta' => __('Consultar trilha de auditoria', 'glpiacessivel'),
            'handoff_humano' => __('Encaminhar para atendimento humano', 'glpiacessivel'),
        ];
    }
}
