<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiSearchValueProvider;
use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;

final class TicketSearchValueController extends BaseController
{
    public static function search(): void
    {
        self::requireLogin();
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            if (!headers_sent()) {
                header('Allow: POST');
            }
            self::respond(405, 'method_not_allowed');
            return;
        }

        if (
            !self::container()->portalModulePolicy()->isEnabled(ConfigService::MODULE_TICKETS)
            || !self::container()->authorization()->canViewTickets()
        ) {
            self::container()->auditLogger()->log('ticket.search_value.denied', [
                'reason' => 'not_authorized',
            ]);
            self::respond(403, 'not_authorized');
            return;
        }

        try {
            self::csrf()->validateRequest(true);
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('csrf.failed', [
                'endpoint' => 'ticket.search-values',
                'exception' => get_class($e),
            ]);
            self::respond(403, 'invalid_security_token');
            return;
        }

        $rate = self::container()->searchValueRateLimiter()->consume();
        if (!$rate['allowed']) {
            $status = $rate['reason'] === 'rate_limited' ? 429 : 403;
            if ($status === 429 && !headers_sent()) {
                header('Retry-After: ' . (string) $rate['retry_after']);
            }
            self::respond($status, $rate['reason']);
            return;
        }

        try {
            $request = self::request($_POST);
            $result = self::container()->searchValueProvider()->search(
                $request['itemtype'],
                $request['field'],
                $request['q'],
                $request['page'],
                $request['selected_id'],
                $request['operator'],
                $request['context_revision']
            );
            self::respond(200, '', $result);
        } catch (\InvalidArgumentException $e) {
            $errorCode = self::safeErrorCode($e, 'invalid_request');
            self::container()->auditLogger()->log('ticket.search_value.validation_failed', [
                'error_code' => $errorCode,
            ]);
            if ($errorCode === 'search_value_context_stale') {
                self::respond(409, 'context_stale');
                return;
            }
            self::respond(422, 'invalid_request');
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('ticket.search_value.failed', [
                'error_code' => 'lookup_failed',
                'exception' => get_class($e),
            ]);
            if (!headers_sent()) {
                header('Retry-After: 5');
            }
            self::respond(503, 'temporarily_unavailable');
        }
    }

    /**
     * @param array<string,mixed> $post
     * @return array{itemtype:string,field:int,q:string,page:int,selected_id:?int,operator:string,context_revision:string}
     */
    private static function request(array $post): array
    {
        $allowedKeys = [
            'itemtype',
            'field',
            'q',
            'page',
            'selected_id',
            'operator',
            'context_revision',
            '_glpi_csrf_token',
        ];
        foreach (array_keys($post) as $key) {
            if (
                !is_string($key)
                || !in_array($key, $allowedKeys, true)
            ) {
                throw new \InvalidArgumentException('search_value_parameter_not_allowed');
            }
        }
        if (
            !is_string($post['itemtype'] ?? null)
            || (
                array_key_exists('q', $post)
                && !is_string($post['q'])
            )
        ) {
            throw new \InvalidArgumentException('search_value_request_invalid');
        }

        $sanitizer = new InputSanitizer();
        $itemtype = $sanitizer->text($post['itemtype'] ?? '', 191);
        $query = $sanitizer->text(
            $post['q'] ?? '',
            GlpiSearchValueProvider::MAX_QUERY_LENGTH + 1
        );
        if (
            mb_strlen($query) > GlpiSearchValueProvider::MAX_QUERY_LENGTH
            || preg_match('/\A[A-Za-z_][A-Za-z0-9_\\\\]*\z/D', $itemtype) !== 1
        ) {
            throw new \InvalidArgumentException('search_value_request_invalid');
        }

        $field = self::strictInteger($post['field'] ?? null, 1, PHP_INT_MAX);
        $page = self::strictInteger(
            $post['page'] ?? 1,
            1,
            GlpiSearchValueProvider::MAX_PAGE
        );
        $selected = null;
        if (array_key_exists('selected_id', $post)) {
            $rawSelected = $post['selected_id'];
            if (!is_int($rawSelected) && !is_string($rawSelected)) {
                throw new \InvalidArgumentException('search_value_integer_invalid');
            }
            if ((string) $rawSelected !== '') {
                $selected = self::strictInteger($rawSelected, 0, PHP_INT_MAX);
            }
        }

        if (!is_string($post['operator'] ?? null)) {
            throw new \InvalidArgumentException('search_value_operator_invalid');
        }
        $operator = trim($post['operator']);
        if (
            $operator === ''
            || $operator !== strtolower($operator)
            || preg_match('/\A[a-z]{1,40}\z/D', $operator) !== 1
        ) {
            throw new \InvalidArgumentException('search_value_operator_invalid');
        }

        if (
            !is_string($post['context_revision'] ?? null)
            || preg_match('/\A[a-f0-9]{64}\z/D', $post['context_revision']) !== 1
        ) {
            throw new \InvalidArgumentException('search_value_context_stale');
        }
        $contextRevision = $post['context_revision'];
        return [
            'itemtype' => $itemtype,
            'field' => $field,
            'q' => $query,
            'page' => $page,
            'selected_id' => $selected,
            'operator' => $operator,
            'context_revision' => $contextRevision,
        ];
    }

    private static function strictInteger(mixed $value, int $minimum, int $maximum): int
    {
        if (
            (!is_int($value) && !is_string($value))
            || preg_match('/\A(?:0|[1-9]\d*)\z/D', (string) $value) !== 1
            || strlen((string) $value) > 10
        ) {
            throw new \InvalidArgumentException('search_value_integer_invalid');
        }
        $normalized = (int) $value;
        if ($normalized < $minimum || $normalized > $maximum) {
            throw new \InvalidArgumentException('search_value_integer_invalid');
        }

        return $normalized;
    }

    /**
     * @param array{
     *   results:array<int,array{id:int,label:string}>,
     *   pagination:array{more:bool}
     * }|null $result
     */
    private static function respond(int $status, string $error = '', ?array $result = null): void
    {
        if (!headers_sent()) {
            http_response_code($status);
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store, private');
            header('X-Content-Type-Options: nosniff');
        }

        $payload = [
            'contract' => GlpiSearchValueProvider::CONTRACT,
            'version' => GlpiSearchValueProvider::VERSION,
            'success' => $status >= 200 && $status < 300,
            'results' => $result['results'] ?? [],
            'pagination' => $result['pagination'] ?? ['more' => false],
        ];
        if ($error !== '') {
            $payload['error'] = $error;
        }
        $json = json_encode(
            $payload,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        );
        echo is_string($json)
            ? $json
            : '{"contract":"search_option_value","version":1,"success":false,"results":[],"pagination":{"more":false},"error":"encoding_failed"}';
    }

    private static function safeErrorCode(\Throwable $exception, string $fallback): string
    {
        $reason = $exception->getMessage();
        return preg_match('/\Asearch_value_[a-z0-9_]{1,80}\z/D', $reason) === 1
            ? $reason
            : $fallback;
    }
}
