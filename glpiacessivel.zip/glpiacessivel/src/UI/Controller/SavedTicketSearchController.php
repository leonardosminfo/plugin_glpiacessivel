<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\TicketSearchStateStore;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchValidationException;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\SavedTicketSearchRepository;
use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\Support\Url;

final class SavedTicketSearchController extends BaseController
{
    /**
     * @param array<string, mixed> $query
     * @return array{
     *   catalog:array<string,mixed>,
     *   selected:string,
     *   active:?array<string,mixed>,
     *   invalid:bool,
     *   filters:array<string,mixed>
     * }
     */
    public static function indexState(array $query): array
    {
        $service = self::container()->savedTicketSearchService();
        $sanitizer = new InputSanitizer();
        $catalogQuery = $sanitizer->text($query['saved_search_q'] ?? '', 120);
        $catalogCursor = $sanitizer->text($query['saved_search_cursor'] ?? '', 500);
        try {
            $catalog = $service->catalog($catalogQuery, $catalogCursor, 25);
        } catch (\InvalidArgumentException $exception) {
            if ($exception->getMessage() !== 'saved_search_cursor_invalid') {
                throw $exception;
            }
            self::container()->auditLogger()->log('ticket.saved_search.cursor_invalid', [
                'error_code' => 'saved_search_cursor_invalid',
            ]);
            self::setMessage(
                'warning',
                __(
                    'Não foi possível continuar a paginação das pesquisas salvas. Voltamos para a primeira página.',
                    'glpiacessivel'
                )
            );
            $catalog = $service->catalog($catalogQuery, '', 25);
        }
        $selected = $sanitizer->text($query['saved_search'] ?? '', 40);
        $hasExplicitSelection = array_key_exists('saved_search', $query);
        $hasExplicitFilters = count(array_intersect(
            array_keys($query),
            ['scope', 'status', 'q', 'group_id', 'group_by', 'page_size', 'sort', 'direction', 'columns', 'search_mode', 'advanced_search_token']
        )) > 0;
        if ($selected === '' && !$hasExplicitSelection && !$hasExplicitFilters) {
            $selected = (string) ($catalog['default_key'] ?? '');
        }

        $resolved = $selected !== '' ? $service->resolve($selected) : null;
        $invalid = $selected !== '' && $resolved === null;
        return [
            'catalog' => $catalog,
            'selected' => $selected,
            'active' => is_array($resolved['view'] ?? null) ? $resolved['view'] : null,
            'invalid' => $invalid,
            'filters' => is_array($resolved['filters'] ?? null) ? $resolved['filters'] : [],
        ];
    }

    public static function action(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }
        if (!self::container()->authorization()->canViewTickets()) {
            self::denyAccess(
                __('Pesquisas de chamados indisponíveis para este perfil', 'glpiacessivel'),
                __(
                    'O perfil ativo não possui permissão para consultar ou alterar pesquisas de chamados.',
                    'glpiacessivel'
                ),
                'ticket.saved_search.access_denied'
            );
            return;
        }
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            \Html::redirect(Url::plugin('front/tickets.php'));
            return;
        }

        try {
            self::csrf()->validateRequest(true);
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('csrf.failed', [
                'endpoint' => 'ticket.saved-search',
                'exception' => get_class($e),
            ]);
            self::setMessage(
                'error',
                __(
                    'Sua sessão expirou ou o token de segurança venceu. Recarregue a lista e tente novamente.',
                    'glpiacessivel'
                )
            );
            \Html::redirect(Url::plugin('front/tickets.php?saved_search='));
            return;
        }

        $sanitizer = new InputSanitizer();
        $action = $sanitizer->enum(
            $_POST['saved_search_action'] ?? '',
            ['create', 'update', 'delete', 'default', 'unset_default'],
            ''
        );
        $nativeId = max(0, $sanitizer->int($_POST['native_saved_search_id'] ?? 0));
        $expectedFingerprint = $sanitizer->text($_POST['expected_fingerprint'] ?? '', 64);
        $name = $sanitizer->text($_POST['saved_search_name'] ?? '', 180);
        $isDefault = (string) ($_POST['saved_search_default'] ?? '') === '1';
        $idempotencyKey = $sanitizer->text($_POST['idempotency_key'] ?? '', 512);
        $filters = SavedTicketSearchRepository::normalizePortalFilters([
            'scope' => $_POST['scope'] ?? 'all',
            'status' => $_POST['status'] ?? '',
            'q' => $_POST['q'] ?? '',
            'group_id' => $_POST['group_id'] ?? 0,
            'group_by' => $_POST['group_by'] ?? 'none',
            'page_size' => $_POST['page_size'] ?? 20,
            'sort' => $_POST['sort'] ?? 'date_mod',
            'direction' => $_POST['direction'] ?? 'DESC',
            'columns' => $_POST['columns'] ?? [],
        ]);
        $service = self::container()->savedTicketSearchService();
        $rawSearchMode = $_POST['search_mode'] ?? '';
        $searchMode = is_string($rawSearchMode)
            ? trim($rawSearchMode)
            : '__invalid__';
        $advancedDefinition = null;
        $redirect = 'front/tickets.php';

        try {
            if (!in_array($searchMode, ['', 'advanced'], true)) {
                throw new \InvalidArgumentException('saved_search_mode_invalid');
            }
            if ($action === '') {
                throw new \InvalidArgumentException('saved_search_action_invalid');
            }
            if ($action !== 'create') {
                if ($nativeId < 1) {
                    throw new \InvalidArgumentException('saved_search_id_invalid');
                }
                if (strlen($expectedFingerprint) !== 64 || !ctype_xdigit($expectedFingerprint)) {
                    throw new \InvalidArgumentException('saved_search_fingerprint_invalid');
                }
            }
            if ($action === 'delete' && (string) ($_POST['confirm_delete'] ?? '') !== '1') {
                throw new \InvalidArgumentException('saved_search_delete_confirmation_required');
            }
            if ($searchMode === 'advanced') {
                if ($action !== 'create') {
                    throw new \InvalidArgumentException('saved_search_mode_invalid');
                }
                $token = is_string($_POST['advanced_search_token'] ?? null)
                    ? trim((string) $_POST['advanced_search_token'])
                    : '';
                $contextRevision = self::advancedCatalogRevision($service->searchCatalog());
                $storedState = (new TicketSearchStateStore())->resolve($token, $contextRevision);
                if ($storedState === null) {
                    throw new NativeSearchValidationException(
                        'native_search_token_invalid',
                        'advanced_search_token'
                    );
                }
                $wrapper = self::advancedStateWrapper($storedState);
                $advancedDefinition = $service->validateDefinition($wrapper['definition']);
            }

            $requestPayload = [
                'action' => $action,
                'native_id' => $nativeId,
                'fingerprint' => $expectedFingerprint,
                'name' => $name,
                'is_default' => $isDefault,
                'filters' => $advancedDefinition === null ? $filters : [],
                'definition' => $advancedDefinition,
                'delete_confirmed' => $action === 'delete',
            ];
            $encodedPayload = json_encode(
                $requestPayload,
                JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
            );
            if (!is_string($encodedPayload)) {
                throw new \RuntimeException('saved_search_request_hash_failed');
            }
            $requestHash = hash('sha256', $encodedPayload);
            $scope = implode('|', [
                'ticket-saved-search',
                'user:' . (int) ($_SESSION['glpiID'] ?? 0),
                'profile:' . (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
                'entity:' . (int) ($_SESSION['glpiactive_entity'] ?? 0),
                'action:' . $action,
            ]);

            $mutation = static function () use (
                $service,
                $action,
                $nativeId,
                $expectedFingerprint,
                $name,
                $isDefault,
                $filters,
                $advancedDefinition
            ): int {
                if ($action === 'create') {
                    $definition = $advancedDefinition;
                    if ($definition === null) {
                        $definition = $service->buildSimpleDefinition($filters);
                    }
                    return $service->create($name, $definition, $isDefault, [
                        'is_private' => true,
                    ]);
                }

                if ($action === 'update') {
                    $service->updateMetadata(
                        $nativeId,
                        $name,
                        $expectedFingerprint,
                        ['set_default' => $isDefault]
                    );
                    return $nativeId;
                }

                if ($action === 'delete') {
                    $service->delete($nativeId, $expectedFingerprint);
                    return $nativeId;
                }
                if ($action === 'default') {
                    $service->setDefault($nativeId, $expectedFingerprint);
                    return $nativeId;
                }
                if ($action === 'unset_default') {
                    $service->unsetDefault($nativeId, $expectedFingerprint);
                    return $nativeId;
                }

                throw new \InvalidArgumentException('saved_search_action_invalid');
            };

            $mutationResult = $service->mutateIdempotently(
                self::container()->idempotencyLedger(),
                $scope,
                $idempotencyKey,
                $requestHash,
                $mutation
            );
            $resultId = max(0, (int) ($mutationResult['result_id'] ?? 0));
            $messages = [
                'create' => __('Pesquisa criada diretamente no GLPI.', 'glpiacessivel'),
                'update' => __('Pesquisa atualizada diretamente no GLPI.', 'glpiacessivel'),
                'delete' => __('Pesquisa excluída diretamente do GLPI.', 'glpiacessivel'),
                'default' => __('Pesquisa definida como padrão no GLPI.', 'glpiacessivel'),
                'unset_default' => __('Pesquisa removida como padrão no GLPI.', 'glpiacessivel'),
            ];
            self::setMessage('success', $messages[$action]);
            $redirect = $action === 'delete'
                ? 'front/tickets.php?saved_search='
                : 'front/tickets.php?saved_search=native:' . $resultId;
        } catch (\InvalidArgumentException $e) {
            $errorCode = self::savedSearchErrorCode($e, 'saved_search_request_invalid');
            self::container()->auditLogger()->log('ticket.saved_search.validation_failed', [
                'action' => $action,
                'error_code' => $errorCode,
            ]);
            $messages = [
                'saved_search_delete_confirmation_required' => __(
                    'Confirme a exclusão permanente no GLPI antes de continuar.',
                    'glpiacessivel'
                ),
                'saved_search_name_required' => __('Informe um nome para a pesquisa salva.', 'glpiacessivel'),
                'native_saved_search_definition_unsupported' => __(
                    // phpcs:ignore Generic.Files.LineLength.TooLong
                    'Os filtros atuais ainda não possuem equivalência exata para serem salvos pelo portal. Abra a pesquisa avançada no GLPI.',
                    'glpiacessivel'
                ),
                'native_search_context_stale' => __(
                    'Os campos da busca mudaram para o perfil ou entidade atual. Aplique a busca novamente.',
                    'glpiacessivel'
                ),
                'native_search_token_invalid' => __(
                    'A busca avançada expirou ou pertence a outro contexto. Aplique os critérios novamente.',
                    'glpiacessivel'
                ),
            ];
            self::setMessage(
                'error',
                $messages[$errorCode] ?? __(
                    'Os dados da operação são inválidos. Recarregue a lista e tente novamente.',
                    'glpiacessivel'
                )
            );
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('ticket.saved_search.failed', [
                'action' => $action,
                'error_code' => 'saved_search_operation_failed',
                'exception' => get_class($e),
            ]);
            $transactionUnavailable = __(
                // phpcs:ignore Generic.Files.LineLength.TooLong
                'As alterações estão temporariamente em modo somente leitura porque o banco não oferece a transação exigida.',
                'glpiacessivel'
            );
            $messages = [
                'native_saved_search_conflict' => __(
                    // phpcs:ignore Generic.Files.LineLength.TooLong
                    'A pesquisa foi alterada no GLPI depois que esta página foi carregada. Recarregue a lista antes de tentar novamente.',
                    'glpiacessivel'
                ),
                'saved_search_idempotency_conflict' => __(
                    'Esta solicitação já foi usada com dados diferentes. Recarregue a lista antes de tentar novamente.',
                    'glpiacessivel'
                ),
                'saved_search_idempotency_in_progress' => __(
                    'Esta operação já está em andamento. Aguarde e atualize a lista.',
                    'glpiacessivel'
                ),
                'native_saved_search_transaction_lock_required' => $transactionUnavailable,
                'native_saved_search_transaction_begin_failed' => $transactionUnavailable,
                'native_saved_search_transaction_commit_failed' => $transactionUnavailable,
                'native_saved_search_lock_failed' => $transactionUnavailable,
                'native_saved_search_default_lock_failed' => $transactionUnavailable,
                'native_saved_search_definition_unsupported' => __(
                    'A pesquisa continua disponível no GLPI, mas ainda não pode ser alterada fielmente neste portal.',
                    'glpiacessivel'
                ),
            ];
            self::setMessage(
                'error',
                $messages[$e->getMessage()] ?? __(
                    'Não foi possível concluir a operação diretamente no GLPI.',
                    'glpiacessivel'
                )
            );
            $redirect = $nativeId > 0
                ? 'front/tickets.php?saved_search=native:' . $nativeId
                : 'front/tickets.php';
        }

        \Html::redirect(Url::plugin($redirect));
    }

    /** @param array<string,mixed> $catalog */
    private static function advancedCatalogRevision(array $catalog): string
    {
        $revision = $catalog['context_revision'] ?? null;
        if (
            !is_string($revision)
            || preg_match('/\A[a-f0-9]{64}\z/D', $revision) !== 1
        ) {
            throw new NativeSearchValidationException(
                'native_search_context_stale',
                'catalog.context_revision'
            );
        }
        return $revision;
    }

    /**
     * @param array<string,mixed> $state
     * @return array{definition:array<string,mixed>,page_size:int,presentation:array{group_by:string}}
     */
    private static function advancedStateWrapper(array $state): array
    {
        $keys = array_keys($state);
        $legacy = $keys === ['definition', 'page_size'];
        if (
            (!$legacy && $keys !== ['definition', 'page_size', 'presentation'])
            || !is_array($state['definition'] ?? null)
            || !is_int($state['page_size'] ?? null)
            || !in_array($state['page_size'], [10, 20, 50, 100], true)
            || (
                !$legacy
                && (
                    !is_array($state['presentation'] ?? null)
                    || array_keys($state['presentation']) !== ['group_by']
                    || !is_string($state['presentation']['group_by'] ?? null)
                    || !in_array($state['presentation']['group_by'], ['none', 'group'], true)
                )
            )
        ) {
            throw new NativeSearchValidationException(
                'native_search_token_invalid',
                'advanced_search_token'
            );
        }
        return [
            'definition' => $state['definition'],
            'page_size' => $state['page_size'],
            'presentation' => $legacy
                ? ['group_by' => 'none']
                : ['group_by' => $state['presentation']['group_by']],
        ];
    }

    private static function savedSearchErrorCode(
        \Throwable $exception,
        string $fallback
    ): string {
        if ($exception instanceof NativeSearchValidationException) {
            $reason = $exception->reasonCode();
            if (preg_match('/\Anative_search_[a-z0-9_]{1,80}\z/D', $reason) === 1) {
                return $reason;
            }
        }

        $reason = $exception->getMessage();
        if (preg_match('/\Asaved_search_[a-z0-9_]{1,80}\z/D', $reason) === 1) {
            return $reason;
        }
        if ($reason === 'native_saved_search_definition_unsupported') {
            return $reason;
        }
        return $fallback;
    }
}
