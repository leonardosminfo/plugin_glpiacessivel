<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\TicketSearchStateStore;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class CockpitController extends BaseController
{
    private const KPI_KEYS = [
        'total_open',
        'pending',
        'solved_today',
        'mine_open',
        'group_open',
    ];

    public static function index(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_COCKPIT)) {
            return;
        }
        if (!self::container()->authorization()->canViewCockpit()) {
            self::denyAccess(
                __('Cockpit indisponível para este perfil', 'glpiacessivel'),
                __('O perfil ativo não possui permissão para visualizar indicadores de chamados.', 'glpiacessivel'),
                'cockpit.access_denied'
            );
            return;
        }

        $metrics = self::container()->ticketService()->cockpitMetrics();
        $metrics = self::attachDrilldownUrls($metrics);

        View::render('cockpit/index', [
            'title' => __('Cockpit rápido', 'glpiacessivel'),
            'metrics' => $metrics,
        ]);
    }

    /**
     * Validate each server-built definition against the current GLPI catalog,
     * then keep it in the authenticated session. The URL carries only an
     * opaque, short-lived token bound to that context revision.
     *
     * @param array<string,mixed> $metrics
     * @return array<string,mixed>
     */
    private static function attachDrilldownUrls(array $metrics): array
    {
        try {
            $service = self::container()->savedTicketSearchService();
            $catalog = $service->searchCatalog();
            $contextRevision = $catalog['context_revision'] ?? null;
            if (
                !is_string($contextRevision)
                || preg_match('/\A[a-f0-9]{64}\z/D', $contextRevision) !== 1
            ) {
                throw new \RuntimeException('cockpit_context_unavailable');
            }

            $stateStore = new TicketSearchStateStore();
            foreach (self::KPI_KEYS as $key) {
                if (!is_array($metrics[$key] ?? null) || empty($metrics[$key]['available'])) {
                    continue;
                }
                try {
                    $definition = $metrics[$key]['drilldown_filters'] ?? null;
                    if (!is_array($definition) || $definition === []) {
                        throw new \RuntimeException('cockpit_definition_unavailable');
                    }
                    $definition = $service->validateDefinition($definition);
                    self::container()->remoteSearchValueAuthorizer()->authorize(
                        $definition,
                        $contextRevision
                    );
                    $token = $stateStore->issue([
                        'definition' => $definition,
                        'page_size' => 20,
                    ], $contextRevision);
                    $url = Url::plugin('front/tickets.php?' . http_build_query([
                        'advanced_search_token' => $token,
                        'focus' => 'results',
                    ], '', '&', PHP_QUERY_RFC3986));
                    $metrics[$key]['drilldown_filters'] = $definition;
                    $metrics[$key]['url_definition'] = $definition;
                    $metrics[$key]['drilldown_url'] = $url;
                    $metrics[$key]['url'] = $url;
                } catch (\Throwable $e) {
                    $metrics[$key] = self::unavailableMetric(
                        $metrics[$key],
                        'drilldown_unavailable'
                    );
                }
            }
        } catch (\Throwable $e) {
            foreach (self::KPI_KEYS as $key) {
                if (is_array($metrics[$key] ?? null)) {
                    $metrics[$key] = self::unavailableMetric(
                        $metrics[$key],
                        'drilldown_context_unavailable'
                    );
                }
            }
        }

        $metrics['backend'] = self::allMetricsAvailable($metrics)
            ? 'search_api'
            : 'unavailable';
        return $metrics;
    }

    /** @param array<string,mixed> $metric @return array<string,mixed> */
    private static function unavailableMetric(array $metric, string $errorCode): array
    {
        $metric['value'] = null;
        $metric['count'] = null;
        $metric['available'] = false;
        $metric['completeness'] = 'unknown';
        $metric['backend'] = 'unavailable';
        $metric['error_code'] = $errorCode;
        $metric['drilldown_url'] = '';
        $metric['url'] = '';
        return $metric;
    }

    /** @param array<string,mixed> $metrics */
    private static function allMetricsAvailable(array $metrics): bool
    {
        foreach (self::KPI_KEYS as $key) {
            if (!is_array($metrics[$key] ?? null) || empty($metrics[$key]['available'])) {
                return false;
            }
        }
        return true;
    }
}
