<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Presenter;

/**
 * Projects form data for the selected audience before it reaches a template.
 *
 * Public views receive only functional state and safe actions. Technical
 * detection details are present only for configuration managers.
 */
final class FormExperiencePresenter
{
    private const DIAGNOSTIC_CODES = [
        'formcreator_class_missing',
        'formcreator_plugin_inactive',
        'catalog_disabled_by_policy',
        'version_unsupported',
        'signature_unsupported',
        'query_shape_unsupported',
        'probe_failed',
        'web_root_unavailable',
        'native_query_failed',
        'invalid_cursor',
        'empty_authorized_result',
        'glpi11_uses_native_catalog',
    ];

    /**
     * @param array<string,mixed> $catalog
     * @return array<string,mixed>
     */
    public function presentCatalog(array $catalog, bool $administrator): array
    {
        $page = is_array($catalog['catalog_page'] ?? null) ? $catalog['catalog_page'] : [];
        $rawState = (string) ($page['state'] ?? 'not_detected');
        $items = [];
        foreach ((array) ($catalog['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $id = max(0, (int) ($item['id'] ?? 0));
            $source = $this->source((string) ($item['source'] ?? ''));
            if ($id <= 0 || $source === '') {
                continue;
            }

            $projected = [
                'id' => $id,
                'source' => $source,
                'name' => $this->text($item['name'] ?? '', 240, 'Formulário'),
                'description' => $this->text($item['description'] ?? '', 1200),
                'illustration' => $this->safeIllustration((string) ($item['illustration'] ?? '')),
                'visual_kind' => $this->token((string) ($item['visual_kind'] ?? 'form'), 'form'),
            ];

            if ($administrator) {
                $projected['diagnostics'] = [
                    'source_label' => $this->text($item['source_label'] ?? $source, 120),
                    'rendering_message' => $this->text($item['rendering_message'] ?? '', 500),
                    'compatibility_status' => $this->token(
                        (string) ($item['compatibility_status'] ?? 'native_fallback_required'),
                        'native_fallback_required'
                    ),
                    'compatibility_summary' => $this->text($item['compatibility_summary'] ?? '', 800),
                    'compatibility_reasons' => $this->textList($item['compatibility_reasons'] ?? [], 4, 500),
                    'compatibility_advisories' => $this->textList($item['compatibility_advisories'] ?? [], 3, 500),
                ];
            }

            $items[] = $projected;
        }

        $view = [
            'audience' => $administrator ? 'administrator' : 'public',
            'state' => $this->publicCatalogState($rawState, $items),
            'query' => $this->text($catalog['query'] ?? $page['query'] ?? '', 120),
            'page' => max(1, (int) ($page['page'] ?? 1)),
            'has_more' => !empty($page['has_more']),
            'next_cursor' => $this->text($page['next_cursor'] ?? '', 4000),
            'previous_cursor' => $this->text($page['previous_cursor'] ?? '', 4000),
            'item_count' => count($items),
            'items' => $items,
            'full_list_url' => $this->catalogFallbackUrl((array) ($catalog['sources'] ?? [])),
        ];

        if ($administrator) {
            $view['admin_diagnostics'] = [
                'raw_state' => $this->token($rawState, 'unexpected_failure'),
                'fallback_policy' => $this->text($catalog['fallback_policy'] ?? '', 800),
                'sources' => $this->diagnosticSources((array) ($catalog['sources'] ?? [])),
            ];
        }

        return $view;
    }

    /**
     * @param array<string,mixed> $form
     * @param array<string,mixed> $schema
     * @return array<string,mixed>
     */
    public function presentForm(
        array $form,
        array $schema,
        bool $administrator,
        string $glpiVersion,
        string $formcreatorVersion
    ): array {
        $source = $this->source((string) ($form['source'] ?? ''));
        $metadata = is_array($schema['metadata'] ?? null) ? $schema['metadata'] : [];
        $capabilities = is_array($schema['capabilities'] ?? null) ? $schema['capabilities'] : [];
        $functionalCapabilities = [];
        foreach (['renders_own_fields', 'own_submission_readiness', 'native_submit_contract'] as $key) {
            if (array_key_exists($key, $capabilities)) {
                $functionalCapabilities[$key] = $capabilities[$key];
            }
        }

        $view = [
            'audience' => $administrator ? 'administrator' : 'public',
            'form' => [
                'id' => max(0, (int) ($form['id'] ?? $metadata['form_id'] ?? 0)),
                'source' => $source,
                'name' => $this->text($form['name'] ?? $schema['title'] ?? '', 240, 'Formulário'),
                'description' => $this->text($form['description'] ?? '', 1200),
                'native_url' => $this->safeLocalUrl((string) ($form['native_url'] ?? '')),
            ],
            'schema' => [
                'title' => $this->text($schema['title'] ?? $form['name'] ?? '', 240, 'Formulário'),
                'sections' => is_array($schema['sections'] ?? null) ? $schema['sections'] : [],
                'fields' => is_array($schema['fields'] ?? null) ? $schema['fields'] : [],
                'conditions' => is_array($schema['conditions'] ?? null) ? $schema['conditions'] : [],
                'capabilities' => $functionalCapabilities,
                'metadata' => ['form_id' => max(0, (int) ($metadata['form_id'] ?? $form['id'] ?? 0))],
            ],
        ];

        if ($administrator) {
            $fallback = is_array($schema['fallback'] ?? null) ? $schema['fallback'] : [];
            $view['admin_diagnostics'] = [
                'source' => $source,
                'glpi_version' => $this->version($glpiVersion),
                'form_provider_version' => $this->version($formcreatorVersion),
                'fallback_reasons' => $this->textList($fallback['reasons'] ?? [], 8, 500),
                'unsupported_questions' => $this->textList($metadata['unsupported_questions'] ?? [], 20, 500),
                'detected_apis' => is_array($capabilities['detected_apis'] ?? null)
                    ? $capabilities['detected_apis']
                    : [],
                'compatibility_matrix' => is_array($capabilities['compatibility_matrix'] ?? null)
                    ? array_slice($capabilities['compatibility_matrix'], 0, 20)
                    : [],
            ];
        }

        return $view;
    }

    /**
     * @param array<string,mixed> $sources
     * @return array<int,array<string,mixed>>
     */
    private function diagnosticSources(array $sources): array
    {
        $result = [];
        foreach ($sources as $key => $source) {
            if (!is_array($source)) {
                continue;
            }
            $code = (string) ($source['diagnostic_code'] ?? '');
            $result[] = [
                'key' => $this->token((string) $key, 'unknown'),
                'label' => $this->text($source['label'] ?? $key, 120),
                'available' => !empty($source['available']),
                'message' => $this->text($source['message'] ?? '', 500),
                'diagnostic_code' => in_array($code, self::DIAGNOSTIC_CODES, true)
                    ? $code
                    : ($code === '' ? '' : 'unexpected_failure'),
                'native_url' => $this->safeLocalUrl((string) ($source['native_url'] ?? '')),
            ];
        }
        return $result;
    }

    /**
     * @param array<string,mixed> $sources
     */
    private function catalogFallbackUrl(array $sources): string
    {
        foreach (['glpi11_service_catalog', 'formcreator_glpi10'] as $key) {
            $source = is_array($sources[$key] ?? null) ? $sources[$key] : [];
            $url = $this->safeLocalUrl((string) ($source['native_url'] ?? ''));
            if (!empty($source['available']) && $url !== '') {
                return $url;
            }
        }
        return '';
    }

    /**
     * @param array<int,mixed> $items
     */
    private function publicCatalogState(string $state, array $items): string
    {
        if ($items !== [] && $state !== 'partial') {
            return 'ready';
        }
        return match ($state) {
            'ready' => 'ready',
            'ready_empty', 'unavailable_context' => 'empty',
            'partial' => 'degraded',
            default => 'unavailable',
        };
    }

    private function source(string $source): string
    {
        return in_array($source, ['glpi11_service_catalog', 'formcreator_glpi10'], true) ? $source : '';
    }

    private function safeLocalUrl(string $url): string
    {
        $url = trim($url);
        if ($url === '' || str_contains($url, '\\') || str_contains($url, "\0")) {
            return '';
        }
        $parts = parse_url($url);
        if (
            $parts === false
            || isset($parts['scheme'])
            || isset($parts['host'])
            || isset($parts['user'])
            || isset($parts['pass'])
        ) {
            return '';
        }
        return str_starts_with((string) ($parts['path'] ?? ''), '/') ? $url : '';
    }

    private function safeIllustration(string $url): string
    {
        $url = trim($url);
        if ($url === '' || str_contains($url, '\\') || str_contains($url, "\0")) {
            return '';
        }
        if (str_starts_with($url, 'data:image/')) {
            return preg_match('#^data:image/(?:png|gif|jpeg|webp);base64,[A-Za-z0-9+/=]+$#', $url) ? $url : '';
        }
        if (str_starts_with($url, '/')) {
            return $url;
        }
        $parts = parse_url($url);
        return $parts !== false && in_array(strtolower((string) ($parts['scheme'] ?? '')), ['http', 'https'], true)
            ? $url
            : '';
    }

    private function version(string $version): string
    {
        return preg_match('/^[0-9]+(?:\\.[0-9]+){1,3}(?:[-+][A-Za-z0-9.-]+)?$/', $version) ? $version : '';
    }

    private function token(string $value, string $fallback): string
    {
        return preg_match('/^[a-z0-9_.-]{1,80}$/i', $value) ? $value : $fallback;
    }

    /**
     * @param mixed $value
     */
    private function text($value, int $maximum, string $fallback = ''): string
    {
        $text = is_scalar($value) ? trim((string) $value) : '';
        if ($text === '') {
            return $fallback;
        }
        return function_exists('mb_substr') ? mb_substr($text, 0, $maximum) : substr($text, 0, $maximum);
    }

    /**
     * @param mixed $values
     * @return array<int,string>
     */
    private function textList($values, int $maximumItems, int $maximumLength): array
    {
        $result = [];
        foreach (is_array($values) ? $values : [] as $value) {
            $text = $this->text($value, $maximumLength);
            if ($text !== '') {
                $result[] = $text;
            }
            if (count($result) >= $maximumItems) {
                break;
            }
        }
        return $result;
    }
}
