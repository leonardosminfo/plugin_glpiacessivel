<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Presenter;

/**
 * Produces an ACL-safe, text-only description of the effective ticket search.
 * The view may render this structure without JavaScript or knowledge of GLPI ids.
 */
final class TicketSearchSummaryPresenter
{
    /**
     * @param array<string,mixed> $definition
     * @param array<string,mixed> $catalog
     * @param array<string,mixed> $savedSearch
     * @param array<string,mixed> $filters
     * @return array{active:bool,source:string,heading:string,saved_search_name:string,sections:array<int,array{key:string,label:string,items:array<int,string>}>,warnings:array<int,string>,plain_text:string}
     */
    public function present(
        array $definition,
        array $catalog,
        array $savedSearch = [],
        array $filters = []
    ): array {
        $sections = [];
        $warnings = [];
        $name = trim((string) ($savedSearch['name'] ?? ''));
        $source = $name !== '' ? 'glpi_saved_search' : 'advanced_search';

        $text = trim((string) ($definition['text'] ?? ''));
        if ($text !== '') {
            $sections[] = $this->section('text', 'Texto livre', [$text]);
        }

        $scope = (string) ($definition['scope'] ?? 'all');
        $scopeLabels = [
            'all' => 'Todos os chamados permitidos pelo seu perfil',
            'mine' => 'Meus chamados',
            'group' => 'Chamados dos meus grupos',
        ];
        if ($scope !== 'all') {
            $sections[] = $this->section('scope', 'Escopo', [
                $scopeLabels[$scope] ?? $scopeLabels['all'],
            ]);
        }

        $ticketOptions = $this->ticketOptions($catalog);
        $metaOptions = $this->metaOptionsByItemtype((array) ($catalog['meta_itemtypes'] ?? []));
        $criteria = $this->narrateCriteria(
            (array) ($definition['criteria'] ?? []),
            $ticketOptions,
            $metaOptions,
            $warnings
        );
        if ($criteria !== []) {
            $sections[] = $this->section('criteria', 'Critérios', $criteria);
        }

        $metaCriteria = $this->narrateMetaCriteria(
            (array) ($definition['metacriteria'] ?? []),
            $metaOptions,
            $warnings
        );
        if ($metaCriteria !== []) {
            $sections[] = $this->section('metacriteria', 'Critérios relacionados', $metaCriteria);
        }

        $sections[] = $this->section('deleted_scope', 'Registros excluídos', [
            (int) ($definition['is_deleted'] ?? 0) === 1
                ? 'Somente chamados excluídos'
                : 'Somente chamados ativos',
        ]);

        $sortItems = $this->narrateSorts($definition, $ticketOptions, $warnings);
        if ($sortItems !== []) {
            $sections[] = $this->section('sort', 'Ordenação', $sortItems);
        }

        $columnItems = $this->narrateColumns(
            (array) ($definition['columns'] ?? $filters['columns'] ?? []),
            (array) ($catalog['columns'] ?? []),
            $warnings
        );
        if ($columnItems !== []) {
            $sections[] = $this->section('columns', 'Colunas', $columnItems);
        }

        $pageSize = (int) ($filters['page_size'] ?? 0);
        if (in_array($pageSize, [10, 20, 50, 100], true)) {
            $sections[] = $this->section('page_size', 'Resultados por página', [
                (string) $pageSize,
            ]);
        }

        foreach ((array) ($savedSearch['presentation_warnings'] ?? []) as $warning) {
            if ($warning === 'native_column_unavailable') {
                $warnings[] = 'Algumas colunas salvas não estão disponíveis neste perfil ou entidade.';
            }
        }
        $warnings = array_values(array_unique($warnings));
        $heading = $name !== '' ? 'Pesquisa salva aplicada: ' . $name : 'Pesquisa aplicada';
        $plainParts = [$heading];
        foreach ($sections as $section) {
            $plainParts[] = $section['label'] . ': ' . implode('; ', $section['items']);
        }
        foreach ($warnings as $warning) {
            $plainParts[] = 'Aviso: ' . $warning;
        }

        return [
            'active' => $sections !== [],
            'source' => $source,
            'heading' => $heading,
            'saved_search_name' => $name,
            'sections' => $sections,
            'warnings' => $warnings,
            'plain_text' => implode('. ', $plainParts),
        ];
    }

    /** @return array{key:string,label:string,items:array<int,string>} */
    private function section(string $key, string $label, array $items): array
    {
        return ['key' => $key, 'label' => $label, 'items' => array_values($items)];
    }

    /** @return array<int,array<string,mixed>> */
    private function ticketOptions(array $catalog): array
    {
        $options = [];
        foreach ((array) ($catalog['options'] ?? []) as $option) {
            if (is_array($option) && (int) ($option['id'] ?? 0) > 0) {
                $options[(int) $option['id']] = $option;
            }
        }
        return $options;
    }

    /** @return array<int,string> */
    private function narrateCriteria(
        array $criteria,
        array $options,
        array $metaOptions,
        array &$warnings,
        int $depth = 0
    ): array {
        $items = [];
        foreach ($criteria as $criterion) {
            if (!is_array($criterion)) {
                continue;
            }
            $connector = $this->connector((string) ($criterion['link'] ?? 'AND'));
            if (is_array($criterion['criteria'] ?? null)) {
                $children = $this->narrateCriteria(
                    $criterion['criteria'],
                    $options,
                    $metaOptions,
                    $warnings,
                    $depth + 1
                );
                if ($children !== []) {
                    $items[] = $connector . ' grupo: ' . implode('; ', $children);
                }
                continue;
            }

            $rawField = $criterion['field'] ?? 0;
            $isMeta = (int) ($criterion['meta'] ?? 0) === 1
                || array_key_exists('itemtype', $criterion);
            if ($isMeta) {
                $itemtype = (string) ($criterion['itemtype'] ?? '');
                $field = (int) $rawField;
                if (!isset($metaOptions[$itemtype]['options'][$field])) {
                    $warnings[] = 'Um critério relacionado não está disponível neste perfil ou entidade.';
                    continue;
                }
                $relation = (string) $metaOptions[$itemtype]['label'];
                $items[] = $connector
                    . ' ' . ($relation !== '' ? $relation . ': ' : '')
                    . $this->narrateLeaf($criterion, $metaOptions[$itemtype]['options'][$field]);
                continue;
            }

            $special = is_string($rawField) ? $this->specialCriterionOption($rawField) : null;
            $field = (int) $rawField;
            $option = $special ?? ($options[$field] ?? null);
            if (!is_array($option)) {
                $warnings[] = 'Um critério salvo não está disponível neste perfil ou entidade.';
                continue;
            }
            $items[] = $connector . ' ' . $this->narrateLeaf($criterion, $option);
        }
        return $items;
    }

    /** @return array<string,array{label:string,options:array<int,array<string,mixed>>}> */
    private function metaOptionsByItemtype(array $metaCatalogs): array
    {
        $byItemtype = [];
        foreach ($metaCatalogs as $metaCatalog) {
            if (!is_array($metaCatalog)) {
                continue;
            }
            $options = [];
            foreach ((array) ($metaCatalog['options'] ?? []) as $option) {
                if (is_array($option) && (int) ($option['id'] ?? 0) > 0) {
                    $options[(int) $option['id']] = $option;
                }
            }
            $byItemtype[(string) ($metaCatalog['itemtype'] ?? '')] = [
                'label' => trim((string) ($metaCatalog['label'] ?? '')),
                'options' => $options,
            ];
        }
        return $byItemtype;
    }

    /**
     * @param array<string,array{label:string,options:array<int,array<string,mixed>>}> $byItemtype
     * @return array<int,string>
     */
    private function narrateMetaCriteria(array $criteria, array $byItemtype, array &$warnings): array
    {
        $items = [];
        foreach ($criteria as $criterion) {
            if (!is_array($criterion)) {
                continue;
            }
            $itemtype = (string) ($criterion['itemtype'] ?? '');
            $field = (int) ($criterion['field'] ?? 0);
            if (!isset($byItemtype[$itemtype]['options'][$field])) {
                $warnings[] = 'Um critério relacionado não está disponível neste perfil ou entidade.';
                continue;
            }
            $relation = (string) $byItemtype[$itemtype]['label'];
            $items[] = $this->connector((string) ($criterion['link'] ?? 'AND'))
                . ' ' . ($relation !== '' ? $relation . ': ' : '')
                . $this->narrateLeaf($criterion, $byItemtype[$itemtype]['options'][$field]);
        }
        return $items;
    }

    /** @return null|array<string,mixed> */
    private function specialCriterionOption(string $field): ?array
    {
        $labels = [
            'all' => 'Todos os campos',
            'view' => 'Campos exibidos',
        ];
        if (!isset($labels[$field])) {
            return null;
        }
        $operatorLabels = [
            'contains' => 'contém',
            'notcontains' => 'não contém',
            'equals' => 'é',
            'notequals' => 'não é',
            'empty' => 'está vazio',
            'notempty' => 'não está vazio',
        ];
        return [
            'label' => $labels[$field],
            'operators' => array_map(
                static fn(string $operator, string $label): array => [
                    'value' => $operator,
                    'label' => $label,
                    'value_contract' => ['kind' => 'text'],
                ],
                array_keys($operatorLabels),
                array_values($operatorLabels)
            ),
            'value' => ['mode' => 'text', 'options' => []],
        ];
    }

    private function narrateLeaf(array $criterion, array $option): string
    {
        $operator = (string) ($criterion['searchtype'] ?? 'contains');
        $operatorLabel = $operator;
        $contractKind = 'text';
        foreach ((array) ($option['operators'] ?? []) as $descriptor) {
            if (is_array($descriptor) && (string) ($descriptor['value'] ?? '') === $operator) {
                $operatorLabel = (string) ($descriptor['label'] ?? $operator);
                $contractKind = (string) (($descriptor['value_contract'] ?? [])['kind'] ?? 'text');
                break;
            }
        }
        $value = (string) ($criterion['value'] ?? '');
        if (in_array($operator, ['empty', 'notempty'], true)) {
            $value = '';
        } elseif ($contractKind === 'remote_select') {
            $value = 'valor selecionado';
        } else {
            foreach ((array) (($option['value'] ?? [])['options'] ?? []) as $valueOption) {
                if (!is_array($valueOption)) {
                    continue;
                }
                $candidate = (string) ($valueOption['value'] ?? $valueOption['id'] ?? '');
                if ($candidate === $value) {
                    $value = (string) ($valueOption['label'] ?? $valueOption['name'] ?? $value);
                    break;
                }
            }
        }
        return trim((string) ($option['label'] ?? 'Campo') . ' ' . $operatorLabel . ' ' . $value);
    }

    /** @return array<int,string> */
    private function narrateSorts(array $definition, array $options, array &$warnings): array
    {
        $items = [];
        foreach ((array) ($definition['sort'] ?? []) as $index => $field) {
            $field = (int) $field;
            if (!isset($options[$field])) {
                $warnings[] = 'Uma ordenação salva não está disponível neste perfil ou entidade.';
                continue;
            }
            $direction = strtoupper((string) (((array) ($definition['order'] ?? []))[$index] ?? 'ASC'));
            $items[] = (string) $options[$field]['label']
                . ($direction === 'DESC' ? ' — decrescente' : ' — crescente');
        }
        return $items;
    }

    /** @return array<int,string> */
    private function narrateColumns(array $columns, array $catalog, array &$warnings): array
    {
        $labels = [];
        foreach ($catalog as $column) {
            if (is_array($column)) {
                $labels[(string) ($column['identifier'] ?? '')] = (string) ($column['label'] ?? '');
            }
        }
        $items = [];
        foreach ($columns as $column) {
            $column = (string) $column;
            if ($column === '' || !isset($labels[$column]) || $labels[$column] === '') {
                $warnings[] = 'Uma coluna salva não está disponível neste perfil ou entidade.';
                continue;
            }
            $items[] = $labels[$column];
        }
        return array_values(array_unique($items));
    }

    private function connector(string $link): string
    {
        return [
            'OR' => 'OU',
            'AND NOT' => 'E NÃO',
            'OR NOT' => 'OU NÃO',
        ][strtoupper(trim($link))] ?? 'E';
    }
}
