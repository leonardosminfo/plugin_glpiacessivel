<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Ticket;

/**
 * Immutable, serializable contract for one field/operator value pair.
 */
final class SearchOperatorValueContract
{
    /** @var array<int,array{value:string,label:string}> */
    private array $options;

    /**
     * @param array<int,array{value:string,label:string}> $options
     */
    public function __construct(
        private string $operator,
        private SearchValueKind $kind,
        private bool $required = true,
        private ?string $canonicalValue = null,
        array $options = [],
        private int $maxBytes = 4096,
        private bool $allowEmpty = false,
        private string $table = '',
        private string $linkfield = '',
        private bool $hierarchical = false
    ) {
        $this->operator = strtolower(trim($this->operator));
        if ($this->operator === '') {
            throw new \InvalidArgumentException('search_operator_invalid');
        }
        if ($this->maxBytes < 1 || $this->maxBytes > 4096) {
            throw new \InvalidArgumentException('search_value_max_bytes_invalid');
        }

        $normalized = [];
        foreach ($options as $option) {
            if (!is_array($option)) {
                throw new \InvalidArgumentException('search_value_options_invalid');
            }
            $value = $option['value'] ?? null;
            $label = $option['label'] ?? null;
            if (!is_string($value) || !is_string($label) || $value === '') {
                throw new \InvalidArgumentException('search_value_options_invalid');
            }
            if (isset($normalized[$value])) {
                throw new \InvalidArgumentException('search_value_options_duplicate');
            }
            $normalized[$value] = ['value' => $value, 'label' => $label];
        }
        $this->options = array_values($normalized);

        if ($this->kind === SearchValueKind::NONE) {
            if ($this->required || $this->canonicalValue !== '' || $this->options !== []) {
                throw new \InvalidArgumentException('search_none_contract_invalid');
            }
        } elseif (!$this->required) {
            throw new \InvalidArgumentException('search_required_contract_invalid');
        }
        if ($this->kind === SearchValueKind::LOCAL_SELECT && $this->options === []) {
            throw new \InvalidArgumentException('search_local_options_missing');
        }
        if ($this->kind !== SearchValueKind::LOCAL_SELECT && $this->options !== []) {
            throw new \InvalidArgumentException('search_value_options_unexpected');
        }
        if ($this->kind !== SearchValueKind::NONE && $this->canonicalValue !== null) {
            throw new \InvalidArgumentException('search_canonical_value_unexpected');
        }
        if ($this->kind !== SearchValueKind::TEXT && $this->allowEmpty) {
            throw new \InvalidArgumentException('search_allow_empty_unexpected');
        }
        if ($this->kind !== SearchValueKind::REMOTE_SELECT && $this->hierarchical) {
            throw new \InvalidArgumentException('search_hierarchy_unexpected');
        }
    }

    public static function none(string $operator): self
    {
        return new self($operator, SearchValueKind::NONE, false, '');
    }

    /**
     * Compatibility contract for trusted server contexts created before
     * field/operator contracts were introduced. Production catalogs do not use it.
     */
    public static function legacy(string $operator): self
    {
        return new self($operator, SearchValueKind::TEXT);
    }

    /** @param array<string,mixed> $descriptor */
    public static function fromArray(string $operator, array $descriptor): self
    {
        $allowed = [
            'kind', 'required', 'canonical_value', 'options', 'max_bytes',
            'allow_empty', 'hierarchical',
        ];
        foreach (array_keys($descriptor) as $key) {
            if (!is_string($key) || !in_array($key, $allowed, true)) {
                throw new \InvalidArgumentException('search_value_contract_key_invalid');
            }
        }

        $kindValue = $descriptor['kind'] ?? null;
        $required = $descriptor['required'] ?? null;
        if (!is_string($kindValue) || !is_bool($required)) {
            throw new \InvalidArgumentException('search_value_contract_invalid');
        }
        $kind = SearchValueKind::tryFrom($kindValue);
        if ($kind === null) {
            throw new \InvalidArgumentException('search_value_kind_invalid');
        }
        $kindKeys = match ($kind) {
            SearchValueKind::NONE => ['kind', 'required', 'canonical_value'],
            SearchValueKind::TEXT => ['kind', 'required', 'max_bytes', 'allow_empty'],
            SearchValueKind::LOCAL_SELECT => ['kind', 'required', 'options'],
            SearchValueKind::REMOTE_SELECT => ['kind', 'required', 'hierarchical'],
            default => ['kind', 'required'],
        };
        foreach (array_keys($descriptor) as $key) {
            if (!is_string($key) || !in_array($key, $kindKeys, true)) {
                throw new \InvalidArgumentException('search_value_contract_kind_key_invalid');
            }
        }

        $canonical = $descriptor['canonical_value'] ?? null;
        if ($canonical !== null && !is_string($canonical)) {
            throw new \InvalidArgumentException('search_canonical_value_invalid');
        }
        $options = $descriptor['options'] ?? [];
        if (!is_array($options) || !array_is_list($options)) {
            throw new \InvalidArgumentException('search_value_options_invalid');
        }
        $maxBytes = $descriptor['max_bytes'] ?? 4096;
        $allowEmpty = $descriptor['allow_empty'] ?? false;
        $hierarchical = $descriptor['hierarchical'] ?? false;
        if (
            !is_int($maxBytes)
            || !is_bool($allowEmpty)
            || !is_bool($hierarchical)
        ) {
            throw new \InvalidArgumentException('search_value_contract_invalid');
        }

        /** @var array<int,array{value:string,label:string}> $options */
        return new self(
            $operator,
            $kind,
            $required,
            $canonical,
            $options,
            $maxBytes,
            $allowEmpty,
            '',
            '',
            $hierarchical
        );
    }

    public function operator(): string
    {
        return $this->operator;
    }

    public function kind(): SearchValueKind
    {
        return $this->kind;
    }

    public function required(): bool
    {
        return $this->required;
    }

    public function canonicalValue(): ?string
    {
        return $this->canonicalValue;
    }

    /** @return array<int,array{value:string,label:string}> */
    public function options(): array
    {
        return $this->options;
    }

    public function maxBytes(): int
    {
        return $this->maxBytes;
    }

    public function allowEmpty(): bool
    {
        return $this->allowEmpty;
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        $descriptor = [
            'kind' => $this->kind->value,
            'required' => $this->required,
        ];
        if ($this->kind === SearchValueKind::NONE) {
            $descriptor['canonical_value'] = '';
        } elseif ($this->kind === SearchValueKind::TEXT) {
            $descriptor['max_bytes'] = $this->maxBytes;
            $descriptor['allow_empty'] = $this->allowEmpty;
        } elseif ($this->kind === SearchValueKind::LOCAL_SELECT) {
            $descriptor['options'] = $this->options;
        } elseif ($this->kind === SearchValueKind::REMOTE_SELECT) {
            $descriptor['hierarchical'] = $this->hierarchical;
        }

        return $descriptor;
    }
}
