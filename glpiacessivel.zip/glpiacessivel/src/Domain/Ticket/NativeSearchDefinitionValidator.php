<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Ticket;

/**
 * Validates an untrusted advanced-search AST against server-side capabilities.
 *
 * The capability context must be built after the current GLPI user, profile and
 * entity have been authorized. No field, operator, relation or presentation
 * column supplied by the client becomes an allowlist entry.
 */
final class NativeSearchDefinitionValidator
{
    public const VERSION = 3;
    public const LEGACY_VERSION = 2;
    public const MAX_DEFINITION_BYTES = 49152;
    public const MAX_QUERY_BYTES = 49152;
    public const MAX_PARAMETER_LEAVES = 600;
    public const MAX_CRITERIA = 50;
    public const MAX_META_CRITERIA = 25;
    public const MAX_DEPTH = 4;
    public const MAX_SORTS = 5;
    public const MAX_COLUMNS = 50;
    public const MAX_VALUE_BYTES = 4096;

    /** @var string[] */
    private const ROOT_KEYS = [
        'version',
        'itemtype',
        'text',
        'scope',
        'criteria',
        'metacriteria',
        'sort',
        'order',
        'is_deleted',
        'columns',
    ];

    /** @var string[] */
    private const LINKS = ['AND', 'OR', 'AND NOT', 'OR NOT'];

    /** @var string[] */
    private const HOMOLOGATED_OPERATORS = [
        'contains',
        'notcontains',
        'equals',
        'notequals',
        'under',
        'notunder',
        'lessthan',
        'morethan',
        'empty',
        'notempty',
    ];

    /** @var array<int|string,array<string,SearchOperatorValueContract>> */
    private array $fields = [];

    /** @var array<string,array<int,array<string,SearchOperatorValueContract>>> */
    private array $metaFields = [];

    /** @var array<int,true> */
    private array $sortFields = [];

    /** @var array<string,true> */
    private array $columns = [];

    private int $criteriaCount = 0;
    private int $metaCriteriaCount = 0;
    private int $parameterLeaves = 0;
    private bool $allowDeleted = false;

    /**
     * @param array<string,mixed> $definition
     * @param array<string,mixed> $context
     * @return array<string,mixed>
     *
     * Required context keys:
     * - authorized: true only after the current GLPI context may search Ticket;
     * - fields: [positive search-option id => [operator => value contract]];
     * - sort_fields: [positive search-option ids];
     * - meta_fields: [related itemtype => [field id => [operator => value contract]]].
     *
     * A legacy list of operator strings remains accepted for trusted internal
     * callers, but current production catalogs always provide strict contracts.
     *
     * Optional context keys:
     * - allow_deleted: whether the current context may include deleted tickets;
     * - columns: allowed semantic/presentation column identifiers.
     */
    public function validate(array $definition, array $context): array
    {
        $this->reset();
        $this->loadContext($context);
        $this->assertDefinitionBudget($definition);
        $versionValue = $definition['version'] ?? null;
        if (
            !$this->isIntegerValue($versionValue)
            || !in_array((int) $versionValue, [self::LEGACY_VERSION, self::VERSION], true)
        ) {
            $this->fail('native_search_version_unsupported', 'definition.version');
        }
        $version = (int) $versionValue;
        $rootKeys = $version === self::LEGACY_VERSION
            ? array_values(array_diff(self::ROOT_KEYS, ['text', 'scope']))
            : self::ROOT_KEYS;
        $this->assertExactKeys($definition, $rootKeys, 'definition');

        foreach (
            [
            'version',
            'itemtype',
            'criteria',
            'metacriteria',
            'sort',
            'order',
            'is_deleted',
            ] as $required
        ) {
            if (!array_key_exists($required, $definition)) {
                $this->fail('native_search_parameter_missing', 'definition.' . $required);
            }
        }

        if ($definition['itemtype'] !== 'Ticket') {
            $this->fail('native_search_itemtype_unsupported', 'definition.itemtype');
        }
        if ($version === self::VERSION) {
            foreach (['text', 'scope'] as $required) {
                if (!array_key_exists($required, $definition)) {
                    $this->fail('native_search_parameter_missing', 'definition.' . $required);
                }
            }
        }

        $text = $version === self::LEGACY_VERSION
            ? ''
            : $this->validateText($definition['text']);
        $scope = $version === self::LEGACY_VERSION
            ? 'all'
            : $this->validateScope($definition['scope']);

        $criteria = $this->validateCriteriaList(
            $definition['criteria'],
            'definition.criteria',
            0
        );
        $metacriteria = $this->validateMetaCriteriaList(
            $definition['metacriteria'],
            'definition.metacriteria'
        );
        [$sort, $order] = $this->validateSort(
            $definition['sort'],
            $definition['order']
        );
        $isDeleted = $this->validateDeletedScope($definition['is_deleted']);
        $columns = array_key_exists('columns', $definition)
            ? $this->validateColumns($definition['columns'])
            : [];

        if ($this->criteriaCount > self::MAX_CRITERIA) {
            $this->fail('native_search_criteria_limit_exceeded', 'definition.criteria');
        }
        if ($this->metaCriteriaCount > self::MAX_META_CRITERIA) {
            $this->fail('native_search_meta_criteria_limit_exceeded', 'definition.metacriteria');
        }

        $canonical = [
            'version' => self::VERSION,
            'itemtype' => 'Ticket',
            'text' => $text,
            'scope' => $scope,
            'criteria' => $criteria,
            'metacriteria' => $metacriteria,
            'sort' => $sort,
            'order' => $order,
            'is_deleted' => $isDeleted,
        ];
        if (array_key_exists('columns', $definition)) {
            $canonical['columns'] = $columns;
        }

        $this->parameterLeaves += 5 + count($sort) + count($order) + count($columns);
        if ($this->parameterLeaves > self::MAX_PARAMETER_LEAVES) {
            $this->fail('native_search_parameter_limit_exceeded', 'definition');
        }

        $nativeDefinition = $canonical;
        unset(
            $nativeDefinition['version'],
            $nativeDefinition['columns'],
            $nativeDefinition['text'],
            $nativeDefinition['scope']
        );
        $query = http_build_query($nativeDefinition, '', '&', PHP_QUERY_RFC3986);
        if (strlen($query) > self::MAX_QUERY_BYTES) {
            $this->fail('native_search_query_byte_limit_exceeded', 'definition');
        }

        return $canonical;
    }

    private function reset(): void
    {
        $this->fields = [];
        $this->metaFields = [];
        $this->sortFields = [];
        $this->columns = [];
        $this->criteriaCount = 0;
        $this->metaCriteriaCount = 0;
        $this->parameterLeaves = 0;
        $this->allowDeleted = false;
    }

    /** @param array<string,mixed> $context */
    private function loadContext(array $context): void
    {
        $this->assertExactKeys(
            $context,
            [
                'authorized', 'fields', 'special_fields', 'sort_fields',
                'meta_fields', 'allow_deleted', 'columns',
            ],
            'context'
        );
        if (($context['authorized'] ?? null) !== true) {
            $this->fail('native_search_access_denied', 'context.authorized');
        }
        foreach (['fields', 'sort_fields', 'meta_fields'] as $required) {
            if (!array_key_exists($required, $context) || !is_array($context[$required])) {
                $this->fail('native_search_context_invalid', 'context.' . $required);
            }
        }

        /** @var array<mixed,mixed> $fields */
        $fields = $context['fields'];
        $this->fields = $this->normalizeFieldMap($fields, 'context.fields');
        if (array_key_exists('special_fields', $context)) {
            if (!is_array($context['special_fields'])) {
                $this->fail('native_search_context_invalid', 'context.special_fields');
            }
            /** @var array<mixed,mixed> $specialFields */
            $specialFields = $context['special_fields'];
            foreach (
                $this->normalizeFieldMap(
                    $specialFields,
                    'context.special_fields',
                    true
                ) as $field => $operators
            ) {
                $this->fields[$field] = $operators;
            }
        }

        /** @var array<mixed,mixed> $sortFields */
        $sortFields = $context['sort_fields'];
        if (!array_is_list($sortFields)) {
            $this->fail('native_search_context_invalid', 'context.sort_fields');
        }
        foreach ($sortFields as $index => $field) {
            if (!$this->isPositiveInteger($field)) {
                $this->fail('native_search_context_invalid', 'context.sort_fields.' . $index);
            }
            $this->sortFields[(int) $field] = true;
        }

        /** @var array<mixed,mixed> $metaFields */
        $metaFields = $context['meta_fields'];
        foreach ($metaFields as $itemtype => $itemtypeFields) {
            if (
                !is_string($itemtype)
                || !$this->isSafeItemtype($itemtype)
                || !is_array($itemtypeFields)
            ) {
                $this->fail('native_search_context_invalid', 'context.meta_fields');
            }
            /** @var array<mixed,mixed> $itemtypeFields */
            $this->metaFields[$itemtype] = $this->normalizeFieldMap(
                $itemtypeFields,
                'context.meta_fields.' . $itemtype
            );
        }

        if (array_key_exists('allow_deleted', $context) && !is_bool($context['allow_deleted'])) {
            $this->fail('native_search_context_invalid', 'context.allow_deleted');
        }
        $this->allowDeleted = ($context['allow_deleted'] ?? false) === true;

        if (array_key_exists('columns', $context)) {
            if (!is_array($context['columns']) || !array_is_list($context['columns'])) {
                $this->fail('native_search_context_invalid', 'context.columns');
            }
            foreach ($context['columns'] as $index => $column) {
                $identifier = $this->normalizeColumnIdentifier(
                    $column,
                    'context.columns.' . $index,
                    'native_search_context_invalid'
                );
                $this->columns[$identifier] = true;
            }
        }
    }

    /**
     * @param array<mixed,mixed> $fields
     * @return array<int|string,array<string,SearchOperatorValueContract>>
     */
    private function normalizeFieldMap(
        array $fields,
        string $path,
        bool $allowSpecial = false
    ): array {
        $normalized = [];
        foreach ($fields as $field => $operators) {
            $fieldId = $this->isPositiveInteger($field)
                ? (int) $field
                : ($allowSpecial && is_string($field) && in_array($field, ['all', 'view'], true)
                    ? $field
                    : null);
            if ($fieldId === null || !is_array($operators)) {
                $this->fail('native_search_context_invalid', $path);
            }
            $normalized[$fieldId] = [];

            if (array_is_list($operators)) {
                foreach ($operators as $operatorIndex => $operator) {
                    if (!is_string($operator)) {
                        $this->fail(
                            'native_search_context_invalid',
                            $path . '.' . $fieldId . '.' . $operatorIndex
                        );
                    }
                    $operator = strtolower(trim($operator));
                    if (
                        !in_array($operator, self::HOMOLOGATED_OPERATORS, true)
                        || isset($normalized[$fieldId][$operator])
                    ) {
                        $this->fail(
                            'native_search_context_invalid',
                            $path . '.' . $fieldId . '.' . $operatorIndex
                        );
                    }
                    $normalized[$fieldId][$operator] = SearchOperatorValueContract::legacy($operator);
                }
            } else {
                foreach ($operators as $operator => $contractDescriptor) {
                    if (!is_string($operator) || !is_array($contractDescriptor)) {
                        $this->fail('native_search_context_invalid', $path . '.' . $fieldId);
                    }
                    $operator = strtolower(trim($operator));
                    if (
                        !in_array($operator, self::HOMOLOGATED_OPERATORS, true)
                        || isset($normalized[$fieldId][$operator])
                    ) {
                        $this->fail(
                            'native_search_context_invalid',
                            $path . '.' . $fieldId . '.' . $operator
                        );
                    }
                    try {
                        $normalized[$fieldId][$operator] = SearchOperatorValueContract::fromArray(
                            $operator,
                            $contractDescriptor
                        );
                    } catch (\InvalidArgumentException $e) {
                        $this->fail(
                            'native_search_context_invalid',
                            $path . '.' . $fieldId . '.' . $operator
                        );
                    }
                }
            }
            if ($normalized[$fieldId] === []) {
                $this->fail('native_search_context_invalid', $path . '.' . $fieldId);
            }
        }
        return $normalized;
    }
    /** @param mixed $value */
    private function assertDefinitionBudget($value): void
    {
        $encoded = json_encode(
            $value,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR
        );
        if (!is_string($encoded) || strlen($encoded) > self::MAX_DEFINITION_BYTES) {
            $this->fail('native_search_definition_byte_limit_exceeded', 'definition');
        }
    }

    /**
     * @param mixed $criteria
     * @return array<int,array<string,mixed>>
     */
    private function validateCriteriaList($criteria, string $path, int $depth): array
    {
        if (!is_array($criteria) || !array_is_list($criteria)) {
            $this->fail('native_search_criteria_invalid', $path);
        }
        if ($depth > self::MAX_DEPTH) {
            $this->fail('native_search_criteria_depth_exceeded', $path);
        }

        $normalized = [];
        foreach ($criteria as $index => $criterion) {
            $criterionPath = $path . '.' . $index;
            if (!is_array($criterion)) {
                $this->fail('native_search_criterion_invalid', $criterionPath);
            }
            if (array_key_exists('criteria', $criterion)) {
                $this->assertExactKeys($criterion, ['link', 'criteria'], $criterionPath);
                $children = $this->validateCriteriaList(
                    $criterion['criteria'],
                    $criterionPath . '.criteria',
                    $depth + 1
                );
                if ($children === []) {
                    $this->fail('native_search_group_empty', $criterionPath . '.criteria');
                }
                $normalized[] = [
                    'link' => $this->validateLink($criterion['link'] ?? null, $criterionPath . '.link'),
                    'criteria' => $children,
                ];
                $this->parameterLeaves++;
                continue;
            }

            $hasMeta = array_key_exists('meta', $criterion) || array_key_exists('itemtype', $criterion);
            $normalized[] = $hasMeta
                ? $this->validateModernMetaCriterion($criterion, $criterionPath)
                : $this->validateLeaf($criterion, $criterionPath, 'Ticket', $this->fields);
        }
        return $normalized;
    }

    /**
     * @param mixed $criteria
     * @return array<int,array<string,mixed>>
     */
    private function validateMetaCriteriaList($criteria, string $path): array
    {
        if (!is_array($criteria) || !array_is_list($criteria)) {
            $this->fail('native_search_meta_criteria_invalid', $path);
        }

        $normalized = [];
        foreach ($criteria as $index => $criterion) {
            $criterionPath = $path . '.' . $index;
            if (!is_array($criterion)) {
                $this->fail('native_search_meta_criterion_invalid', $criterionPath);
            }
            $this->assertExactKeys(
                $criterion,
                ['link', 'itemtype', 'field', 'searchtype', 'value'],
                $criterionPath
            );
            $itemtype = $criterion['itemtype'] ?? null;
            if (!is_string($itemtype) || !isset($this->metaFields[$itemtype])) {
                $this->fail('native_search_meta_itemtype_denied', $criterionPath . '.itemtype');
            }
            $normalized[] = $this->validateLeaf(
                $criterion,
                $criterionPath,
                $itemtype,
                $this->metaFields[$itemtype],
                ['itemtype']
            ) + ['itemtype' => $itemtype];
            $this->metaCriteriaCount++;
            $this->parameterLeaves++;
        }
        return $normalized;
    }

    /**
     * @param array<mixed,mixed> $criterion
     * @return array<string,mixed>
     */
    private function validateModernMetaCriterion(array $criterion, string $path): array
    {
        $this->assertExactKeys(
            $criterion,
            ['link', 'meta', 'itemtype', 'field', 'searchtype', 'value'],
            $path
        );
        if (!$this->isIntegerValue($criterion['meta'] ?? null) || (int) $criterion['meta'] !== 1) {
            $this->fail('native_search_meta_flag_invalid', $path . '.meta');
        }
        $itemtype = $criterion['itemtype'] ?? null;
        if (!is_string($itemtype) || !isset($this->metaFields[$itemtype])) {
            $this->fail('native_search_meta_itemtype_denied', $path . '.itemtype');
        }

        $leaf = $this->validateLeaf(
            $criterion,
            $path,
            $itemtype,
            $this->metaFields[$itemtype],
            ['meta', 'itemtype']
        );
        $this->metaCriteriaCount++;
        return $leaf + ['meta' => 1, 'itemtype' => $itemtype];
    }

    /**
     * @param array<mixed,mixed> $criterion
     * @param array<int|string,array<string,SearchOperatorValueContract>> $allowedFields
     * @param string[] $additionalKeys
     * @return array<string,mixed>
     */
    private function validateLeaf(
        array $criterion,
        string $path,
        string $itemtype,
        array $allowedFields,
        array $additionalKeys = []
    ): array {
        $this->assertExactKeys(
            $criterion,
            array_merge(['link', 'field', 'searchtype', 'value'], $additionalKeys),
            $path
        );
        foreach (['link', 'field', 'searchtype', 'value'] as $required) {
            if (!array_key_exists($required, $criterion)) {
                $this->fail('native_search_criterion_parameter_missing', $path . '.' . $required);
            }
        }

        $rawField = $criterion['field'];
        $field = $this->isPositiveInteger($rawField)
            ? (int) $rawField
            : ($itemtype === 'Ticket'
                && is_string($rawField)
                && in_array($rawField, ['all', 'view'], true)
                ? $rawField
                : null);
        if ($field === null || !isset($allowedFields[$field])) {
            $this->fail(
                $itemtype === 'Ticket'
                    ? 'native_search_field_denied'
                    : 'native_search_meta_field_denied',
                $path . '.field'
            );
        }

        $operator = $criterion['searchtype'];
        if (!is_string($operator)) {
            $this->fail('native_search_operator_denied', $path . '.searchtype');
        }
        $operator = strtolower(trim($operator));
        if (!isset($allowedFields[$field][$operator])) {
            $this->fail('native_search_operator_denied', $path . '.searchtype');
        }

        $value = $this->validateValue(
            $criterion['value'],
            $path . '.value',
            $allowedFields[$field][$operator]
        );
        $this->criteriaCount++;
        if ($this->criteriaCount > self::MAX_CRITERIA) {
            $this->fail('native_search_criteria_limit_exceeded', $path);
        }
        $this->parameterLeaves += 4 + count($additionalKeys);

        return [
            'link' => $this->validateLink($criterion['link'], $path . '.link'),
            'field' => $field,
            'searchtype' => $operator,
            'value' => $value,
        ];
    }

    /**
     * @param mixed $sort
     * @param mixed $order
     * @return array{0:array<int,int>,1:array<int,string>}
     */
    private function validateSort($sort, $order): array
    {
        if (
            !is_array($sort)
            || !array_is_list($sort)
            || !is_array($order)
            || !array_is_list($order)
        ) {
            $this->fail('native_search_sort_invalid', 'definition.sort');
        }
        if (count($sort) !== count($order)) {
            $this->fail('native_search_sort_order_mismatch', 'definition.sort');
        }
        if (count($sort) > self::MAX_SORTS) {
            $this->fail('native_search_sort_limit_exceeded', 'definition.sort');
        }

        $normalizedSort = [];
        $normalizedOrder = [];
        $seen = [];
        foreach ($sort as $index => $field) {
            if (!$this->isPositiveInteger($field) || !isset($this->sortFields[(int) $field])) {
                $this->fail('native_search_sort_field_denied', 'definition.sort.' . $index);
            }
            $field = (int) $field;
            if (isset($seen[$field])) {
                $this->fail('native_search_sort_duplicate', 'definition.sort.' . $index);
            }
            $seen[$field] = true;
            $direction = $order[$index];
            if (!is_string($direction)) {
                $this->fail('native_search_order_unsupported', 'definition.order.' . $index);
            }
            $direction = strtoupper(trim($direction));
            if (!in_array($direction, ['ASC', 'DESC'], true)) {
                $this->fail('native_search_order_unsupported', 'definition.order.' . $index);
            }
            $normalizedSort[] = $field;
            $normalizedOrder[] = $direction;
        }
        return [$normalizedSort, $normalizedOrder];
    }

    /** @param mixed $value */
    private function validateText($value): string
    {
        $validUtf8 = is_string($value) && (
            function_exists('mb_check_encoding')
                ? mb_check_encoding($value, 'UTF-8')
                : preg_match('//u', $value) === 1
        );
        if (
            !$validUtf8
            || mb_strlen((string) $value, 'UTF-8') > 120
            || preg_match('/[\x00-\x1F\x7F]/u', (string) $value) === 1
        ) {
            $this->fail('native_search_text_invalid', 'definition.text');
        }
        return trim((string) $value);
    }

    /** @param mixed $value */
    private function validateScope($value): string
    {
        if (!is_string($value) || !in_array($value, ['all', 'mine', 'group'], true)) {
            $this->fail('native_search_scope_unsupported', 'definition.scope');
        }
        return $value;
    }

    /** @param mixed $value */
    private function validateDeletedScope($value): int
    {
        if (!$this->isIntegerValue($value) || !in_array((int) $value, [0, 1], true)) {
            $this->fail('native_search_deleted_scope_unsupported', 'definition.is_deleted');
        }
        if ((int) $value === 1 && !$this->allowDeleted) {
            $this->fail('native_search_deleted_scope_denied', 'definition.is_deleted');
        }
        return (int) $value;
    }

    /**
     * @param mixed $columns
     * @return string[]
     */
    private function validateColumns($columns): array
    {
        if (!is_array($columns) || !array_is_list($columns)) {
            $this->fail('native_search_columns_invalid', 'definition.columns');
        }
        if (count($columns) > self::MAX_COLUMNS) {
            $this->fail('native_search_column_limit_exceeded', 'definition.columns');
        }

        $normalized = [];
        foreach ($columns as $index => $column) {
            $identifier = $this->normalizeColumnIdentifier(
                $column,
                'definition.columns.' . $index,
                'native_search_column_denied'
            );
            if (!isset($this->columns[$identifier])) {
                $this->fail('native_search_column_denied', 'definition.columns.' . $index);
            }
            if (in_array($identifier, $normalized, true)) {
                $this->fail('native_search_column_duplicate', 'definition.columns.' . $index);
            }
            $normalized[] = $identifier;
        }
        return $normalized;
    }

    /**
     * @param mixed $column
     */
    private function normalizeColumnIdentifier($column, string $path, string $reasonCode): string
    {
        if (!is_string($column) && !$this->isPositiveInteger($column)) {
            $this->fail($reasonCode, $path);
        }
        $column = trim((string) $column);
        if (
            $column === ''
            || strlen($column) > 128
            || preg_match('/\A[A-Za-z0-9_.:-]+\z/D', $column) !== 1
        ) {
            $this->fail($reasonCode, $path);
        }
        return $column;
    }

    /** @param mixed $link */
    private function validateLink($link, string $path): string
    {
        if (!is_string($link)) {
            $this->fail('native_search_link_unsupported', $path);
        }
        $link = strtoupper(trim($link));
        if (!in_array($link, self::LINKS, true)) {
            $this->fail('native_search_link_unsupported', $path);
        }
        return $link;
    }

    /** @param mixed $value */
    private function validateValue(
        $value,
        string $path,
        SearchOperatorValueContract $contract
    ): string {
        try {
            return (new SearchCriterionValueValidator())->validate($value, $contract);
        } catch (\InvalidArgumentException $e) {
            $this->fail('native_search_value_unsupported', $path);
        }
    }

    /**
     * @param array<mixed,mixed> $value
     * @param string[] $allowed
     */
    private function assertExactKeys(array $value, array $allowed, string $path): void
    {
        foreach (array_keys($value) as $key) {
            if (!is_string($key) || !in_array($key, $allowed, true)) {
                $this->fail('native_search_parameter_unsupported', $path);
            }
        }
    }

    /** @param mixed $value */
    private function isPositiveInteger($value): bool
    {
        return $this->isIntegerValue($value) && (int) $value > 0;
    }

    /** @param mixed $value */
    private function isIntegerValue($value): bool
    {
        return is_int($value)
            || (is_string($value) && preg_match('/\A(?:0|[1-9][0-9]*)\z/D', $value) === 1);
    }

    private function isSafeItemtype(string $itemtype): bool
    {
        return strlen($itemtype) <= 128
            && preg_match('/\A[A-Za-z_][A-Za-z0-9_\\\\]*\z/D', $itemtype) === 1;
    }

    private function fail(string $reasonCode, string $path): never
    {
        throw new NativeSearchValidationException($reasonCode, $path);
    }
}
