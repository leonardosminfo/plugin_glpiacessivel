<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Ticket;

use GlpiPlugin\Glpiacessivel\Support\I18n;

final class TicketCreationPolicy
{
    public const SUPPORTED_CREATE_FIELDS = [
        'name',
        'content',
        'type',
        'itilcategories_id',
        'locations_id',
        'requesttypes_id',
        'externalid',
        'urgency',
        'impact',
        '_groups_id_assign',
        '_groups_id_observer',
        '_users_id_assign',
        '_users_id_observer',
        '_filename',
    ];

    /**
     * @param array<string, mixed> $input
     * @param array<string, array<string, mixed>> $requirements
     * @return string[]
     */
    public function validateRequiredFields(array $input, array $requirements): array
    {
        return array_map(
            static fn(array $error): string => $error['message'],
            $this->validateRequiredFieldErrors($input, $requirements)
        );
    }

    /**
     * @param array<string, mixed> $input
     * @param array<string, array<string, mixed>> $requirements
     * @return array<int, array{field:string, code:string, message:string}>
     */
    public function validateRequiredFieldErrors(array $input, array $requirements): array
    {
        $errors = [];
        foreach ($requirements as $field => $metadata) {
            if (empty($metadata['required']) || empty($metadata['visible']) || !empty($metadata['readonly'])) {
                continue;
            }

            if (!$this->hasValue($input[$field] ?? null)) {
                $field = (string) $field;
                $errors[] = [
                    'field' => $field,
                    'code' => 'required',
                    'message' => sprintf(
                        I18n::translate('Informe %s.'),
                        mb_strtolower(self::fieldLabel($field), 'UTF-8')
                    ),
                ];
            }
        }

        return $errors;
    }

    /**
     * @param string[] $mandatoryFields
     * @return string[]
     */
    public function unsupportedMandatoryFields(array $mandatoryFields): array
    {
        $supported = array_fill_keys(self::SUPPORTED_CREATE_FIELDS, true);
        $ignored = array_fill_keys(['id', 'entities_id', 'users_id_recipient'], true);
        $unsupported = [];
        foreach ($mandatoryFields as $field) {
            $field = (string) $field;
            if ($field === '' || isset($supported[$field]) || isset($ignored[$field])) {
                continue;
            }
            $unsupported[] = $field;
        }

        return array_values(array_unique($unsupported));
    }

    public static function fieldLabel(string $field): string
    {
        return [
            'name' => I18n::translate('Título'),
            'content' => I18n::translate('Descrição'),
            'type' => I18n::translate('Tipo'),
            'itilcategories_id' => I18n::translate('Categoria'),
            'locations_id' => I18n::translate('Localização'),
            'requesttypes_id' => I18n::translate('Origem da requisição'),
            'externalid' => I18n::translate('ID externo'),
            'urgency' => I18n::translate('Urgência'),
            'impact' => I18n::translate('Impacto'),
            '_groups_id_assign' => I18n::translate('Grupo técnico'),
            '_groups_id_observer' => I18n::translate('Grupo observador'),
            '_users_id_assign' => I18n::translate('Técnico atribuído'),
            '_users_id_observer' => I18n::translate('Observador'),
            '_filename' => I18n::translate('Anexos'),
        ][$field] ?? $field;
    }

    private function hasValue(mixed $value): bool
    {
        if (is_array($value)) {
            return array_values(array_filter($value, static fn($item): bool => trim((string) $item) !== '')) !== [];
        }

        return trim((string) $value) !== '' && trim((string) $value) !== '0';
    }
}
