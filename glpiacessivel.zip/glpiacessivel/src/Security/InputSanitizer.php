<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Security;

final class InputSanitizer
{
    public function int(mixed $value, int $default = 0): int
    {
        if (is_int($value)) {
            return $value;
        }

        if (is_string($value) && preg_match('/^-?\d+$/', $value) === 1) {
            return (int) $value;
        }

        return $default;
    }

    public function text(mixed $value, int $maxLength = 4000): string
    {
        $clean = trim((string) $value);
        $clean = strip_tags($clean);
        if (mb_strlen($clean) > $maxLength) {
            $clean = mb_substr($clean, 0, $maxLength);
        }

        return $clean;
    }

    public function enum(mixed $value, array $allowed, string $default): string
    {
        if (!is_scalar($value) && $value !== null) {
            return $default;
        }

        $value = (string) $value;
        return in_array($value, $allowed, true) ? $value : $default;
    }
}
