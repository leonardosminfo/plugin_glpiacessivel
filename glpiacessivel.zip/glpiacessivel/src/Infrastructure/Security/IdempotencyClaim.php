<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Security;

final class IdempotencyClaim
{
    public const ACQUIRED = 'acquired';
    public const REPLAY = 'replay';
    public const IN_PROGRESS = 'in_progress';
    public const CONFLICT = 'conflict';

    private string $status;
    private string $scopeHash;
    private string $keyHash;
    private string $requestHash;
    private string $reservationToken;
    private ?int $resultId;

    public function __construct(
        string $status,
        string $scopeHash,
        string $keyHash,
        string $requestHash,
        string $reservationToken = '',
        ?int $resultId = null
    ) {
        if (!in_array($status, [self::ACQUIRED, self::REPLAY, self::IN_PROGRESS, self::CONFLICT], true)) {
            throw new \InvalidArgumentException('idempotency_claim_status_invalid');
        }

        $this->status = $status;
        $this->scopeHash = $scopeHash;
        $this->keyHash = $keyHash;
        $this->requestHash = $requestHash;
        $this->reservationToken = $reservationToken;
        $this->resultId = $resultId;
    }

    public function status(): string
    {
        return $this->status;
    }

    public function isAcquired(): bool
    {
        return $this->status === self::ACQUIRED;
    }

    public function isReplay(): bool
    {
        return $this->status === self::REPLAY;
    }

    public function scopeHash(): string
    {
        return $this->scopeHash;
    }

    public function keyHash(): string
    {
        return $this->keyHash;
    }

    public function requestHash(): string
    {
        return $this->requestHash;
    }

    public function reservationToken(): string
    {
        return $this->reservationToken;
    }

    public function resultId(): ?int
    {
        return $this->resultId;
    }
}
