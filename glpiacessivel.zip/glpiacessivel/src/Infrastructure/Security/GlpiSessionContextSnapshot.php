<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Security;

/**
 * Minimal, immutable authorization context derived only from GLPI's session.
 */
final class GlpiSessionContextSnapshot
{
    /**
     * @return array{
     *   user_id:int,
     *   profile_id:int,
     *   active_entity:int,
     *   active_entities:int[],
     *   recursive:bool,
     *   language:string,
     *   revision:string
     * }
     */
    public function snapshot(): array
    {
        $userId = class_exists('\Session') && method_exists('\Session', 'getLoginUserID')
            ? (int) \Session::getLoginUserID()
            : (int) ($_SESSION['glpiID'] ?? 0);
        $profileId = (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0);
        $activeEntity = is_numeric($_SESSION['glpiactive_entity'] ?? null)
            ? (int) $_SESSION['glpiactive_entity']
            : -1;

        $activeEntities = [];
        foreach ((array) ($_SESSION['glpiactiveentities'] ?? []) as $entity) {
            if (!is_numeric($entity) || (int) $entity < 0) {
                throw new \RuntimeException('session_context_unavailable');
            }
            $activeEntities[(int) $entity] = (int) $entity;
        }
        if ($activeEntities === [] && $activeEntity >= 0) {
            $activeEntities[$activeEntity] = $activeEntity;
        }
        sort($activeEntities, SORT_NUMERIC);

        if ($userId < 1 || $profileId < 1 || $activeEntity < 0 || $activeEntities === []) {
            throw new \RuntimeException('session_context_unavailable');
        }

        $language = trim((string) ($_SESSION['glpilanguage'] ?? ''));
        $profileRights = $_SESSION['glpiactiveprofile']['rights'] ?? [];
        $groups = $_SESSION['glpigroups'] ?? [];
        $revisionSource = json_encode([
            'user' => $userId,
            'profile' => $profileId,
            'entity' => $activeEntity,
            'entities' => $activeEntities,
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
            'language' => $language,
            'rights' => is_array($profileRights) ? $profileRights : [],
            'groups' => is_array($groups) ? $groups : [],
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if (!is_string($revisionSource)) {
            throw new \RuntimeException('session_context_unavailable');
        }

        return [
            'user_id' => $userId,
            'profile_id' => $profileId,
            'active_entity' => $activeEntity,
            'active_entities' => array_values($activeEntities),
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
            'language' => $language,
            'revision' => hash('sha256', $revisionSource),
        ];
    }
}
