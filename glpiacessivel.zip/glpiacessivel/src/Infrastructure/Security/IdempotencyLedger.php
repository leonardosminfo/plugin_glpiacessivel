<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Security;

use DBmysql;

/**
 * Short-lived coordination ledger. It never stores search names, filters, URLs,
 * values or definitions. Callers must reserve and complete in the same database
 * transaction as the protected native mutation.
 */
final class IdempotencyLedger
{
    private const TABLE = 'glpi_plugin_glpiacessivel_idempotency';
    private const STATUS_PENDING = 'pending';
    private const STATUS_COMPLETED = 'completed';
    private const DEFAULT_TTL_SECONDS = 900;
    private const MIN_TTL_SECONDS = 60;
    private const MAX_TTL_SECONDS = 3600;

    private DBmysql $db;

    /** @var callable(): int */
    private $clock;

    /** @param callable(): int|null $clock */
    public function __construct(DBmysql $db, ?callable $clock = null)
    {
        $this->db = $db;
        $this->clock = $clock ?? static fn(): int => time();
    }

    public function reserve(
        string $scope,
        string $idempotencyKey,
        string $requestHash,
        int $ttlSeconds = self::DEFAULT_TTL_SECONDS
    ): IdempotencyClaim {
        $this->assertOpaqueInput($scope, 'scope', 1, 512);
        $this->assertOpaqueInput($idempotencyKey, 'key', 16, 512);
        $requestHash = $this->normalizeRequestHash($requestHash);
        $ttlSeconds = min(self::MAX_TTL_SECONDS, max(self::MIN_TTL_SECONDS, $ttlSeconds));

        $now = $this->now();
        if (!$this->purgeExpiredAt($now)) {
            throw new \RuntimeException('idempotency_ledger_cleanup_failed');
        }

        $scopeHash = hash('sha256', $scope);
        $keyHash = hash('sha256', $idempotencyKey);
        $reservationToken = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $reservationToken);
        $nowSql = $this->formatTime($now);
        $expiresAt = $this->formatTime($now + $ttlSeconds);
        $insertFailure = null;

        try {
            $inserted = (bool) $this->db->insert(self::TABLE, [
                'scope_hash' => $scopeHash,
                'idempotency_key_hash' => $keyHash,
                'request_hash' => $requestHash,
                'reservation_token_hash' => $tokenHash,
                'status' => self::STATUS_PENDING,
                'result_id' => null,
                'expires_at' => $expiresAt,
                'created_at' => $nowSql,
                'updated_at' => $nowSql,
            ]);
        } catch (\Throwable $e) {
            $inserted = false;
            $insertFailure = $e;
        }

        if ($inserted) {
            return new IdempotencyClaim(
                IdempotencyClaim::ACQUIRED,
                $scopeHash,
                $keyHash,
                $requestHash,
                $reservationToken
            );
        }

        $row = $this->find($scopeHash, $keyHash);
        if ($row === null) {
            throw new \RuntimeException('idempotency_ledger_unavailable', 0, $insertFailure);
        }

        if (!$this->isUnexpired($row, $now)) {
            throw new \RuntimeException('idempotency_ledger_expired_row');
        }

        if (!hash_equals((string) ($row['request_hash'] ?? ''), $requestHash)) {
            return new IdempotencyClaim(
                IdempotencyClaim::CONFLICT,
                $scopeHash,
                $keyHash,
                $requestHash
            );
        }

        $status = (string) ($row['status'] ?? '');
        if ($status === self::STATUS_COMPLETED) {
            if (!isset($row['result_id']) || !is_numeric($row['result_id']) || (int) $row['result_id'] < 0) {
                throw new \RuntimeException('idempotency_ledger_state_invalid');
            }
            $resultId = (int) $row['result_id'];
            return new IdempotencyClaim(
                IdempotencyClaim::REPLAY,
                $scopeHash,
                $keyHash,
                $requestHash,
                '',
                $resultId
            );
        }
        if ($status === self::STATUS_PENDING) {
            return new IdempotencyClaim(
                IdempotencyClaim::IN_PROGRESS,
                $scopeHash,
                $keyHash,
                $requestHash
            );
        }

        throw new \RuntimeException('idempotency_ledger_state_invalid');
    }

    public function complete(IdempotencyClaim $claim, int $resultId): bool
    {
        if (!$claim->isAcquired() || $claim->reservationToken() === '' || $resultId < 0) {
            return false;
        }

        $now = $this->now();
        $updated = (bool) $this->db->update(self::TABLE, [
            'status' => self::STATUS_COMPLETED,
            'result_id' => $resultId,
            'updated_at' => $this->formatTime($now),
        ], [
            'scope_hash' => $claim->scopeHash(),
            'idempotency_key_hash' => $claim->keyHash(),
            'request_hash' => $claim->requestHash(),
            'reservation_token_hash' => hash('sha256', $claim->reservationToken()),
            'status' => self::STATUS_PENDING,
            'expires_at' => ['>', $this->formatTime($now)],
        ]);
        if (!$updated) {
            return false;
        }

        $row = $this->find($claim->scopeHash(), $claim->keyHash());
        return is_array($row)
            && ($row['status'] ?? null) === self::STATUS_COMPLETED
            && hash_equals((string) ($row['request_hash'] ?? ''), $claim->requestHash())
            && hash_equals(
                (string) ($row['reservation_token_hash'] ?? ''),
                hash('sha256', $claim->reservationToken())
            )
            && (int) ($row['result_id'] ?? -1) === $resultId
            && $this->isUnexpired($row, $now);
    }

    public function release(IdempotencyClaim $claim): bool
    {
        if (!$claim->isAcquired() || $claim->reservationToken() === '') {
            return false;
        }

        $deleted = (bool) $this->db->delete(self::TABLE, [
            'scope_hash' => $claim->scopeHash(),
            'idempotency_key_hash' => $claim->keyHash(),
            'request_hash' => $claim->requestHash(),
            'reservation_token_hash' => hash('sha256', $claim->reservationToken()),
            'status' => self::STATUS_PENDING,
        ]);
        if (!$deleted) {
            return false;
        }

        return $this->find($claim->scopeHash(), $claim->keyHash()) === null;
    }

    public function purgeExpired(): bool
    {
        return $this->purgeExpiredAt($this->now());
    }

    private function purgeExpiredAt(int $now): bool
    {
        return (bool) $this->db->delete(self::TABLE, [
            'expires_at' => ['<', $this->formatTime($now)],
        ]);
    }

    /** @return array<string, mixed>|null */
    private function find(string $scopeHash, string $keyHash): ?array
    {
        try {
            $row = $this->db->request([
                'FROM' => self::TABLE,
                'WHERE' => [
                    'scope_hash' => $scopeHash,
                    'idempotency_key_hash' => $keyHash,
                ],
                'LIMIT' => 1,
            ])->current();
        } catch (\Throwable $e) {
            throw new \RuntimeException('idempotency_ledger_unavailable', 0, $e);
        }

        return is_array($row) && $row !== [] ? $row : null;
    }

    /** @param array<string, mixed> $row */
    private function isUnexpired(array $row, int $now): bool
    {
        $expiresAt = strtotime((string) ($row['expires_at'] ?? ''));
        return $expiresAt !== false && $expiresAt > $now;
    }

    private function assertOpaqueInput(string $value, string $field, int $minLength, int $maxLength): void
    {
        $length = strlen($value);
        if ($length < $minLength || $length > $maxLength || preg_match('/[\x00-\x1F\x7F]/', $value) === 1) {
            throw new \InvalidArgumentException('idempotency_' . $field . '_invalid');
        }
    }

    private function normalizeRequestHash(string $requestHash): string
    {
        $requestHash = strtolower($requestHash);
        if (strlen($requestHash) !== 64 || !ctype_xdigit($requestHash)) {
            throw new \InvalidArgumentException('idempotency_request_hash_invalid');
        }

        return $requestHash;
    }

    private function now(): int
    {
        return (int) call_user_func($this->clock);
    }

    private function formatTime(int $timestamp): string
    {
        return date('Y-m-d H:i:s', $timestamp);
    }
}
