<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Repository;

use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchDefinitionValidator;
use GlpiPlugin\Glpiacessivel\Infrastructure\Database\GlpiDatabaseQuery;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\IdempotencyClaim;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\IdempotencyLedger;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiSearchOptionCatalog;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiTicketActorSearchOptionResolver;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiTicketStatusCriterionCodec;

/**
 * Native-only gateway for ticket searches stored by GLPI.
 *
 * SavedSearch and SavedSearch_User are the only sources of truth. This class
 * never writes a plugin-owned search, filter, default or mirror.
 */
final class NativeSavedSearchGateway
{
    private const TABLE = 'glpi_savedsearches';
    private const DEFAULT_TABLE = 'glpi_savedsearches_users';
    private const SEARCH_TYPE = 1;
    private const MAX_QUERY_BYTES = 49152;
    private const MAX_QUERY_VARIABLES = 600;
    private const MAX_CRITERIA = 100;
    private const MAX_META_CRITERIA = 25;
    private const MAX_SORTS = 5;
    private const MAX_COLUMNS = 50;
    private const MAX_VALUE_BYTES = 4096;
    private const MAX_DEPTH = 8;
    private const CURSOR_TTL = 900;
    private const MAX_CATALOG_SCAN_ROWS = 1000;
    private const MAX_CATALOG_SCAN_MILLISECONDS = 250;
    private int $transactionDepth = 0;

    /**
     * @return array{items:array<int,array<string,mixed>>,next_cursor:string,has_more:bool,page_size:int,query:string}
     */
    public function page(string $query = '', string $cursor = '', int $pageSize = 25): array
    {
        global $DB;

        $pageSize = min(100, max(1, $pageSize));
        $query = mb_substr(trim($query), 0, 120, 'UTF-8');
        $empty = [
            'items' => [],
            'next_cursor' => '',
            'has_more' => false,
            'page_size' => $pageSize,
            'query' => $query,
        ];
        if (!isset($DB) || !method_exists($DB, 'request') || $this->currentUserId() <= 0) {
            return $empty;
        }

        $scanAfterId = $cursor === '' ? 0 : $this->decodeCursor($cursor, $query);
        $items = [];
        $defaultId = $this->defaultIdUnchecked();
        $batchSize = min(500, max(50, ($pageSize + 1) * 4));
        $scanStartedAt = microtime(true);
        $totalScanned = 0;
        $scanLimited = false;
        $where = [
            'itemtype' => 'Ticket',
            'type' => self::SEARCH_TYPE,
            'OR' => [
                ['is_private' => 1, 'users_id' => $this->currentUserId()],
                ['is_private' => 0],
            ],
        ];
        if ($query !== '') {
            $where['name'] = ['LIKE', $this->savedSearchNamePattern($query)];
        }

        while (count($items) <= $pageSize) {
            $where['id'] = ['>', $scanAfterId];
            try {
                $rows = $DB->request([
                    'FROM' => self::TABLE,
                    'WHERE' => $where,
                    'ORDER' => ['id ASC'],
                    'LIMIT' => $batchSize,
                ]);
            } catch (\Throwable $e) {
                break;
            }

            $scanned = 0;
            foreach ($rows as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $id = (int) ($row['id'] ?? 0);
                if ($id <= $scanAfterId) {
                    continue;
                }
                $scanAfterId = $id;
                $scanned++;
                $totalScanned++;
                if (
                    $this->nameMatches((string) ($row['name'] ?? ''), $query)
                    && $this->authorizedModel($id, $this->readRight()) !== null
                ) {
                    $items[] = $this->viewFromRow($row, $defaultId);
                    if (count($items) > $pageSize) {
                        break 2;
                    }
                }
                if (
                    $totalScanned >= self::MAX_CATALOG_SCAN_ROWS
                    || ((microtime(true) - $scanStartedAt) * 1000) >= self::MAX_CATALOG_SCAN_MILLISECONDS
                ) {
                    $scanLimited = true;
                    break 2;
                }
            }
            if ($scanned < $batchSize) {
                break;
            }
        }

        $hasBufferedItem = count($items) > $pageSize;
        if ($hasBufferedItem) {
            array_pop($items);
        }
        $hasMore = $hasBufferedItem || $scanLimited;
        $lastId = $scanLimited && !$hasBufferedItem
            ? $scanAfterId
            : ($items === [] ? 0 : (int) ($items[array_key_last($items)]['id'] ?? 0));

        return [
            'items' => $items,
            'next_cursor' => $hasMore && $lastId > 0 ? $this->encodeCursor($lastId, $query) : '',
            'has_more' => $hasMore,
            'page_size' => $pageSize,
            'query' => $query,
        ];
    }

    /** @return array{can_create_private:bool,can_create_public:bool} */
    public function capabilities(): array
    {
        $canCreatePrivate = $this->currentUserId() > 0
            && class_exists('\SavedSearch')
            && $this->supportsSafeMutations();
        $canCreatePublic = $canCreatePrivate
            && class_exists('\Session')
            && method_exists('\Session', 'haveRight')
            && \Session::haveRight('bookmark_public', $this->updateRight());

        return [
            'can_create_private' => $canCreatePrivate,
            'can_create_public' => $canCreatePublic,
        ];
    }

    /** @return array<string,mixed> */
    public function searchCatalog(): array
    {
        return (new GlpiSearchOptionCatalog())->forTickets();
    }

    /** @return array<string,mixed> */
    public function validationContext(bool $authorized): array
    {
        return (new GlpiSearchOptionCatalog())->validationContext($authorized);
    }

    /**
     * @param array<string,mixed> $definition
     * @return array<string,mixed>
     */
    public function validateDefinition(array $definition): array
    {
        return (new NativeSearchDefinitionValidator())->validate(
            $definition,
            $this->validationContext(true)
        );
    }

    /** @return array<string,mixed>|null */
    public function getAuthorized(int $id, ?int $right = null): ?array
    {
        $right ??= $this->readRight();
        $model = $this->authorizedModel($id, $right);
        if ($model === null || !is_array($model->fields ?? null)) {
            return null;
        }
        $row = $model->fields;
        $analysis = $this->resolvedAnalysisFromModel($model);
        $view = $this->viewFromRow($row, $this->defaultIdUnchecked(), $analysis);
        $view['definition'] = $analysis['definition'];
        $view['native_criteria'] = $analysis['criteria'];
        $view['native_metacriteria'] = $analysis['metacriteria'];
        $view['native_sort'] = $analysis['sort'];
        $view['native_order'] = $analysis['order'];
        $view['native_is_deleted'] = $analysis['is_deleted'];
        $view['columns_source'] = $analysis['columns_source'];
        $view['presentation_warnings'] = $analysis['presentation_reasons'];
        $view['page_size'] = (int) ($analysis['list_limit'] ?? 0);
        return $view;
    }

    public function defaultId(): int
    {
        $id = $this->defaultIdUnchecked();
        return $id > 0 && $this->authorizedModel($id, $this->readRight()) !== null ? $id : 0;
    }

    /**
     * Build an exact SavedSearch definition from the existing simple form.
     * Non-GLPI presentation keys such as page_size and group_by are excluded.
     *
     * @return array<string,mixed>
     */
    public function buildSimpleDefinition(array $filters): array
    {
        $criteria = [];
        $status = trim((string) ($filters['status'] ?? ''));
        if ($status !== '') {
            if (!ctype_digit($status)) {
                throw new \InvalidArgumentException('native_saved_search_definition_unsupported');
            }
            $criteria[] = $this->criterion(
                $this->ticketOptionNumber('status'),
                'equals',
                (string) ((int) $status)
            );
        }

        $text = trim((string) ($filters['q'] ?? ''));
        if ($text !== '') {
            if (ctype_digit($text)) {
                $criteria[] = $this->criterion(
                    $this->ticketOptionNumber('id'),
                    'equals',
                    (string) ((int) $text)
                );
            } else {
                $criteria[] = [
                    'link' => 'AND',
                    'criteria' => [
                        $this->criterion($this->ticketOptionNumber('name'), 'contains', $text),
                        $this->criterion($this->ticketOptionNumber('content'), 'contains', $text, 'OR'),
                    ],
                ];
            }
        }

        $scope = (string) ($filters['scope'] ?? 'all');
        $groupId = max(0, (int) ($filters['group_id'] ?? 0));
        if ($scope === 'mine') {
            $userId = $this->currentUserId();
            $options = $this->ticketUserOptionNumbersByType();
            if ($userId <= 0 || count($options) !== 3) {
                throw new \RuntimeException('native_saved_search_definition_unsupported');
            }
            $alternatives = [];
            foreach ([1, 2, 3] as $index => $type) {
                $alternatives[] = $this->criterion(
                    $options[$type],
                    'equals',
                    (string) $userId,
                    $index === 0 ? 'AND' : 'OR'
                );
            }
            $criteria[] = ['link' => 'AND', 'criteria' => $alternatives];
        } elseif ($scope === 'group' || $groupId > 0) {
            $option = $this->ticketAssignedGroupOptionNumber();
            $groups = $groupId > 0 ? [$groupId] : $this->currentUserGroupIds();
            if ($option <= 0 || $groups === []) {
                throw new \RuntimeException('native_saved_search_definition_unsupported');
            }
            $alternatives = [];
            foreach ($groups as $index => $id) {
                $alternatives[] = $this->criterion(
                    $option,
                    'equals',
                    (string) $id,
                    $index === 0 ? 'AND' : 'OR'
                );
            }
            $criteria[] = ['link' => 'AND', 'criteria' => $alternatives];
        } elseif ($scope !== 'all') {
            throw new \InvalidArgumentException('native_saved_search_definition_unsupported');
        }

        $sortMap = [
            'id' => 'id',
            'name' => 'name',
            'status' => 'status',
            'priority' => 'priority',
            'date' => 'date',
            'date_mod' => 'date_mod',
        ];
        $sortName = (string) ($filters['sort'] ?? 'date_mod');
        if (!isset($sortMap[$sortName])) {
            throw new \InvalidArgumentException('native_saved_search_definition_unsupported');
        }
        $definition = [
            'itemtype' => 'Ticket',
            'criteria' => $criteria,
            'metacriteria' => [],
            'sort' => [$this->ticketOptionNumber($sortMap[$sortName])],
            'order' => [strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC'],
            'is_deleted' => 0,
        ];
        if (array_key_exists('columns', $filters)) {
            $definition['columns'] = array_values((array) $filters['columns']);
        }
        $this->serializeDefinition($definition);
        return $definition;
    }

    /** @param array<string,mixed> $options */
    public function create(string $name, array $definition, array $options = []): int
    {
        $name = $this->normalizeName($name);
        $query = $this->serializeDefinition($definition);
        $userId = $this->currentUserId();
        if ($userId <= 0) {
            throw new \RuntimeException('saved_search_user_unavailable');
        }
        $isPrivate = !array_key_exists('is_private', $options) || !empty($options['is_private']);
        $entityId = array_key_exists('entities_id', $options)
            ? max(0, (int) $options['entities_id'])
            : $this->currentEntityId();
        $recursive = !empty($options['is_recursive']);
        $this->assertVisibilityAndEntity($isPrivate, $entityId, $recursive);

        return $this->transactional(function () use (
            $name,
            $query,
            $userId,
            $isPrivate,
            $entityId,
            $recursive,
            $options
        ): int {
            if (!empty($options['set_default'])) {
                $this->lockDefaultScope();
            }
            $model = $this->newModel();
            $id = $model->add([
                'name' => $name,
                'type' => $this->searchType(),
                'itemtype' => 'Ticket',
                'users_id' => $userId,
                'is_private' => $isPrivate ? 1 : 0,
                'entities_id' => $entityId,
                'is_recursive' => $recursive ? 1 : 0,
                'url' => $this->ticketUrlForQuery($query),
            ]);
            $id = is_numeric($id) ? (int) $id : 0;
            if ($id <= 0 || $this->getAuthorized($id) === null) {
                throw new \RuntimeException('native_saved_search_create_failed');
            }
            if (!empty($options['set_default'])) {
                $this->setDefaultInternal($id);
            }
            return $id;
        });
    }

    /** @param array<string,mixed> $options */
    public function update(
        int $id,
        string $name,
        array $definition,
        string $expectedFingerprint = '',
        array $options = []
    ): bool {
        $name = $this->normalizeName($name);
        $query = $this->serializeDefinition($definition);

        return $this->transactional(function () use (
            $id,
            $name,
            $query,
            $expectedFingerprint,
            $options
        ): bool {
            $this->lockSavedSearch($id);
            if (array_key_exists('set_default', $options)) {
                $this->lockDefaultScope();
            }
            $model = $this->authorizedModel($id, $this->updateRight());
            if ($model === null) {
                throw new \RuntimeException('native_saved_search_update_denied');
            }
            $this->assertFingerprint($model->fields, $expectedFingerprint);
            $isPrivate = array_key_exists('is_private', $options)
                ? !empty($options['is_private'])
                : !empty($model->fields['is_private']);
            $entityId = array_key_exists('entities_id', $options)
                ? max(0, (int) $options['entities_id'])
                : (int) ($model->fields['entities_id'] ?? $this->currentEntityId());
            $recursive = array_key_exists('is_recursive', $options)
                ? !empty($options['is_recursive'])
                : !empty($model->fields['is_recursive']);
            $this->assertVisibilityAndEntity($isPrivate, $entityId, $recursive);

            if (
                !(bool) $model->update([
                'id' => $id,
                'name' => $name,
                'type' => $this->searchType(),
                'itemtype' => 'Ticket',
                'is_private' => $isPrivate ? 1 : 0,
                'entities_id' => $entityId,
                'is_recursive' => $recursive ? 1 : 0,
                'url' => $this->ticketUrlForQuery($query),
                ])
            ) {
                throw new \RuntimeException('native_saved_search_update_failed');
            }
            if ($this->getAuthorized($id) === null) {
                throw new \RuntimeException('native_saved_search_update_readback_failed');
            }
            if (array_key_exists('set_default', $options)) {
                if (!empty($options['set_default'])) {
                    $this->setDefaultInternal($id);
                } elseif ($this->defaultIdUnchecked() === $id) {
                    $this->unsetDefaultInternal($id);
                }
            }
            return true;
        });
    }

    /**
     * Renames a native search without reserializing its GLPI definition.
     *
     * @param array<string,mixed> $options
     */
    public function updateMetadata(
        int $id,
        string $name,
        string $expectedFingerprint = '',
        array $options = []
    ): bool {
        $name = $this->normalizeName($name);

        return $this->transactional(function () use (
            $id,
            $name,
            $expectedFingerprint,
            $options
        ): bool {
            $this->lockSavedSearch($id);
            if (array_key_exists('set_default', $options)) {
                $this->lockDefaultScope();
            }
            $model = $this->authorizedModel($id, $this->updateRight());
            if ($model === null) {
                throw new \RuntimeException('native_saved_search_update_denied');
            }
            $this->assertFingerprint($model->fields, $expectedFingerprint);
            $this->assertVisibilityAndEntity(
                !empty($model->fields['is_private']),
                (int) ($model->fields['entities_id'] ?? $this->currentEntityId()),
                !empty($model->fields['is_recursive'])
            );

            if (!(bool) $model->update(['id' => $id, 'name' => $name])) {
                throw new \RuntimeException('native_saved_search_update_failed');
            }
            if ($this->getAuthorized($id) === null) {
                throw new \RuntimeException('native_saved_search_update_readback_failed');
            }
            if (array_key_exists('set_default', $options)) {
                if (!empty($options['set_default'])) {
                    $this->setDefaultInternal($id);
                } elseif ($this->defaultIdUnchecked() === $id) {
                    $this->unsetDefaultInternal($id);
                }
            }
            return true;
        });
    }
    public function delete(int $id, string $expectedFingerprint = ''): bool
    {
        return $this->transactional(function () use ($id, $expectedFingerprint): bool {
            $this->lockSavedSearch($id);
            $this->lockDefaultScope();
            $model = $this->authorizedModel($id, $this->deleteRight());
            if ($model === null) {
                throw new \RuntimeException('native_saved_search_delete_denied');
            }
            $this->assertFingerprint($model->fields, $expectedFingerprint);
            if (!(bool) $model->delete(['id' => $id], true)) {
                throw new \RuntimeException('native_saved_search_delete_failed');
            }
            if ($this->row($id) !== null) {
                throw new \RuntimeException('native_saved_search_delete_readback_failed');
            }
            return true;
        });
    }

    public function setDefault(int $id, string $expectedFingerprint = ''): bool
    {
        return $this->transactional(function () use ($id, $expectedFingerprint): bool {
            $this->setDefaultInternal($id, $expectedFingerprint);
            return true;
        });
    }

    public function unsetDefault(int $id, string $expectedFingerprint = ''): bool
    {
        return $this->transactional(function () use ($id, $expectedFingerprint): bool {
            $this->unsetDefaultInternal($id, $expectedFingerprint);
            return true;
        });
    }

    /**
     * @param callable():int $mutation
     * @return array{status:string,result_id:int}
     */
    public function mutateIdempotently(
        IdempotencyLedger $ledger,
        string $scope,
        string $idempotencyKey,
        string $requestHash,
        callable $mutation
    ): array {
        return $this->transactional(function () use (
            $ledger,
            $scope,
            $idempotencyKey,
            $requestHash,
            $mutation
        ): array {
            $claim = $ledger->reserve($scope, $idempotencyKey, $requestHash);
            if ($claim->isReplay()) {
                return [
                    'status' => IdempotencyClaim::REPLAY,
                    'result_id' => max(0, (int) $claim->resultId()),
                ];
            }
            if (!$claim->isAcquired()) {
                throw new \RuntimeException(
                    $claim->status() === IdempotencyClaim::CONFLICT
                        ? 'saved_search_idempotency_conflict'
                        : 'saved_search_idempotency_in_progress'
                );
            }

            $resultId = (int) $mutation();
            if ($resultId < 0 || !$ledger->complete($claim, $resultId)) {
                throw new \RuntimeException('saved_search_idempotency_completion_failed');
            }

            return [
                'status' => IdempotencyClaim::ACQUIRED,
                'result_id' => $resultId,
            ];
        });
    }

    /**
     * @return array{capability:string,reasons:array<int,string>,presentation_reasons:array<int,string>,criteria_count:int,criteria:array<int,mixed>,metacriteria:array<int,mixed>,sort:array<int,int>,order:array<int,string>,is_deleted:int,list_limit:int,columns_source:string,forcetoview:array<int,int>,definition:array<string,mixed>}
     */
    public static function analyzeQuery(string $query): array
    {
        $clean = html_entity_decode(ltrim(trim($query), '?'), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $reasons = [];
        $params = [];
        if (strlen($clean) > self::MAX_QUERY_BYTES) {
            $reasons[] = 'native_query_byte_limit_exceeded';
        }
        $variableCount = $clean === '' ? 0 : substr_count($clean, '&') + 1;
        if ($variableCount > self::MAX_QUERY_VARIABLES) {
            $reasons[] = 'native_query_variable_limit_exceeded';
        }
        if ($reasons === []) {
            @parse_str($clean, $params);
            if ($variableCount > self::countLeaves($params)) {
                $reasons[] = 'native_query_truncated';
            }
        }
        if ($clean !== '' && $params === []) {
            $reasons[] = 'native_query_invalid';
        }

        $semanticParameters = [
            'itemtype', 'criteria', 'metacriteria', 'sort', 'order',
            'reset', 'savedsearches_id', 'is_deleted', 'forcetoview',
        ];
        $presentationParameters = [
            'start', 'list_limit', 'display_type', 'showmassiveactions',
            'dont_flush', 'show_pager', 'show_footer', 'no_sort',
            'export_all', 'as_map', 'browse',
        ];
        $editable = true;
        foreach (array_keys($params) as $parameter) {
            $parameter = (string) $parameter;
            if (in_array($parameter, $presentationParameters, true)) {
                $editable = false;
                continue;
            }
            if (!in_array($parameter, $semanticParameters, true)) {
                $reasons[] = 'native_parameter_unsupported';
            }
        }
        if (isset($params['itemtype']) && (string) $params['itemtype'] !== 'Ticket') {
            $reasons[] = 'native_itemtype_unsupported';
        }

        $catalog = new GlpiSearchOptionCatalog();
        $criteriaCount = 0;
        $criteria = self::normalizeCriteria(
            is_array($params['criteria'] ?? null) ? $params['criteria'] : [],
            $reasons,
            $criteriaCount,
            $editable,
            $catalog
        );
        $statusCriterionCodec = new GlpiTicketStatusCriterionCodec();
        $criteria = $statusCriterionCodec->restorePortalSemantics($criteria, 'Ticket');
        if ($criteriaCount > self::MAX_CRITERIA) {
            $reasons[] = 'native_criteria_limit_exceeded';
        }

        $metaCount = 0;
        $metacriteria = self::normalizeMetaCriteria(
            is_array($params['metacriteria'] ?? null) ? $params['metacriteria'] : [],
            $reasons,
            $metaCount,
            $catalog
        );
        $metacriteria = $statusCriterionCodec->restorePortalSemantics(
            $metacriteria,
            'Ticket'
        );
        if ($metaCount > self::MAX_META_CRITERIA) {
            $reasons[] = 'native_meta_criteria_limit_exceeded';
        }

        $sort = [];
        foreach ((array) ($params['sort'] ?? []) as $value) {
            if (!is_numeric($value) || (int) $value <= 0) {
                $reasons[] = 'native_sort_unsupported';
                continue;
            }
            if (!$catalog->supportsField('Ticket', (int) $value)) {
                $reasons[] = 'native_sort_field_unavailable';
                continue;
            }
            $sort[] = (int) $value;
        }
        $order = [];
        foreach ((array) ($params['order'] ?? []) as $value) {
            $direction = strtoupper((string) $value);
            if (!in_array($direction, ['ASC', 'DESC'], true)) {
                $reasons[] = 'native_order_unsupported';
                continue;
            }
            $order[] = $direction;
        }
        if (count($sort) > self::MAX_SORTS || count($order) > self::MAX_SORTS) {
            $reasons[] = 'native_sort_limit_exceeded';
        }
        if (count($sort) !== count($order)) {
            $reasons[] = 'native_sort_order_mismatch';
        }

        $rawIsDeleted = $params['is_deleted'] ?? 0;
        if (
            (!is_int($rawIsDeleted) && !is_string($rawIsDeleted))
            || !in_array((string) $rawIsDeleted, ['0', '1'], true)
        ) {
            $reasons[] = 'native_deleted_scope_unsupported';
            $rawIsDeleted = 0;
        }
        $isDeleted = (int) $rawIsDeleted;

        $presentationReasons = [];
        $listLimit = 0;
        if (array_key_exists('list_limit', $params)) {
            $rawListLimit = $params['list_limit'];
            if (
                (is_int($rawListLimit) || (is_string($rawListLimit) && ctype_digit($rawListLimit)))
                && in_array((int) $rawListLimit, [10, 20, 50, 100], true)
            ) {
                $listLimit = (int) $rawListLimit;
            } else {
                $presentationReasons[] = 'native_page_size_unavailable';
            }
        }

        $columns = [];
        $columnOptionIds = [];
        $columnsSource = 'context_default';
        if (array_key_exists('forcetoview', $params)) {
            $columnsSource = 'saved_search';
            $rawColumns = is_array($params['forcetoview'])
                ? array_values($params['forcetoview'])
                : [$params['forcetoview']];
            if (count($rawColumns) > self::MAX_COLUMNS) {
                $reasons[] = 'native_column_limit_exceeded';
            } else {
                foreach ($rawColumns as $rawColumn) {
                    if (
                        (!is_int($rawColumn) && !(is_string($rawColumn) && ctype_digit($rawColumn)))
                        || (int) $rawColumn <= 0
                    ) {
                        $reasons[] = 'native_column_unsupported';
                        continue;
                    }
                    $columnOptionIds[] = (int) $rawColumn;
                }
                $columnOptionIds = array_values(array_unique($columnOptionIds));
                $projection = $catalog->ticketColumnsFromOptionIds($columnOptionIds);
                $columns = (array) $projection['columns'];
                if (!$projection['complete']) {
                    $editable = false;
                    $presentationReasons[] = 'native_column_unavailable';
                }
            }
        }

        $reasons = array_values(array_unique($reasons));
        $presentationReasons = array_values(array_unique($presentationReasons));
        $definition = [
            'itemtype' => 'Ticket',
            'criteria' => $criteria,
            'metacriteria' => $metacriteria,
            'sort' => $sort,
            'order' => $order,
            'is_deleted' => $isDeleted,
        ];
        if ($columnsSource === 'saved_search') {
            $definition['columns'] = $columns;
        }
        return [
            'capability' => $reasons !== []
                ? 'native_only'
                : ($editable ? 'editable' : 'executable_read_only'),
            'reasons' => $reasons,
            'presentation_reasons' => $presentationReasons,
            'criteria_count' => $criteriaCount,
            'criteria' => $criteria,
            'metacriteria' => $metacriteria,
            'sort' => $sort,
            'order' => $order,
            'is_deleted' => $isDeleted,
            'list_limit' => $listLimit,
            'columns_source' => $columnsSource,
            'forcetoview' => $columnOptionIds,
            'definition' => $definition,
        ];
    }

    /** @return array<int,mixed> */
    private static function normalizeCriteria(
        array $criteria,
        array &$reasons,
        int &$count,
        bool &$editable,
        GlpiSearchOptionCatalog $catalog,
        int $depth = 0
    ): array {
        if ($depth > self::MAX_DEPTH) {
            $reasons[] = 'native_criteria_depth_exceeded';
            return [];
        }
        $normalized = [];
        foreach ($criteria as $criterion) {
            if (!is_array($criterion)) {
                $reasons[] = 'native_criterion_invalid';
                continue;
            }
            $link = strtoupper(trim((string) ($criterion['link'] ?? 'AND')));
            if (!in_array($link, ['AND', 'OR', 'AND NOT', 'OR NOT'], true)) {
                $reasons[] = 'native_link_unsupported';
                continue;
            }
            if (array_key_exists('criteria', $criterion)) {
                if (!is_array($criterion['criteria'])) {
                    $reasons[] = 'native_nested_criteria_invalid';
                    continue;
                }
                $normalized[] = [
                    'link' => $link,
                    'criteria' => self::normalizeCriteria(
                        $criterion['criteria'],
                        $reasons,
                        $count,
                        $editable,
                        $catalog,
                        $depth + 1
                    ),
                ];
                continue;
            }
            $itemtype = !empty($criterion['meta']) || isset($criterion['itemtype'])
                ? (string) ($criterion['itemtype'] ?? '')
                : 'Ticket';
            $leaf = self::normalizeLeaf($criterion, $itemtype, $link, $reasons, $catalog);
            if ($leaf === null) {
                continue;
            }
            if ($itemtype !== 'Ticket') {
                $leaf['meta'] = 1;
                $leaf['itemtype'] = $itemtype;
            }
            $normalized[] = $leaf;
            $count++;
        }
        return $normalized;
    }

    /** @return array<int,mixed> */
    private static function normalizeMetaCriteria(
        array $criteria,
        array &$reasons,
        int &$count,
        GlpiSearchOptionCatalog $catalog
    ): array {
        $normalized = [];
        foreach ($criteria as $criterion) {
            if (!is_array($criterion)) {
                $reasons[] = 'native_meta_criterion_invalid';
                continue;
            }
            $itemtype = (string) ($criterion['itemtype'] ?? '');
            $link = strtoupper(trim((string) ($criterion['link'] ?? 'AND')));
            if ($itemtype === '' || !in_array($link, ['AND', 'OR', 'AND NOT', 'OR NOT'], true)) {
                $reasons[] = 'native_meta_criterion_invalid';
                continue;
            }
            $leaf = self::normalizeLeaf($criterion, $itemtype, $link, $reasons, $catalog);
            if ($leaf === null) {
                continue;
            }
            $leaf['itemtype'] = $itemtype;
            $normalized[] = $leaf;
            $count++;
        }
        return $normalized;
    }

    /** @return array<string,mixed>|null */
    private static function normalizeLeaf(
        array $criterion,
        string $itemtype,
        string $link,
        array &$reasons,
        GlpiSearchOptionCatalog $catalog
    ): ?array {
        if (
            $itemtype === ''
            || ($itemtype !== 'Ticket' && !$catalog->supportsMetaItemtype('Ticket', $itemtype))
        ) {
            $reasons[] = 'native_meta_itemtype_unavailable';
            return null;
        }
        $field = $criterion['field'] ?? null;
        if (!(is_numeric($field) && (int) $field > 0) && !in_array((string) $field, ['view', 'all'], true)) {
            $reasons[] = 'native_field_unsupported';
            return null;
        }
        if (!$catalog->supportsField($itemtype, $field)) {
            $reasons[] = 'native_field_unavailable';
            return null;
        }
        $searchType = strtolower((string) ($criterion['searchtype'] ?? 'contains'));
        if (
            !$catalog->supportsOperator($itemtype, $field, $searchType)
        ) {
            $reasons[] = 'native_searchtype_unsupported';
            return null;
        }
        $value = $criterion['value'] ?? '';
        if (!is_scalar($value) || strlen((string) $value) > self::MAX_VALUE_BYTES) {
            $reasons[] = 'native_value_unsupported';
            return null;
        }
        return [
            'link' => $link,
            'field' => is_numeric($field) ? (int) $field : (string) $field,
            'searchtype' => $searchType,
            'value' => (string) $value,
        ];
    }

    /**
     * Convert portal-only text/scope semantics into native Search criteria
     * before persisting the SavedSearch query.
     *
     * @param array<string,mixed> $definition
     * @return array<string,mixed>
     */
    private function materializeDefinition(array $definition): array
    {
        if (isset($definition['itemtype']) && (string) $definition['itemtype'] !== 'Ticket') {
            throw new \InvalidArgumentException('native_saved_search_definition_unsupported');
        }
        $canonical = [
            'itemtype' => 'Ticket',
            'criteria' => is_array($definition['criteria'] ?? null) ? $definition['criteria'] : [],
            'metacriteria' => is_array($definition['metacriteria'] ?? null)
                ? $definition['metacriteria']
                : [],
            'sort' => array_values((array) ($definition['sort'] ?? [])),
            'order' => array_values((array) ($definition['order'] ?? [])),
            'is_deleted' => (int) ($definition['is_deleted'] ?? 0),
        ];
        if (array_key_exists('columns', $definition)) {
            $columnProjection = (new GlpiSearchOptionCatalog())->ticketColumnOptionIds(
                array_values((array) $definition['columns'])
            );
            if (!$columnProjection['complete']) {
                throw new \InvalidArgumentException('native_saved_search_columns_unavailable');
            }
            if ($columnProjection['option_ids'] !== []) {
                $canonical['forcetoview'] = $columnProjection['option_ids'];
            }
        }

        $text = trim((string) ($definition['text'] ?? ''));
        if ($text !== '') {
            if (ctype_digit($text)) {
                $canonical['criteria'][] = $this->criterion(
                    $this->ticketOptionNumber('id'),
                    'equals',
                    (string) ((int) $text)
                );
            } else {
                $canonical['criteria'][] = [
                    'link' => 'AND',
                    'criteria' => [
                        $this->criterion($this->ticketOptionNumber('name'), 'contains', $text),
                        $this->criterion($this->ticketOptionNumber('content'), 'contains', $text, 'OR'),
                    ],
                ];
            }
        }

        $scope = (string) ($definition['scope'] ?? 'all');
        if ($scope === 'mine') {
            $userId = $this->currentUserId();
            $options = $this->ticketUserOptionNumbersByType();
            if ($userId <= 0 || count($options) !== 3) {
                throw new \RuntimeException('native_saved_search_definition_unsupported');
            }
            $alternatives = [];
            foreach ([1, 2, 3] as $index => $type) {
                $alternatives[] = $this->criterion(
                    $options[$type],
                    'equals',
                    (string) $userId,
                    $index === 0 ? 'AND' : 'OR'
                );
            }
            $canonical['criteria'][] = ['link' => 'AND', 'criteria' => $alternatives];
        } elseif ($scope === 'group') {
            $option = $this->ticketAssignedGroupOptionNumber();
            $groups = $this->currentUserGroupIds();
            if ($option <= 0 || $groups === []) {
                throw new \RuntimeException('native_saved_search_definition_unsupported');
            }
            $alternatives = [];
            foreach ($groups as $index => $groupId) {
                $alternatives[] = $this->criterion(
                    $option,
                    'equals',
                    (string) $groupId,
                    $index === 0 ? 'AND' : 'OR'
                );
            }
            $canonical['criteria'][] = ['link' => 'AND', 'criteria' => $alternatives];
        } elseif ($scope !== 'all') {
            throw new \InvalidArgumentException('native_saved_search_definition_unsupported');
        }

        return $canonical;
    }

    /** @param array<string,mixed> $definition */
    private function serializeDefinition(array $definition): string
    {
        $canonical = $this->materializeDefinition($definition);
        $statusCriterionCodec = new GlpiTicketStatusCriterionCodec();
        $canonical['criteria'] = $statusCriterionCodec->compileForGlpi(
            (array) $canonical['criteria'],
            'Ticket'
        );
        $canonical['metacriteria'] = $statusCriterionCodec->compileForGlpi(
            (array) $canonical['metacriteria'],
            'Ticket'
        );
        $query = http_build_query($canonical, '', '&', PHP_QUERY_RFC3986);
        if (strlen($query) > self::MAX_QUERY_BYTES) {
            throw new \LengthException('native_saved_search_query_too_large');
        }
        $analysis = self::analyzeQuery($query);
        if ((string) $analysis['capability'] === 'native_only') {
            throw new \InvalidArgumentException('native_saved_search_definition_unsupported');
        }
        return $query;
    }

    /** @return array<string,mixed> */
    private function resolvedAnalysisFromModel(object $model): array
    {
        $row = is_array($model->fields ?? null) ? $model->fields : [];
        $rawAnalysis = self::analyzeQuery((string) ($row['query'] ?? ''));
        $resolutionMetadata = ['reasons' => [], 'read_only' => false];
        $resolvedParameters = $this->executionParametersFromModel(
            $model,
            $rawAnalysis,
            $resolutionMetadata
        );
        $analysis = self::analyzeQuery(http_build_query(
            $resolvedParameters,
            '',
            '&',
            PHP_QUERY_RFC3986
        ));
        $analysis['reasons'] = array_values(array_unique(array_merge(
            (array) $analysis['reasons'],
            (array) $resolutionMetadata['reasons']
        )));
        if ($analysis['reasons'] !== []) {
            $analysis['capability'] = 'native_only';
        } elseif (
            !empty($resolutionMetadata['read_only'])
            && (string) $analysis['capability'] === 'editable'
        ) {
            $analysis['capability'] = 'executable_read_only';
        }
        return $analysis;
    }

    /**
     * GLPI 10 prepares saved-search parameters before returning them, while
     * GLPI 11 delegates more of that work to Search. This adapter accepts both
     * behaviours and exposes only parameters that affect result semantics.
     *
     * @param array<string,mixed> $analysis
     * @param array{reasons:array<int,string>,read_only:bool} $metadata
     * @return array<string,mixed>
     */
    private function executionParametersFromModel(
        object $model,
        array $analysis,
        array &$metadata = ['reasons' => [], 'read_only' => false]
    ): array {
        $fallback = [
            'itemtype' => 'Ticket',
            'criteria' => (array) ($analysis['criteria'] ?? []),
            'metacriteria' => (array) ($analysis['metacriteria'] ?? []),
            'sort' => (array) ($analysis['sort'] ?? []),
            'order' => (array) ($analysis['order'] ?? []),
            'is_deleted' => (int) ($analysis['is_deleted'] ?? 0),
        ];
        if ((array) ($analysis['forcetoview'] ?? []) !== []) {
            $fallback['forcetoview'] = (array) $analysis['forcetoview'];
        }
        if ((int) ($analysis['list_limit'] ?? 0) > 0) {
            $fallback['list_limit'] = (int) $analysis['list_limit'];
        }
        if (
            !method_exists($model, 'getParameters')
            && !method_exists($model, 'prepareQueryToUse')
        ) {
            return $fallback;
        }

        try {
            $parameters = $this->nativeParametersFromModel($model);
            if (!is_array($parameters)) {
                return $fallback;
            }

            $metadata = ['reasons' => [], 'read_only' => false];
            $semanticKeys = [
                'itemtype', 'criteria', 'metacriteria', 'sort', 'order',
                'is_deleted', 'forcetoview',
            ];
            $internalKeys = ['reset', 'savedsearches_id'];
            $presentationKeys = [
                'start', 'list_limit', 'display_type', 'showmassiveactions',
                'dont_flush', 'show_pager', 'show_footer', 'no_sort',
                'export_all', 'as_map', 'browse',
            ];
            foreach (array_keys($parameters) as $parameter) {
                $parameter = (string) $parameter;
                if (
                    in_array($parameter, $semanticKeys, true)
                    || in_array($parameter, $internalKeys, true)
                ) {
                    continue;
                }
                if (in_array($parameter, $presentationKeys, true)) {
                    $metadata['read_only'] = true;
                    continue;
                }
                $metadata['reasons'][] = 'native_parameter_unsupported';
            }

            $resolved = [
                'itemtype' => $parameters['itemtype'] ?? 'Ticket',
                'criteria' => is_array($parameters['criteria'] ?? null)
                    ? $parameters['criteria']
                    : $fallback['criteria'],
                'metacriteria' => is_array($parameters['metacriteria'] ?? null)
                    ? $parameters['metacriteria']
                    : $fallback['metacriteria'],
                'sort' => array_values((array) ($parameters['sort'] ?? $fallback['sort'])),
                'order' => array_values((array) ($parameters['order'] ?? $fallback['order'])),
                'is_deleted' => (int) ($parameters['is_deleted'] ?? $fallback['is_deleted']),
            ];
            $forcedColumns = array_key_exists('forcetoview', $parameters)
                ? (is_array($parameters['forcetoview'])
                    ? array_values($parameters['forcetoview'])
                    : [$parameters['forcetoview']])
                : (array) ($fallback['forcetoview'] ?? []);
            $rawListLimit = $parameters['list_limit'] ?? ($fallback['list_limit'] ?? null);
            if (
                (is_int($rawListLimit) || (is_string($rawListLimit) && ctype_digit($rawListLimit)))
                && in_array((int) $rawListLimit, [10, 20, 50, 100], true)
            ) {
                $resolved['list_limit'] = (int) $rawListLimit;
            }
            if ($forcedColumns !== []) {
                $validForcedColumns = [];
                foreach ($forcedColumns as $forcedColumn) {
                    if (
                        (!is_int($forcedColumn)
                            && !(is_string($forcedColumn) && ctype_digit($forcedColumn)))
                        || (int) $forcedColumn <= 0
                    ) {
                        $metadata['reasons'][] = 'native_column_unsupported';
                        continue;
                    }
                    $validForcedColumns[] = (int) $forcedColumn;
                }
                $validForcedColumns = array_values(array_unique($validForcedColumns));
                if (count($validForcedColumns) > self::MAX_COLUMNS) {
                    $metadata['reasons'][] = 'native_column_limit_exceeded';
                } elseif ($validForcedColumns !== []) {
                    $resolved['forcetoview'] = $validForcedColumns;
                }
            }
            $metadata['reasons'] = array_values(array_unique($metadata['reasons']));
            return $resolved;
        } catch (\Throwable $e) {
            return $fallback;
        }
    }

    /** @return null|array<string,mixed> */
    private function nativeParametersFromModel(object $model): ?array
    {
        if (method_exists($model, 'prepareQueryToUse')) {
            $parameters = [];
            parse_str((string) ($model->fields['query'] ?? ''), $parameters);
            $method = new \ReflectionMethod($model, 'prepareQueryToUse');
            $arguments = [
                (int) ($model->fields['type'] ?? self::SEARCH_TYPE),
                $parameters,
                false,
            ];
        } else {
            $method = new \ReflectionMethod($model, 'getParameters');
            $arguments = [(int) ($model->fields['id'] ?? 0)];
        }
        if (!$method->isVariadic()) {
            $arguments = array_slice($arguments, 0, $method->getNumberOfParameters());
        }
        if ($method->getNumberOfRequiredParameters() > count($arguments)) {
            return null;
        }
        $parameters = $method->invokeArgs($method->isStatic() ? null : $model, $arguments);
        return is_array($parameters) ? $parameters : null;
    }

    /** @return array<string,mixed>|null */
    private function row(int $id): ?array
    {
        global $DB;
        if ($id <= 0 || !isset($DB) || !method_exists($DB, 'request')) {
            return null;
        }
        try {
            $row = $DB->request([
                'FROM' => self::TABLE,
                'WHERE' => ['id' => $id, 'itemtype' => 'Ticket', 'type' => self::SEARCH_TYPE],
                'LIMIT' => 1,
            ])->current();
            return is_array($row) ? $row : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** @return array<string,mixed> */
    private function viewFromRow(array $row, int $defaultId, ?array $resolvedAnalysis = null): array
    {
        $id = (int) ($row['id'] ?? 0);
        if ($resolvedAnalysis === null) {
            $model = $this->authorizedModel($id, $this->readRight());
            $resolvedAnalysis = $model !== null
                ? $this->resolvedAnalysisFromModel($model)
                : self::analyzeQuery((string) ($row['query'] ?? ''));
        }
        $analysis = $resolvedAnalysis;
        $canMutate = $this->supportsSafeMutations();
        $canEdit = $canMutate
            && (string) $analysis['capability'] !== 'native_only'
            && $this->authorizedModel($id, $this->updateRight()) !== null;
        $canDelete = $canMutate && $this->authorizedModel($id, $this->deleteRight()) !== null;
        $canSetDefault = $canMutate && $this->authorizedModel($id, $this->readRight()) !== null;
        $isDefault = $id === $defaultId;
        $capabilities = [
            'can_edit' => $canEdit,
            'can_delete' => $canDelete,
            'can_set_default' => $canSetDefault && !$isDefault,
            'can_unset_default' => $canSetDefault && $isDefault,
        ];
        return [
            'key' => 'native:' . $id,
            'id' => $id,
            'origin' => 'glpi',
            'name' => trim((string) ($row['name'] ?? '')) ?: ('Pesquisa GLPI ' . $id),
            'visibility' => !empty($row['is_private']) ? 'private' : 'public',
            'entities_id' => (int) ($row['entities_id'] ?? 0),
            'is_recursive' => !empty($row['is_recursive']),
            'is_default' => $isDefault,
            'capability' => (string) $analysis['capability'],
            'capability_reasons' => (array) $analysis['reasons'],
            'criteria_count' => (int) $analysis['criteria_count'],
            'fingerprint' => self::fingerprint($row),
            'native_url' => $this->nativeSearchUrl($id, (string) ($row['query'] ?? '')),
            'capabilities' => $capabilities,
            'can_edit' => $capabilities['can_edit'],
            'can_delete' => $capabilities['can_delete'],
            'can_set_default' => $capabilities['can_set_default'],
            'can_unset_default' => $capabilities['can_unset_default'],
        ];
    }

    private function authorizedModel(int $id, int $right): ?object
    {
        if ($id <= 0 || !class_exists('\\SavedSearch')) {
            return null;
        }
        try {
            $model = $this->newModel();
            if (!method_exists($model, 'getFromDB') || !$model->getFromDB($id)) {
                return null;
            }
            if (
                (string) ($model->fields['itemtype'] ?? '') !== 'Ticket'
                || (int) ($model->fields['type'] ?? 0) !== $this->searchType()
                || !method_exists($model, 'can')
                || !$model->can($id, $right)
            ) {
                return null;
            }
            return $model;
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function newModel(): object
    {
        if (!class_exists('\\SavedSearch')) {
            throw new \RuntimeException('native_saved_search_model_unavailable');
        }
        return new \SavedSearch();
    }

    private function setDefaultInternal(int $id, string $expectedFingerprint = ''): void
    {
        $this->lockSavedSearch($id);
        $this->lockDefaultScope();
        $model = $this->authorizedModel($id, $this->readRight());
        if (!($model instanceof \SavedSearch) || !method_exists($model, 'markDefault')) {
            throw new \RuntimeException('native_saved_search_default_denied');
        }
        $this->assertFingerprint($model->fields, $expectedFingerprint);
        $model->markDefault($id);
        if ($this->defaultIdUnchecked() !== $id) {
            throw new \RuntimeException('native_saved_search_default_failed');
        }
    }

    private function unsetDefaultInternal(int $id, string $expectedFingerprint = ''): void
    {
        $this->lockSavedSearch($id);
        $this->lockDefaultScope();
        $model = $this->authorizedModel($id, $this->readRight());
        if (!($model instanceof \SavedSearch) || !method_exists($model, 'unmarkDefault')) {
            throw new \RuntimeException('native_saved_search_default_denied');
        }
        $this->assertFingerprint($model->fields, $expectedFingerprint);
        $model->unmarkDefault($id);
        if ($this->defaultIdUnchecked() === $id) {
            throw new \RuntimeException('native_saved_search_default_failed');
        }
    }

    private function defaultIdUnchecked(): int
    {
        global $DB;
        if (!isset($DB) || !method_exists($DB, 'request')) {
            return 0;
        }
        try {
            $row = $DB->request([
                'SELECT' => ['savedsearches_id'],
                'FROM' => self::DEFAULT_TABLE,
                'WHERE' => ['users_id' => $this->currentUserId(), 'itemtype' => 'Ticket'],
                'LIMIT' => 1,
            ])->current();
            return is_array($row) ? (int) ($row['savedsearches_id'] ?? 0) : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /** @param array<string,mixed> $fields */
    private function assertFingerprint(array $fields, string $expected): void
    {
        if ($expected !== '' && !hash_equals(self::fingerprint($fields), $expected)) {
            throw new \RuntimeException('native_saved_search_conflict');
        }
    }

    /** @param array<string,mixed> $fields */
    private static function fingerprint(array $fields): string
    {
        $canonical = [
            'id' => (int) ($fields['id'] ?? 0),
            'name' => (string) ($fields['name'] ?? ''),
            'query' => (string) ($fields['query'] ?? ''),
            'type' => (int) ($fields['type'] ?? 0),
            'is_private' => (int) ($fields['is_private'] ?? 1),
            'entities_id' => (int) ($fields['entities_id'] ?? 0),
            'is_recursive' => (int) ($fields['is_recursive'] ?? 0),
        ];
        return hash(
            'sha256',
            json_encode($canonical, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: ''
        );
    }

    private function assertVisibilityAndEntity(bool $private, int $entityId, bool $recursive): void
    {
        // GLPI 10 does not enforce this transition in prepareInputForUpdate;
        // therefore the adapter checks bookmark_public explicitly on both versions.
        if (
            !$private
            && (
                !class_exists('\\Session')
                || !method_exists('\\Session', 'haveRight')
                || !\Session::haveRight('bookmark_public', $this->updateRight())
            )
        ) {
            throw new \RuntimeException('native_saved_search_publish_denied');
        }
        if (
            class_exists('\\Session')
            && method_exists('\\Session', 'haveAccessToEntity')
            && !\Session::haveAccessToEntity($entityId, $recursive)
        ) {
            throw new \RuntimeException('native_saved_search_entity_denied');
        }
    }

    private function normalizeName(string $name): string
    {
        $name = trim($name);
        if ($name === '') {
            throw new \InvalidArgumentException('saved_search_name_required');
        }
        return mb_substr($name, 0, 255, 'UTF-8');
    }

    /** @return array<string,mixed> */
    private static function option(string $itemtype, int $number): array
    {
        if ($number <= 0 || !class_exists('\\Search') || !method_exists('\\Search', 'getOptions')) {
            return [];
        }
        try {
            $options = \Search::getOptions($itemtype);
            return is_array($options[$number] ?? null) ? $options[$number] : [];
        } catch (\Throwable $e) {
            return [];
        }
    }

    private static function optionsAvailable(string $itemtype): bool
    {
        if (!class_exists('\\Search') || !method_exists('\\Search', 'getOptions')) {
            return false;
        }
        try {
            return \Search::getOptions($itemtype) !== [];
        } catch (\Throwable $e) {
            return false;
        }
    }

    private function ticketOptionNumber(string $field): int
    {
        if (!class_exists('\\Search') || !method_exists('\\Search', 'getOptions')) {
            throw new \RuntimeException('native_saved_search_definition_unsupported');
        }
        $ticketTable = class_exists('\\Ticket') && method_exists('\\Ticket', 'getTable')
            ? (string) \Ticket::getTable()
            : 'glpi_tickets';
        foreach ((array) \Search::getOptions('Ticket') as $number => $option) {
            if (!is_numeric($number) || !is_array($option)) {
                continue;
            }
            if (
                (string) ($option['field'] ?? '') === $field
                && in_array((string) ($option['table'] ?? $ticketTable), ['', $ticketTable], true)
            ) {
                return (int) $number;
            }
        }
        throw new \RuntimeException('native_saved_search_definition_unsupported');
    }

    /** @return array<int,int> */
    private function ticketUserOptionNumbersByType(): array
    {
        $resolved = (new GlpiTicketActorSearchOptionResolver())->resolve();
        return $resolved['supported'] ? $resolved['options'] : [];
    }

    private function ticketAssignedGroupOptionNumber(): int
    {
        foreach ((array) \Search::getOptions('Ticket') as $number => $option) {
            if (!is_numeric($number) || !is_array($option)) {
                continue;
            }
            $serialized = strtolower(
                json_encode($option, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: ''
            );
            $table = (string) ($option['table'] ?? '');
            if (
                str_contains($serialized, 'glpi_groups_tickets')
                && (
                    preg_match('/(?:type|glpi_groups_tickets\.type)[^0-9]{0,40}2/', $serialized) === 1
                    || str_contains($serialized, 'groups_id_assign')
                )
                && in_array($table, ['glpi_groups_tickets', 'glpi_groups'], true)
            ) {
                return (int) $number;
            }
        }
        return 0;
    }

    /** @return int[] */
    private function currentUserGroupIds(): array
    {
        $groups = [];
        foreach ((array) ($_SESSION['glpigroups'] ?? []) as $key => $value) {
            $candidate = is_numeric($value) ? (int) $value : (is_numeric($key) ? (int) $key : 0);
            if ($candidate > 0) {
                $groups[$candidate] = $candidate;
            }
        }
        return array_values($groups);
    }

    /** @return array<string,mixed> */
    private function criterion(int $field, string $searchType, string $value, string $link = 'AND'): array
    {
        if ($field <= 0 || strlen($value) > self::MAX_VALUE_BYTES) {
            throw new \RuntimeException('native_saved_search_definition_unsupported');
        }
        return ['link' => $link, 'field' => $field, 'searchtype' => $searchType, 'value' => $value];
    }

    private function searchType(): int
    {
        return defined('SavedSearch::SEARCH') ? (int) constant('SavedSearch::SEARCH') : self::SEARCH_TYPE;
    }

    private function readRight(): int
    {
        return defined('READ') ? (int) constant('READ') : 1;
    }

    private function updateRight(): int
    {
        return defined('UPDATE') ? (int) constant('UPDATE') : 4;
    }

    private function deleteRight(): int
    {
        if (defined('DELETE')) {
            return (int) constant('DELETE');
        }
        return defined('PURGE') ? (int) constant('PURGE') : 8;
    }

    private function supportsTransactions(): bool
    {
        global $DB;
        return isset($DB)
            && method_exists($DB, 'beginTransaction')
            && method_exists($DB, 'commit')
            && method_exists($DB, 'rollBack');
    }

    private function supportsSafeMutations(): bool
    {
        global $DB;
        return $this->supportsTransactions()
            && isset($DB)
            && GlpiDatabaseQuery::isSupported($DB)
            && method_exists($DB, 'numrows');
    }

    private function lockSavedSearch(int $id): void
    {
        global $DB;
        if ($id < 1 || !$this->supportsSafeMutations()) {
            throw new \RuntimeException('native_saved_search_transaction_lock_required');
        }
        $result = GlpiDatabaseQuery::execute(
            $DB,
            'SELECT `id` FROM `' . self::TABLE . '`'
            . ' WHERE `id` = ' . $id
            . ' AND `itemtype` = \'Ticket\''
            . ' AND `type` = ' . self::SEARCH_TYPE
            . ' FOR UPDATE'
        );
        if ($result === false || (int) $DB->numrows($result) !== 1) {
            throw new \RuntimeException('native_saved_search_lock_failed');
        }
    }

    private function lockDefaultScope(): void
    {
        global $DB;
        $userId = $this->currentUserId();
        if ($userId < 1 || !$this->supportsSafeMutations()) {
            throw new \RuntimeException('native_saved_search_transaction_lock_required');
        }
        $result = GlpiDatabaseQuery::execute(
            $DB,
            'SELECT `id` FROM `glpi_users` WHERE `id` = ' . $userId . ' FOR UPDATE'
        );
        if ($result === false || (int) $DB->numrows($result) !== 1) {
            throw new \RuntimeException('native_saved_search_default_lock_failed');
        }
        $defaultResult = GlpiDatabaseQuery::execute(
            $DB,
            'SELECT `id` FROM `' . self::DEFAULT_TABLE . '`'
            . ' WHERE `users_id` = ' . $userId
            . ' AND `itemtype` = \'Ticket\''
            . ' FOR UPDATE'
        );
        if ($defaultResult === false || (int) $DB->numrows($defaultResult) > 1) {
            throw new \RuntimeException('native_saved_search_default_lock_failed');
        }
    }

    /** @return mixed */
    private function transactional(callable $operation)
    {
        global $DB;
        $outermost = $this->transactionDepth === 0;
        $supported = $this->supportsSafeMutations();

        if ($outermost && !$supported) {
            throw new \RuntimeException('native_saved_search_transaction_lock_required');
        }
        if ($outermost && $DB->beginTransaction() === false) {
            throw new \RuntimeException('native_saved_search_transaction_begin_failed');
        }

        $this->transactionDepth++;
        try {
            $result = $operation();
            $this->transactionDepth--;
            if ($outermost && $DB->commit() === false) {
                throw new \RuntimeException('native_saved_search_transaction_commit_failed');
            }
            return $result;
        } catch (\Throwable $e) {
            $this->transactionDepth = max(0, $this->transactionDepth - 1);
            if ($outermost) {
                try {
                    $DB->rollBack();
                } catch (\Throwable $rollbackError) {
                    // Preserve the original mutation or commit failure.
                }
            }
            throw $e;
        }
    }

    private function ticketUrlForQuery(string $query): string
    {
        global $CFG_GLPI;
        return rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/')
            . '/front/ticket.php?'
            . ltrim($query, '?&');
    }

    private function nativeSearchUrl(int $id, string $query): string
    {
        $query = ltrim(html_entity_decode($query, ENT_QUOTES | ENT_HTML5, 'UTF-8'), '?&');
        return $this->ticketUrlForQuery($query . ($query !== '' ? '&' : '') . 'savedsearches_id=' . $id);
    }

    private function savedSearchNamePattern(string $query): string
    {
        return '%' . addcslashes($query, '\\%_') . '%';
    }

    private function nameMatches(string $name, string $query): bool
    {
        return $query === ''
            || str_contains(mb_strtolower($name, 'UTF-8'), mb_strtolower($query, 'UTF-8'));
    }

    private function encodeCursor(int $lastId, string $query): string
    {
        $payload = [
            'v' => 1,
            'last_id' => $lastId,
            'user' => $this->currentUserId(),
            'profile' => $this->currentProfileId(),
            'entity' => $this->currentEntityId(),
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
            'query' => hash('sha256', $query),
            'exp' => time() + self::CURSOR_TTL,
        ];
        $json = json_encode($payload, JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) {
            throw new \RuntimeException('saved_search_cursor_unavailable');
        }
        $body = self::base64UrlEncode($json);
        return $body . '.' . self::base64UrlEncode(
            hash_hmac('sha256', $body, $this->cursorSecret(), true)
        );
    }

    private function decodeCursor(string $cursor, string $query): int
    {
        $parts = explode('.', $cursor, 2);
        if (count($parts) !== 2) {
            throw new \InvalidArgumentException('saved_search_cursor_invalid');
        }
        [$body, $encodedSignature] = $parts;
        $payload = json_decode(self::base64UrlDecode($body), true);
        $signature = self::base64UrlDecode($encodedSignature);
        $expected = hash_hmac('sha256', $body, $this->cursorSecret(), true);
        if (
            $signature === ''
            || !hash_equals($expected, $signature)
            || !is_array($payload)
            || (int) ($payload['v'] ?? 0) !== 1
            || (int) ($payload['user'] ?? 0) !== $this->currentUserId()
            || (int) ($payload['profile'] ?? 0) !== $this->currentProfileId()
            || (int) ($payload['entity'] ?? -1) !== $this->currentEntityId()
            || (bool) ($payload['recursive'] ?? false) !== !empty($_SESSION['glpiactive_entity_recursive'])
            || (string) ($payload['query'] ?? '') !== hash('sha256', $query)
            || (int) ($payload['exp'] ?? 0) < time()
            || (int) ($payload['last_id'] ?? 0) <= 0
        ) {
            throw new \InvalidArgumentException('saved_search_cursor_invalid');
        }
        return (int) $payload['last_id'];
    }

    private function cursorSecret(): string
    {
        $secret = $_SESSION['glpiacessivel_saved_search_cursor_key'] ?? null;
        if (!is_string($secret) || strlen($secret) < 32) {
            $secret = bin2hex(random_bytes(32));
            $_SESSION['glpiacessivel_saved_search_cursor_key'] = $secret;
        }
        return $secret;
    }

    private static function base64UrlEncode(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    private static function base64UrlDecode(string $value): string
    {
        $padding = strlen($value) % 4;
        if ($padding > 0) {
            $value .= str_repeat('=', 4 - $padding);
        }
        $decoded = base64_decode(strtr($value, '-_', '+/'), true);
        return is_string($decoded) ? $decoded : '';
    }

    /** @param array<string,mixed> $value */
    private static function countLeaves(array $value): int
    {
        $count = 0;
        foreach ($value as $item) {
            $count += is_array($item) ? self::countLeaves($item) : 1;
        }
        return $count;
    }

    private function currentUserId(): int
    {
        return class_exists('\\Session') && method_exists('\\Session', 'getLoginUserID')
            ? (int) \Session::getLoginUserID()
            : (int) ($_SESSION['glpiID'] ?? 0);
    }

    private function currentProfileId(): int
    {
        return (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0);
    }

    private function currentEntityId(): int
    {
        return (int) ($_SESSION['glpiactive_entity'] ?? 0);
    }
}
