<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Repository;

use GlpiPlugin\Glpiacessivel\Domain\Ticket\TicketCreationPolicy;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchDefinitionValidator;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiSearchOptionCatalog;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiTicketActorSearchOptionResolver;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiTicketStatusCriterionCodec;
use GlpiPlugin\Glpiacessivel\Security\SessionContextGuard;
use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;

final class TicketRepository
{
    public function getTicketCreationContext(bool $includeRemoteResources = true): array
    {
        $activeEntity = $this->getConcreteActiveEntityId();
        $defaultRequestSourceId = $this->getDefaultRequestSourceId();

        return [
            'entity_id' => $activeEntity,
            'entity_name' => $this->getEntityName($activeEntity),
            'requester_name' => $this->getCurrentUserName(),
            'opening_date_preview' => date('d/m/Y H:i'),
            'status_preview' => I18n::translate('Novo'),
            'requester_editable' => false,
            'categories' => $includeRemoteResources ? $this->getTicketCategories() : [],
            'locations' => $includeRemoteResources ? $this->getTicketLocations() : [],
            'assignable_users' => $includeRemoteResources ? $this->getAssignableUsers() : [],
            'assignable_groups' => $includeRemoteResources ? $this->getAssignableGroups() : [],
            'observer_groups' => $includeRemoteResources ? $this->getObserverGroups() : [],
            'type_options' => $this->getTicketTypeOptions(),
            'urgency_options' => $this->getUrgencyOptions(),
            'impact_options' => $this->getImpactOptions(),
            'request_source_options' => $this->getRequestSourceOptions(),
            'request_source_supported' => $this->ticketSupportsRequestSource(),
            'default_request_source_id' => $defaultRequestSourceId,
            'default_request_source_label' => $this->resolveRequestSourceLabel($defaultRequestSourceId),
            'external_id_supported' => $this->ticketSupportsExternalId(),
            'group_assignment_supported' => $this->tableExists('glpi_groups'),
            'duration_total_help' => I18n::translate(
                'A duração total passa a ser contabilizada pelo atendimento após a abertura do chamado.'
            ),
            'priority_preview' => $this->computePriorityPreview(3, 3),
            'field_requirements' => $this->getTicketCreationFieldRequirements(),
            'ticket_templates' => $this->getTicketTemplates(),
            'service_catalog' => $this->getServiceCatalogContext(),
            'portal_limitations' => $this->getTicketCreatePortalLimitations(),
        ];
    }

    public function listTickets(array $filters): array
    {
        $page = max(1, (int) ($filters['page'] ?? 1));
        $pageSize = min(100, max(10, (int) ($filters['page_size'] ?? 20)));

        if (!empty($filters['saved_search_invalid'])) {
            return $this->blockedSavedSearchResult($filters, $pageSize, 'saved_search_unavailable');
        }

        $groupScope = $this->currentUserGroupScopeResolution($filters);
        if ($groupScope['state'] === 'empty') {
            return $this->emptyGroupScopeResult($filters, $pageSize, $groupScope['reason']);
        }
        if ($groupScope['state'] === 'unavailable') {
            return $this->blockedSavedSearchResult($filters, $pageSize, $groupScope['reason']);
        }

        $sort = (string) ($filters['sort'] ?? 'date_mod');
        $direction = strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC';

        $searchApiResult = $this->listTicketsFromSearchApi($filters, $page, $pageSize, $sort, $direction);
        if ($searchApiResult !== null) {
            return $searchApiResult;
        }

        return $this->blockedSavedSearchResult(
            $filters,
            $pageSize,
            !empty($filters['native_saved_search_id'])
                ? 'native_saved_search_unavailable'
                : $this->getSearchApiFallbackReason($filters)
        );
    }

    /** @return array<string, mixed> */
    private function emptyGroupScopeResult(array $filters, int $pageSize, string $reason): array
    {
        $diagnostics = $this->ticketListBackendDiagnostics($filters, 'scope_empty', false, 0);
        $diagnostics['backend_reason'] = $reason;

        return [
            'items' => [],
            'total' => 0,
            'total_is_lower_bound' => false,
            'partial_results' => false,
            'page' => 1,
            'page_size' => $pageSize,
            'pages' => 1,
            'backend' => 'scope_empty',
            'backend_reason' => $reason,
            'backend_limit' => 0,
            'backend_limited' => false,
            'fallback_limit_hit' => false,
            'assigned_group_search_option' => 0,
            'backend_diagnostics' => $diagnostics,
        ];
    }

    /** @return array<string, mixed> */
    private function blockedSavedSearchResult(array $filters, int $pageSize, string $reason): array
    {
        $diagnostics = $this->ticketListBackendDiagnostics(
            $filters,
            'native_saved_search_blocked',
            false
        );
        $diagnostics['backend_reason'] = $reason;

        return [
            'items' => [],
            'total' => 0,
            'total_is_lower_bound' => false,
            'partial_results' => false,
            'page' => 1,
            'page_size' => $pageSize,
            'pages' => 1,
            'backend' => 'native_saved_search_blocked',
            'backend_reason' => $reason,
            'backend_limit' => 0,
            'backend_limited' => false,
            'fallback_limit_hit' => false,
            'assigned_group_search_option' => $this->getTicketAssignedGroupSearchOptionNumber(),
            'backend_diagnostics' => $diagnostics,
        ];
    }

    private function listTicketsFromSearchApi(array $filters, int $page, int $pageSize, string $sort, string $direction): ?array
    {
        if (!$this->canUseSearchApiForTicketList($filters)) {
            return null;
        }

        try {
            $itemtype = \Ticket::class;
            $forcedisplay = $this->getTicketSearchForcedDisplay((array) ($filters['columns'] ?? []));
            if ($forcedisplay === []) {
                return null;
            }

            $nativeParameters = is_array($filters['native_parameters'] ?? null)
                ? $filters['native_parameters']
                : [];
            $hasNativeSort = array_key_exists('sort', $nativeParameters)
                || array_key_exists('native_sort', $filters);
            $nativeSort = (array) ($nativeParameters['sort'] ?? $filters['native_sort'] ?? []);
            $sortOptions = [];
            if ($nativeSort !== []) {
                foreach ($nativeSort as $value) {
                    if (!is_numeric($value) || (int) $value <= 0) {
                            return null;
                    }
                    $sortOptions[] = (int) $value;
                }
            } elseif (!$hasNativeSort) {
                $sortOption = $this->getTicketSearchOptionForSort($sort);
                if ($sortOption <= 0) {
                    return null;
                }
                $sortOptions[] = $sortOption;
            }
            $hasNativeCriteria = array_key_exists('criteria', $nativeParameters)
                || array_key_exists('native_criteria', $filters);
            $criteria = array_key_exists('criteria', $nativeParameters)
                ? (is_array($nativeParameters['criteria']) ? $nativeParameters['criteria'] : null)
                : (array_key_exists('native_criteria', $filters)
                ? (is_array($filters['native_criteria']) ? $filters['native_criteria'] : null)
                : $this->buildTicketSearchCriteria($filters));
            if ($criteria === null) {
                return null;
            }
            if ($hasNativeCriteria) {
                $semanticCriteria = $this->buildTicketSearchCriteria($filters);
                if ($semanticCriteria === null) {
                    return null;
                }
                $criteria = array_merge($criteria, $semanticCriteria);
            }
            $metacriteria = array_key_exists('metacriteria', $nativeParameters)
                ? (is_array($nativeParameters['metacriteria']) ? $nativeParameters['metacriteria'] : null)
                : (array_key_exists('native_metacriteria', $filters)
                ? (is_array($filters['native_metacriteria']) ? $filters['native_metacriteria'] : null)
                : []);
            if ($metacriteria === null) {
                return null;
            }

            $statusCriterionCodec = new GlpiTicketStatusCriterionCodec();
            $criteria = $statusCriterionCodec->compileForGlpi($criteria, $itemtype);
            $metacriteria = $statusCriterionCodec->compileForGlpi($metacriteria, $itemtype);

            $nativeOrder = (array) ($nativeParameters['order'] ?? $filters['native_order'] ?? []);
            $orders = [];
            if ($hasNativeSort) {
                if (count($nativeOrder) !== count($sortOptions)) {
                    return null;
                }
                foreach ($nativeOrder as $value) {
                    $normalizedOrder = strtoupper((string) $value);
                    if (!in_array($normalizedOrder, ['ASC', 'DESC'], true)) {
                        return null;
                    }
                    $orders[] = $normalizedOrder;
                }
            } else {
                if ($nativeOrder !== []) {
                    return null;
                }
                $orders[] = strtoupper($direction) === 'ASC' ? 'ASC' : 'DESC';
            }

            $isDeleted = (int) ($nativeParameters['is_deleted'] ?? $filters['native_is_deleted'] ?? 0);
            if (!in_array($isDeleted, [0, 1], true)) {
                return null;
            }
            $params = [
                'is_deleted' => $isDeleted,
                'start' => ($page - 1) * $pageSize,
                'list_limit' => $pageSize,
                'criteria' => $criteria,
                'metacriteria' => $metacriteria,
                'reset' => 'reset',
            ];
            if (!$hasNativeSort || $sortOptions !== []) {
                $params['sort'] = $sortOptions;
                $params['order'] = $orders;
            }

            if (method_exists('\Search', 'manageParams')) {
                $params = \Search::manageParams($itemtype, $params, false, false);
            }

            $searchStartedAt = microtime(true);
            $data = \Search::getDatas($itemtype, $params, $forcedisplay);
            $searchDurationMs = (int) round((microtime(true) - $searchStartedAt) * 1000);
            if (!is_array($data)) {
                return null;
            }

            $rows = $this->extractSearchRows($data);
            $total = $this->extractSearchTotal($data);
            $pages = (int) ceil(max(1, $total) / $pageSize);
            if ($rows === []) {
                $emptyReason = !empty($filters['native_saved_search_id'])
                    ? 'native_saved_search'
                    : 'native_search_api';
                return [
                    'items' => [],
                    'total' => $total,
                    'total_is_lower_bound' => false,
                    'partial_results' => false,
                    'page' => min($page, max(1, $pages)),
                    'page_size' => $pageSize,
                    'pages' => max(1, $pages),
                    'backend' => 'search_api',
                    'backend_reason' => $emptyReason,
                    'backend_limit' => 0,
                    'backend_limited' => false,
                    'fallback_limit_hit' => false,
                    'assigned_group_search_option' => $this->getTicketAssignedGroupSearchOptionNumber(),
                    'backend_diagnostics' => $this->ticketListBackendDiagnostics(
                        $filters,
                        'search_api',
                        false
                    ) + [
                        'stage_durations_ms' => [
                            'native_search' => $searchDurationMs,
                            'batch_hydration' => 0,
                        ],
                    ],
                ];
            }

            $ticketIds = [];
            foreach ($rows as $row) {
                $ticketId = $this->extractTicketIdFromSearchRow($row);
                if ($ticketId <= 0) {
                    return null;
                }

                $ticketIds[] = $ticketId;
            }

            // Search::getDatas() is the authorization boundary and returns only
            // ticket IDs visible in the active GLPI context. Hydrate that bounded
            // page in batches so the amount of SQL does not grow per displayed row.
            $hydrationStartedAt = microtime(true);
            $items = $this->hydrateTicketListRows($ticketIds);
            $hydrationDurationMs = (int) round((microtime(true) - $hydrationStartedAt) * 1000);
            if ($items === null || count($items) !== count($ticketIds)) {
                return null;
            }

            if ($total < count($items)) {
                $total = count($items);
                $pages = (int) ceil(max(1, $total) / $pageSize);
            }

            return [
                'items' => $items,
                'total' => $total,
                'total_is_lower_bound' => false,
                'partial_results' => false,
                'page' => min($page, max(1, $pages)),
                'page_size' => $pageSize,
                'pages' => max(1, $pages),
                'backend' => 'search_api',
                'backend_reason' => 'native_search_api',
                'backend_limit' => 0,
                'backend_limited' => false,
                'fallback_limit_hit' => false,
                'assigned_group_search_option' => $this->getTicketAssignedGroupSearchOptionNumber(),
                'backend_diagnostics' => $this->ticketListBackendDiagnostics(
                    $filters,
                    'search_api',
                    false
                ) + [
                    'stage_durations_ms' => [
                        'native_search' => $searchDurationMs,
                        'batch_hydration' => $hydrationDurationMs,
                    ],
                ],
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function canUseSearchApiForTicketList(array $filters): bool
    {
        if (!class_exists('\Search') || !class_exists('\Ticket') || !method_exists('\Search', 'getDatas')) {
            return false;
        }

        if (!empty($filters['native_saved_search_id']) && !array_key_exists('native_criteria', $filters)) {
            return false;
        }
        if (array_key_exists('native_criteria', $filters) && !is_array($filters['native_criteria'])) {
            return false;
        }

        $scope = (string) ($filters['scope'] ?? 'all');
        $groupId = (int) ($filters['group_id'] ?? 0);
        if ($scope === 'mine') {
            return (int) ($_SESSION['glpiID'] ?? 0) > 0
                && $this->getTicketUserSearchOptionNumbersByType() !== [];
        }

        if ($scope === 'group') {
            $groupScope = $this->currentUserGroupScopeResolution($filters);
            return $groupScope['state'] === 'resolved'
                && $this->getTicketAssignedGroupSearchOptionNumber() > 0;
        }

        if ($scope !== 'all') {
            return false;
        }

        if ($groupId > 0) {
            return $this->getTicketAssignedGroupSearchOptionNumber() > 0;
        }

        return true;
    }

    /**
     * @return array<string, mixed>
     */
    private function ticketListBackendDiagnostics(
        array $filters,
        string $backend,
        bool $fallbackLimitHit,
        ?int $assignedGroupOption = null
    ): array {
        $query = trim((string) ($filters['q'] ?? ''));
        $assignedGroupOption = $assignedGroupOption ?? $this->getTicketAssignedGroupSearchOptionNumber();

        return [
            'backend' => $backend,
            'backend_reason' => $backend === 'search_api' ? 'native_search_api' : $this->getSearchApiFallbackReason($filters),
            'scope' => (string) ($filters['scope'] ?? 'all'),
            'group_id' => max(0, (int) ($filters['group_id'] ?? 0)),
            'status' => (string) ($filters['status'] ?? ''),
            'page' => max(1, (int) ($filters['page'] ?? 1)),
            'page_size' => min(100, max(10, (int) ($filters['page_size'] ?? 20))),
            'sort' => (string) ($filters['sort'] ?? 'date_mod'),
            'direction' => strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC',
            'query_len' => strlen($query),
            'assigned_group_search_option' => $assignedGroupOption,
            'current_user_group_count' => count($this->getCurrentUserGroupIds()),
            'fallback_scan_limit' => 0,
            'fallback_limit_hit' => $fallbackLimitHit,
            'fallback_limit_policy' => 'search_api_only_for_ticket_list',
        ];
    }

    private function getSearchApiFallbackReason(array $filters): string
    {
        if (!class_exists('\Search') || !class_exists('\Ticket') || !method_exists('\Search', 'getDatas')) {
            return 'search_api_unavailable';
        }

        $scope = (string) ($filters['scope'] ?? 'all');
        $groupId = (int) ($filters['group_id'] ?? 0);
        if ($scope === 'mine' && $this->getTicketUserSearchOptionNumbersByType() === []) {
            return 'mine_scope_search_options_unavailable';
        }

        if ($scope === 'group') {
            $groupScope = $this->currentUserGroupScopeResolution($filters);
            if ($groupScope['state'] !== 'resolved') {
                return $groupScope['reason'];
            }
        }

        if (($scope === 'group' || $groupId > 0) && $this->getTicketAssignedGroupSearchOptionNumber() <= 0) {
            return 'assigned_group_search_option_unavailable';
        }

        if ($scope !== 'all' && $scope !== 'group') {
            return 'scope_requires_portal_filter';
        }

        return 'search_api_response_unusable';
    }

    /**
     * @param string[] $selectedColumns
     * @return int[]
     */
    private function getTicketSearchForcedDisplay(array $selectedColumns = []): array
    {
        $fields = ['id', 'name', 'status', 'priority', 'date', 'date_mod', 'content', 'entities_id', 'users_id_recipient'];
        $options = [];
        foreach ($fields as $field) {
            $option = $this->getTicketSearchOptionNumber($field);
            if ($option > 0) {
                $options[$option] = $option;
            }
        }

        $selected = array_fill_keys(array_values(array_filter(array_map(
            static fn($column): string => is_scalar($column) ? trim((string) $column) : '',
            $selectedColumns
        ))), true);
        if ($selected !== []) {
            $catalog = (new GlpiSearchOptionCatalog())->forTickets();
            foreach ((array) ($catalog['columns'] ?? []) as $column) {
                if (!is_array($column) || empty($column['available'])) {
                    continue;
                }
                $identifier = (string) ($column['identifier'] ?? '');
                $option = (int) ($column['option_id'] ?? 0);
                if (isset($selected[$identifier]) && $option > 0) {
                    $options[$option] = $option;
                }
            }
        }

        return array_values($options);
    }

    private function getTicketSearchOptionForSort(string $sort): int
    {
        $allowed = ['id', 'name', 'status', 'priority', 'date', 'date_mod'];
        $field = in_array($sort, $allowed, true) ? $sort : 'date_mod';
        return $this->getTicketSearchOptionNumber($field);
    }

    private function getTicketSearchOptionNumber(string $field): int
    {
        if (method_exists('\Search', 'getOptionNumber')) {
            $option = (int) \Search::getOptionNumber(\Ticket::class, $field);
            if ($option > 0) {
                return $option;
            }
        }

        if (!method_exists('\Search', 'getOptions')) {
            return 0;
        }

        $ticketTable = method_exists('\Ticket', 'getTable') ? (string) \Ticket::getTable() : 'glpi_tickets';
        foreach ((array) \Search::getOptions(\Ticket::class) as $number => $option) {
            if (!is_numeric($number) || !is_array($option)) {
                continue;
            }

            if ((string) ($option['field'] ?? '') !== $field) {
                continue;
            }

            $table = (string) ($option['table'] ?? $ticketTable);
            if ($table === '' || $table === $ticketTable) {
                return (int) $number;
            }
        }

        return 0;
    }

    /**
     * @return array<int, array<string, mixed>>|null
     */
    private function buildTicketSearchCriteria(array $filters): ?array
    {
        $criteria = [];
        $status = (string) ($filters['status'] ?? '');
        if ($status !== '' && ctype_digit($status)) {
            $statusOption = $this->getTicketSearchOptionNumber('status');
            if ($statusOption <= 0) {
                return null;
            }
            $criteria[] = [
                'link' => 'AND',
                'field' => $statusOption,
                'searchtype' => 'equals',
                'value' => (string) ((int) $status),
            ];
        }

        $query = trim((string) ($filters['q'] ?? ''));
        if ($query !== '') {
            if (ctype_digit($query)) {
                $idOption = $this->getTicketSearchOptionNumber('id');
                if ($idOption <= 0) {
                    return null;
                }
                $criteria[] = [
                    'link' => 'AND',
                    'field' => $idOption,
                    'searchtype' => 'equals',
                    'value' => (string) ((int) $query),
                ];
            } else {
                $textCriteria = $this->buildTicketTextSearchCriteria($query);
                if ($textCriteria === null) {
                    return null;
                }
                foreach ($textCriteria as $criterion) {
                    $criteria[] = $criterion;
                }
            }
        }

        $groupCriteria = $this->buildTicketAssignedGroupSearchCriteria($filters);
        if ($groupCriteria === null) {
            return null;
        }

        foreach ($groupCriteria as $criterion) {
            $criteria[] = $criterion;
        }

        return $criteria;
    }

    /**
     * @return array<int, array<string, mixed>>|null
     */
    private function buildTicketAssignedGroupSearchCriteria(array $filters): ?array
    {
        $scope = (string) ($filters['scope'] ?? 'all');
        $groupId = (int) ($filters['group_id'] ?? 0);
        if ($scope !== 'group' && $groupId <= 0) {
            return $scope === 'mine' ? $this->buildTicketMineSearchCriteria() : [];
        }

        $option = $this->getTicketAssignedGroupSearchOptionNumber();
        if ($option <= 0) {
            return null;
        }

        $groups = $groupId > 0 ? [$groupId] : $this->getCurrentUserGroupIds();
        $groups = array_values(array_unique(array_filter(array_map('intval', $groups), static fn(int $id): bool => $id > 0)));
        if ($groups === []) {
            return null;
        }

        $alternatives = [];
        foreach ($groups as $index => $currentGroupId) {
            $alternatives[] = [
                'link' => $index === 0 ? 'AND' : 'OR',
                'field' => $option,
                'searchtype' => 'equals',
                'value' => (string) $currentGroupId,
            ];
        }

        return [[
            'link' => 'AND',
            'criteria' => $alternatives,
        ]];
    }

    /**
     * Require both title and content Search Options to preserve fallback semantics.
     *
     * @return array<int, array<string, mixed>>|null
     */
    private function buildTicketTextSearchCriteria(string $query): ?array
    {
        $nameOption = $this->getTicketSearchOptionNumber('name');
        $contentOption = $this->getTicketSearchOptionNumber('content');
        if ($nameOption <= 0 || $contentOption <= 0) {
            return null;
        }

        return [[
            'link' => 'AND',
            'criteria' => [
                ['link' => 'AND', 'field' => $nameOption, 'searchtype' => 'contains', 'value' => $query],
                ['link' => 'OR', 'field' => $contentOption, 'searchtype' => 'contains', 'value' => $query],
            ],
        ]];
    }

    /**
     * Detect requester, assigned and observer Search Options by their native link type.
     * No hard-coded option numbers are used because GLPI 10 and 11 differ.
     *
     * @return array<int, int> keyed by ITIL user type (1 requester, 2 assigned, 3 observer)
     */
    private function getTicketUserSearchOptionNumbersByType(): array
    {
        $resolved = (new GlpiTicketActorSearchOptionResolver())->resolve();
        return $resolved['supported'] ? $resolved['options'] : [];
    }

    /** @return array<int, array<string, mixed>>|null */
    private function buildTicketMineSearchCriteria(): ?array
    {
        $compiled = (new GlpiTicketActorSearchOptionResolver())->compileMineCriteria(
            (int) ($_SESSION['glpiID'] ?? 0)
        );
        return $compiled['supported'] ? $compiled['criteria'] : null;
    }
    private function getTicketAssignedGroupSearchOptionNumber(): int
    {
        if (!method_exists('\Search', 'getOptions')) {
            return 0;
        }

        foreach ((array) \Search::getOptions(\Ticket::class) as $number => $option) {
            if (!is_numeric($number) || !is_array($option)) {
                continue;
            }

            if ($this->searchOptionLooksLikeAssignedGroup($option)) {
                return (int) $number;
            }
        }

        return 0;
    }

    /** @param array<string, mixed> $option */
    private function searchOptionLooksLikeAssignedGroup(array $option): bool
    {
        $table = (string) ($option['table'] ?? '');
        $field = (string) ($option['field'] ?? '');
        $linkfield = (string) ($option['linkfield'] ?? '');
        $serialized = strtolower(json_encode($option, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '');

        if ($table === 'glpi_groups_tickets' && in_array($field, ['groups_id', 'id'], true)) {
            return $this->serializedSearchOptionContainsAssignedGroupType($serialized);
        }

        if ($table === 'glpi_groups' && ($linkfield === 'groups_id' || str_contains($serialized, 'glpi_groups_tickets'))) {
            return $this->serializedSearchOptionContainsAssignedGroupType($serialized);
        }

        return false;
    }

    private function serializedSearchOptionContainsAssignedGroupType(string $serialized): bool
    {
        if ($serialized === '' || !str_contains($serialized, 'glpi_groups_tickets')) {
            return false;
        }

        return preg_match('/(?:type|\bglpi_groups_tickets\.type\b)[^0-9]{0,40}2/', $serialized) === 1
            || str_contains($serialized, 'groups_id_assign')
            || str_contains($serialized, '_groups_id_assign');
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function extractSearchRows(array $data): array
    {
        $rows = $data['data']['rows'] ?? $data['rows'] ?? [];
        if (!is_array($rows)) {
            return [];
        }

        return array_values(array_filter($rows, 'is_array'));
    }

    private function extractSearchTotal(array $data): int
    {
        foreach (['totalcount', 'count'] as $key) {
            if (isset($data['data'][$key]) && is_numeric($data['data'][$key])) {
                return max(0, (int) $data['data'][$key]);
            }
        }

        if (isset($data['totalcount']) && is_numeric($data['totalcount'])) {
            return max(0, (int) $data['totalcount']);
        }

        return count($this->extractSearchRows($data));
    }

    private function extractTicketIdFromSearchRow(array $row): int
    {
        foreach (['id', 'item_id', 'tickets_id'] as $key) {
            if (isset($row[$key]) && is_numeric($row[$key])) {
                return max(0, (int) $row[$key]);
            }
        }

        foreach (['raw', 'values'] as $containerKey) {
            if (isset($row[$containerKey]) && is_array($row[$containerKey])) {
                $ticketId = $this->extractTicketIdFromSearchValues($row[$containerKey]);
                if ($ticketId > 0) {
                    return $ticketId;
                }
            }
        }

        return 0;
    }

    private function extractTicketIdFromSearchValues(array $values): int
    {
        foreach ($values as $key => $value) {
            $key = (string) $key;
            if (is_numeric($value) && preg_match('/(?:^|_)Ticket_(?:id|2|80)$/i', $key)) {
                return max(0, (int) $value);
            }

            if (is_array($value)) {
                $nested = $this->extractTicketIdFromSearchValues($value);
                if ($nested > 0) {
                    return $nested;
                }
            }
        }

        return 0;
    }

    private function getTicketListRowById(int $ticketId): ?array
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return null;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId)) {
            return null;
        }

        return $this->mapTicketFieldsToListRow($ticket->fields);
    }

    /**
     * Hydrate one already-authorized native Search page with a fixed number of
     * database requests. No identifier outside the Search result is introduced.
     *
     * @param int[] $ticketIds
     * @return array<int, array<string, mixed>>|null
     */
    private function hydrateTicketListRows(array $ticketIds): ?array
    {
        global $DB;

        $ticketIds = array_values(array_map('intval', $ticketIds));
        if ($ticketIds === []) {
            return [];
        }
        if (
            !isset($DB)
            || !method_exists($DB, 'request')
            || !$this->tableExists('glpi_tickets')
            || !$this->tableExists('glpi_tickets_users')
            || !$this->tableExists('glpi_groups_tickets')
        ) {
            return null;
        }

        $uniqueTicketIds = array_values(array_unique(array_filter(
            $ticketIds,
            static fn(int $id): bool => $id > 0
        )));
        if (count($uniqueTicketIds) !== count($ticketIds)) {
            return null;
        }

        try {
            $ticketRows = [];
            foreach (
                $DB->request([
                'SELECT' => $this->getTableColumns('glpi_tickets'),
                'FROM' => 'glpi_tickets',
                'WHERE' => ['id' => $uniqueTicketIds],
                ]) as $row
            ) {
                $row = (array) $row;
                $id = (int) ($row['id'] ?? 0);
                if ($id > 0) {
                    $ticketRows[$id] = $row;
                }
            }

            if (count($ticketRows) !== count($uniqueTicketIds)) {
                return null;
            }

            $usersByTicket = [];
            $userIds = [];
            foreach (
                $DB->request([
                'SELECT' => ['tickets_id', 'users_id', 'type'],
                'FROM' => 'glpi_tickets_users',
                'WHERE' => [
                    'tickets_id' => $uniqueTicketIds,
                    'type' => [1, 2],
                ],
                ]) as $row
            ) {
                $ticketId = (int) ($row['tickets_id'] ?? 0);
                $userId = (int) ($row['users_id'] ?? 0);
                $type = (int) ($row['type'] ?? 0);
                if ($ticketId > 0 && $userId > 0 && in_array($type, [1, 2], true)) {
                    $usersByTicket[$ticketId][$type][$userId] = $userId;
                    $userIds[$userId] = $userId;
                }
            }

            $userLabels = [];
            if ($userIds !== [] && $this->tableExists('glpi_users')) {
                foreach (
                    $DB->request([
                    'SELECT' => ['id', 'name', 'firstname', 'realname'],
                    'FROM' => 'glpi_users',
                    'WHERE' => ['id' => array_values($userIds)],
                    ]) as $row
                ) {
                    $row = (array) $row;
                    $id = (int) ($row['id'] ?? 0);
                    if ($id > 0) {
                        $userLabels[$id] = $this->formatUserName($row, $id);
                    }
                }
            }

            $groupsByTicket = [];
            $groupIds = [];
            foreach (
                $DB->request([
                'SELECT' => ['tickets_id', 'groups_id'],
                'FROM' => 'glpi_groups_tickets',
                'WHERE' => [
                    'tickets_id' => $uniqueTicketIds,
                    'type' => 2,
                ],
                ]) as $row
            ) {
                $ticketId = (int) ($row['tickets_id'] ?? 0);
                $groupId = (int) ($row['groups_id'] ?? 0);
                if ($ticketId > 0 && $groupId > 0) {
                    $groupsByTicket[$ticketId][$groupId] = $groupId;
                    $groupIds[$groupId] = $groupId;
                }
            }

            $groupLabels = $this->batchDropdownLabels('glpi_groups', array_values($groupIds), 'Grupo');
            $entityLabels = $this->batchDropdownLabels(
                'glpi_entities',
                $this->collectForeignIds($ticketRows, 'entities_id'),
                'Entidade'
            );
            $categoryLabels = $this->batchDropdownLabels(
                'glpi_itilcategories',
                $this->collectForeignIds($ticketRows, 'itilcategories_id'),
                'Categoria'
            );
            $locationLabels = $this->batchDropdownLabels(
                'glpi_locations',
                $this->collectForeignIds($ticketRows, 'locations_id'),
                I18n::translate('Localização')
            );
        } catch (\Throwable $e) {
            return null;
        }

        $itemsById = [];
        foreach ($ticketRows as $ticketId => $fields) {
            $requesterNames = $this->labelsForIds(
                array_values((array) ($usersByTicket[$ticketId][1] ?? [])),
                $userLabels,
                I18n::translate('Usuário')
            );
            $assigneeNames = $this->labelsForIds(
                array_values((array) ($usersByTicket[$ticketId][2] ?? [])),
                $userLabels,
                I18n::translate('Usuário')
            );
            $ticketGroupIds = array_values((array) ($groupsByTicket[$ticketId] ?? []));
            usort($ticketGroupIds, static function (int $left, int $right) use ($groupLabels): int {
                return strcasecmp(
                    (string) ($groupLabels[$left] ?? ('Grupo #' . $left)),
                    (string) ($groupLabels[$right] ?? ('Grupo #' . $right))
                );
            });
            $groupNames = $this->labelsForIds($ticketGroupIds, $groupLabels, 'Grupo');

            $itemsById[$ticketId] = $this->mapTicketFieldsToListRowWithRelations(
                $fields,
                $requesterNames,
                $assigneeNames,
                $ticketGroupIds,
                $groupNames,
                $entityLabels,
                $categoryLabels,
                $locationLabels
            );
        }

        $items = [];
        foreach ($ticketIds as $ticketId) {
            if (!isset($itemsById[$ticketId]) || !is_array($itemsById[$ticketId])) {
                return null;
            }
            $items[] = $itemsById[$ticketId];
        }

        return $items;
    }

    /** @param array<int, array<string, mixed>> $rows @return int[] */
    private function collectForeignIds(array $rows, string $field): array
    {
        $ids = [];
        foreach ($rows as $row) {
            $id = (int) ($row[$field] ?? 0);
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }

        return array_values($ids);
    }

    /**
     * @param int[] $ids
     * @return array<int, string>
     */
    private function batchDropdownLabels(string $table, array $ids, string $fallbackPrefix): array
    {
        global $DB;

        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn(int $id): bool => $id > 0)));
        if ($ids === [] || !isset($DB) || !method_exists($DB, 'request') || !$this->tableExists($table)) {
            return [];
        }

        $availableColumns = $this->getTableColumns($table);
        $select = array_values(array_intersect(['id', 'completename', 'name'], $availableColumns));
        if (!in_array('id', $select, true)) {
            return [];
        }

        $labels = [];
        foreach (
            $DB->request([
            'SELECT' => $select,
            'FROM' => $table,
            'WHERE' => ['id' => $ids],
            ]) as $row
        ) {
            $id = (int) ($row['id'] ?? 0);
            if ($id <= 0) {
                continue;
            }
            $label = trim((string) ($row['completename'] ?? $row['name'] ?? ''));
            $labels[$id] = TextNormalizer::fromGlpi($label !== '' ? $label : $fallbackPrefix . ' ' . $id);
        }

        return $labels;
    }

    /** @param int[] $ids @param array<int, string> $labels @return string[] */
    private function labelsForIds(array $ids, array $labels, string $fallbackPrefix): array
    {
        $resolved = [];
        foreach ($ids as $id) {
            $id = (int) $id;
            if ($id > 0) {
                $resolved[] = (string) ($labels[$id] ?? ($fallbackPrefix . ' #' . $id));
            }
        }

        return array_values($resolved);
    }

    /**
     * @param string[] $requesterNames
     * @param string[] $assigneeNames
     * @param int[] $groupIds
     * @param string[] $groupNames
     * @param array<int, string> $entityLabels
     * @param array<int, string> $categoryLabels
     * @param array<int, string> $locationLabels
     * @return array<string, mixed>|null
     */
    private function mapTicketFieldsToListRowWithRelations(
        array $fields,
        array $requesterNames,
        array $assigneeNames,
        array $groupIds,
        array $groupNames,
        array $entityLabels,
        array $categoryLabels,
        array $locationLabels
    ): ?array {
        $ticketId = (int) ($fields['id'] ?? 0);
        if ($ticketId <= 0) {
            return null;
        }

        $entityId = (int) ($fields['entities_id'] ?? 0);
        $categoryId = (int) ($fields['itilcategories_id'] ?? 0);
        $locationId = (int) ($fields['locations_id'] ?? 0);

        return [
            'id' => $ticketId,
            'name' => TextNormalizer::fromGlpi((string) ($fields['name'] ?? '')),
            'content' => TextNormalizer::fromGlpi((string) ($fields['content'] ?? '')),
            'status' => (int) ($fields['status'] ?? 0),
            'priority' => (int) ($fields['priority'] ?? 0),
            'urgency' => (int) ($fields['urgency'] ?? 0),
            'impact' => (int) ($fields['impact'] ?? 0),
            'date' => (string) ($fields['date'] ?? ''),
            'date_mod' => (string) ($fields['date_mod'] ?? ''),
            'entities_id' => $entityId,
            'itilcategories_id' => $categoryId,
            'locations_id' => $locationId,
            'entity_name' => (string) ($entityLabels[$entityId] ?? ('Entidade ' . $entityId)),
            'category_name' => $categoryId > 0
                ? (string) ($categoryLabels[$categoryId] ?? sprintf(I18n::translate('Categoria %d'), $categoryId))
                : I18n::translate('Não informado'),
            'location_name' => $locationId > 0
                ? (string) ($locationLabels[$locationId] ?? sprintf(I18n::translate('Localização %d'), $locationId))
                : I18n::translate('Não informado'),
            'time_to_resolve' => (string) ($fields['time_to_resolve'] ?? ''),
            'users_id_recipient' => (int) ($fields['users_id_recipient'] ?? 0),
            'requester_name' => TextNormalizer::fromGlpi(implode(', ', $requesterNames)),
            'assignee_name' => TextNormalizer::fromGlpi(implode(', ', $assigneeNames)),
            'group_names' => $groupNames,
            'group_ids' => $groupIds,
            'primary_group_name' => $groupNames[0] ?? 'Sem grupo',
            'primary_group_id' => $groupIds[0] ?? 0,
        ];
    }

    /** @return array<int, array{id:int,label:string}> */
    public function getTicketGroupFilterOptions(): array
    {
        $map = [];
        foreach ($this->getCurrentUserGroupIds() as $groupId) {
            $label = $this->resolveGroupName((int) $groupId);
            if ($label !== '') {
                $map[(int) $groupId] = $label;
            }
        }

        asort($map, SORT_NATURAL | SORT_FLAG_CASE);
        $options = [];
        foreach ($map as $id => $label) {
            $options[] = ['id' => (int) $id, 'label' => TextNormalizer::fromGlpi((string) $label)];
        }

        return $options;
    }

    public function getTicketById(int $ticketId): ?array
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return null;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId)) {
            return null;
        }

        $row = $ticket->fields;
        $requesterIds = $this->getTicketUserIdsByType($ticketId, 1);
        $requesterId = (int) ($requesterIds[0] ?? 0);
        $requester = $this->getUserContact($requesterId);

        $row['requester_id'] = $requesterId;
        $row['requester_firstname'] = $requester['firstname'] ?? '';
        $row['requester_realname'] = $requester['realname'] ?? '';
        $row['requester_email'] = '';
        $row['requester_phone'] = '';
        $row['requester_mobile'] = '';
        $row['requester_decision'] = $this->getTicketSatisfaction((int) $ticketId);
        $row['satisfaction_state'] = $this->getTicketSatisfactionState((int) $ticketId);
        $row['entity_name'] = $this->getEntityName((int) ($row['entities_id'] ?? 0));
        $row['category_name'] = $this->resolveTicketCategoryName((int) ($row['itilcategories_id'] ?? 0));
        $row['location_name'] = $this->resolveTicketLocationName((int) ($row['locations_id'] ?? 0));

        return $row;
    }

    /**
     * Return requester contact only after the caller has already established
     * ticket access. The application service masks these values by default and
     * reveals them only through the audited PII flow.
     *
     * @return array{firstname:string,realname:string,email:string,phone:string,mobile:string}
     */
    public function getTicketRequesterContact(int $ticketId): array
    {
        $empty = ['firstname' => '', 'realname' => '', 'email' => '', 'phone' => '', 'mobile' => ''];
        if (!$this->canReadTicket($ticketId)) {
            return $empty;
        }

        $requesterIds = $this->getTicketUserIdsByType($ticketId, 1);
        $requesterId = (int) ($requesterIds[0] ?? 0);
        if ($requesterId <= 0) {
            return $empty;
        }

        return $this->getUserContact($requesterId);
    }

    private function nativeTicketOrder(string $sort, string $direction): string
    {
        $direction = strtoupper($direction) === 'ASC' ? 'ASC' : 'DESC';
        $allowed = ['id', 'name', 'status', 'priority', 'date', 'date_mod'];
        $field = in_array($sort, $allowed, true) ? $sort : 'date_mod';
        return $field . ' ' . $direction;
    }

    private function ticketMatchesPortalFilters(array $fields, array $filters): bool
    {
        $ticketId = (int) ($fields['id'] ?? 0);
        if ($ticketId <= 0 || !$this->canReadTicket($ticketId)) {
            return false;
        }

        if (isset($fields['entities_id']) && !in_array((int) $fields['entities_id'], $this->getCurrentEntities(), true)) {
            return false;
        }

        $status = (string) ($filters['status'] ?? '');
        if ($status !== '' && ctype_digit($status) && (int) ($fields['status'] ?? 0) !== (int) $status) {
            return false;
        }

        $scope = (string) ($filters['scope'] ?? 'all');
        if ($scope === 'mine' && !$this->isCurrentUserTicketParticipant($ticketId)) {
            return false;
        }
        if ($scope === 'group' && !$this->isCurrentUserGroupTicket($ticketId)) {
            return false;
        }

        $groupId = (int) ($filters['group_id'] ?? 0);
        if ($groupId > 0 && !in_array($groupId, $this->getTicketGroupIdsByType($ticketId, 2), true)) {
            return false;
        }

        $search = trim((string) ($filters['q'] ?? ''));
        if ($search !== '') {
            $haystack = $this->normalizeSearchText(
                (string) ($fields['id'] ?? '') . ' ' .
                (string) ($fields['name'] ?? '') . ' ' .
                (string) ($fields['content'] ?? '')
            );
            if (!str_contains($haystack, $this->normalizeSearchText($search))) {
                return false;
            }
        }

        return true;
    }

    private function mapTicketFieldsToListRow(array $fields): ?array
    {
        $ticketId = (int) ($fields['id'] ?? 0);
        if ($ticketId <= 0) {
            return null;
        }

        $requesterNames = $this->getTicketUserNamesByType($ticketId, 1);
        $assigneeNames = $this->getTicketUserNamesByType($ticketId, 2);
        $groups = $this->getTicketAssignedGroups($ticketId);

        $groupNames = array_values(array_map(
            static fn(array $group): string => (string) ($group['name'] ?? ''),
            $groups
        ));
        $groupIds = array_values(array_map(
            static fn(array $group): int => (int) ($group['id'] ?? 0),
            $groups
        ));

        return [
            'id' => $ticketId,
            'name' => TextNormalizer::fromGlpi((string) ($fields['name'] ?? '')),
            'content' => TextNormalizer::fromGlpi((string) ($fields['content'] ?? '')),
            'status' => (int) ($fields['status'] ?? 0),
            'priority' => (int) ($fields['priority'] ?? 0),
            'urgency' => (int) ($fields['urgency'] ?? 0),
            'impact' => (int) ($fields['impact'] ?? 0),
            'date' => (string) ($fields['date'] ?? ''),
            'date_mod' => (string) ($fields['date_mod'] ?? ''),
            'entities_id' => (int) ($fields['entities_id'] ?? 0),
            'itilcategories_id' => (int) ($fields['itilcategories_id'] ?? 0),
            'locations_id' => (int) ($fields['locations_id'] ?? 0),
            'entity_name' => TextNormalizer::fromGlpi($this->getEntityName((int) ($fields['entities_id'] ?? 0))),
            'category_name' => TextNormalizer::fromGlpi($this->resolveTicketCategoryName((int) ($fields['itilcategories_id'] ?? 0))),
            'location_name' => TextNormalizer::fromGlpi($this->resolveTicketLocationName((int) ($fields['locations_id'] ?? 0))),
            'time_to_resolve' => (string) ($fields['time_to_resolve'] ?? ''),
            'users_id_recipient' => (int) ($fields['users_id_recipient'] ?? 0),
            'requester_name' => TextNormalizer::fromGlpi(implode(', ', $requesterNames)),
            'assignee_name' => TextNormalizer::fromGlpi(implode(', ', $assigneeNames)),
            'group_names' => $groupNames,
            'group_ids' => $groupIds,
            'primary_group_name' => $groupNames[0] ?? 'Sem grupo',
            'primary_group_id' => $groupIds[0] ?? 0,
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     */
    private function sortTicketRows(array &$rows, string $sort, string $direction): void
    {
        $allowed = ['id', 'name', 'status', 'priority', 'date', 'date_mod'];
        $field = in_array($sort, $allowed, true) ? $sort : 'date_mod';
        $multiplier = strtoupper($direction) === 'ASC' ? 1 : -1;

        usort($rows, static function (array $left, array $right) use ($field, $multiplier): int {
            $leftValue = $left[$field] ?? '';
            $rightValue = $right[$field] ?? '';
            if (is_numeric($leftValue) && is_numeric($rightValue)) {
                return ((int) $leftValue <=> (int) $rightValue) * $multiplier;
            }

            return strcmp((string) $leftValue, (string) $rightValue) * $multiplier;
        });
    }

    private function isCurrentUserTicketParticipant(int $ticketId): bool
    {
        $userId = (int) ($_SESSION['glpiID'] ?? 0);
        if ($userId <= 0) {
            return false;
        }

        foreach ([1, 2, 3] as $type) {
            if (in_array($userId, $this->getTicketUserIdsByType($ticketId, $type), true)) {
                return true;
            }
        }

        return false;
    }

    private function isCurrentUserGroupTicket(int $ticketId): bool
    {
        $currentGroups = $this->getCurrentUserGroupIds();
        if ($currentGroups === []) {
            return false;
        }

        // Search API uses the native assigned-group relation (type=2).
        // Keep the compatibility backend semantically identical.
        if (array_intersect($currentGroups, $this->getTicketGroupIdsByType($ticketId, 2)) !== []) {
            return true;
        }

        return false;
    }

    /**
     * @return int[]
     */
    private function getTicketUserIdsByType(int $ticketId, int $type): array
    {
        if (!class_exists('\Ticket_User')) {
            return [];
        }

        $ticketUser = new \Ticket_User();
        $ids = [];
        foreach ($ticketUser->find(['tickets_id' => max(1, $ticketId), 'type' => $type]) as $row) {
            $id = (int) ($row['users_id'] ?? 0);
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }

        return array_values($ids);
    }

    /**
     * @return string[]
     */
    private function getTicketUserNamesByType(int $ticketId, int $type): array
    {
        $names = [];
        foreach ($this->getTicketUserIdsByType($ticketId, $type) as $userId) {
            $names[] = $this->resolveUserName($userId);
        }

        return $names;
    }

    /**
     * @return int[]
     */
    private function getTicketGroupIdsByType(int $ticketId, int $type): array
    {
        if (!class_exists('\Group_Ticket')) {
            return [];
        }

        $groupTicket = new \Group_Ticket();
        $ids = [];
        foreach ($groupTicket->find(['tickets_id' => max(1, $ticketId), 'type' => $type]) as $row) {
            $id = (int) ($row['groups_id'] ?? 0);
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }

        return array_values($ids);
    }

    /**
     * @return int[]
     */
    public function getCurrentUserGroupIds(): array
    {
        return $this->currentUserGroupContext()['ids'];
    }

    /**
     * GLPI 10 and 11 populate glpigroups for the active entity context. An
     * explicitly empty array is authoritative; a missing or malformed value
     * must remain unavailable so it is never mistaken for an exact zero.
     *
     * @return array{state:'resolved'|'unavailable',ids:int[]}
     */
    private function currentUserGroupContext(): array
    {
        $loadConfirmed = $_SESSION[SessionContextGuard::GROUP_CONTEXT_LOAD_CONFIRMED_SESSION_KEY] ?? null;
        if ($loadConfirmed === false) {
            return ['state' => 'unavailable', 'ids' => []];
        }
        if (!array_key_exists('glpigroups', $_SESSION) || !is_array($_SESSION['glpigroups'])) {
            return ['state' => 'unavailable', 'ids' => []];
        }

        $ids = [];
        foreach ($_SESSION['glpigroups'] as $key => $value) {
            $candidate = 0;
            if (is_numeric($value)) {
                $candidate = (int) $value;
            } elseif (is_array($value) && is_numeric($value['id'] ?? null)) {
                $candidate = (int) $value['id'];
            } elseif (is_numeric($key)) {
                $candidate = (int) $key;
            }

            if ($candidate <= 0) {
                return ['state' => 'unavailable', 'ids' => []];
            }
            $ids[$candidate] = $candidate;
        }

        $ids = array_values($ids);
        sort($ids, SORT_NUMERIC);
        return ['state' => 'resolved', 'ids' => $ids];
    }

    /** @return array{state:'not_applicable'|'resolved'|'empty'|'unavailable',reason:string} */
    private function currentUserGroupScopeResolution(array $filters): array
    {
        if ((string) ($filters['scope'] ?? 'all') !== 'group') {
            return ['state' => 'not_applicable', 'reason' => ''];
        }

        $context = $this->currentUserGroupContext();
        if ($context['state'] !== 'resolved') {
            return ['state' => 'unavailable', 'reason' => 'group_scope_context_unavailable'];
        }

        $groupId = max(0, (int) ($filters['group_id'] ?? 0));
        if ($groupId > 0 && !in_array($groupId, $context['ids'], true)) {
            return ['state' => 'empty', 'reason' => 'group_scope_group_not_in_current_groups'];
        }
        if ($groupId <= 0 && $context['ids'] === []) {
            return ['state' => 'empty', 'reason' => 'group_scope_without_current_groups'];
        }

        return ['state' => 'resolved', 'reason' => ''];
    }

    private function resolveUserName(int $userId): string
    {
        if ($userId <= 0 || !class_exists('\User')) {
            return $userId > 0 ? sprintf(I18n::translate('Usuário #%d'), $userId) : '';
        }

        $user = new \User();
        if (!$user->getFromDB($userId)) {
            return sprintf(I18n::translate('Usuário #%d'), $userId);
        }

        return $this->formatUserName($user->fields, $userId);
    }

    private function formatUserName(array $fields, int $fallbackId): string
    {
        $name = trim((string) (($fields['firstname'] ?? '') . ' ' . ($fields['realname'] ?? '')));
        if ($name !== '') {
            return $name;
        }

        $login = trim((string) ($fields['name'] ?? ''));
        return $login !== '' ? $login : sprintf(I18n::translate('Usuário #%d'), $fallbackId);
    }

    private function resolveGroupName(int $groupId): string
    {
        if ($groupId <= 0 || !class_exists('\Group')) {
            return $groupId > 0 ? 'Grupo ' . $groupId : '';
        }

        $group = new \Group();
        if (!$group->getFromDB($groupId)) {
            return 'Grupo ' . $groupId;
        }

        return TextNormalizer::fromGlpi((string) ($group->fields['completename'] ?? $group->fields['name'] ?? ('Grupo ' . $groupId)));
    }

    /**
     * @return array{firstname:string,realname:string,email:string,phone:string,mobile:string}
     */
    private function getUserContact(int $userId): array
    {
        $contact = [
            'firstname' => '',
            'realname' => '',
            'email' => '',
            'phone' => '',
            'mobile' => '',
        ];

        if ($userId <= 0 || !class_exists('\User')) {
            return $contact;
        }

        $user = new \User();
        if (!$user->getFromDB($userId)) {
            return $contact;
        }

        $contact['firstname'] = (string) ($user->fields['firstname'] ?? '');
        $contact['realname'] = (string) ($user->fields['realname'] ?? '');
        $contact['phone'] = (string) ($user->fields['phone'] ?? '');
        $contact['mobile'] = (string) ($user->fields['mobile'] ?? '');
        $contact['email'] = (string) ($user->fields['email'] ?? '');

        if (class_exists('\UserEmail')) {
            $email = new \UserEmail();
            $rows = $email->find(['users_id' => $userId, 'is_default' => 1]);
            if ($rows === []) {
                $rows = $email->find(['users_id' => $userId]);
            }
            $first = is_array($rows) ? reset($rows) : false;
            if (is_array($first) && trim((string) ($first['email'] ?? '')) !== '') {
                $contact['email'] = (string) $first['email'];
            }
        }

        return $contact;
    }

    private function getTicketSatisfaction(int $ticketId): int
    {
        if (!class_exists('\TicketSatisfaction')) {
            return 0;
        }

        $satisfaction = new \TicketSatisfaction();
        $rows = $satisfaction->find(['tickets_id' => max(1, $ticketId)]);
        $first = is_array($rows) ? reset($rows) : false;
        return is_array($first) ? (int) ($first['satisfaction'] ?? 0) : 0;
    }

    public function getTicketSatisfactionState(int $ticketId): array
    {
        $ticketId = max(1, $ticketId);
        $state = [
            'exists' => false,
            'available' => false,
            'can_answer' => false,
            'is_closed' => false,
            'id' => 0,
            'score' => null,
            'comment' => '',
            'date_answered' => '',
        ];

        if (!class_exists('\Ticket') || !class_exists('\TicketSatisfaction') || !$this->canReadTicket($ticketId)) {
            return $state;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId)) {
            return $state;
        }

        $status = (int) ($ticket->fields['status'] ?? 0);
        $closedStatuses = method_exists(\Ticket::class, 'getClosedStatusArray') ? \Ticket::getClosedStatusArray() : [6];
        $state['is_closed'] = in_array($status, array_map('intval', (array) $closedStatuses), true);

        $satisfaction = new \TicketSatisfaction();
        $rows = $satisfaction->find(['tickets_id' => $ticketId]);
        $first = is_array($rows) ? reset($rows) : false;
        if (!is_array($first) || empty($first['id'])) {
            return $state;
        }

        $state['exists'] = true;
        $state['id'] = (int) $first['id'];
        $state['score'] = isset($first['satisfaction']) ? (int) $first['satisfaction'] : null;
        $state['comment'] = (string) ($first['comment'] ?? '');
        $state['date_answered'] = (string) ($first['date_answered'] ?? '');
        $state['available'] = (bool) $state['is_closed'];

        $current = new \TicketSatisfaction();
        if ($state['available'] && $current->getFromDB((int) $state['id'])) {
            $state['can_answer'] = method_exists($current, 'canUpdateItem')
                ? (bool) $current->canUpdateItem()
                : $this->canReadTicket($ticketId);
        }

        return $state;
    }

    public function getTicketActors(int $ticketId): array
    {
        if (!$this->canReadTicket($ticketId)) {
            return [];
        }

        $actors = [
            'requesters' => [],
            'assignees' => [],
            'watchers' => [],
        ];

        $ticketUser = new \Ticket_User();
        foreach ($ticketUser->find(['tickets_id' => max(1, $ticketId)]) as $row) {
            $type = (int) ($row['type'] ?? 0);
            $userId = (int) ($row['users_id'] ?? 0);
            if ($userId <= 0) {
                continue;
            }

            $item = [
                'id' => $userId,
                'name' => $this->resolveUserName($userId),
            ];

            if ($type === 1) {
                $actors['requesters'][] = $item;
            } elseif ($type === 2) {
                $actors['assignees'][] = $item;
            } elseif ($type === 3) {
                $actors['watchers'][] = $item;
            }
        }

        if (class_exists('\Group_Ticket')) {
            $groupTicket = new \Group_Ticket();
            foreach ($groupTicket->find(['tickets_id' => max(1, $ticketId)]) as $row) {
                $type = (int) ($row['type'] ?? 0);
                $groupId = (int) ($row['groups_id'] ?? 0);
                if ($groupId <= 0) {
                    continue;
                }
                $item = [
                    'id' => $groupId,
                    'name' => $this->resolveGroupName($groupId),
                ];

                if ($type === 1) {
                    $actors['requesters'][] = $item;
                } elseif ($type === 2) {
                    $actors['assignees'][] = $item;
                } elseif ($type === 3) {
                    $actors['watchers'][] = $item;
                }
            }
        }

        return $actors;
    }

    public function getTicketActionContext(int $ticketId): array
    {
        $canRead = $ticketId > 0 && $this->canReadTicket($ticketId);
        $canUpdate = $canRead && $this->canUpdateTicket($ticketId);
        $canAddFollowup = $canRead && $this->canAddFollowupToTicket($ticketId);
        $canAddTask = $canRead && $this->canAddTaskToTicket($ticketId);
        $canAddPrivateFollowup = $canAddFollowup && $this->canAddPrivateFollowup();
        $canAddPrivateTask = $canAddTask && $this->canAddPrivateTask();
        $canAddSolution = $canRead && $this->canAddSolutionToTicket($ticketId);
        $canChangeStatus = $canRead && $this->canChangeStatusToTicket($ticketId);
        $canRoute = $canRead && $this->canRouteTicket($ticketId);

        return [
            'can_read' => $canRead,
            'can_update' => $canUpdate,
            'can_add_followup' => $canAddFollowup,
            'can_add_task' => $canAddTask,
            'can_add_private_followup' => $canAddPrivateFollowup,
            'can_add_private_task' => $canAddPrivateTask,
            'can_add_solution' => $canAddSolution,
            'can_change_status' => $canChangeStatus,
            'can_route' => $canRoute,
            'default_followup_is_private' => $canAddPrivateFollowup && $this->defaultTimelineItemPrivacy(
                \ITILFollowup::class,
                'glpifollowup_private'
            ),
            'default_task_is_private' => $canAddPrivateTask && $this->defaultTimelineItemPrivacy(
                \TicketTask::class,
                'glpitask_private'
            ),
        ];
    }

    public function getTicketRoutingContext(int $ticketId, bool $includeRemoteResources = true): array
    {
        $actions = $this->getTicketActionContext($ticketId);
        $canUpdate = !empty($actions['can_update']);
        $canAddTask = !empty($actions['can_add_task']);
        $canRoute = !empty($actions['can_route']);
        $needsAssignmentOptions = $canAddTask || $canRoute;
        $context = $needsAssignmentOptions
            ? $this->getTicketCreationContext($includeRemoteResources)
            : [];
        $ticket = !empty($actions['can_read'])
            ? $this->getTicketById($ticketId)
            : null;
        $ticketEntityId = is_array($ticket) && array_key_exists('entities_id', $ticket)
            ? (int) $ticket['entities_id']
            : null;

        return [
            'can_update' => $canUpdate,
            'can_add_task' => $canAddTask,
            'can_route' => $canRoute,
            'assignable_users' => $needsAssignmentOptions ? ($context['assignable_users'] ?? []) : [],
            'assignable_groups' => $includeRemoteResources && $needsAssignmentOptions && $ticketEntityId !== null
                ? $this->getAssignableGroups($ticketEntityId)
                : [],
            'observer_groups' => $includeRemoteResources && $canRoute && $ticketEntityId !== null
                ? $this->getObserverGroups($ticketEntityId)
                : [],
            'task_categories' => $canAddTask ? $this->getTaskCategories() : [],
            'task_state_options' => $canAddTask ? $this->getTaskStateOptions() : [],
            'task_duration_options' => $canAddTask ? $this->getTaskDurationOptions() : [],
            'assigned_user_ids' => $this->getTicketUserIdsByType($ticketId, 2),
            'observer_user_ids' => $this->getTicketUserIdsByType($ticketId, 3),
            'assigned_group_ids' => $this->getTicketGroupIdsByType($ticketId, 2),
            'observer_group_ids' => $this->getTicketGroupIdsByType($ticketId, 3),
        ];
    }

    /**
     * @param string[] $expectedFilenames
     * @return array<string, mixed>
     */
    public function ticketDocumentLinkDiagnostics(
        int $ticketId,
        int $expectedLinks = 1,
        array $expectedFilenames = []
    ): array {
        return $this->documentItemLinkDiagnostics('Ticket', $ticketId, $expectedLinks, $expectedFilenames);
    }

    /**
     * @param string[] $expectedFilenames
     * @return array<string, mixed>
     */
    public function documentItemLinkDiagnostics(
        string $itemtype,
        int $itemId,
        int $expectedLinks = 1,
        array $expectedFilenames = []
    ): array {
        $expectedLinks = max(0, $expectedLinks);
        $itemtype = trim($itemtype);
        if ($itemId <= 0 || $itemtype === '' || $expectedLinks <= 0) {
            return [
                'available' => true,
                'expected' => $expectedLinks,
                'linked' => 0,
                'matched' => 0,
                'document_ids' => [],
                'filenames' => [],
                'complete' => true,
                'reason' => 'not_required',
            ];
        }
        if (!class_exists('\Document_Item') || !class_exists('\Document')) {
            return [
                'available' => false,
                'expected' => $expectedLinks,
                'linked' => 0,
                'matched' => 0,
                'document_ids' => [],
                'filenames' => [],
                'complete' => false,
                'reason' => 'document_item_api_unavailable',
            ];
        }

        $document = new \Document();
        $documentIds = [];
        $filenames = [];
        $link = new \Document_Item();
        foreach ((array) $link->find(['itemtype' => $itemtype, 'items_id' => $itemId]) as $row) {
            $documentId = (int) (((array) $row)['documents_id'] ?? 0);
            if ($documentId <= 0 || in_array($documentId, $documentIds, true)) {
                continue;
            }
            if (!$document->getFromDB($documentId)) {
                continue;
            }
            $documentIds[] = $documentId;
            $filenames[] = basename((string) ($document->fields['filename'] ?? $document->fields['name'] ?? ''));
        }

        $expectedFilenames = array_values(array_unique(array_filter(array_map(
            static fn(string $filename): string => basename(trim($filename)),
            array_map('strval', $expectedFilenames)
        ))));
        $normalizedLinked = array_map(
            static fn(string $filename): string => mb_strtolower($filename, 'UTF-8'),
            $filenames
        );
        $matched = 0;
        foreach ($expectedFilenames as $expectedFilename) {
            if (in_array(mb_strtolower($expectedFilename, 'UTF-8'), $normalizedLinked, true)) {
                $matched++;
            }
        }
        $complete = $expectedFilenames !== []
            ? $matched >= min($expectedLinks, count($expectedFilenames))
            : count($documentIds) >= $expectedLinks;

        return [
            'available' => true,
            'expected' => $expectedLinks,
            'linked' => count($documentIds),
            'matched' => $matched,
            'document_ids' => $documentIds,
            'filenames' => $filenames,
            'complete' => $complete,
            'reason' => $complete ? 'confirmed' : 'document_item_link_missing',
        ];
    }
    public function ticketHasDocumentLinks(int $ticketId, int $minimumLinks = 1): bool
    {
        $diagnostics = $this->ticketDocumentLinkDiagnostics($ticketId, $minimumLinks);
        return $diagnostics['available'] && $diagnostics['complete'];
    }

    public function getTicketDocuments(int $ticketId): array
    {
        return $this->getReadableDocumentsForParent($ticketId, 'Ticket', $ticketId);
    }

    public function applyRequesterDecision(int $ticketId, int $decision, string $comment): bool
    {
        if (!$this->canReadTicket($ticketId)) {
            return false;
        }

        $decision = max(1, min(5, $decision));
        $comment = trim($comment);
        $userId = (int) ($_SESSION['glpiID'] ?? 0);

        $satisfaction = new \TicketSatisfaction();
        $existing = $satisfaction->find([
            'tickets_id' => max(1, $ticketId),
        ]);

        if (!$existing) {
            throw new \RuntimeException(I18n::translate('Não há pesquisa de satisfação gerada para este chamado.'));
        }

        $input = [
            'tickets_id' => max(1, $ticketId),
            'users_id' => $userId,
            'satisfaction' => $decision,
            'comment' => $comment,
            'date_answered' => date('Y-m-d H:i:s'),
        ];

        if ($existing) {
            $first = array_shift($existing);
            if (is_array($first) && isset($first['id'])) {
                $input['id'] = (int) $first['id'];
                $current = new \TicketSatisfaction();
                if ($current->getFromDB((int) $input['id']) && method_exists($current, 'canUpdateItem') && !$current->canUpdateItem()) {
                    throw new \RuntimeException(I18n::translate('Sem permissão para responder à pesquisa de satisfação.'));
                }

                return (bool) $satisfaction->update($input);
            }
        }

        return false;
    }

    public function getTicketTimeline(int $ticketId): array
    {
        if ($ticketId <= 0 || !$this->canReadTicket($ticketId)) {
            return [];
        }

        $events = [];

        if (class_exists('\ITILFollowup')) {
            $canViewPrivateFollowups = $this->canViewPrivateFollowups();
            $followupCriteria = ['itemtype' => 'Ticket', 'items_id' => $ticketId];
            if (!$canViewPrivateFollowups) {
                $followupCriteria['is_private'] = 0;
            }

            $followup = new \ITILFollowup();
            foreach ($followup->find($followupCriteria, 'date ASC') as $row) {
                $followupId = (int) ($row['id'] ?? 0);
                $isPrivate = !empty($row['is_private']) ? 1 : 0;
                if (
                    ($isPrivate === 1 && !$canViewPrivateFollowups)
                    || !$this->canReadTimelineItem(\ITILFollowup::class, $followupId, $isPrivate)
                ) {
                    continue;
                }

                $userId = (int) ($row['users_id'] ?? 0);
                $events[] = [
                    'id' => $followupId,
                    'type' => 'followup',
                    'date' => (string) ($row['date'] ?? ''),
                    'content' => (string) ($row['content'] ?? ''),
                    'users_id' => $userId,
                    'author_name' => $this->resolveUserName($userId),
                    'is_private' => $isPrivate,
                    'documents' => $this->getReadableDocumentsForParent(
                        $ticketId,
                        'ITILFollowup',
                        $followupId,
                        $isPrivate
                    ),
                ];
            }
        }

        if (class_exists('\TicketTask')) {
            $canViewPrivateTasks = $this->canViewPrivateTasks();
            $taskCriteria = ['tickets_id' => $ticketId];
            if (!$canViewPrivateTasks) {
                $taskCriteria['is_private'] = 0;
            }

            $task = new \TicketTask();
            foreach ($task->find($taskCriteria, 'date ASC') as $row) {
                $taskId = (int) ($row['id'] ?? 0);
                $isPrivate = !empty($row['is_private']) ? 1 : 0;
                if (
                    ($isPrivate === 1 && !$canViewPrivateTasks)
                    || !$this->canReadTimelineItem(\TicketTask::class, $taskId, $isPrivate)
                ) {
                    continue;
                }

                $userId = (int) ($row['users_id'] ?? $row['users_id_tech'] ?? 0);
                $events[] = [
                    'id' => $taskId,
                    'type' => 'task',
                    'date' => (string) ($row['date'] ?? ''),
                    'content' => (string) ($row['content'] ?? ''),
                    'users_id' => $userId,
                    'author_name' => $this->resolveUserName($userId),
                    'is_private' => $isPrivate,
                    'documents' => $this->getReadableDocumentsForParent(
                        $ticketId,
                        'TicketTask',
                        $taskId,
                        $isPrivate
                    ),
                ];
            }
        }

        if (class_exists('\ITILSolution')) {
            $solution = new \ITILSolution();
            foreach ($solution->find(['itemtype' => 'Ticket', 'items_id' => $ticketId], 'date_creation ASC') as $row) {
                $solutionId = (int) ($row['id'] ?? 0);
                if (!$this->canReadTimelineItem(\ITILSolution::class, $solutionId)) {
                    continue;
                }

                $userId = (int) ($row['users_id'] ?? 0);
                $events[] = [
                    'id' => $solutionId,
                    'type' => 'solution',
                    'date' => (string) ($row['date_creation'] ?? ''),
                    'content' => (string) ($row['content'] ?? ''),
                    'users_id' => $userId,
                    'author_name' => $this->resolveUserName($userId),
                ];
            }
        }

        usort($events, static fn(array $a, array $b): int => strcmp((string) $a['date'], (string) $b['date']));

        return $events;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function getReadableDocumentsForParent(
        int $ticketId,
        string $parentType,
        int $parentId,
        int $isPrivate = 0
    ): array {
        if (
            $ticketId <= 0
            || $parentId <= 0
            || !in_array($parentType, ['Ticket', 'ITILFollowup', 'TicketTask'], true)
            || !class_exists('\Document_Item')
            || !class_exists('\Document')
            || !$this->canReadTicket($ticketId)
            || !$this->canReadDocumentParent($ticketId, $parentType, $parentId, $isPrivate)
        ) {
            return [];
        }

        $documents = [];
        $seenDocumentIds = [];
        $link = new \Document_Item();
        foreach ((array) $link->find(['itemtype' => $parentType, 'items_id' => $parentId]) as $row) {
            $documentId = (int) (((array) $row)['documents_id'] ?? 0);
            if ($documentId <= 0 || isset($seenDocumentIds[$documentId])) {
                continue;
            }

            $document = new \Document();
            try {
                if (
                    !$document->getFromDB($documentId)
                    || !method_exists($document, 'canViewFile')
                    || !$document->canViewFile([
                        'itemtype' => $parentType,
                        'items_id' => $parentId,
                    ])
                ) {
                    continue;
                }
            } catch (\Throwable $e) {
                continue;
            }

            $seenDocumentIds[$documentId] = true;
            $filename = basename(trim((string) ($document->fields['filename'] ?? '')));
            $name = trim((string) ($document->fields['name'] ?? ''));
            $displayName = $filename !== '' ? $filename : $name;
            if ($displayName === '') {
                $displayName = sprintf('Documento #%d', $documentId);
            }

            $documents[] = [
                'id' => $documentId,
                'name' => $name,
                'filename' => $filename,
                'display_name' => $displayName,
                'mime' => trim((string) ($document->fields['mime'] ?? '')),
                'size' => max(0, (int) ($document->fields['filesize'] ?? 0)),
                'date_mod' => (string) ($document->fields['date_mod'] ?? ''),
                'parent_itemtype' => $parentType,
                'parent_id' => $parentId,
                'is_private' => $isPrivate === 1,
                'download_url' => $this->nativeDocumentDownloadUrl(
                    $documentId,
                    $ticketId,
                    $parentType,
                    $parentId
                ),
            ];
        }

        usort(
            $documents,
            static fn(array $left, array $right): int => strcmp(
                (string) ($right['date_mod'] ?? ''),
                (string) ($left['date_mod'] ?? '')
            )
        );

        return $documents;
    }

    private function canReadDocumentParent(
        int $ticketId,
        string $parentType,
        int $parentId,
        int $isPrivate
    ): bool {
        if ($parentType === 'Ticket') {
            return $parentId === $ticketId && $this->canReadTicket($ticketId);
        }

        if ($parentType === 'ITILFollowup') {
            if ($isPrivate === 1 && !$this->canViewPrivateFollowups()) {
                return false;
            }

            return $this->timelineParentBelongsToTicket(
                \ITILFollowup::class,
                $parentId,
                $ticketId,
                'items_id',
                $isPrivate,
                'itemtype'
            );
        }

        if ($parentType === 'TicketTask') {
            if ($isPrivate === 1 && !$this->canViewPrivateTasks()) {
                return false;
            }

            return $this->timelineParentBelongsToTicket(
                \TicketTask::class,
                $parentId,
                $ticketId,
                'tickets_id',
                $isPrivate
            );
        }

        return false;
    }

    private function timelineParentBelongsToTicket(
        string $itemClass,
        int $itemId,
        int $ticketId,
        string $ticketField,
        int $expectedPrivacy,
        string $itemtypeField = ''
    ): bool {
        if ($itemId <= 0 || !class_exists($itemClass)) {
            return false;
        }

        try {
            $item = new $itemClass();
            if (
                !method_exists($item, 'can')
                || !method_exists($item, 'getFromDB')
                || !$item->can($itemId, READ)
                || !$item->getFromDB($itemId)
                || (int) ($item->fields[$ticketField] ?? 0) !== $ticketId
                || (int) (!empty($item->fields['is_private'])) !== $expectedPrivacy
            ) {
                return false;
            }

            return $itemtypeField === ''
                || (string) ($item->fields[$itemtypeField] ?? '') === 'Ticket';
        } catch (\Throwable $e) {
            return false;
        }
    }

    private function nativeDocumentDownloadUrl(
        int $documentId,
        int $ticketId,
        string $parentType,
        int $parentId
    ): string {
        global $CFG_GLPI;

        $root = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/');
        $query = [
            'docid' => max(1, $documentId),
            'itemtype' => $parentType,
            'items_id' => max(1, $parentId),
        ];
        if ($parentType === 'Ticket') {
            $query['tickets_id'] = max(1, $ticketId);
        }

        return $root . '/front/document.send.php?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    }

    private function canReadTimelineItem(string $itemClass, int $itemId, int $isPrivate = 0): bool
    {
        if ($itemId <= 0 || !class_exists($itemClass)) {
            return false;
        }
        if ($isPrivate === 1) {
            if ($itemClass === \ITILFollowup::class && !$this->canViewPrivateFollowups()) {
                return false;
            }
            if ($itemClass === \TicketTask::class && !$this->canViewPrivateTasks()) {
                return false;
            }
        }

        try {
            $item = new $itemClass();
            return method_exists($item, 'can') && (bool) $item->can($itemId, READ);
        } catch (\Throwable $e) {
            return false;
        }
    }

    private function defaultTimelineItemPrivacy(string $itemClass, string $sessionKey): bool
    {
        if (class_exists($itemClass)) {
            try {
                $item = new $itemClass();
                if (method_exists($item, 'getEmpty')) {
                    $item->getEmpty();
                    if (isset($item->fields['is_private'])) {
                        return !empty($item->fields['is_private']);
                    }
                }
            } catch (\Throwable $e) {
                // Fall back to the native session preference used by GLPI 10 and 11.
            }
        }

        return !empty($_SESSION[$sessionKey]);
    }

    public function canAddPrivateFollowup(): bool
    {
        return $this->canViewPrivateFollowups();
    }

    public function canAddPrivateTask(): bool
    {
        return $this->canViewPrivateTasks();
    }

    private function canViewPrivateFollowups(): bool
    {
        return $this->hasTimelinePrivateRight('followup', [\ITILFollowup::class]);
    }

    private function canViewPrivateTasks(): bool
    {
        return $this->hasTimelinePrivateRight('task', [\TicketTask::class, '\CommonITILTask']);
    }

    /**
     * @param string[] $itemClasses
     */
    private function hasTimelinePrivateRight(string $rightName, array $itemClasses): bool
    {
        if (!class_exists('\Session') || !method_exists('\Session', 'haveRight')) {
            return false;
        }

        foreach ($itemClasses as $itemClass) {
            $constantName = ltrim($itemClass, '\\') . '::SEEPRIVATE';
            if (!defined($constantName)) {
                continue;
            }

            try {
                return (bool) \Session::haveRight($rightName, (int) constant($constantName));
            } catch (\Throwable $e) {
                return false;
            }
        }

        return false;
    }

    public function canReadTicketHistory(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return false;
        }

        try {
            if (class_exists('\Log') && method_exists('\Log', 'canView') && (bool) \Log::canView()) {
                return true;
            }
        } catch (\Throwable $e) {
            return false;
        }

        if (class_exists('\Session') && method_exists('\Session', 'haveRight') && defined('READ')) {
            return (bool) \Session::haveRight('logs', READ)
                || (bool) \Session::haveRight('log', READ);
        }

        return false;
    }

    /**
     * @return array{can_view:bool,available:bool,limit:int,items:array<int,array<string,string|int>>}
     */
    public function getTicketHistoryContext(int $ticketId, int $limit = 50): array
    {
        $limit = min(100, max(10, $limit));
        $context = [
            'can_view' => $this->canReadTicketHistory($ticketId),
            'available' => false,
            'limit' => $limit,
            'items' => [],
        ];
        if (!$context['can_view']) {
            return $context;
        }

        $context['items'] = $this->getTicketHistory($ticketId, $limit);
        $context['available'] = class_exists('\Log') || $this->tableExists('glpi_logs');
        return $context;
    }

    /**
     * @return array<int, array<string, string|int>>
     */
    public function getTicketHistory(int $ticketId, int $limit = 50): array
    {
        $ticketId = max(1, $ticketId);
        $limit = min(100, max(10, $limit));
        if (!$this->canReadTicketHistory($ticketId)) {
            return [];
        }

        $fromNative = $this->getTicketHistoryFromNativeLog($ticketId, $limit);
        if ($fromNative !== []) {
            return $fromNative;
        }

        return $this->getTicketHistoryFromLogTable($ticketId, $limit);
    }

    /**
     * @return array<int, array<string, string|int>>
     */
    private function getTicketHistoryFromNativeLog(int $ticketId, int $limit): array
    {
        if (!class_exists('\Log') || !method_exists('\Log', 'getHistoryData') || !class_exists('\Ticket')) {
            return [];
        }

        try {
            $ticket = new \Ticket();
            if (!$ticket->getFromDB($ticketId)) {
                return [];
            }

            $data = \Log::getHistoryData($ticket, 0, $limit);
            if (!is_array($data)) {
                return [];
            }

            return $this->normalizeTicketHistoryRows($data, $limit);
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * @return array<int, array<string, string|int>>
     */
    private function getTicketHistoryFromLogTable(int $ticketId, int $limit): array
    {
        global $DB;
        if (!isset($DB) || !method_exists($DB, 'request') || !$this->tableExists('glpi_logs')) {
            return [];
        }

        $columns = $this->getTableColumns('glpi_logs');
        if ($columns === []) {
            return [];
        }

        try {
            $rows = $DB->request([
                'SELECT' => $columns,
                'FROM' => 'glpi_logs',
                'WHERE' => [
                    'itemtype' => 'Ticket',
                    'items_id' => $ticketId,
                ],
                'ORDER' => ['id DESC'],
                'LIMIT' => $limit,
            ]);
        } catch (\Throwable $e) {
            return [];
        }

        $history = [];
        foreach ($rows as $row) {
            $history[] = $this->normalizeTicketHistoryRow((array) $row);
        }

        return array_values(array_filter($history, static fn(array $row): bool => trim((string) ($row['summary'] ?? '')) !== ''));
    }

    /**
     * @param array<string, mixed> $data
     * @return array<int, array<string, string|int>>
     */
    private function normalizeTicketHistoryRows(array $data, int $limit): array
    {
        $candidateRows = $data['history'] ?? $data['data'] ?? $data['rows'] ?? $data;
        if (!is_array($candidateRows)) {
            return [];
        }

        $history = [];
        foreach ($candidateRows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $normalized = $this->normalizeTicketHistoryRow($row);
            if (trim((string) ($normalized['summary'] ?? '')) === '') {
                continue;
            }
            $history[] = $normalized;
            if (count($history) >= $limit) {
                break;
            }
        }

        return $history;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, string|int>
     */
    private function normalizeTicketHistoryRow(array $row): array
    {
        $id = (int) ($row['id'] ?? $row['logs_id'] ?? 0);
        $date = (string) ($row['date_mod'] ?? $row['date'] ?? $row['date_creation'] ?? '');
        $user = (string) ($row['user_name'] ?? $row['user'] ?? $row['username'] ?? '');
        $field = (string) ($row['field'] ?? $row['fieldname'] ?? $row['id_search_option'] ?? $row['itemtype_link'] ?? '');
        $action = (string) ($row['linked_action'] ?? $row['action'] ?? '');
        $summaryCandidates = [
            $row['change'] ?? null,
            $row['changes'] ?? null,
            $row['message'] ?? null,
            $row['display_history'] ?? null,
            $row['old_value'] ?? null,
            $row['new_value'] ?? null,
        ];
        $summaryParts = [];
        foreach ($summaryCandidates as $candidate) {
            if (is_array($candidate)) {
                $candidate = implode(' ', array_map(static fn($value): string => is_scalar($value) ? (string) $value : '', $candidate));
            }
            if (!is_scalar($candidate)) {
                continue;
            }
            $clean = $this->normalizeHistoryText((string) $candidate);
            if ($clean !== '' && !in_array($clean, $summaryParts, true)) {
                $summaryParts[] = $clean;
            }
        }

        $summary = implode(' -> ', $summaryParts);
        if ($summary === '' && $field !== '') {
            $summary = sprintf(
                I18n::translate('Alteração registrada em %s'),
                $this->normalizeHistoryText($field)
            );
        }

        return [
            'id' => $id,
            'date' => $this->normalizeHistoryText($date),
            'user' => $this->normalizeHistoryText($user),
            'field' => $this->normalizeHistoryText($field),
            'action' => $this->normalizeHistoryText($action),
            'summary' => $summary,
        ];
    }

    private function normalizeHistoryText(string $value): string
    {
        $value = html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = preg_replace('/\s+/u', ' ', $value) ?? $value;
        return trim($value);
    }
    public function getCockpitMetrics(): array
    {
        $timezone = $this->cockpitTimezone();
        $clock = new \DateTimeImmutable('now', $timezone);
        $generatedAt = $clock->format(DATE_ATOM);
        $definitions = $this->cockpitMetricDefinitions($clock);
        $metrics = [];

        foreach ($definitions as $key => $descriptor) {
            $definition = is_array($descriptor['definition'] ?? null)
                ? $descriptor['definition']
                : null;
            $result = $definition !== null
                ? $this->countTicketsFromSearchApi($definition)
                : $this->unknownCockpitCount('search_option_unavailable');
            $exact = ($result['completeness'] ?? 'unknown') === 'exact';
            $value = $exact && is_int($result['value'] ?? null)
                ? $result['value']
                : null;

            $metrics[$key] = [
                'value' => $value,
                'count' => $value,
                'available' => $exact,
                'completeness' => $exact ? 'exact' : 'unknown',
                'label' => (string) ($descriptor['label'] ?? $key),
                'period' => (string) ($descriptor['period'] ?? 'current'),
                'scope' => (string) ($descriptor['scope'] ?? 'allowed'),
                'generated_at' => $generatedAt,
                'data_as_of' => $generatedAt,
                'updated_at' => $generatedAt,
                'timezone' => $timezone->getName(),
                'drilldown_filters' => $definition ?? [],
                'url_definition' => $definition ?? [],
                'drilldown_url' => '',
                'url' => '',
                'backend' => $exact ? (string) ($result['backend'] ?? 'search_api') : 'unavailable',
                'error_code' => $exact ? '' : (string) ($result['error_code'] ?? 'search_total_unavailable'),
                'query_duration_ms' => max(0, (int) ($result['query_duration_ms'] ?? 0)),
            ];
        }

        $allExact = $metrics !== [] && count(array_filter(
            $metrics,
            static fn(array $metric): bool => ($metric['completeness'] ?? 'unknown') === 'exact'
        )) === count($metrics);

        return $metrics + [
            'generated_at' => $generatedAt,
            'data_as_of' => $generatedAt,
            'updated_at' => $generatedAt,
            'timezone' => $timezone->getName(),
            'scope' => 'allowed',
            'scope_label' => 'Todos os chamados permitidos',
            'backend' => $allExact ? 'search_api' : 'unavailable',
        ];
    }

    /**
     * Build only server-owned definitions. The browser never supplies cockpit
     * criteria, Search Option identifiers, entity scope or participant IDs.
     *
     * @return array<string,array<string,mixed>>
     */
    private function cockpitMetricDefinitions(\DateTimeImmutable $clock): array
    {
        $today = $clock->format('Y-m-d');
        $dayStart = $clock->setTime(0, 0, 0);
        $dayLowerBound = $dayStart->modify('-1 second')->format('Y-m-d H:i:s');
        $dayUpperBound = $dayStart->modify('+1 day')->format('Y-m-d H:i:s');
        $statusOption = $this->getTicketSearchOptionNumber('status');
        $solvedDateOption = $this->getTicketSearchOptionNumber('solvedate');
        $openCriteria = $statusOption > 0
            ? $this->cockpitStatusCriteria($statusOption, [1, 2, 3, 4])
            : null;
        $pendingCriteria = $statusOption > 0
            ? $this->cockpitStatusCriteria($statusOption, [4])
            : null;
        $solvedTodayCriteria = $statusOption > 0 && $solvedDateOption > 0
            ? array_merge(
                $this->cockpitStatusCriteria($statusOption, [5]),
                [[
                    'link' => 'AND',
                    'field' => $solvedDateOption,
                    'searchtype' => 'morethan',
                    'value' => $dayLowerBound,
                ], [
                    'link' => 'AND',
                    'field' => $solvedDateOption,
                    'searchtype' => 'lessthan',
                    'value' => $dayUpperBound,
                ]]
            )
            : null;

        return [
            'total_open' => [
                'label' => 'Abertos',
                'period' => 'current',
                'scope' => 'allowed',
                'definition' => $openCriteria === null
                    ? null
                    : $this->cockpitSearchDefinition('all', $openCriteria),
            ],
            'pending' => [
                'label' => 'Pendentes',
                'period' => 'current',
                'scope' => 'allowed',
                'definition' => $pendingCriteria === null
                    ? null
                    : $this->cockpitSearchDefinition('all', $pendingCriteria),
            ],
            'solved_today' => [
                'label' => 'Solucionados hoje',
                'period' => $today,
                'scope' => 'allowed',
                'definition' => $solvedTodayCriteria === null
                    ? null
                    : $this->cockpitSearchDefinition('all', $solvedTodayCriteria),
            ],
            'mine_open' => [
                'label' => 'Meus abertos',
                'period' => 'current',
                'scope' => 'mine',
                'definition' => $openCriteria === null
                    ? null
                    : $this->cockpitSearchDefinition('mine', $openCriteria),
            ],
            'group_open' => [
                'label' => 'Grupo aberto',
                'period' => 'current',
                'scope' => 'group',
                'definition' => $openCriteria === null
                    ? null
                    : $this->cockpitSearchDefinition('group', $openCriteria),
            ],
        ];
    }

    /** @return array<int,array<string,mixed>> */
    private function cockpitStatusCriteria(int $statusOption, array $statuses): array
    {
        $alternatives = [];
        foreach (array_values(array_unique(array_map('intval', $statuses))) as $index => $status) {
            if ($status < 1) {
                continue;
            }
            $alternatives[] = [
                'link' => $index === 0 ? 'AND' : 'OR',
                'field' => $statusOption,
                'searchtype' => 'equals',
                'value' => (string) $status,
            ];
        }

        return $alternatives === [] ? [] : [[
            'link' => 'AND',
            'criteria' => $alternatives,
        ]];
    }

    /** @return array<string,mixed> */
    private function cockpitSearchDefinition(string $scope, array $criteria): array
    {
        return [
            'version' => NativeSearchDefinitionValidator::VERSION,
            'itemtype' => 'Ticket',
            'text' => '',
            'scope' => $scope,
            'criteria' => $criteria,
            'metacriteria' => [],
            'sort' => [],
            'order' => [],
            'is_deleted' => 0,
            'columns' => ['id', 'name'],
        ];
    }

    /**
     * Count the complete ACL-filtered Search API universe without hydrating
     * rows. Only an explicit native total is accepted as exact.
     *
     * @param array<string,mixed> $definition
     * @return array{value:?int,completeness:string,backend:string,error_code:string,query_duration_ms:int}
     */
    private function countTicketsFromSearchApi(array $definition): array
    {
        $filters = [
            'scope' => (string) ($definition['scope'] ?? 'all'),
            'q' => (string) ($definition['text'] ?? ''),
            'native_criteria' => (array) ($definition['criteria'] ?? []),
            'native_metacriteria' => (array) ($definition['metacriteria'] ?? []),
            'native_is_deleted' => (int) ($definition['is_deleted'] ?? 0),
        ];
        $groupScope = $this->currentUserGroupScopeResolution($filters);
        if ($groupScope['state'] === 'empty') {
            return [
                'value' => 0,
                'completeness' => 'exact',
                'backend' => 'scope_empty',
                'error_code' => '',
                'query_duration_ms' => 0,
            ];
        }
        if ($groupScope['state'] === 'unavailable') {
            return $this->unknownCockpitCount($groupScope['reason']);
        }
        if (!$this->canUseSearchApiForTicketList($filters)) {
            return $this->unknownCockpitCount($this->getSearchApiFallbackReason($filters));
        }

        $idOption = $this->getTicketSearchOptionNumber('id');
        if ($idOption <= 0) {
            return $this->unknownCockpitCount('search_option_unavailable');
        }

        $semanticCriteria = $this->buildTicketSearchCriteria($filters);
        if ($semanticCriteria === null) {
            return $this->unknownCockpitCount('scope_unavailable');
        }
        $statusCriterionCodec = new GlpiTicketStatusCriterionCodec();
        $criteria = $statusCriterionCodec->compileForGlpi(
            array_merge((array) $filters['native_criteria'], $semanticCriteria),
            \Ticket::class
        );
        $metacriteria = $statusCriterionCodec->compileForGlpi(
            (array) $filters['native_metacriteria'],
            \Ticket::class
        );
        $params = [
            'is_deleted' => (int) $filters['native_is_deleted'],
            'start' => 0,
            'list_limit' => 1,
            'criteria' => $criteria,
            'metacriteria' => $metacriteria,
            'reset' => 'reset',
        ];

        try {
            if (method_exists('\Search', 'manageParams')) {
                $params = \Search::manageParams(\Ticket::class, $params, false, false);
                if (!is_array($params)) {
                    return $this->unknownCockpitCount('search_request_unavailable');
                }
            }

            $startedAt = microtime(true);
            $data = \Search::getDatas(\Ticket::class, $params, [$idOption]);
            $duration = max(0, (int) round((microtime(true) - $startedAt) * 1000));
            if (!is_array($data)) {
                return $this->unknownCockpitCount('search_response_unavailable', $duration);
            }
            $total = $this->extractExactSearchTotal($data);
            if ($total === null) {
                return $this->unknownCockpitCount('search_total_unavailable', $duration);
            }

            return [
                'value' => $total,
                'completeness' => 'exact',
                'backend' => 'search_api',
                'error_code' => '',
                'query_duration_ms' => $duration,
            ];
        } catch (\Throwable $e) {
            return $this->unknownCockpitCount('search_execution_failed');
        }
    }

    private function extractExactSearchTotal(array $data): ?int
    {
        foreach ([['data', 'totalcount'], ['data', 'count']] as $path) {
            $value = $data[$path[0]][$path[1]] ?? null;
            if (is_numeric($value) && (int) $value >= 0) {
                return (int) $value;
            }
        }
        $value = $data['totalcount'] ?? null;
        return is_numeric($value) && (int) $value >= 0 ? (int) $value : null;
    }

    /** @return array{value:null,completeness:string,backend:string,error_code:string,query_duration_ms:int} */
    private function unknownCockpitCount(string $errorCode, int $duration = 0): array
    {
        return [
            'value' => null,
            'completeness' => 'unknown',
            'backend' => 'unavailable',
            'error_code' => $errorCode,
            'query_duration_ms' => max(0, $duration),
        ];
    }

    private function cockpitTimezone(): \DateTimeZone
    {
        global $CFG_GLPI;

        $candidates = [
            $_SESSION['glpitimezone'] ?? null,
            is_array($CFG_GLPI ?? null) ? ($CFG_GLPI['timezone'] ?? null) : null,
            date_default_timezone_get(),
            'UTC',
        ];
        foreach ($candidates as $candidate) {
            if (!is_string($candidate) || trim($candidate) === '') {
                continue;
            }
            try {
                return new \DateTimeZone(trim($candidate));
            } catch (\Throwable $e) {
                continue;
            }
        }

        return new \DateTimeZone('UTC');
    }

    public function getKnowledgeArticles(string $query = '', int $limit = 30): array
    {
        $result = $this->searchKnowledgeArticles([
            'query' => $query,
            'public_only' => true,
            'page' => 1,
            'page_size' => $limit,
        ]);

        return $result['items'] ?? [];
    }

    public function searchKnowledgeArticles(array $filters): array
    {
        $query = trim((string) ($filters['query'] ?? ''));
        $categoryId = max(0, (int) ($filters['category_id'] ?? 0));
        $publicOnly = (bool) ($filters['public_only'] ?? false);
        $page = max(1, (int) ($filters['page'] ?? 1));
        $pageSize = min(20, max(1, (int) ($filters['page_size'] ?? 10)));

        if ($query === '' && $categoryId === 0) {
            return [
                'items' => [],
                'total' => 0,
                'page' => $page,
                'page_size' => $pageSize,
                'pages' => 1,
            ];
        }

        $items = $this->fetchKnowledgeCandidates([
            'query' => $query,
            'category_id' => $categoryId,
            'public_only' => $publicOnly,
            'limit' => max(50, $pageSize * 12),
            'order' => 'updated',
        ]);

        if ($query !== '') {
            usort($items, function (array $left, array $right) use ($query): int {
                $scoreDiff = $this->scoreKnowledgeArticle($right, $query) <=> $this->scoreKnowledgeArticle($left, $query);
                if ($scoreDiff !== 0) {
                    return $scoreDiff;
                }

                return strcmp((string) ($right['date_mod'] ?? ''), (string) ($left['date_mod'] ?? ''));
            });
        }

        $total = count($items);
        $pages = max(1, (int) ceil(max(1, $total) / $pageSize));
        $page = min($page, $pages);
        $offset = ($page - 1) * $pageSize;

        return [
            'items' => array_slice($items, $offset, $pageSize),
            'total' => $total,
            'page' => $page,
            'page_size' => $pageSize,
            'pages' => $pages,
        ];
    }

    public function getKnowledgeHomeLists(bool $publicOnly, int $limit = 5): array
    {
        $limit = min(10, max(1, $limit));

        return [
            'recentes' => array_slice($this->fetchKnowledgeCandidates([
                'public_only' => $publicOnly,
                'limit' => $limit,
                'order' => 'recent',
            ]), 0, $limit),
            'atualizadas' => array_slice($this->fetchKnowledgeCandidates([
                'public_only' => $publicOnly,
                'limit' => $limit,
                'order' => 'updated',
            ]), 0, $limit),
            'populares' => array_slice($this->fetchKnowledgeCandidates([
                'public_only' => $publicOnly,
                'limit' => $limit,
                'order' => 'popular',
            ]), 0, $limit),
        ];
    }

    public function getKnowledgeCategories(bool $publicOnly, int $limit = 200): array
    {
        $items = $this->fetchKnowledgeCandidates([
            'public_only' => $publicOnly,
            'limit' => max(40, min(300, $limit)),
            'order' => 'updated',
        ]);

        $categories = [];
        foreach ($items as $item) {
            $categoryId = (int) ($item['category_id'] ?? 0);
            $label = trim((string) ($item['category'] ?? ''));
            if ($categoryId <= 0 || $label === '') {
                continue;
            }

            $categories[$categoryId] = [
                'id' => $categoryId,
                'label' => $label,
            ];
        }

        uasort($categories, static fn(array $left, array $right): int => strcasecmp($left['label'], $right['label']));

        return array_values($categories);
    }

    public function getKnowledgeArticle(int $articleId, bool $publicOnly = false): ?array
    {
        $articleId = max(1, $articleId);
        $kb = new \KnowbaseItem();
        if (!$kb->can($articleId, READ) || !$kb->getFromDB($articleId)) {
            return null;
        }

        $item = $this->mapKnowledgeItem($kb);
        if ($publicOnly) {
            $columns = $this->getTableColumns('glpi_knowbaseitems');
            if (in_array('is_faq', $columns, true) && empty($item['is_faq'])) {
                return null;
            }
        }

        return $item;
    }

    /**
     * Varredura controlada para gerar sugestoes de roteiro do chatbot.
     * Mantem os mesmos filtros nativos usados nas telas de KB e limita o volume
     * para evitar carga indevida em homologacao/producao.
     *
     * @return array<int, array<string, mixed>>
     */
    public function scanKnowledgeArticles(bool $publicOnly, int $limit = 80): array
    {
        return $this->fetchKnowledgeCandidates([
            'public_only' => $publicOnly,
            'limit' => min(200, max(10, $limit)),
            'order' => 'updated',
        ]);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function fetchKnowledgeCandidates(array $filters): array
    {
        $columns = $this->getTableColumns('glpi_knowbaseitems');
        if ($columns === [] || !class_exists('\KnowbaseItem')) {
            return [];
        }

        $query = trim((string) ($filters['query'] ?? ''));
        $categoryId = max(0, (int) ($filters['category_id'] ?? 0));
        $publicOnly = (bool) ($filters['public_only'] ?? false);
        $limit = min(250, max(1, (int) ($filters['limit'] ?? 20)));
        $order = (string) ($filters['order'] ?? 'updated');

        $criteria = [];

        if ($publicOnly && in_array('is_faq', $columns, true)) {
            $criteria['is_faq'] = 1;
        }
        if (in_array('is_deleted', $columns, true)) {
            $criteria['is_deleted'] = 0;
        }
        if ($categoryId > 0 && in_array('knowbaseitemcategories_id', $columns, true)) {
            $criteria['knowbaseitemcategories_id'] = $categoryId;
        }
        if ($query !== '') {
            $searchable = [];
            foreach (['name', 'question', 'answer'] as $field) {
                if (in_array($field, $columns, true)) {
                    $searchable[$field] = ['LIKE', '%' . $query . '%'];
                }
            }
            if ($searchable !== []) {
                $criteria['OR'] = $searchable;
            }
        }

        $orderClause = $this->getKnowledgeNativeOrder($columns, $order);
        $items = [];
        $seen = [];
        $maxScan = min(100, max($limit * 2, $limit));
        $kbFinder = new \KnowbaseItem();
        $rows = $kbFinder->find($criteria, $orderClause, $maxScan);

        foreach ((array) $rows as $row) {
            $id = (int) ($row['id'] ?? 0);
            if ($id <= 0 || isset($seen[$id])) {
                continue;
            }
            $seen[$id] = true;

            $kb = new \KnowbaseItem();
            if (!$kb->can($id, READ) || !$kb->getFromDB($id)) {
                continue;
            }

            $item = $this->mapKnowledgeItem($kb);
            if ($publicOnly && empty($item['is_faq']) && in_array('is_faq', $columns, true)) {
                continue;
            }
            if ($categoryId > 0 && (int) ($item['category_id'] ?? 0) !== $categoryId) {
                continue;
            }
            if ($query !== '' && !$this->knowledgeMatchesQuery($item, $query)) {
                continue;
            }

            $items[] = $item;
            if (count($items) >= $limit) {
                break;
            }
        }

        return $items;
    }

    private function getKnowledgeNativeOrder(array $columns, string $order): string
    {
        $dateCreationField = in_array('date_creation', $columns, true) ? 'date_creation' : 'id';
        $dateModField = in_array('date_mod', $columns, true) ? 'date_mod' : $dateCreationField;
        $popularityField = null;

        foreach (['view', 'views', 'visits', 'numviews'] as $field) {
            if (in_array($field, $columns, true)) {
                $popularityField = $field;
                break;
            }
        }

        return match ($order) {
            'recent' => $dateCreationField . ' DESC, id DESC',
            'popular' => ($popularityField ?? $dateModField) . ' DESC, ' . $dateModField . ' DESC',
            default => $dateModField . ' DESC, id DESC',
        };
    }

    private function getKnowledgeOrderClause(array $columns, string $order): string
    {
        $dateCreationField = in_array('date_creation', $columns, true) ? 'k.date_creation' : 'k.id';
        $dateModField = in_array('date_mod', $columns, true) ? 'k.date_mod' : $dateCreationField;
        $popularityField = null;

        foreach (['view', 'views', 'visits', 'numviews'] as $field) {
            if (in_array($field, $columns, true)) {
                $popularityField = 'k.' . $field;
                break;
            }
        }

        return match ($order) {
            'recent' => $dateCreationField . ' DESC, k.id DESC',
            'popular' => ($popularityField ?? $dateModField) . ' DESC, ' . $dateModField . ' DESC',
            default => $dateModField . ' DESC, k.id DESC',
        };
    }

    /**
     * @return array<string, mixed>
     */
    private function mapKnowledgeItem(\KnowbaseItem $kb): array
    {
        $fields = $kb->fields;
        $title = trim((string) ($fields['name'] ?? ''));
        if ($title === '') {
            $title = trim((string) ($fields['question'] ?? ''));
        }
        if ($title === '') {
            $title = 'Artigo #' . (int) ($fields['id'] ?? 0);
        }

        $questionHtml = $this->sanitizeKnowledgeHtml((string) ($fields['question'] ?? ''));
        $answerHtml = $this->sanitizeKnowledgeHtml((string) ($fields['answer'] ?? ''));
        $bodyHtml = $answerHtml !== '' ? $answerHtml : $questionHtml;
        $questionText = $this->toKnowledgePlainText($questionHtml);
        $answerText = $this->toKnowledgePlainText($answerHtml);
        $bodyText = $this->toKnowledgePlainText($bodyHtml);
        $summary = $bodyText;
        if (mb_strlen($summary) > 220) {
            $summary = rtrim(mb_substr($summary, 0, 217)) . '...';
        }

        $categoryId = (int) ($fields['knowbaseitemcategories_id'] ?? 0);
        $associated = $this->getKnowledgeAssociatedElements((int) ($fields['id'] ?? 0));

        return [
            'id' => (int) ($fields['id'] ?? 0),
            'assunto' => $title,
            'question' => $questionText,
            'answer' => $answerText,
            'question_html' => $questionHtml,
            'answer_html' => $answerHtml,
            'summary' => $summary,
            'body' => $bodyText,
            'body_html' => $bodyHtml,
            'category_id' => $categoryId,
            'category' => $this->resolveKnowledgeCategoryName($categoryId),
            'associados' => $associated,
            'date_creation' => (string) ($fields['date_creation'] ?? ''),
            'date_mod' => (string) ($fields['date_mod'] ?? ''),
            'is_faq' => !empty($fields['is_faq']),
            'popularity' => (int) ($fields['view'] ?? $fields['views'] ?? $fields['visits'] ?? $fields['numviews'] ?? 0),
        ];
    }

    private function resolveKnowledgeCategoryName(int $categoryId): string
    {
        if ($categoryId <= 0) {
            return 'Sem categoria';
        }

        if (class_exists('\Dropdown') && method_exists('\Dropdown', 'getDropdownName')) {
            $label = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName('glpi_knowbaseitemcategories', $categoryId));
            if ($label !== '') {
                return $label;
            }
        }

        if (class_exists('\KnowbaseItemCategory')) {
            $category = new \KnowbaseItemCategory();
            if ($category->getFromDB($categoryId)) {
                return TextNormalizer::fromGlpi((string) ($category->fields['completename'] ?? $category->fields['name'] ?? ('Categoria ' . $categoryId)));
            }
        }

        return 'Categoria ' . $categoryId;
    }

    private function getKnowledgeAssociatedElements(int $articleId): string
    {
        global $DB;

        if ($articleId <= 0 || !$this->tableExists('glpi_items_knowbaseitems')) {
            return I18n::translate('Não informado');
        }

        $counts = [];
        foreach (
            $DB->request([
            'SELECT' => ['itemtype'],
            'FROM' => 'glpi_items_knowbaseitems',
            'WHERE' => ['knowbaseitems_id' => $articleId],
            ]) as $row
        ) {
            $itemtype = (string) ($row['itemtype'] ?? '');
            if ($itemtype === '') {
                continue;
            }
            $counts[$itemtype] = ($counts[$itemtype] ?? 0) + 1;
        }

        arsort($counts);

        $items = [];
        foreach (array_slice($counts, 0, 3, true) as $itemtype => $total) {
            $label = $this->resolveItemTypeLabel((string) $itemtype, (int) $total);
            if ($label !== '') {
                $items[] = $label;
            }
        }

        return $items === [] ? I18n::translate('Não informado') : implode(', ', $items);
    }

    private function resolveItemTypeLabel(string $itemtype, int $count): string
    {
        $itemtype = trim($itemtype);
        if ($itemtype === '') {
            return '';
        }

        if (class_exists($itemtype) && method_exists($itemtype, 'getTypeName')) {
            $label = (string) $itemtype::getTypeName($count);
            if ($label !== '') {
                return $label;
            }
        }

        $short = str_contains($itemtype, '\\') ? substr($itemtype, (int) strrpos($itemtype, '\\') + 1) : $itemtype;
        $short = preg_replace('/(?<!^)([A-Z])/', ' $1', $short) ?? $short;
        return trim($short);
    }

    private function knowledgeMatchesQuery(array $item, string $query): bool
    {
        $needle = $this->normalizeSearchText($query);
        if ($needle === '') {
            return true;
        }

        foreach ([$item['assunto'] ?? '', $item['summary'] ?? '', $item['body'] ?? '', $item['category'] ?? ''] as $haystack) {
            if (str_contains($this->normalizeSearchText((string) $haystack), $needle)) {
                return true;
            }
        }

        return false;
    }

    private function scoreKnowledgeArticle(array $item, string $query): int
    {
        $terms = array_values(array_filter(preg_split('/\s+/u', $this->normalizeSearchText($query)) ?: []));
        if ($terms === []) {
            return 0;
        }

        $title = $this->normalizeSearchText((string) ($item['assunto'] ?? ''));
        $summary = $this->normalizeSearchText((string) ($item['summary'] ?? ''));
        $body = $this->normalizeSearchText((string) ($item['body'] ?? ''));
        $category = $this->normalizeSearchText((string) ($item['category'] ?? ''));

        $score = 0;
        foreach ($terms as $term) {
            if ($term === '') {
                continue;
            }
            if (str_contains($title, $term)) {
                $score += 6;
            }
            if (str_contains($summary, $term)) {
                $score += 4;
            }
            if (str_contains($body, $term)) {
                $score += 2;
            }
            if (str_contains($category, $term)) {
                $score += 1;
            }
        }

        return $score;
    }

    private function normalizeSearchText(string $value): string
    {
        $value = mb_strtolower($value, 'UTF-8');
        $converted = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if ($converted !== false) {
            $value = $converted;
        }

        return trim(preg_replace('/\s+/', ' ', $value) ?? $value);
    }

    private function sanitizeKnowledgeHtml(string $value): string
    {
        $value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        $safeHtml = $this->sanitizeHtmlWithGlpiCore($value);
        if ($safeHtml !== null) {
            return $this->normalizeKnowledgeMediaHtml($safeHtml);
        }

        $value = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $value) ?? $value;
        $value = preg_replace('#<style(.*?)>(.*?)</style>#is', '', $value) ?? $value;
        $value = preg_replace('/\s+on[a-z]+\s*=\s*"[^"]*"/i', '', $value) ?? $value;
        $value = preg_replace("/\s+on[a-z]+\s*=\s*'[^']*'/i", '', $value) ?? $value;
        $value = preg_replace('/\s+on[a-z]+\s*=\s*[^\s>]+/i', '', $value) ?? $value;
        $value = preg_replace('/\s+style\s*=\s*"[^"]*"/i', '', $value) ?? $value;
        $value = preg_replace("/\s+style\s*=\s*'[^']*'/i", '', $value) ?? $value;
        $value = preg_replace('/\s+style\s*=\s*[^\s>]+/i', '', $value) ?? $value;
        $value = preg_replace('/\s+class\s*=\s*"[^"]*"/i', '', $value) ?? $value;
        $value = preg_replace("/\s+class\s*=\s*'[^']*'/i", '', $value) ?? $value;
        $value = preg_replace('/\s+class\s*=\s*[^\s>]+/i', '', $value) ?? $value;
        $value = preg_replace('/href\s*=\s*"javascript:[^"]*"/i', 'href="#"', $value) ?? $value;
        $value = preg_replace("/href\s*=\s*'javascript:[^']*'/i", 'href="#"', $value) ?? $value;

        $allowed = '<p><br><strong><b><em><i><u><ul><ol><li><a><h1><h2><h3><h4><h5><h6><blockquote><code><pre><img><figure><figcaption><table><thead><tbody><tfoot><tr><th><td>';
        $clean = strip_tags($value, $allowed);
        $clean = $this->normalizeKnowledgeMediaHtml($clean);
        $clean = preg_replace("/\r\n?/", "\n", $clean) ?? $clean;
        return trim($clean);
    }

    private function sanitizeHtmlWithGlpiCore(string $value): ?string
    {
        if (class_exists('\Glpi\RichText\RichText') && is_callable(['\Glpi\RichText\RichText', 'getSafeHtml'])) {
            return trim((string) \Glpi\RichText\RichText::getSafeHtml($value));
        }

        if (class_exists('\Html') && is_callable(['\Html', 'clean'])) {
            return trim((string) \Html::clean($value));
        }

        return null;
    }

    private function normalizeKnowledgeMediaHtml(string $value): string
    {
        $value = $this->rewriteKnowledgeUrlAttributes($value, 'src');
        $value = $this->rewriteKnowledgeUrlAttributes($value, 'href');
        $value = preg_replace('/<img\b(?![^>]*\balt=)/i', '<img alt="Imagem do artigo"', $value) ?? $value;
        $value = preg_replace('/<img\b(?![^>]*\bloading=)/i', '<img loading="lazy"', $value) ?? $value;
        $value = preg_replace('/<img\b(?![^>]*\bdecoding=)/i', '<img decoding="async"', $value) ?? $value;
        $value = preg_replace('/<a\b(?![^>]*\brel=)/i', '<a rel="noopener noreferrer"', $value) ?? $value;

        return $value;
    }

    private function rewriteKnowledgeUrlAttributes(string $value, string $attribute): string
    {
        return preg_replace_callback(
            '/\s' . preg_quote($attribute, '/') . '\s*=\s*(["\'])(.*?)\1/i',
            function (array $matches) use ($attribute): string {
                $url = html_entity_decode((string) ($matches[2] ?? ''), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $safeUrl = $this->normalizeKnowledgeAssetUrl($url, $attribute === 'src');
                if ($safeUrl === '') {
                    return $attribute === 'href' ? ' href="#"' : '';
                }

                return ' ' . $attribute . '="' . htmlspecialchars($safeUrl, ENT_QUOTES, 'UTF-8') . '"';
            },
            $value
        ) ?? $value;
    }

    private function normalizeKnowledgeAssetUrl(string $url, bool $isImage): string
    {
        global $CFG_GLPI;

        $url = trim($url);
        if ($url === '') {
            return '';
        }

        $decoded = html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (preg_match('/^\s*(javascript|vbscript):/i', $decoded)) {
            return '';
        }

        if ($isImage && preg_match('#^data:image/(png|gif|jpe?g|webp);base64,[a-z0-9+/=\s]+$#i', $decoded)) {
            return preg_replace('/\s+/', '', $decoded) ?? $decoded;
        }

        if (preg_match('#^https?://#i', $decoded)) {
            return $decoded;
        }

        $root = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/');
        if ($root === '') {
            $root = '';
        }

        if (str_starts_with($decoded, '/')) {
            return $root !== '' && !str_starts_with($decoded, $root . '/') ? $root . $decoded : $decoded;
        }

        $trimmedRelative = preg_replace('#^(\./|\.\./)+#', '', $decoded) ?? $decoded;
        if (str_starts_with($trimmedRelative, 'front/') || str_starts_with($trimmedRelative, 'ajax/') || str_starts_with($trimmedRelative, 'plugins/')) {
            return $root . '/' . $trimmedRelative;
        }

        if (str_starts_with($decoded, 'front/') || str_starts_with($decoded, 'ajax/') || str_starts_with($decoded, 'plugins/')) {
            return $root . '/' . $decoded;
        }

        if (str_starts_with($decoded, './')) {
            return $root . '/' . ltrim(substr($decoded, 2), '/');
        }

        return $isImage ? '' : $decoded;
    }

    private function toKnowledgePlainText(string $value): string
    {
        $value = str_replace(
            ['<br>', '<br/>', '<br />', '</p>', '</div>', '</li>', '<li>'],
            ["\n", "\n", "\n", "\n\n", "\n\n", "\n", "- "],
            $value
        );
        $value = html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = preg_replace("/\r\n?/", "\n", $value) ?? $value;
        $value = preg_replace("/\n{3,}/", "\n\n", $value) ?? $value;
        $value = preg_replace('/[ \t]+/', ' ', $value) ?? $value;
        return trim($value);
    }

    /**
     * @return string[]
     */
    private function getTableColumns(string $table): array
    {
        global $DB;

        $knownColumns = [
            'glpi_tickets' => [
                'id', 'name', 'content', 'status', 'type', 'urgency', 'impact', 'priority',
                'entities_id', 'itilcategories_id', 'locations_id', 'requesttypes_id',
                'users_id_recipient', 'externalid', 'date', 'date_mod', 'date_creation',
                'time_to_resolve', 'is_deleted',
            ],
            'glpi_knowbaseitems' => [
                'id', 'name', 'answer', 'is_faq', 'is_recursive', 'view',
                'knowbaseitemcategories_id', 'date_mod', 'date_creation',
            ],
            'glpi_users' => ['id', 'name', 'firstname', 'realname', 'is_deleted', 'is_active'],
            'glpi_groups' => [
                'id', 'name', 'completename', 'is_deleted', 'is_active',
                'entities_id', 'is_recursive', 'is_assign', 'is_watcher',
            ],
            'glpi_entities' => ['id', 'name', 'completename'],
            'glpi_itilcategories' => [
                'id', 'name', 'completename', 'is_deleted', 'is_active',
                'entities_id', 'is_recursive', 'is_incident', 'is_request',
            ],
            'glpi_locations' => [
                'id', 'name', 'completename', 'is_deleted', 'is_active',
                'entities_id', 'is_recursive',
            ],
            'glpi_requesttypes' => ['id', 'name', 'is_active'],
            'glpi_taskcategories' => ['id', 'name', 'completename', 'is_deleted', 'is_active', 'entities_id', 'is_recursive'],
            'glpi_logs' => [
                'id', 'itemtype', 'items_id', 'itemtype_link', 'linked_action',
                'id_search_option', 'user_name', 'date_mod', 'old_value', 'new_value',
            ],
        ];

        $columns = $knownColumns[$table] ?? [];
        if ($columns === [] || !method_exists($DB, 'fieldExists')) {
            return $columns;
        }

        return array_values(array_filter(
            $columns,
            static fn(string $column): bool => (bool) $DB->fieldExists($table, $column)
        ));
    }

    private function columnExists(string $table, string $column): bool
    {
        global $DB;

        if (method_exists($DB, 'fieldExists')) {
            return (bool) $DB->fieldExists($table, $column);
        }

        return in_array($column, $this->getTableColumns($table), true);
    }

    private function ticketColumnExists(string $column): bool
    {
        return $this->columnExists('glpi_tickets', $column);
    }

    private function tableExists(string $table): bool
    {
        global $DB;

        if (method_exists($DB, 'tableExists')) {
            return (bool) $DB->tableExists($table);
        }

        return in_array($table, [
            'glpi_tickets',
            'glpi_knowbaseitems',
            'glpi_items_knowbaseitems',
            'glpi_users',
            'glpi_groups',
            'glpi_entities',
            'glpi_itilcategories',
            'glpi_locations',
            'glpi_tickets_users',
            'glpi_groups_tickets',
            'glpi_requesttypes',
            'glpi_taskcategories',
            'glpi_logs',
        ], true);
    }

    /**
     * @return array<int, array{id:int,name:string,content:string,is_private:int,requesttypes_id:int}>
     */
    public function getFollowupTemplatesForTicket(int $ticketId): array
    {
        if (!$this->canReadTicket($ticketId) || !class_exists('\ITILFollowupTemplate')) {
            return [];
        }

        $template = new \ITILFollowupTemplate();
        $table = \ITILFollowupTemplate::getTable();
        if (!$this->tableExists($table)) {
            return [];
        }

        $criteria = [];
        if ($this->columnExists($table, 'is_active')) {
            $criteria['is_active'] = 1;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB(max(1, $ticketId))) {
            return [];
        }

        $templates = [];
        foreach ($template->find($criteria, 'name ASC', 200) as $row) {
            $templateId = (int) ($row['id'] ?? 0);
            $name = trim((string) ($row['name'] ?? ''));
            if ($templateId <= 0 || $name === '') {
                continue;
            }

            $entityId = (int) ($row['entities_id'] ?? 0);
            $recursive = (bool) ($row['is_recursive'] ?? false);
            $targetEntityId = (int) ($ticket->fields['entities_id'] ?? 0);
            if (!$this->canUseTemplateEntity($entityId, $recursive, $targetEntityId)) {
                continue;
            }

            $loaded = new \ITILFollowupTemplate();
            if (!$loaded->getFromDB($templateId)) {
                continue;
            }
            if (!empty($loaded->fields['is_private']) && !$this->canAddPrivateFollowup()) {
                continue;
            }

            $templates[] = [
                'id' => $templateId,
                'name' => $name,
                'content' => $this->renderFollowupTemplateContentFromItem($loaded, $ticket),
                'is_private' => (int) ($loaded->fields['is_private'] ?? 0),
                'requesttypes_id' => (int) ($loaded->fields['requesttypes_id'] ?? 0),
            ];
        }

        return $templates;
    }

    public function renderFollowupTemplateContent(int $ticketId, int $templateId): string
    {
        if ($templateId <= 0 || !$this->canReadTicket($ticketId) || !class_exists('\ITILFollowupTemplate')) {
            return '';
        }

        $ticket = new \Ticket();
        $template = new \ITILFollowupTemplate();
        if (!$ticket->getFromDB(max(1, $ticketId)) || !$template->getFromDB($templateId)) {
            return '';
        }

        $entityId = (int) ($template->fields['entities_id'] ?? 0);
        $recursive = !empty($template->fields['is_recursive']);
        $targetEntityId = (int) ($ticket->fields['entities_id'] ?? 0);
        if (!$this->canUseTemplateEntity($entityId, $recursive, $targetEntityId)) {
            return '';
        }

        return $this->renderFollowupTemplateContentFromItem($template, $ticket);
    }

    private function canUseFollowupTemplateForTicket(int $ticketId, int $templateId): bool
    {
        if ($templateId <= 0 || !$this->canReadTicket($ticketId) || !class_exists('\ITILFollowupTemplate')) {
            return false;
        }

        $ticket = new \Ticket();
        $template = new \ITILFollowupTemplate();
        if (!$ticket->getFromDB(max(1, $ticketId)) || !$template->getFromDB($templateId)) {
            return false;
        }
        if (!empty($template->fields['is_private']) && !$this->canAddPrivateFollowup()) {
            return false;
        }

        return $this->canUseTemplateEntity(
            (int) ($template->fields['entities_id'] ?? 0),
            !empty($template->fields['is_recursive']),
            (int) ($ticket->fields['entities_id'] ?? 0)
        );
    }

    private function renderFollowupTemplateContentFromItem(\ITILFollowupTemplate $template, \Ticket $ticket): string
    {
        if (method_exists($template, 'getRenderedContent')) {
            return (string) $template->getRenderedContent($ticket);
        }

        return (string) ($template->fields['content'] ?? '');
    }

    private function canUseTemplateEntity(int $entityId, bool $recursive, ?int $targetEntityId = null): bool
    {
        if (class_exists('\Session') && method_exists('\Session', 'haveAccessToEntity')) {
            if (!(bool) \Session::haveAccessToEntity($entityId, $recursive)) {
                return false;
            }
        } elseif (!in_array($entityId, $this->getCurrentEntities(), true)) {
            return false;
        }

        $targetEntityId = $targetEntityId ?? (int) ($_SESSION['glpiactive_entity'] ?? 0);
        if ($targetEntityId === $entityId) {
            return true;
        }
        if (!$recursive || !function_exists('getSonsOf')) {
            return false;
        }

        $descendants = array_map('intval', (array) getSonsOf('glpi_entities', $entityId));
        return in_array($targetEntityId, $descendants, true);
    }

    public function resolveFollowupPrivacy(
        int $ticketId,
        int $followupTemplateId,
        int $requestedPrivacy
    ): int {
        $isPrivate = $requestedPrivacy === 1 ? 1 : 0;
        if (
            $ticketId <= 0
            || $followupTemplateId <= 0
            || !class_exists('\ITILFollowupTemplate')
            || !$this->canUseFollowupTemplateForTicket($ticketId, $followupTemplateId)
        ) {
            return $isPrivate;
        }

        try {
            $template = new \ITILFollowupTemplate();
            if ($template->getFromDB($followupTemplateId) && !empty($template->fields['is_private'])) {
                return 1;
            }
        } catch (\Throwable $e) {
            return $isPrivate;
        }

        return $isPrivate;
    }

    public function addFollowup(
        int $ticketId,
        string $content,
        array $filesPayload = [],
        int $followupTemplateId = 0,
        int $isPrivate = 0
    ): int {
        $isPrivate = $this->resolveFollowupPrivacy($ticketId, $followupTemplateId, $isPrivate);
        if (!$this->canAddFollowupToTicket($ticketId, $isPrivate)) {
            return 0;
        }

        $payload = [
            'itemtype' => 'Ticket',
            'items_id' => $ticketId,
            'content' => $content,
            'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'is_private' => $isPrivate,
        ];

        if ($followupTemplateId > 0 && class_exists('\ITILFollowupTemplate')) {
            if (!$this->canUseFollowupTemplateForTicket($ticketId, $followupTemplateId)) {
                return 0;
            }

            $rendered = $this->renderFollowupTemplateContent($ticketId, $followupTemplateId);
            $payload['_itilfollowuptemplates_id'] = $followupTemplateId;
            $template = new \ITILFollowupTemplate();
            if (!$template->getFromDB($followupTemplateId)) {
                return 0;
            }
            if (!empty($template->fields['is_private'])) {
                $payload['is_private'] = 1;
            }
            if (trim($content) === '') {
                $payload['content'] = $rendered;
            }
        }

        if (trim((string) $payload['content']) === '') {
            return 0;
        }

        foreach (['_filename', '_tag_filename', '_prefix_filename'] as $key) {
            if (!empty($filesPayload[$key]) && is_array($filesPayload[$key])) {
                $payload[$key] = array_values($filesPayload[$key]);
            }
        }

        $followup = new \ITILFollowup();
        return (int) $followup->add($payload);
    }

    public function addTask(int $ticketId, string $content, array $taskInput = [], array $filesPayload = []): int
    {
        $isPrivate = !empty($taskInput['is_private']) ? 1 : 0;
        if (!$this->canAddTaskToTicket($ticketId, $isPrivate)) {
            return 0;
        }

        $taskInput['is_private'] = $isPrivate;
        $currentUserId = (int) ($_SESSION['glpiID'] ?? 0);
        $payload = [
            'tickets_id' => $ticketId,
            'content' => $content,
            'users_id_tech' => max(0, (int) ($taskInput['users_id_tech'] ?? $currentUserId)),
            'state' => max(1, (int) ($taskInput['state'] ?? $this->getDefaultTaskState())),
            'actiontime' => max(0, (int) ($taskInput['actiontime'] ?? 0)),
        ];

        if ($this->columnExists('glpi_tickettasks', 'users_id')) {
            $payload['users_id'] = $currentUserId;
        }
        if ($this->columnExists('glpi_tickettasks', 'groups_id_tech')) {
            $payload['groups_id_tech'] = max(0, (int) ($taskInput['groups_id_tech'] ?? 0));
        }
        if ($this->columnExists('glpi_tickettasks', 'taskcategories_id')) {
            $payload['taskcategories_id'] = max(0, (int) ($taskInput['taskcategories_id'] ?? 0));
        }
        if ($this->columnExists('glpi_tickettasks', 'is_private')) {
            $payload['is_private'] = !empty($taskInput['is_private']) ? 1 : 0;
        }

        $begin = $this->normalizeDateTime((string) ($taskInput['begin'] ?? ''));
        $end = $this->normalizeDateTime((string) ($taskInput['end'] ?? ''));
        if ($begin !== '' && $end === '' && $payload['actiontime'] > 0) {
            $end = date('Y-m-d H:i:s', strtotime($begin) + (int) $payload['actiontime']);
        }
        if ($begin !== '' && $this->columnExists('glpi_tickettasks', 'begin')) {
            $payload['begin'] = $begin;
        }
        if ($end !== '' && $this->columnExists('glpi_tickettasks', 'end')) {
            $payload['end'] = $end;
        }

        foreach (['_filename', '_tag_filename', '_prefix_filename'] as $key) {
            if (!empty($filesPayload[$key]) && is_array($filesPayload[$key])) {
                $payload[$key] = array_values($filesPayload[$key]);
            }
        }

        $task = new \TicketTask();
        return (int) $task->add($payload);
    }

    public function addSolution(int $ticketId, string $content): bool
    {
        if (!$this->canAddSolutionToTicket($ticketId)) {
            return false;
        }

        $solution = new \ITILSolution();
        $ok = (bool) $solution->add([
            'itemtype' => 'Ticket',
            'items_id' => $ticketId,
            'content' => $content,
            'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
        ]);

        if (!$ok) {
            return false;
        }

        $ticket = new \Ticket();
        if ($this->canChangeStatusToTicket($ticketId) && $ticket->getFromDB($ticketId)) {
            return (bool) $ticket->update([
                'id' => $ticketId,
                'status' => $this->solvedStatus(),
            ]);
        }

        return true;
    }

    public function approveSolution(int $ticketId, string $comment = '', array $filesPayload = []): bool
    {
        $this->markLatestSolution($ticketId, $this->acceptedSolutionStatus());

        if (trim($comment) !== '') {
            $this->addFollowup($ticketId, $comment, $filesPayload, 0);
        }

        return $this->updateTicketStatus($ticketId, $this->closedStatus());
    }

    public function refuseSolution(int $ticketId, string $comment, array $filesPayload = []): bool
    {
        $this->markLatestSolution($ticketId, $this->refusedSolutionStatus());
        $this->addFollowup(
            $ticketId,
            sprintf(I18n::translate('Solução recusada: %s'), trim($comment)),
            $filesPayload,
            0
        );

        return $this->updateTicketStatus($ticketId, $this->assignedStatus());
    }

    public function changeStatus(int $ticketId, int $status): bool
    {
        return $this->updateTicketStatus($ticketId, $status, true);
    }

    private function updateTicketStatus(int $ticketId, int $status, bool $requireUpdateRight = false): bool
    {
        $ticket = new \Ticket();
        if (!$ticket->getFromDB(max(1, $ticketId)) || !$ticket->canViewItem()) {
            return false;
        }
        if ($requireUpdateRight && !$this->canChangeStatusToTicket($ticketId)) {
            return false;
        }

        $payload = [
            'id' => $ticketId,
            'status' => $status,
        ];
        if (method_exists($ticket, 'enforceReadonlyFields')) {
            $payload = $ticket->enforceReadonlyFields($payload);
        }

        return (bool) $ticket->update($payload);
    }

    private function markLatestSolution(int $ticketId, int $status): void
    {
        if (!class_exists('\ITILSolution')) {
            return;
        }

        $solution = new \ITILSolution();
        $rows = $solution->find(
            [
                'itemtype' => 'Ticket',
                'items_id' => max(1, $ticketId),
            ],
            'id DESC',
            1
        );
        $row = is_array($rows) ? reset($rows) : false;
        $solutionId = is_array($row) ? (int) ($row['id'] ?? 0) : 0;
        if ($solutionId <= 0) {
            return;
        }

        $payload = [
            'id' => $solutionId,
            'status' => $status,
            'users_id_approval' => (int) ($_SESSION['glpiID'] ?? 0),
            'date_approval' => date('Y-m-d H:i:s'),
        ];

        $solution->update($payload);
    }

    private function solvedStatus(): int
    {
        return defined('\CommonITILObject::SOLVED') ? (int) \CommonITILObject::SOLVED : 5;
    }

    private function closedStatus(): int
    {
        return defined('\CommonITILObject::CLOSED') ? (int) \CommonITILObject::CLOSED : 6;
    }

    private function assignedStatus(): int
    {
        return defined('\CommonITILObject::ASSIGNED') ? (int) \CommonITILObject::ASSIGNED : 2;
    }

    private function acceptedSolutionStatus(): int
    {
        return defined('\ITILSolution::ACCEPTED') ? (int) \ITILSolution::ACCEPTED : 3;
    }

    private function refusedSolutionStatus(): int
    {
        return defined('\ITILSolution::REFUSED') ? (int) \ITILSolution::REFUSED : 4;
    }

    public function updateTicketFields(int $ticketId, array $fields): bool
    {
        $ticketId = max(1, $ticketId);
        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId) || !$ticket->canViewItem()) {
            return false;
        }

        $routingFields = [
            '_users_id_assign', '_users_id_observer',
            '_groups_id_assign', '_groups_id_observer',
        ];
        $containsRoutingFields = false;
        foreach ($routingFields as $routingField) {
            if (array_key_exists($routingField, $fields)) {
                $containsRoutingFields = true;
                break;
            }
        }
        if ($containsRoutingFields) {
            if (!$this->canRouteTicket($ticketId)) {
                return false;
            }
        } elseif (!\Ticket::canUpdate()) {
            return false;
        }

        $groupReplacements = [];
        $groupContracts = [
            '_groups_id_assign' => ['type' => 2, 'capability' => 'is_assign'],
            '_groups_id_observer' => ['type' => 3, 'capability' => 'is_watcher'],
        ];
        foreach ($groupContracts as $field => $contract) {
            if (!array_key_exists($field, $fields)) {
                continue;
            }
            if (!is_array($fields[$field])) {
                return false;
            }
            $ids = array_values(array_unique(array_filter(
                array_map('intval', $fields[$field]),
                static fn(int $id): bool => $id > 0
            )));
            $authorization = $this->authorizedTicketGroupIds(
                $ticket,
                $ids,
                (string) $contract['capability']
            );
            if ($authorization === null) {
                return false;
            }
            $groupReplacements[$field] = [
                'type' => (int) $contract['type'],
                'ids' => $authorization['desired'],
                'removable_ids' => $authorization['allowed'],
            ];
        }

        $payload = ['id' => $ticketId];

        if (isset($fields['urgency'])) {
            $payload['urgency'] = max(1, min(5, (int) $fields['urgency']));
        }
        if (isset($fields['impact'])) {
            $payload['impact'] = max(1, min(5, (int) $fields['impact']));
        }
        if (isset($fields['type'])) {
            $payload['type'] = max(1, (int) $fields['type']);
        }
        if (isset($fields['itilcategories_id'])) {
            $payload['itilcategories_id'] = max(0, (int) $fields['itilcategories_id']);
        }
        if (isset($fields['_users_id_assign']) && is_array($fields['_users_id_assign'])) {
            $payload['_users_id_assign'] = array_values(array_map('intval', $fields['_users_id_assign']));
        }
        if (isset($fields['_users_id_observer']) && is_array($fields['_users_id_observer'])) {
            $payload['_users_id_observer'] = array_values(array_map('intval', $fields['_users_id_observer']));
        }

        if (method_exists($ticket, 'enforceReadonlyFields')) {
            $payload = $ticket->enforceReadonlyFields($payload);
        }

        foreach ($groupReplacements as $field => $replacement) {
            $groupDiff = $this->ticketGroupDiffPayload(
                $ticketId,
                (int) $replacement['type'],
                (array) $replacement['ids'],
                (array) $replacement['removable_ids'],
                $field
            );
            if ($groupDiff === null) {
                return false;
            }
            $payload = array_merge($payload, $groupDiff);
        }

        return count($payload) === 1 || (bool) $ticket->update($payload);
    }

    /**
     * @param int[] $ids
     * @return array{desired:int[],allowed:int[]}|null
     */
    private function authorizedTicketGroupIds(\Ticket $ticket, array $ids, string $capability): ?array
    {
        if (!in_array($capability, ['is_assign', 'is_watcher'], true)) {
            return null;
        }
        $ticketFields = is_array($ticket->fields ?? null) ? $ticket->fields : [];
        if (!array_key_exists('entities_id', $ticketFields)) {
            return null;
        }
        $available = $this->getActorGroups($capability, (int) $ticketFields['entities_id']);
        $allowed = [];
        foreach ($available as $group) {
            $id = (int) ($group['id'] ?? 0);
            if ($id > 0) {
                $allowed[$id] = true;
            }
        }
        foreach ($ids as $id) {
            if (!isset($allowed[$id])) {
                return null;
            }
        }

        return [
            'desired' => $ids,
            'allowed' => array_keys($allowed),
        ];
    }

    /**
     * Build a native actor diff for one group role only. Relation IDs are used
     * for deletions so users, suppliers and the opposite group role survive.
     *
     * @param int[] $desiredIds
     * @param int[] $removableIds
     * @return array<string,mixed>|null
     */
    private function ticketGroupDiffPayload(
        int $ticketId,
        int $type,
        array $desiredIds,
        array $removableIds,
        string $field
    ): ?array {
        $contracts = [
            2 => '_groups_id_assign',
            3 => '_groups_id_observer',
        ];
        if (
            !class_exists('\Group_Ticket')
            || ($contracts[$type] ?? '') !== $field
        ) {
            return null;
        }

        $model = new \Group_Ticket();
        if (!method_exists($model, 'find')) {
            return null;
        }
        $current = [];
        foreach ($model->find(['tickets_id' => $ticketId, 'type' => $type]) as $row) {
            $relationId = (int) ($row['id'] ?? 0);
            $groupId = (int) ($row['groups_id'] ?? 0);
            if ($relationId <= 0 || $groupId <= 0) {
                return null;
            }
            $current[$groupId][] = $relationId;
        }

        $desired = array_fill_keys($desiredIds, true);
        $removable = array_fill_keys($removableIds, true);
        $deleteIds = [];
        foreach ($current as $groupId => $relationIds) {
            if (!isset($desired[$groupId])) {
                if (isset($removable[$groupId])) {
                    array_push($deleteIds, ...$relationIds);
                }
                continue;
            }
            array_push($deleteIds, ...array_slice($relationIds, 1));
        }
        $addIds = array_values(array_filter(
            $desiredIds,
            static fn(int $groupId): bool => !isset($current[$groupId])
        ));

        $payload = [];
        if ($addIds !== []) {
            $payload[$field] = $addIds;
        }
        if ($deleteIds !== []) {
            $payload[$field . '_deleted'] = array_map(
                static fn(int $relationId): array => [
                    'itemtype' => \Group::class,
                    'id' => $relationId,
                ],
                $deleteIds
            );
        }

        return $payload;
    }
    public function canReadTicket(int $ticketId): bool
    {
        $ticket = new \Ticket();
        return $ticket->can(max(1, $ticketId), READ);
    }

    public function canUpdateTicket(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        $ticket = new \Ticket();
        try {
            if (method_exists($ticket, 'can')) {
                return (bool) $ticket->can($ticketId, UPDATE);
            }

            return $ticket->getFromDB($ticketId)
                && $ticket->canViewItem()
                && \Ticket::canUpdate();
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function canRouteTicket(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return false;
        }

        $ticket = new \Ticket();
        try {
            if (!$ticket->getFromDB($ticketId) || !$ticket->canViewItem()) {
                return false;
            }
            if (method_exists($ticket, 'canAssign')) {
                return defined('\Ticket::ASSIGN')
                    ? (((int) ($_SESSION['glpiactiveprofile']['ticket'] ?? 0) & (int) \Ticket::ASSIGN) === (int) \Ticket::ASSIGN)
                    : false;
            }
            if (class_exists('\Session') && method_exists('\Session', 'haveRight')) {
                if (defined('\Ticket::ASSIGN')) {
                    return (bool) \Session::haveRight('ticket', \Ticket::ASSIGN);
                }
                if (defined('\CommonITILObject::ASSIGN')) {
                    return (bool) \Session::haveRight('ticket', \CommonITILObject::ASSIGN);
                }
            }
        } catch (\Throwable $e) {
            return false;
        }

        return false;
    }

    public function canAddFollowupToTicket(int $ticketId, int $isPrivate = 0): bool
    {
        if ($ticketId <= 0 || !$this->canReadTicket($ticketId) || !class_exists('\ITILFollowup')) {
            return false;
        }
        if ($isPrivate === 1 && !$this->canAddPrivateFollowup()) {
            return false;
        }

        try {
            $followup = new \ITILFollowup();
            $input = [
                'itemtype' => 'Ticket',
                'items_id' => $ticketId,
                'content' => 'Verificação de permissão',
                'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'is_private' => $isPrivate === 1 ? 1 : 0,
            ];
            $followup->input = $input;
            $followup->fields = $input;

            if (method_exists($followup, 'can')) {
                return (bool) $followup->can(-1, CREATE, $input);
            }
            if (method_exists($followup, 'canCreateItem')) {
                return (bool) $followup->canCreateItem();
            }
        } catch (\Throwable $e) {
            return false;
        }

        return false;
    }

    public function canAddTaskToTicket(int $ticketId, int $isPrivate = 0): bool
    {
        if ($ticketId <= 0 || !$this->canReadTicket($ticketId) || !class_exists('\TicketTask')) {
            return false;
        }
        if ($isPrivate === 1 && !$this->canAddPrivateTask()) {
            return false;
        }

        try {
            $task = new \TicketTask();
            $input = [
                'tickets_id' => $ticketId,
                'content' => 'Verificação de permissão',
                'users_id_tech' => (int) ($_SESSION['glpiID'] ?? 0),
                'is_private' => $isPrivate === 1 ? 1 : 0,
            ];
            $task->input = $input;
            $task->fields = $input;

            if (method_exists($task, 'can')) {
                return (bool) $task->can(-1, CREATE, $input);
            }
            if (method_exists($task, 'canCreateItem')) {
                return (bool) $task->canCreateItem();
            }
        } catch (\Throwable $e) {
            return false;
        }

        return false;
    }

    public function canAddSolutionToTicket(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId) || !class_exists('\ITILSolution')) {
            return false;
        }

        try {
            $solution = new \ITILSolution();
            $input = [
                'itemtype' => 'Ticket',
                'items_id' => $ticketId,
                'content' => 'Verificação de permissão',
                'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
            ];
            $solution->input = $input;
            $solution->fields = $input;

            if (method_exists($solution, 'can')) {
                return (bool) $solution->can(-1, CREATE, $input);
            }
            if (method_exists($solution, 'canCreateItem')) {
                return (bool) $solution->canCreateItem();
            }
        } catch (\Throwable $e) {
            return false;
        }

        return $this->canUpdateTicket($ticketId);
    }

    public function canChangeStatusToTicket(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canUpdateTicket($ticketId)) {
            return false;
        }

        if (!class_exists('\Ticket') || !method_exists('\Ticket', 'canUpdate') || !\Ticket::canUpdate()) {
            return false;
        }

        return $this->getAllowedStatusTransitions($ticketId) !== [];
    }

    /**
     * Return only transitions accepted by the native GLPI status matrix.
     *
     * @return int[]
     */
    public function getAllowedStatusTransitions(int $ticketId): array
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return [];
        }

        $ticket = new \Ticket();
        try {
            if (!$ticket->getFromDB($ticketId)) {
                return [];
            }
            $currentStatus = (int) ($ticket->fields['status'] ?? 0);
            if ($currentStatus <= 0 || !class_exists('\Ticket') || !method_exists('\Ticket', 'getAllowedStatusArray')) {
                return [];
            }

            $allowed = (array) \Ticket::getAllowedStatusArray($currentStatus);
            $transitions = [];
            foreach ($allowed as $key => $value) {
                $candidate = is_int($key) || ctype_digit((string) $key) ? (int) $key : (int) $value;
                if ($candidate > 0 && $candidate !== $currentStatus) {
                    $transitions[] = $candidate;
                }
            }

            return array_values(array_unique($transitions));
        } catch (\Throwable $e) {
            return [];
        }
    }

    public function isStatusTransitionAllowed(int $ticketId, int $newStatus): bool
    {
        $ticketId = max(1, $ticketId);
        $newStatus = (int) $newStatus;
        if ($newStatus <= 0 || !$this->canChangeStatusToTicket($ticketId)) {
            return false;
        }

        return in_array($newStatus, $this->getAllowedStatusTransitions($ticketId), true);
    }

    /**
     * @return array<int, array{id:int,name:string}>
     */
    private function getTicketAssignedGroups(int $ticketId): array
    {
        if (!class_exists('\Group_Ticket')) {
            return [];
        }

        $ticketId = max(1, $ticketId);
        $groups = [];
        $groupTicket = new \Group_Ticket();
        foreach ($groupTicket->find(['tickets_id' => $ticketId, 'type' => 2]) as $row) {
            $groupId = (int) ($row['groups_id'] ?? 0);
            if ($groupId > 0) {
                $groups[] = [
                    'id' => $groupId,
                    'name' => $this->resolveGroupName($groupId),
                ];
            }
        }

        usort($groups, static fn(array $left, array $right): int => strcasecmp((string) ($left['name'] ?? ''), (string) ($right['name'] ?? '')));

        return $groups;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function getTicketCreationFieldRequirements(): array
    {
        $fields = [];
        foreach (TicketCreationPolicy::SUPPORTED_CREATE_FIELDS as $field) {
            $fields[$field] = [
                'label' => TicketCreationPolicy::fieldLabel($field),
                'required' => in_array($field, ['name', 'content', 'type', 'urgency', 'impact'], true),
                'visible' => true,
                'readonly' => false,
                'source' => 'portal_default',
            ];
        }

        return $fields;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function getTicketTemplates(): array
    {
        if (!class_exists('\TicketTemplate')) {
            return [];
        }

        $template = new \TicketTemplate();
        $table = method_exists('\TicketTemplate', 'getTable') ? (string) \TicketTemplate::getTable() : 'glpi_tickettemplates';
        if (!$this->tableExists($table)) {
            return [];
        }

        $criteria = [];
        if ($this->columnExists($table, 'is_active')) {
            $criteria['is_active'] = 1;
        }

        $templates = [];
        foreach ($template->find($criteria, 'name ASC', 80) as $row) {
            $id = (int) ($row['id'] ?? 0);
            $name = trim((string) ($row['name'] ?? ''));
            if ($id <= 0 || $name === '') {
                continue;
            }
            $entityId = (int) ($row['entities_id'] ?? 0);
            $recursive = (bool) ($row['is_recursive'] ?? false);
            if (!$this->canUseTemplateEntity($entityId, $recursive)) {
                continue;
            }

            $metadata = $this->getTicketTemplateMetadata($id);
            if ($metadata !== null) {
                $templates[] = $metadata;
            }
        }

        return $templates;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getTicketTemplateMetadata(int $templateId): ?array
    {
        if ($templateId <= 0 || !class_exists('\TicketTemplate')) {
            return null;
        }

        try {
            $template = new \TicketTemplate();
            $loaded = method_exists($template, 'getFromDBWithData')
                ? $template->getFromDBWithData($templateId)
                : $template->getFromDB($templateId);
            if (!$loaded) {
                return null;
            }

            $entityId = (int) ($template->fields['entities_id'] ?? 0);
            $recursive = !empty($template->fields['is_recursive']);
            if (!$this->canUseTemplateEntity($entityId, $recursive)) {
                return null;
            }

            $mandatory = $this->normalizeTicketTemplateFieldList($template->mandatory ?? []);
            $hidden = $this->normalizeTicketTemplateFieldList($template->hidden ?? []);
            $readonly = $this->normalizeTicketTemplateFieldList($template->readonly ?? []);
            $predefined = $this->normalizeTicketTemplatePredefinedFields((array) ($template->predefined ?? []));
            $policy = new TicketCreationPolicy();
            $unsupportedRequired = $policy->unsupportedMandatoryFields($mandatory);
            $fieldRequirements = [];
            foreach ($mandatory as $field) {
                $fieldRequirements[$field] = [
                    'label' => TicketCreationPolicy::fieldLabel($field),
                    'required' => true,
                    'visible' => !in_array($field, $hidden, true),
                    'readonly' => in_array($field, $readonly, true),
                    'source' => 'ticket_template',
                ];
            }

            $supportedPredefined = [];
            $supported = array_fill_keys(TicketCreationPolicy::SUPPORTED_CREATE_FIELDS, true);
            foreach ($predefined as $field => $value) {
                if (isset($supported[(string) $field])) {
                    $supportedPredefined[(string) $field] = $value;
                }
            }

            return [
                'id' => $templateId,
                'label' => TextNormalizer::fromGlpi((string) ($template->fields['name'] ?? ('Modelo #' . $templateId))),
                'field_requirements' => $fieldRequirements,
                'mandatory_fields' => $mandatory,
                'hidden_fields' => $hidden,
                'readonly_fields' => $readonly,
                'predefined' => $supportedPredefined,
                'unsupported_required' => $unsupportedRequired,
                'requires_native_fallback' => $unsupportedRequired !== [],
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * @return string[]
     */
    private function normalizeTicketTemplateFieldList(mixed $fields): array
    {
        if (!is_array($fields)) {
            return [];
        }

        $normalized = [];
        foreach ($fields as $key => $value) {
            $field = '';
            if (is_string($key) && !ctype_digit($key)) {
                $field = $key;
            } elseif (is_array($value)) {
                foreach (['field', 'name', 'num'] as $candidateKey) {
                    if (isset($value[$candidateKey]) && is_scalar($value[$candidateKey])) {
                        $field = $this->resolveTicketTemplateFieldName($value[$candidateKey]);
                        break;
                    }
                }
            } elseif (is_scalar($value)) {
                $field = $this->resolveTicketTemplateFieldName($value);
            }

            $field = trim($field);
            if ($field !== '') {
                $normalized[$field] = $field;
            }
        }

        return array_values($normalized);
    }

    /**
     * @param array<string|int, mixed> $predefined
     * @return array<string, mixed>
     */
    private function normalizeTicketTemplatePredefinedFields(array $predefined): array
    {
        $normalized = [];
        foreach ($predefined as $field => $value) {
            $resolved = $this->resolveTicketTemplateFieldName($field);
            if ($resolved === '') {
                continue;
            }
            $normalized[$resolved] = $value;
        }

        return $normalized;
    }

    private function resolveTicketTemplateFieldName(mixed $field): string
    {
        if (!is_scalar($field)) {
            return '';
        }

        $field = trim((string) $field);
        if ($field === '') {
            return '';
        }

        if (ctype_digit($field)) {
            $resolved = $this->ticketSearchOptionToCreateField((int) $field);
            return $resolved !== '' ? $resolved : 'search_option_' . $field;
        }

        return $field;
    }

    private function ticketSearchOptionToCreateField(int $optionNumber): string
    {
        if ($optionNumber <= 0 || !class_exists('\Search') || !class_exists('\Ticket') || !method_exists('\Search', 'getOptions')) {
            return '';
        }

        $supported = array_fill_keys(TicketCreationPolicy::SUPPORTED_CREATE_FIELDS, true);
        $tableMap = [
            'glpi_itilcategories' => 'itilcategories_id',
            'glpi_locations' => 'locations_id',
            'glpi_requesttypes' => 'requesttypes_id',
            'glpi_groups' => '_groups_id_assign',
            'glpi_users' => '_users_id_assign',
        ];

        $options = (array) \Search::getOptions(\Ticket::class);
        $option = is_array($options[$optionNumber] ?? null) ? $options[$optionNumber] : null;
        if ($option === null) {
            return '';
        }

        foreach (['linkfield', 'field'] as $key) {
            $candidate = trim((string) ($option[$key] ?? ''));
            if ($candidate !== '' && isset($supported[$candidate])) {
                return $candidate;
            }
        }

        $table = trim((string) ($option['table'] ?? ''));
        if ($table !== '' && isset($tableMap[$table])) {
            return $tableMap[$table];
        }

        return '';
    }

    /**
     * @return array<string, mixed>
     */
    private function getServiceCatalogContext(): array
    {
        global $CFG_GLPI;

        $available = class_exists('\Glpi\Form\ServiceCatalog\ServiceCatalog')
            || class_exists('\Glpi\Controller\ServiceCatalog\IndexController');
        $enabled = false;
        $entityId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        if ($available && class_exists('\Entity') && $entityId >= 0) {
            try {
                $entity = new \Entity();
                if ($entity->getFromDB($entityId) && method_exists($entity, 'isServiceCatalogEnabled')) {
                    $enabled = (bool) $entity->isServiceCatalogEnabled();
                }
            } catch (\Throwable $e) {
                $enabled = false;
            }
        }

        return [
            'available' => $available,
            'enabled' => $enabled,
            'url' => (string) ($CFG_GLPI['root_doc'] ?? '') . '/ServiceCatalog',
            'message' => $available
                ? I18n::translate('O GLPI 11 possui Catálogo de Serviços. Use o fluxo nativo quando a solicitação exigir formulário dinâmico ainda não representado aqui.')
                : I18n::translate('Catálogo de Serviços não disponível nesta versão/instalação do GLPI.'),
        ];
    }

    /**
     * @return array<int, string>
     */
    private function getTicketCreatePortalLimitations(): array
    {
        return [
            I18n::translate('Campos dinâmicos de catálogo GLPI 11 ainda usam fallback para o fluxo nativo.'),
            I18n::translate('Modelos ITIL com campos obrigatórios fora do formulário acessível são bloqueados e encaminhados ao GLPI nativo.'),
        ];
    }

    public function createTicket(array $input): int
    {
        $ticket = new \Ticket();

        if (!$ticket::canCreate()) {
            throw new \RuntimeException(I18n::translate('Usuário sem permissão para criar chamado.'));
        }

        $payload = [
            'name' => (string) ($input['name'] ?? ''),
            'content' => (string) ($input['content'] ?? ''),
            'type' => (int) ($input['type'] ?? $this->getDefaultTicketType()),
            'itilcategories_id' => max(0, (int) ($input['itilcategories_id'] ?? 0)),
            'locations_id' => max(0, (int) ($input['locations_id'] ?? 0)),
            'urgency' => (int) ($input['urgency'] ?? 3),
            'impact' => (int) ($input['impact'] ?? 3),
            'entities_id' => $this->getConcreteActiveEntityId(),
            '_users_id_requester' => [(int) ($_SESSION['glpiID'] ?? 0)],
        ];

        if (!empty($input['_users_id_assign']) && is_array($input['_users_id_assign'])) {
            $payload['_users_id_assign'] = array_values(array_map('intval', $input['_users_id_assign']));
        }
        if (!empty($input['_users_id_observer']) && is_array($input['_users_id_observer'])) {
            $payload['_users_id_observer'] = array_values(array_map('intval', $input['_users_id_observer']));
        }
        if (!empty($input['_groups_id_assign']) && is_array($input['_groups_id_assign'])) {
            $payload['_groups_id_assign'] = array_values(array_map('intval', $input['_groups_id_assign']));
        }
        if (!empty($input['_groups_id_observer']) && is_array($input['_groups_id_observer'])) {
            $payload['_groups_id_observer'] = array_values(array_map('intval', $input['_groups_id_observer']));
        }
        if (!empty($input['requesttypes_id']) && $this->ticketSupportsRequestSource()) {
            $payload['requesttypes_id'] = (int) $input['requesttypes_id'];
        }
        if (isset($input['externalid']) && trim((string) $input['externalid']) !== '' && $this->ticketSupportsExternalId()) {
            $payload['externalid'] = trim((string) $input['externalid']);
        }
        if (!empty($input['tickettemplates_id']) && class_exists('\TicketTemplate')) {
            $templateId = (int) $input['tickettemplates_id'];
            if ($this->getTicketTemplateMetadata($templateId) === null) {
                throw new \RuntimeException(I18n::translate('Modelo de chamado inválido para a entidade ativa.'));
            }

            $templateField = method_exists('\TicketTemplate', 'getForeignKeyField') ? \TicketTemplate::getForeignKeyField() : 'tickettemplates_id';
            $payload[$templateField] = $templateId;
        }
        $filePayload = [];
        foreach (['_filename', '_tag_filename', '_prefix_filename'] as $key) {
            if (!empty($input[$key]) && is_array($input[$key])) {
                $filePayload[$key] = array_values($input[$key]);
                $payload[$key] = $filePayload[$key];
            }
        }

        if (method_exists($ticket, 'check')) {
            $ticket->check(-1, CREATE, $payload);
        }

        if (method_exists($ticket, 'enforceReadonlyFields')) {
            $payload = $ticket->enforceReadonlyFields($payload, true);
            foreach ($filePayload as $key => $value) {
                $payload[$key] = $value;
            }
        }

        $newId = $ticket->add($payload);
        if (!$newId) {
            throw new \RuntimeException(I18n::translate('Não foi possível registrar o chamado no GLPI.'));
        }

        return (int) $newId;
    }

    /**
     * @return int[]
     */
    private function getCurrentEntities(): array
    {
        $activeEntities = $_SESSION['glpiactiveentities'] ?? null;
        if (is_array($activeEntities)) {
            $entities = [];
            foreach ($activeEntities as $key => $value) {
                $candidate = is_int($value) || ctype_digit((string) $value) ? (int) $value : (is_int($key) || ctype_digit((string) $key) ? (int) $key : 0);
                if ($candidate >= 0) {
                    $entities[$candidate] = $candidate;
                }
            }
            if ($entities !== []) {
                return array_values($entities);
            }
        } elseif (is_string($activeEntities) && trim($activeEntities) !== '') {
            $entities = array_values(array_unique(array_filter(array_map('intval', preg_split('/[;,]/', $activeEntities) ?: []))));
            if ($entities !== []) {
                return $entities;
            }
        }

        $activeEntity = $this->getConcreteActiveEntityId();
        $recursive = !empty($_SESSION['glpiactive_entity_recursive']);
        if ($recursive && function_exists('getSonsOf')) {
            $entities = array_map('intval', (array) getSonsOf('glpi_entities', $activeEntity));
            if ($entities !== []) {
                return array_values(array_unique($entities));
            }
        }

        return [$activeEntity];
    }

    private function getConcreteActiveEntityId(): int
    {
        $entityId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        if (class_exists('\Session') && method_exists('\Session', 'haveAccessToEntity')) {
            if (!(bool) \Session::haveAccessToEntity($entityId, false)) {
                throw new \RuntimeException(I18n::translate('Selecione uma entidade concreta permitida antes de criar ou consultar chamados.'));
            }
        }

        if (class_exists('\Entity')) {
            $entity = new \Entity();
            if (!$entity->getFromDB($entityId)) {
                throw new \RuntimeException(I18n::translate('A entidade ativa não existe ou não está disponível neste contexto.'));
            }
        }

        return $entityId;
    }

    private function getEntityName(int $entityId): string
    {
        if (class_exists('\Entity')) {
            $entity = new \Entity();
            if ($entity->getFromDB($entityId)) {
                return TextNormalizer::fromGlpi((string) ($entity->fields['completename'] ?? $entity->fields['name'] ?? ('Entidade ' . $entityId)));
            }
        }

        return 'Entidade ' . $entityId;
    }

    private function getCurrentUserName(): string
    {
        $userId = (int) ($_SESSION['glpiID'] ?? 0);
        if ($userId <= 0 || !class_exists('\User')) {
            return (string) ($_SESSION['glpiname'] ?? I18n::translate('Usuário atual'));
        }

        $user = new \User();
        if (!$user->getFromDB($userId)) {
            return (string) ($_SESSION['glpiname'] ?? I18n::translate('Usuário atual'));
        }

        $parts = array_filter([
            trim((string) ($user->fields['firstname'] ?? '')),
            trim((string) ($user->fields['realname'] ?? '')),
        ]);

        if ($parts !== []) {
            return implode(' ', $parts);
        }

        return (string) ($user->fields['name'] ?? $_SESSION['glpiname'] ?? I18n::translate('Usuário atual'));
    }

    private function getTicketTypeOptions(): array
    {
        return [
            ['id' => $this->getIncidentTicketType(), 'label' => I18n::translate('Incidente')],
            ['id' => $this->getDemandTicketType(), 'label' => I18n::translate('Requisição')],
        ];
    }

    private function getUrgencyOptions(): array
    {
        return [
            ['id' => 1, 'label' => I18n::translate('Muito baixa')],
            ['id' => 2, 'label' => I18n::translate('Baixa')],
            ['id' => 3, 'label' => I18n::translate('Média')],
            ['id' => 4, 'label' => I18n::translate('Alta')],
            ['id' => 5, 'label' => I18n::translate('Muito alta')],
        ];
    }

    private function getImpactOptions(): array
    {
        return [
            ['id' => 1, 'label' => I18n::translate('Muito baixo')],
            ['id' => 2, 'label' => I18n::translate('Baixo')],
            ['id' => 3, 'label' => I18n::translate('Médio')],
            ['id' => 4, 'label' => I18n::translate('Alto')],
            ['id' => 5, 'label' => I18n::translate('Muito alto')],
        ];
    }

    private function nativeDropdownCriteria(string $table): array
    {
        $criteria = [];
        if ($this->columnExists($table, 'is_deleted')) {
            $criteria['is_deleted'] = 0;
        }

        return $criteria;
    }

    private function dropdownVisibleInCurrentEntity(array $row): bool
    {
        if (!isset($row['entities_id'])) {
            return true;
        }

        $entityId = (int) ($row['entities_id'] ?? 0);
        if (in_array($entityId, $this->getCurrentEntities(), true)) {
            return true;
        }

        return !empty($row['is_recursive']);
    }

    /**
     * @return array<int, array{id:int,label:string}>
     */
    public function getTaskCategories(): array
    {
        if (!class_exists('\TaskCategory') || !$this->tableExists('glpi_taskcategories')) {
            return [];
        }

        $category = new \TaskCategory();
        $criteria = $this->nativeDropdownCriteria('glpi_taskcategories');
        $rows = [];
        foreach ($category->find($criteria, 'completename ASC, name ASC') as $row) {
            if (!$this->dropdownVisibleInCurrentEntity($row)) {
                continue;
            }

            $id = (int) ($row['id'] ?? 0);
            $label = TextNormalizer::fromGlpi((string) ($row['completename'] ?? $row['name'] ?? ''));
            if ($id > 0 && $label !== '') {
                $rows[] = ['id' => $id, 'label' => $label];
            }
        }

        return $rows;
    }

    /**
     * @return array<int, array{id:int,label:string}>
     */
    public function getTaskStateOptions(): array
    {
        $states = [];
        $candidates = [
            'INFO' => I18n::translate('Informação'),
            'TODO' => I18n::translate('A fazer'),
            'DONE' => I18n::translate('Feita'),
        ];

        if (class_exists('\Planning')) {
            foreach ($candidates as $constant => $fallback) {
                $constantName = \Planning::class . '::' . $constant;
                if (!defined($constantName)) {
                    continue;
                }

                $value = (int) constant($constantName);
                $label = $fallback;
                if (method_exists('\Planning', 'getState')) {
                    $nativeLabel = trim((string) \Planning::getState($value));
                    if ($nativeLabel !== '') {
                        $label = $nativeLabel;
                    }
                }
                $states[] = ['id' => $value, 'label' => $label];
            }
        }

        return $states !== []
            ? $states
            : [
                ['id' => 1, 'label' => I18n::translate('Informação')],
                ['id' => 2, 'label' => I18n::translate('A fazer')],
                ['id' => 3, 'label' => I18n::translate('Feita')],
            ];
    }

    /**
     * @return array<int, array{id:int,label:string}>
     */
    public function getTaskDurationOptions(): array
    {
        return [
            ['id' => 0, 'label' => I18n::translate('Não informar')],
            ['id' => 900, 'label' => I18n::translate('15 minutos')],
            ['id' => 1800, 'label' => I18n::translate('30 minutos')],
            ['id' => 3600, 'label' => I18n::translate('1 hora')],
            ['id' => 7200, 'label' => I18n::translate('2 horas')],
            ['id' => 14400, 'label' => I18n::translate('4 horas')],
            ['id' => 28800, 'label' => I18n::translate('8 horas')],
        ];
    }

    private function getDefaultTaskState(): int
    {
        return defined(\Planning::class . '::TODO') ? (int) \Planning::TODO : 2;
    }

    private function normalizeDateTime(string $value): string
    {
        $value = trim(str_replace('T', ' ', $value));
        if ($value === '') {
            return '';
        }

        $timestamp = strtotime($value);
        if ($timestamp === false) {
            return '';
        }

        return date('Y-m-d H:i:s', $timestamp);
    }

    private function getTicketCategories(): array
    {
        if (!class_exists('\ITILCategory')) {
            return [];
        }

        $category = new \ITILCategory();
        $criteria = $this->nativeDropdownCriteria('glpi_itilcategories');
        $rows = [];
        foreach ($category->find($criteria, 'completename ASC') as $row) {
            if (!$this->dropdownVisibleInCurrentEntity($row)) {
                continue;
            }

            $rows[] = [
                'id' => (int) ($row['id'] ?? 0),
                'label' => TextNormalizer::fromGlpi((string) ($row['completename'] ?? $row['name'] ?? '')),
                'is_incident' => !isset($row['is_incident']) || (int) $row['is_incident'] === 1,
                'is_request' => !isset($row['is_request']) || (int) $row['is_request'] === 1,
            ];
        }

        return $rows;
    }

    private function getTicketLocations(): array
    {
        if (!class_exists('\Location')) {
            return [];
        }

        $location = new \Location();
        $criteria = $this->nativeDropdownCriteria('glpi_locations');
        $rows = [];
        foreach ($location->find($criteria, 'completename ASC') as $row) {
            if (!$this->dropdownVisibleInCurrentEntity($row)) {
                continue;
            }

            $rows[] = [
                'id' => (int) ($row['id'] ?? 0),
                'label' => TextNormalizer::fromGlpi((string) ($row['completename'] ?? $row['name'] ?? '')),
            ];
        }

        return $rows;
    }

    private function resolveTicketCategoryName(int $categoryId): string
    {
        if ($categoryId <= 0) {
            return I18n::translate('Não informado');
        }

        if (class_exists('\Dropdown') && method_exists('\Dropdown', 'getDropdownName')) {
            $label = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName('glpi_itilcategories', $categoryId));
            if ($label !== '') {
                return $label;
            }
        }

        return sprintf(I18n::translate('Categoria %d'), $categoryId);
    }

    private function resolveTicketLocationName(int $locationId): string
    {
        if ($locationId <= 0) {
            return I18n::translate('Não informado');
        }

        if (class_exists('\Dropdown') && method_exists('\Dropdown', 'getDropdownName')) {
            $label = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName('glpi_locations', $locationId));
            if ($label !== '') {
                return $label;
            }
        }

        return sprintf(I18n::translate('Localização %d'), $locationId);
    }

    private function getIncidentTicketType(): int
    {
        return defined(\Ticket::class . '::INCIDENT_TYPE') ? (int) \Ticket::INCIDENT_TYPE : 1;
    }

    private function getDemandTicketType(): int
    {
        return defined(\Ticket::class . '::DEMAND_TYPE') ? (int) \Ticket::DEMAND_TYPE : 2;
    }

    private function getDefaultTicketType(): int
    {
        return $this->getIncidentTicketType();
    }

    private function getAssignableUsers(): array
    {
        if (!class_exists('\User')) {
            return [];
        }

        $user = new \User();
        $criteria = [];
        if ($this->columnExists('glpi_users', 'is_deleted')) {
            $criteria['is_deleted'] = 0;
        }
        if ($this->columnExists('glpi_users', 'is_active')) {
            $criteria['is_active'] = 1;
        }

        $rows = [];
        foreach ($user->find($criteria, 'realname ASC, firstname ASC, name ASC', 250) as $row) {
            $id = (int) ($row['id'] ?? 0);
            if ($id <= 0) {
                continue;
            }
            if (method_exists($user, 'can') && !$user->can($id, READ)) {
                continue;
            }

            $rows[] = [
                'id' => $id,
                'label' => $this->formatUserName($row, $id),
            ];
        }

        return $rows;
    }

    private function getAssignableGroups(?int $targetEntityId = null): array
    {
        return $this->getActorGroups('is_assign', $targetEntityId);
    }

    private function getObserverGroups(?int $targetEntityId = null): array
    {
        return $this->getActorGroups('is_watcher', $targetEntityId);
    }

    /**
     * @return array<int, array{id:int,label:string}>
     */
    private function getActorGroups(string $capabilityColumn, ?int $targetEntityId = null): array
    {
        if (
            !class_exists('\Group')
            || !$this->tableExists('glpi_groups')
            || !in_array($capabilityColumn, ['is_assign', 'is_watcher'], true)
        ) {
            return [];
        }

        $group = new \Group();
        $criteria = [];
        if ($this->columnExists('glpi_groups', 'is_deleted')) {
            $criteria['is_deleted'] = 0;
        }
        if ($this->columnExists('glpi_groups', 'is_active')) {
            $criteria['is_active'] = 1;
        }
        if ($this->columnExists('glpi_groups', $capabilityColumn)) {
            $criteria[$capabilityColumn] = 1;
        }

        $rows = [];
        $targetEntityId ??= $this->getConcreteActiveEntityId();
        foreach ($group->find($criteria, 'completename ASC') as $row) {
            $visible = $this->canUseTemplateEntity(
                (int) ($row['entities_id'] ?? 0),
                !empty($row['is_recursive']),
                $targetEntityId
            );
            if (!$visible) {
                continue;
            }

            $id = (int) ($row['id'] ?? 0);
            $label = TextNormalizer::fromGlpi(
                (string) ($row['completename'] ?? $row['name'] ?? '')
            );
            if ($id <= 0 || $label === '') {
                continue;
            }
            $rows[] = [
                'id' => $id,
                'label' => $label,
            ];
        }

        return $rows;
    }

    private function getRequestSourceOptions(): array
    {
        if (class_exists('\RequestType')) {
            $requestType = new \RequestType();
            $rows = [];
            $criteria = [];
            if ($this->columnExists('glpi_requesttypes', 'is_active')) {
                $criteria['is_active'] = 1;
            }
            foreach ($requestType->find($criteria, 'name ASC') as $row) {
                $id = (int) ($row['id'] ?? 0);
                $label = trim((string) ($row['name'] ?? ''));
                if ($id > 0 && $label !== '') {
                    $rows[] = ['id' => $id, 'label' => $label];
                }
            }
            if ($rows !== []) {
                return $rows;
            }
        }

        return [
            ['id' => 1, 'label' => I18n::translate('Central de atendimento')],
            ['id' => 2, 'label' => 'Email'],
            ['id' => 3, 'label' => 'Telefone'],
            ['id' => 4, 'label' => 'Fax'],
            ['id' => 6, 'label' => 'Outro'],
        ];
    }

    private function getDefaultRequestSourceId(): int
    {
        return 1;
    }

    private function resolveRequestSourceLabel(int $requestSourceId): string
    {
        foreach ($this->getRequestSourceOptions() as $option) {
            if ((int) ($option['id'] ?? 0) === $requestSourceId) {
                return (string) ($option['label'] ?? I18n::translate('Central de atendimento'));
            }
        }

        return I18n::translate('Central de atendimento');
    }

    private function computePriorityPreview(int $urgency, int $impact): array
    {
        $urgency = max(1, min(5, $urgency));
        $impact = max(1, min(5, $impact));
        $score = $urgency + $impact;

        $label = match (true) {
            $score <= 3 => I18n::translate('Muito baixa'),
            $score <= 5 => I18n::translate('Baixa'),
            $score <= 7 => I18n::translate('Média'),
            $score <= 9 => I18n::translate('Alta'),
            default => I18n::translate('Muito alta'),
        };

        return [
            'score' => $score,
            'label' => $label,
        ];
    }

    private function ticketSupportsExternalId(): bool
    {
        if (!$this->tableExists('glpi_tickets')) {
            return false;
        }

        return in_array('externalid', $this->getTableColumns('glpi_tickets'), true);
    }

    private function ticketSupportsRequestSource(): bool
    {
        if (!$this->tableExists('glpi_tickets')) {
            return false;
        }

        return in_array('requesttypes_id', $this->getTableColumns('glpi_tickets'), true);
    }
}
