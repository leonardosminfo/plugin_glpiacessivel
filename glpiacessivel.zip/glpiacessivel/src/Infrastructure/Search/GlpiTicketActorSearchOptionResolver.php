<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Resolves the native Ticket actor Search Options from their relation metadata.
 *
 * GLPI 10 and 11 expose actors as glpi_users.name and describe the
 * glpi_tickets_users relation inside joinparams.beforejoin. Search Option
 * numbers and translated labels are deliberately not part of this contract.
 */
final class GlpiTicketActorSearchOptionResolver
{
    public const REQUESTER = 1;
    public const ASSIGNEE = 2;
    public const OBSERVER = 3;

    /**
     * @param array<int|string,mixed>|null $options
     * @return array{supported:bool,options:array<int,int>,error_code:string}
     */
    public function resolve(?array $options = null): array
    {
        if ($options === null) {
            if (!class_exists('\Search') || !method_exists('\Search', 'getOptions')) {
                return $this->unsupported('actor_search_catalog_unavailable');
            }
            $options = (array) \Search::getOptions(class_exists('\Ticket') ? \Ticket::class : 'Ticket');
        }

        $matches = [
            self::REQUESTER => [],
            self::ASSIGNEE => [],
            self::OBSERVER => [],
        ];
        foreach ($options as $number => $option) {
            if (!is_numeric($number) || !is_array($option)) {
                continue;
            }
            $role = $this->roleForOption($option);
            if ($role === null) {
                continue;
            }
            $matches[$role][] = (int) $number;
        }

        $resolved = [];
        foreach ($matches as $role => $numbers) {
            $numbers = array_values(array_unique(array_filter($numbers, static fn(int $id): bool => $id > 0)));
            if ($numbers === []) {
                return $this->unsupported('actor_search_option_missing');
            }
            if (count($numbers) !== 1) {
                return $this->unsupported('actor_search_option_ambiguous');
            }
            $resolved[(int) $role] = $numbers[0];
        }

        ksort($resolved);
        return ['supported' => true, 'options' => $resolved, 'error_code' => 'ready'];
    }

    /**
     * @param array<int|string,mixed>|null $options
     * @return array{supported:bool,criteria:array<int,array<string,mixed>>,error_code:string}
     */
    public function compileMineCriteria(int $userId, ?array $options = null): array
    {
        if ($userId <= 0) {
            return ['supported' => false, 'criteria' => [], 'error_code' => 'current_user_unavailable'];
        }

        $resolved = $this->resolve($options);
        if (!$resolved['supported']) {
            return [
                'supported' => false,
                'criteria' => [],
                'error_code' => $resolved['error_code'],
            ];
        }

        $alternatives = [];
        foreach ([self::REQUESTER, self::ASSIGNEE, self::OBSERVER] as $index => $role) {
            $alternatives[] = [
                'link' => $index === 0 ? 'AND' : 'OR',
                'field' => $resolved['options'][$role],
                'searchtype' => 'equals',
                'value' => (string) $userId,
            ];
        }

        return [
            'supported' => true,
            'criteria' => [[
                'link' => 'AND',
                'criteria' => $alternatives,
            ]],
            'error_code' => 'ready',
        ];
    }

    /** @param array<string,mixed> $option */
    public function roleForOption(array $option): ?int
    {
        if (
            strtolower(trim((string) ($option['table'] ?? ''))) !== 'glpi_users'
            || strtolower(trim((string) ($option['field'] ?? ''))) !== 'name'
        ) {
            return null;
        }

        $relationFound = false;
        $roles = [];
        $this->inspectJoinMetadata((array) ($option['joinparams'] ?? []), $relationFound, $roles);
        $roles = array_values(array_unique($roles));
        if (!$relationFound || count($roles) !== 1) {
            return null;
        }

        return in_array($roles[0], [self::REQUESTER, self::ASSIGNEE, self::OBSERVER], true)
            ? $roles[0]
            : null;
    }

    /**
     * @param array<int|string,mixed> $node
     * @param int[] $roles
     */
    private function inspectJoinMetadata(array $node, bool &$relationFound, array &$roles): void
    {
        foreach ($node as $key => $value) {
            if (is_string($key) && strtolower($key) === 'table' && is_string($value)) {
                if (strtolower($value) === 'glpi_tickets_users') {
                    $relationFound = true;
                }
            }

            if (is_string($key) && $this->isActorTypeCondition($key)) {
                $role = $this->integerConditionValue($value);
                if ($role !== null) {
                    $roles[] = $role;
                }
            }

            if (is_array($value)) {
                $this->inspectJoinMetadata($value, $relationFound, $roles);
            }
        }
    }

    private function isActorTypeCondition(string $key): bool
    {
        $key = strtolower(trim($key));
        return $key === 'newtable.type'
            || $key === 'glpi_tickets_users.type'
            || $key === 'tickets_users.type';
    }

    /** @param mixed $value */
    private function integerConditionValue($value): ?int
    {
        if (is_numeric($value)) {
            return (int) $value;
        }
        if (!is_array($value)) {
            return null;
        }

        foreach ($value as $nested) {
            if (is_numeric($nested)) {
                return (int) $nested;
            }
        }
        return null;
    }

    /** @return array{supported:bool,options:array<int,int>,error_code:string} */
    private function unsupported(string $errorCode): array
    {
        return ['supported' => false, 'options' => [], 'error_code' => $errorCode];
    }
}
