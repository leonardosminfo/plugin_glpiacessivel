<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Permission-aware autocomplete provider for native GLPI search options.
 *
 * The client identifies only an itemtype and a numeric search option. Backing
 * tables and linked itemtypes are always recovered from the contextual catalog.
 */
final class GlpiSearchValueProvider
{
    public const CONTRACT = 'search_option_value';
    public const VERSION = 1;
    public const PAGE_SIZE = 25;
    public const MIN_QUERY_LENGTH = 2;
    public const MAX_QUERY_LENGTH = 120;
    public const MAX_PAGE = 100;

    /** @var array<string,string> */
    private const CORE_TABLE_ITEMTYPES = [
        'glpi_users' => 'User',
        'glpi_groups' => 'Group',
        'glpi_entities' => 'Entity',
        'glpi_itilcategories' => 'ITILCategory',
        'glpi_locations' => 'Location',
    ];

    private GlpiSearchOptionCatalog $catalog;

    /** @var null|\Closure(string,string,int,int,?int,array<string,mixed>):mixed */
    private ?\Closure $nativeLookup;

    /** @var null|\Closure(string,int):mixed */
    private ?\Closure $descriptorResolver;

    /** @var null|\Closure():array<string,mixed> */
    private ?\Closure $contextResolver;

    /** @var array<string,mixed> */
    private array $activeNativeMetadata = [];

    private int $pageSize;

    private int $minimumQueryLength;

    public function __construct(
        ?GlpiSearchOptionCatalog $catalog = null,
        ?callable $nativeLookup = null,
        ?callable $descriptorResolver = null,
        int $pageSize = self::PAGE_SIZE,
        ?callable $contextResolver = null,
        int $minimumQueryLength = self::MIN_QUERY_LENGTH
    ) {
        if ($pageSize < 1 || $pageSize > 50) {
            throw new \InvalidArgumentException('search_value_page_size_invalid');
        }
        if ($minimumQueryLength < 0 || $minimumQueryLength > 10) {
            throw new \InvalidArgumentException('search_value_minimum_query_length_invalid');
        }
        $this->catalog = $catalog ?? new GlpiSearchOptionCatalog();
        $this->nativeLookup = $nativeLookup === null
            ? null
            : \Closure::fromCallable($nativeLookup);
        $this->descriptorResolver = $descriptorResolver === null
            ? null
            : \Closure::fromCallable($descriptorResolver);
        $this->pageSize = $pageSize;
        $this->contextResolver = $contextResolver === null
            ? null
            : \Closure::fromCallable($contextResolver);
        $this->minimumQueryLength = $minimumQueryLength;
    }

    /**
     * @return array{
     *   results:array<int,array{id:int,label:string}>,
     *   pagination:array{more:bool}
     * }
     */
    public function search(
        string $itemtype,
        int $field,
        string $query,
        int $page = 1,
        ?int $selectedId = null,
        ?string $operator = null,
        ?string $contextRevision = null
    ): array {
        $itemtype = trim($itemtype);
        $query = trim($query);
        $this->validateRequest($itemtype, $field, $query, $page, $selectedId);
        if ($contextRevision !== null) {
            $this->assertContextRevision($contextRevision);
        }
        if ($operator !== null) {
            $this->assertOperator($itemtype, $field, $operator);
        }

        $descriptor = $this->resolveDescriptor($itemtype, $field);
        if ($descriptor === null) {
            throw new \InvalidArgumentException('search_value_field_not_allowed');
        }

        $targetItemtype = $this->targetItemtype($descriptor);
        if ($targetItemtype === '') {
            throw new \InvalidArgumentException('search_value_field_not_supported');
        }
        if ($selectedId === 0 && $targetItemtype !== 'Entity') {
            throw new \InvalidArgumentException('search_value_selected_id_invalid');
        }

        $context = $this->activeContext();
        $this->activeNativeMetadata = $this->nativeMetadata(
            $descriptor,
            $targetItemtype
        );
        $lookup = $this->nativeLookup;
        $native = $lookup === null
            ? $this->lookupNative(
                $targetItemtype,
                $query,
                $page,
                $this->pageSize,
                $selectedId,
                $context
            )
            : $lookup(
                $targetItemtype,
                $query,
                $page,
                $this->pageSize,
                $selectedId,
                $context
            );

        $nativeRows = $this->nativeRows($native);
        $more = $selectedId === null
            && $this->nativeHasMore($native, count($nativeRows));
        $results = [];
        foreach ($this->flattenRows($nativeRows) as $row) {
            if (!$this->rowMatchesContext($row, $context)) {
                continue;
            }

            $id = $this->rowId($row);
            if (
                $id === null
                || ($id === 0 && $targetItemtype !== 'Entity')
                || ($selectedId !== null && $id !== $selectedId)
            ) {
                continue;
            }
            $label = $this->rowLabel($row);
            if ($label === '') {
                continue;
            }

            $results[$id] = ['id' => $id, 'label' => $label];
            if (count($results) >= $this->pageSize) {
                break;
            }
        }

        return [
            'results' => array_values($results),
            'pagination' => ['more' => $more],
        ];
    }

    /**
     * Confirm that the browser still uses the catalog issued for the current
     * authenticated profile/entity context.
     */
    public function assertContextRevision(string $contextRevision): void
    {
        if (preg_match('/\A[a-f0-9]{64}\z/D', $contextRevision) !== 1) {
            throw new \InvalidArgumentException('search_value_context_stale');
        }

        $catalog = $this->catalog->forTickets();
        $current = (string) ($catalog['context_revision'] ?? '');
        if (
            preg_match('/\A[a-f0-9]{64}\z/D', $current) !== 1
            || !hash_equals($current, $contextRevision)
        ) {
            throw new \InvalidArgumentException('search_value_context_stale');
        }
    }

    public function assertOperator(string $itemtype, int $field, string $operator): void
    {
        if (
            $operator === ''
            || $operator !== strtolower($operator)
            || preg_match('/\A[a-z]{1,40}\z/D', $operator) !== 1
            || !$this->catalog->supportsOperator($itemtype, $field, $operator)
        ) {
            throw new \InvalidArgumentException('search_value_operator_not_allowed');
        }
    }

    /**
     * Whether the current contextual Search Option declares a remote value.
     * Backing metadata is always recovered from the server catalog.
     */
    public function isRemoteField(string $itemtype, int $field): bool
    {
        if ($field < 1) {
            return false;
        }
        if ($this->descriptorResolver !== null) {
            $descriptor = ($this->descriptorResolver)($itemtype, $field);
            return is_array($descriptor) && $this->isRemoteDescriptor($descriptor);
        }

        $metaContext = $itemtype !== 'Ticket';
        if ($metaContext && !$this->catalog->supportsMetaItemtype('Ticket', $itemtype)) {
            return false;
        }
        $catalog = $this->catalog->forItemtype($itemtype, $metaContext);
        foreach ((array) ($catalog['options'] ?? []) as $option) {
            if (!is_array($option) || (int) ($option['id'] ?? 0) !== $field) {
                continue;
            }
            $value = is_array($option['value'] ?? null) ? $option['value'] : [];
            return (string) ($value['mode'] ?? '') === 'remote';
        }

        return false;
    }

    /**
     * Revalidate a submitted remote identifier using GLPI's native lookup.
     * Null means the contextual field is not remote; false means the ID is not
     * selectable in the current authorization context.
     */
    public function authorizeSelectedId(
        string $itemtype,
        int $field,
        int $selectedId
    ): ?bool {
        if (!$this->isRemoteField($itemtype, $field)) {
            return null;
        }
        if ($selectedId < 1) {
            return false;
        }

        $result = $this->search($itemtype, $field, '', 1, $selectedId);
        foreach ((array) ($result['results'] ?? []) as $row) {
            if (is_array($row) && (int) ($row['id'] ?? -1) === $selectedId) {
                return true;
            }
        }

        return false;
    }

    private function validateRequest(
        string $itemtype,
        int $field,
        string $query,
        int $page,
        ?int $selectedId
    ): void {
        if (
            $itemtype === ''
            || strlen($itemtype) > 191
            || preg_match('/\A[A-Za-z_][A-Za-z0-9_\\\\]*\z/D', $itemtype) !== 1
        ) {
            throw new \InvalidArgumentException('search_value_itemtype_invalid');
        }
        if ($field < 1) {
            throw new \InvalidArgumentException('search_value_field_invalid');
        }
        $validUtf8 = function_exists('mb_check_encoding')
            ? mb_check_encoding($query, 'UTF-8')
            : preg_match('//u', $query) === 1;
        if (
            !$validUtf8
            || mb_strlen($query) > self::MAX_QUERY_LENGTH
            || preg_match('/[\x00-\x1F\x7F]/u', $query) === 1
        ) {
            throw new \InvalidArgumentException('search_value_query_invalid');
        }
        $queryLength = mb_strlen($query);
        if (
            $queryLength > 0
            && $queryLength < $this->minimumQueryLength
            && ($selectedId === null || $selectedId < 1)
        ) {
            throw new \InvalidArgumentException('search_value_query_too_short');
        }
        if ($page < 1 || $page > self::MAX_PAGE) {
            throw new \InvalidArgumentException('search_value_page_invalid');
        }
        if ($selectedId !== null && $page !== 1) {
            throw new \InvalidArgumentException('search_value_page_invalid');
        }
        if ($selectedId !== null && $selectedId < 0) {
            throw new \InvalidArgumentException('search_value_selected_id_invalid');
        }
    }

    /** @return null|array<string,mixed> */
    private function resolveDescriptor(string $itemtype, int $field): ?array
    {
        if ($this->descriptorResolver !== null) {
            $descriptor = ($this->descriptorResolver)($itemtype, $field);
            return is_array($descriptor) && $this->isRemoteDescriptor($descriptor)
                ? $descriptor
                : null;
        }

        $metaContext = $itemtype !== 'Ticket';
        if ($metaContext && !$this->catalog->supportsMetaItemtype('Ticket', $itemtype)) {
            return null;
        }

        $descriptor = $this->catalog->valueLookupDescriptor(
            $itemtype,
            $field,
            $metaContext
        );
        return is_array($descriptor) && $this->isRemoteDescriptor($descriptor)
            ? $descriptor
            : null;
    }

    /** @param array<string,mixed> $descriptor */
    private function isRemoteDescriptor(array $descriptor): bool
    {
        $value = is_array($descriptor['value'] ?? null)
            ? $descriptor['value']
            : [];
        $table = trim((string) ($descriptor['table'] ?? $value['table'] ?? ''));
        $linkfield = trim((string) ($descriptor['linkfield'] ?? $value['linkfield'] ?? ''));

        return (string) ($value['mode'] ?? '') === 'remote'
            && preg_match('/\Aglpi_[a-z0-9_]+\z/D', $table) === 1
            && preg_match('/\A[a-z][a-z0-9_]*\z/D', $linkfield) === 1;
    }

    /** @param array<string,mixed> $descriptor */
    private function targetItemtype(array $descriptor): string
    {
        $value = is_array($descriptor['value'] ?? null)
            ? $descriptor['value']
            : [];
        $table = trim((string) ($descriptor['table'] ?? $value['table'] ?? ''));
        $native = is_array($value['native'] ?? null)
            ? $value['native']
            : [];
        $declaredItemtype = is_string($native['itemtype'] ?? null)
            ? trim((string) $native['itemtype'])
            : '';
        $target = $declaredItemtype !== ''
            ? $declaredItemtype
            : (self::CORE_TABLE_ITEMTYPES[$table] ?? '');

        if ($target === '' && function_exists('getItemTypeForTable')) {
            try {
                $resolved = getItemTypeForTable($table);
                $target = is_string($resolved) ? trim($resolved) : '';
            } catch (\Throwable $e) {
                $target = '';
            }
        }
        if (
            $target === ''
            || preg_match('/\A[A-Za-z_][A-Za-z0-9_\\\\]*\z/D', $target) !== 1
        ) {
            return '';
        }

        // The injected lookup is a test seam. Production always validates the
        // resolved model and its table against the server-side descriptor.
        if ($this->nativeLookup !== null) {
            return $target;
        }
        if (!function_exists('getItemForItemtype')) {
            return '';
        }

        try {
            $item = getItemForItemtype($target);
        } catch (\Throwable $e) {
            return '';
        }
        if (
            !is_object($item)
            || !method_exists($item, 'getTable')
            || (string) $item->getTable() !== $table
        ) {
            return '';
        }

        if (in_array($target, self::CORE_TABLE_ITEMTYPES, true)) {
            return $target;
        }
        if (
            (class_exists('\CommonDropdown') && $item instanceof \CommonDropdown)
            || (class_exists('\CommonTreeDropdown') && $item instanceof \CommonTreeDropdown)
        ) {
            return $target;
        }

        return '';
    }

    /** @return array{active_entities:int[],active_entity:int,recursive:bool} */
    private function activeContext(): array
    {
        if ($this->contextResolver !== null) {
            $context = ($this->contextResolver)();
            $entities = array_values(array_unique(array_filter(
                array_map('intval', (array) ($context['active_entities'] ?? [])),
                static fn(int $entity): bool => $entity >= 0
            )));
            $activeEntity = (int) ($context['active_entity'] ?? -1);
            if ($entities === [] || $activeEntity < 0 || !in_array($activeEntity, $entities, true)) {
                throw new \RuntimeException('search_value_context_unavailable');
            }
            return [
                'active_entities' => $entities,
                'active_entity' => $activeEntity,
                'recursive' => !empty($context['recursive']),
            ];
        }

        $entities = [];
        foreach ((array) ($_SESSION['glpiactiveentities'] ?? []) as $entity) {
            if (is_numeric($entity) && (int) $entity >= 0) {
                $entities[(int) $entity] = (int) $entity;
            }
        }
        if (
            $entities === []
            && array_key_exists('glpiactive_entity', $_SESSION)
            && is_numeric($_SESSION['glpiactive_entity'])
            && (int) $_SESSION['glpiactive_entity'] >= 0
        ) {
            $entity = (int) $_SESSION['glpiactive_entity'];
            $entities[$entity] = $entity;
        }
        if ($entities === []) {
            throw new \RuntimeException('search_value_context_unavailable');
        }

        return [
            'active_entities' => array_values($entities),
            'active_entity' => (int) ($_SESSION['glpiactive_entity'] ?? reset($entities)),
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
        ];
    }

    /**
     * @param array<string,mixed> $descriptor
     * @return array{
     *   itemtype:string,
     *   right:mixed,
     *   condition:array<mixed>,
     *   displaywith:array<mixed>,
     *   toadd:array<mixed>
     * }
     */
    private function nativeMetadata(array $descriptor, string $targetItemtype): array
    {
        $value = is_array($descriptor['value'] ?? null)
            ? $descriptor['value']
            : [];
        $hasNativeMetadata = is_array($value['native'] ?? null);
        $native = $hasNativeMetadata
            ? $value['native']
            : [
                'itemtype' => '',
                'right' => $targetItemtype === 'User'
                    ? 'id'
                    : null,
                'condition' => [],
                'displaywith' => [],
                'toadd' => [],
            ];
        if (
            !is_string($native['itemtype'] ?? null)
            || !is_array($native['condition'] ?? null)
            || !is_array($native['displaywith'] ?? null)
            || !is_array($native['toadd'] ?? null)
        ) {
            throw new \InvalidArgumentException('search_value_metadata_invalid');
        }

        $nativeItemtype = (string) $native['itemtype'];
        if ($nativeItemtype !== '' && $nativeItemtype !== $targetItemtype) {
            throw new \InvalidArgumentException('search_value_metadata_invalid');
        }
        $right = $native['right'] ?? null;
        if ($targetItemtype === 'User') {
            // Some plugin/meta search options omit GLPI's optional right key.
            // Use the least-privileged native user scope instead of "all".
            if ($right === null || $right === '') {
                $right = 'id';
            }
            $rights = is_array($right) ? $right : [$right];
            if ($rights === []) {
                throw new \InvalidArgumentException('search_value_metadata_invalid');
            }
            foreach ($rights as $candidate) {
                if (
                    !is_string($candidate)
                    || preg_match('/\A[a-zA-Z0-9_.-]{1,80}\z/D', $candidate) !== 1
                ) {
                    throw new \InvalidArgumentException('search_value_metadata_invalid');
                }
            }
            if ($native['condition'] !== [] || $native['displaywith'] !== []) {
                throw new \InvalidArgumentException('search_value_metadata_unsupported');
            }
        } elseif ($right !== null && $right !== '') {
            throw new \InvalidArgumentException('search_value_metadata_unsupported');
        }

        if (json_encode($native, JSON_UNESCAPED_SLASHES) === false) {
            throw new \InvalidArgumentException('search_value_metadata_invalid');
        }

        return [
            'itemtype' => $nativeItemtype,
            'right' => $right,
            'condition' => $native['condition'],
            'displaywith' => $native['displaywith'],
            'toadd' => $native['toadd'],
        ];
    }

    /**
     * @param array{active_entities:int[],active_entity:int,recursive:bool} $context
     * @return array<string,mixed>
     */
    private function lookupNative(
        string $targetItemtype,
        string $query,
        int $page,
        int $limit,
        ?int $selectedId,
        array $context
    ): array {
        if (
            !class_exists('\Dropdown')
            || !class_exists('\Session')
            || !method_exists('\Session', 'getNewIDORToken')
        ) {
            throw new \RuntimeException('search_value_native_lookup_unavailable');
        }

        $entityRestrict = json_encode(
            array_values($context['active_entities']),
            JSON_UNESCAPED_SLASHES
        );
        if (!is_string($entityRestrict)) {
            throw new \RuntimeException('search_value_context_unavailable');
        }
        $native = $this->activeNativeMetadata;

        if (
            $targetItemtype === 'User'
            && method_exists('\Dropdown', 'getDropdownUsers')
        ) {
            $right = $native['right'] ?? null;
            $idorToken = call_user_func(
                ['\Session', 'getNewIDORToken'],
                'User',
                [
                    'right' => $right,
                    'entity_restrict' => $entityRestrict,
                ]
            );
            $params = [
                'itemtype' => 'User',
                'right' => $right,
                'entity_restrict' => $entityRestrict,
                'display_emptychoice' => false,
                'all' => 0,
                'inactive_deleted' => 0,
                'with_no_right' => 0,
                'used' => [],
                'toadd' => $native['toadd'] ?? [],
                'value' => $selectedId ?? 0,
                'searchText' => $query,
                'page' => $page,
                'page_limit' => $limit,
                '_idor_token' => $idorToken,
            ];
            $result = \Dropdown::getDropdownUsers($params, false);
            return is_array($result) ? $result : [];
        }

        if (!method_exists('\Dropdown', 'getDropdownValue')) {
            throw new \RuntimeException('search_value_native_lookup_unavailable');
        }

        $condition = $native['condition'] ?? [];
        if ($condition !== []) {
            if (!method_exists('\Dropdown', 'addNewCondition')) {
                throw new \RuntimeException('search_value_native_lookup_unavailable');
            }
            $condition = \Dropdown::addNewCondition($condition);
            if (!is_string($condition) || $condition === '') {
                throw new \RuntimeException('search_value_native_lookup_unavailable');
            }
        }
        $displaywith = $native['displaywith'] ?? [];
        $idorContext = [
            'entity_restrict' => $entityRestrict,
            'displaywith' => $displaywith,
            'condition' => $condition,
        ];
        $idorToken = call_user_func(
            ['\Session', 'getNewIDORToken'],
            $targetItemtype,
            $idorContext
        );
        $params = [
            'itemtype' => $targetItemtype,
            'entity_restrict' => $entityRestrict,
            'displaywith' => $displaywith,
            'condition' => $condition,
            'display_emptychoice' => false,
            'permit_select_parent' => false,
            'used' => [],
            'toadd' => $native['toadd'] ?? [],
            'searchText' => $query,
            'page' => $page,
            'page_limit' => $limit,
            '_idor_token' => $idorToken,
        ];
        if ($selectedId !== null) {
            $params['_one_id'] = $selectedId;
        }

        $result = \Dropdown::getDropdownValue($params, false);
        return is_array($result) ? $result : [];
    }

    /** @return array<int,mixed> */
    private function nativeRows(mixed $native): array
    {
        if (!is_array($native)) {
            return [];
        }
        if (is_array($native['results'] ?? null)) {
            return array_values($native['results']);
        }
        return array_is_list($native) ? $native : [];
    }

    private function nativeHasMore(mixed $native, int $rowCount): bool
    {
        if (is_array($native)) {
            if (is_bool($native['more'] ?? null)) {
                return $native['more'];
            }
            if (is_bool($native['pagination']['more'] ?? null)) {
                return $native['pagination']['more'];
            }
        }

        return $rowCount >= $this->pageSize;
    }

    /**
     * @param array<int,mixed> $rows
     * @return array<int,array<string,mixed>>
     */
    private function flattenRows(array $rows): array
    {
        $flat = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            if (is_array($row['children'] ?? null)) {
                $flat = array_merge($flat, $this->flattenRows(array_values($row['children'])));
                continue;
            }
            $flat[] = $row;
        }
        return $flat;
    }

    /**
     * @param array<string,mixed> $row
     * @param array{active_entities:int[],active_entity:int,recursive:bool} $context
     */
    private function rowMatchesContext(array $row, array $context): bool
    {
        if (!array_key_exists('entities_id', $row)) {
            return true;
        }

        $rowEntities = is_array($row['entities_id'])
            ? $row['entities_id']
            : [$row['entities_id']];
        foreach ($rowEntities as $entity) {
            if (
                is_numeric($entity)
                && in_array((int) $entity, $context['active_entities'], true)
            ) {
                return true;
            }
        }

        return false;
    }

    /** @param array<string,mixed> $row */
    private function rowId(array $row): ?int
    {
        $id = $row['id'] ?? $row['items_id'] ?? null;
        if (
            (!is_int($id) && !is_string($id))
            || preg_match('/\A\d+\z/D', (string) $id) !== 1
            || strlen((string) $id) > 10
        ) {
            return null;
        }

        $normalized = (int) $id;
        return $normalized >= 0 ? $normalized : null;
    }

    /** @param array<string,mixed> $row */
    private function rowLabel(array $row): string
    {
        $label = $row['label'] ?? $row['text'] ?? '';
        if (!is_scalar($label)) {
            return '';
        }

        $label = html_entity_decode(
            strip_tags((string) $label),
            ENT_QUOTES | ENT_HTML5,
            'UTF-8'
        );
        $label = preg_replace('/\s+/u', ' ', trim($label)) ?? '';
        if (mb_strlen($label) > 240) {
            $label = mb_substr($label, 0, 240);
        }

        return $label;
    }
}
