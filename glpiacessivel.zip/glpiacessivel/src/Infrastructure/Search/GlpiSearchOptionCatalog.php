<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Permission and context-aware facade over GLPI Search Options.
 *
 * Search option numbers, operators and related itemtypes vary between GLPI
 * versions, profiles and plugins. Consumers must therefore use this catalog
 * instead of persisting their own allowlists.
 */
final class GlpiSearchOptionCatalog
{
    /** @var array<int,string> */
    private const RESERVED_ACTION_KEYS = [
        'searchopt',
    ];

    /**
     * Operators whose semantics are implemented consistently by the portal
     * executor on both supported GLPI generations.
     *
     * @var array<int,string>
     */
    private const HOMOLOGATED_OPERATORS = [
        'contains',
        'notcontains',
        'equals',
        'notequals',
        'under',
        'notunder',
        'lessthan',
        'morethan',
        'empty',
        'notempty',
    ];

    private string $searchClass;

    private string $searchEngineClass;

    private GlpiTicketLocalValueCatalog $localValueCatalog;

    private GlpiSearchContractResolver $contractResolver;

    public function __construct(
        string $searchClass = '',
        ?GlpiSearchContractResolver $contractResolver = null
    ) {
        $this->localValueCatalog = new GlpiTicketLocalValueCatalog();
        $this->contractResolver = $contractResolver
            ?? new GlpiSearchContractResolver($this->localValueCatalog);
        if ($searchClass !== '') {
            $this->searchClass = $searchClass;
            $this->searchEngineClass = $searchClass;
            return;
        }

        $this->searchClass = class_exists('\Glpi\Search\SearchOption')
            ? '\Glpi\Search\SearchOption'
            : '\Search';
        $this->searchEngineClass = class_exists('\Glpi\Search\SearchEngine')
            ? '\Glpi\Search\SearchEngine'
            : '\Search';
    }

    /** @return array<string,mixed> */
    public function forTickets(): array
    {
        $catalog = $this->forItemtype('Ticket');
        $metaCatalogs = [];
        foreach ((array) ($catalog['meta_itemtypes'] ?? []) as $metaItemtype) {
            if (!is_string($metaItemtype) || $metaItemtype === '') {
                continue;
            }
            $related = $this->forItemtype($metaItemtype, true);
            $metaCatalogs[] = [
                'itemtype' => $metaItemtype,
                'label' => $this->itemtypeLabel($metaItemtype),
                'options' => (array) ($related['options'] ?? []),
                'context_revision' => (string) ($related['context_revision'] ?? ''),
            ];
        }

        $catalog['meta_itemtypes'] = $metaCatalogs;
        $catalog['capabilities'] = [
            'allow_deleted' => $this->allowDeleted(true),
            'max_sorts' => 5,
        ];
        $catalog['columns'] = $this->ticketColumnCatalog($this->rawOptions('Ticket'));
        $catalog['context_revision'] = hash(
            'sha256',
            json_encode([
                'base_revision' => (string) ($catalog['context_revision'] ?? ''),
                'meta_itemtypes' => $metaCatalogs,
                'capabilities' => $catalog['capabilities'],
                'columns' => $catalog['columns'],
            ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: ''
        );

        return $catalog;
    }

    /**
     * @param array<int,mixed> $optionIds
     * @return array{columns:array<int,string>,complete:bool,unavailable_count:int}
     */
    public function ticketColumnsFromOptionIds(array $optionIds): array
    {
        $byOptionId = [];
        $required = [];
        foreach ($this->ticketColumnCatalog($this->rawOptions('Ticket')) as $column) {
            $optionId = (int) ($column['option_id'] ?? 0);
            $identifier = (string) ($column['identifier'] ?? '');
            if ($optionId > 0 && $identifier !== '') {
                $byOptionId[$optionId] = $identifier;
                if (!empty($column['required'])) {
                    $required[] = $identifier;
                }
            }
        }

        $columns = [];
        $unavailable = 0;
        foreach ($optionIds as $optionId) {
            if (!is_int($optionId) && !(is_string($optionId) && ctype_digit($optionId))) {
                $unavailable++;
                continue;
            }
            $optionId = (int) $optionId;
            if ($optionId <= 0 || !isset($byOptionId[$optionId])) {
                $unavailable++;
                continue;
            }
            if (!in_array($byOptionId[$optionId], $columns, true)) {
                $columns[] = $byOptionId[$optionId];
            }
        }

        return [
            'columns' => array_values(array_unique(array_merge($required, $columns))),
            'complete' => $unavailable === 0,
            'unavailable_count' => $unavailable,
        ];
    }

    /**
     * @param array<int,mixed> $identifiers
     * @return array{option_ids:array<int,int>,complete:bool,unavailable_count:int}
     */
    public function ticketColumnOptionIds(array $identifiers): array
    {
        $byIdentifier = [];
        foreach ($this->ticketColumnCatalog($this->rawOptions('Ticket')) as $column) {
            $optionId = (int) ($column['option_id'] ?? 0);
            $identifier = (string) ($column['identifier'] ?? '');
            if ($optionId > 0 && $identifier !== '') {
                $byIdentifier[$identifier] = $optionId;
            }
        }

        $optionIds = [];
        $unavailable = 0;
        foreach ($identifiers as $identifier) {
            if (!is_string($identifier)) {
                $unavailable++;
                continue;
            }
            $identifier = trim($identifier);
            if ($identifier === '' || !isset($byIdentifier[$identifier])) {
                $unavailable++;
                continue;
            }
            if (!in_array($byIdentifier[$identifier], $optionIds, true)) {
                $optionIds[] = $byIdentifier[$identifier];
            }
        }

        return [
            'option_ids' => $optionIds,
            'complete' => $unavailable === 0,
            'unavailable_count' => $unavailable,
        ];
    }

    /** @return array<string,mixed> */
    public function forItemtype(string $itemtype, bool $metaContext = false): array
    {
        $rawOptions = $this->rawOptions($itemtype);
        $options = [];
        $category = 'Outros';
        foreach ($rawOptions as $number => $option) {
            if (!is_array($option)) {
                if (is_scalar($option) && trim((string) $option) !== '') {
                    $category = trim((string) $option);
                }
                continue;
            }
            if (!is_numeric($number) || (int) $number <= 0) {
                $heading = $this->groupLabel($option);
                if ($heading !== '') {
                    $category = $heading;
                }
                continue;
            }

            if (!$this->isSearchableOption($option, $metaContext)) {
                continue;
            }

            $id = (int) $number;
            $operators = $this->operatorDescriptors($itemtype, $id, $rawOptions, $option);
            $options[] = [
                'id' => $id,
                'label' => $this->optionLabel($option, $id),
                'category' => $category,
                'field' => (string) ($option['field'] ?? ''),
                'datatype' => $this->datatype($option),
                'sortable' => empty($option['nosort']),
                'operators' => $operators,
                'value' => $this->valueDescriptor($itemtype, $option, $operators),
            ];
        }

        $metaItemtypes = $this->metaItemtypes($itemtype);
        $context = $this->contextDescriptor();
        $revisionPayload = [
            'itemtype' => $itemtype,
            'context' => $context,
            'options' => $options,
            'meta_itemtypes' => $metaItemtypes,
        ];

        return [
            'itemtype' => $itemtype,
            'context_revision' => hash(
                'sha256',
                json_encode($revisionPayload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: ''
            ),
            'context' => $context,
            'options' => $options,
            'meta_itemtypes' => $metaItemtypes,
        ];
    }

    /**
     * Build the server-side allowlists consumed by NativeSearchDefinitionValidator.
     *
     * @return array<string,mixed>
     */
    public function validationContext(bool $authorized): array
    {
        $ticketCatalog = $this->forTickets();
        $fields = [];
        $sortFields = [];
        foreach ((array) ($ticketCatalog['options'] ?? []) as $option) {
            if (!is_array($option) || (int) ($option['id'] ?? 0) <= 0) {
                continue;
            }
            $id = (int) $option['id'];
            $contracts = $this->operatorContracts((array) ($option['operators'] ?? []));
            if ($contracts === []) {
                continue;
            }
            $fields[$id] = $contracts;
            if (!empty($option['sortable'])) {
                $sortFields[] = $id;
            }
        }

        $metaFields = [];
        foreach ((array) ($ticketCatalog['meta_itemtypes'] ?? []) as $metaCatalog) {
            if (!is_array($metaCatalog) || (string) ($metaCatalog['itemtype'] ?? '') === '') {
                continue;
            }
            $metaItemtype = (string) $metaCatalog['itemtype'];
            foreach ((array) ($metaCatalog['options'] ?? []) as $option) {
                if (!is_array($option) || (int) ($option['id'] ?? 0) <= 0) {
                    continue;
                }
                $contracts = $this->operatorContracts((array) ($option['operators'] ?? []));
                if ($contracts !== []) {
                    $metaFields[$metaItemtype][(int) $option['id']] = $contracts;
                }
            }
        }

        $allowDeleted = $this->allowDeleted($authorized);
        $specialFields = [];
        foreach (['all', 'view'] as $specialField) {
            $contracts = $this->specialFieldContracts($specialField);
            if ($contracts !== []) {
                $specialFields[$specialField] = $contracts;
            }
        }

        return [
            'authorized' => $authorized,
            'fields' => $fields,
            'special_fields' => $specialFields,
            'sort_fields' => array_values(array_unique($sortFields)),
            'meta_fields' => $metaFields,
            'allow_deleted' => $allowDeleted,
            'columns' => array_values(array_filter(array_map(
                static fn(array $column): string => !empty($column['available'])
                    ? (string) ($column['identifier'] ?? '')
                    : '',
                (array) ($ticketCatalog['columns'] ?? [])
            ))),
        ];
    }

    /**
     * @param int|string $field
     * @return string[]
     */
    public function operatorsFor(string $itemtype, $field): array
    {
        if (in_array((string) $field, ['all', 'view'], true)) {
            $options = $this->rawOptions($itemtype);
            return $options === [] || !$this->specialSearchFieldEnabled((string) $field)
                ? []
                : $this->nativeOperators($itemtype, $field, $options);
        }
        if (!is_numeric($field) || (int) $field <= 0) {
            return [];
        }

        $options = $this->rawOptions($itemtype);
        if ($options === [] || !is_array($options[(int) $field] ?? null)) {
            return [];
        }
        if (!$this->isSearchableOption($options[(int) $field], $itemtype !== 'Ticket')) {
            return [];
        }

        return $this->nativeOperators($itemtype, (int) $field, $options);
    }

    /** @param int|string $field */
    public function supportsField(string $itemtype, $field): bool
    {
        if (in_array((string) $field, ['all', 'view'], true)) {
            return $this->specialSearchFieldEnabled((string) $field)
                && $this->rawOptions($itemtype) !== [];
        }
        if (!is_numeric($field) || (int) $field <= 0) {
            return false;
        }

        $options = $this->rawOptions($itemtype);
        return $options !== []
            && is_array($options[(int) $field] ?? null)
            && $this->isSearchableOption($options[(int) $field], $itemtype !== 'Ticket');
    }

    /** @param int|string $field */
    public function supportsOperator(string $itemtype, $field, string $operator): bool
    {
        $operator = strtolower(trim($operator));
        return $operator !== '' && in_array($operator, $this->operatorsFor($itemtype, $field), true);
    }

    public function supportsMetaItemtype(string $rootItemtype, string $metaItemtype): bool
    {
        if ($metaItemtype === '' || !class_exists($metaItemtype)) {
            return false;
        }

        $available = $this->metaItemtypes($rootItemtype);
        return $available !== [] && in_array($metaItemtype, $available, true);
    }

    /**
     * Return the server-only descriptor required to reproduce GLPI's native
     * dropdown semantics. It is not serialized into the browser catalog.
     *
     * @return null|array<string,mixed>
     */
    public function valueLookupDescriptor(
        string $itemtype,
        int $field,
        bool $metaContext = false
    ): ?array {
        if ($field < 1) {
            return null;
        }

        $options = $this->rawOptions($itemtype);
        $option = $options[$field] ?? null;
        if (
            !is_array($option)
            || !$this->isSearchableOption($option, $metaContext)
        ) {
            return null;
        }

        $fieldContract = $this->contractResolver->resolve(
            $itemtype,
            $field,
            $option,
            $this->nativeOperators($itemtype, $field, $options)
        );
        if ($fieldContract === null) {
            return null;
        }
        $remote = false;
        foreach ($fieldContract->operators() as $contract) {
            if ($contract->kind()->value === 'remote_select') {
                $remote = true;
                break;
            }
        }
        if (!$remote) {
            return null;
        }

        $value = [
            'mode' => 'remote',
            'options' => [],
            'table' => (string) ($option['table'] ?? ''),
            'linkfield' => (string) ($option['linkfield'] ?? ''),
        ];
        $native = $this->nativeValueMetadata($option);
        if ($native === null) {
            return null;
        }
        $value['native'] = $native;

        return [
            'id' => $field,
            'table' => (string) ($option['table'] ?? ''),
            'linkfield' => (string) ($option['linkfield'] ?? ''),
            'value' => $value,
        ];
    }

    /** @return array<int|string,mixed> */
    private function rawOptions(string $itemtype): array
    {
        if (!class_exists($this->searchClass)) {
            return [];
        }

        if (method_exists($this->searchClass, 'getCleanedOptions')) {
            try {
                $options = call_user_func([$this->searchClass, 'getCleanedOptions'], $itemtype);
                return is_array($options) ? $options : [];
            } catch (\Throwable $e) {
                return [];
            }
        }

        if (method_exists($this->searchClass, 'getOptionsForItemtype')) {
            try {
                $options = call_user_func([$this->searchClass, 'getOptionsForItemtype'], $itemtype);
                return is_array($options) ? $options : [];
            } catch (\Throwable $e) {
                return [];
            }
        }

        if (!method_exists($this->searchClass, 'getOptions')) {
            return [];
        }
        try {
            $options = call_user_func([$this->searchClass, 'getOptions'], $itemtype);
            return is_array($options) ? $options : [];
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * Preserve only serializable metadata accepted by native dropdown APIs.
     * Objects, resources and excessive nested structures fail closed.
     *
     * @param array<string,mixed> $option
     * @return null|array<string,mixed>
     */
    private function nativeValueMetadata(array $option): ?array
    {
        $ok = true;
        $native = [
            'itemtype' => $this->safeNativeValue($option['itemtype'] ?? '', 0, $ok),
            'right' => $this->safeNativeValue($option['right'] ?? null, 0, $ok),
            'condition' => $this->safeNativeValue($option['condition'] ?? [], 0, $ok),
            'displaywith' => $this->safeNativeValue($option['displaywith'] ?? [], 0, $ok),
            'toadd' => $this->safeNativeValue($option['toadd'] ?? [], 0, $ok),
        ];
        if (!$ok) {
            return null;
        }
        if (
            !is_string($native['itemtype'])
            || (
                $native['itemtype'] !== ''
                && preg_match(
                    '/\A[A-Za-z_][A-Za-z0-9_\\\\]*\z/D',
                    $native['itemtype']
                ) !== 1
            )
            || !is_array($native['condition'])
            || !is_array($native['displaywith'])
            || !is_array($native['toadd'])
        ) {
            return null;
        }

        return $native;
    }

    private function safeNativeValue(mixed $value, int $depth, bool &$ok): mixed
    {
        if (!$ok || $depth > 6) {
            $ok = false;
            return null;
        }
        if ($value === null || is_bool($value) || is_int($value)) {
            return $value;
        }
        if (is_string($value)) {
            if (
                strlen($value) > 500
                || preg_match('/[\x00-\x1F\x7F]/', $value) === 1
            ) {
                $ok = false;
                return null;
            }
            return $value;
        }
        if (!is_array($value) || count($value) > 100) {
            $ok = false;
            return null;
        }

        $safe = [];
        foreach ($value as $key => $entry) {
            if (
                (!is_int($key) && !is_string($key))
                || (
                    is_string($key)
                    && (
                        strlen($key) > 120
                        || preg_match('/[\x00-\x1F\x7F]/', $key) === 1
                    )
                )
            ) {
                $ok = false;
                return null;
            }
            $safe[$key] = $this->safeNativeValue($entry, $depth + 1, $ok);
            if (!$ok) {
                return null;
            }
        }

        return $safe;
    }

    /**
     * @param int|string $field
     * @param array<int|string,mixed> $options
     * @return string[]
     */
    private function nativeOperators(string $itemtype, $field, array $options): array
    {
        if ($options === []) {
            return [];
        }

        if (
            class_exists($this->searchClass)
            && method_exists($this->searchClass, 'getActionsFor')
        ) {
            try {
                $method = new \ReflectionMethod($this->searchClass, 'getActionsFor');
                $arguments = [$itemtype, $field, $options];
                if (!$method->isVariadic()) {
                    $arguments = array_slice($arguments, 0, $method->getNumberOfParameters());
                }
                if ($method->getNumberOfRequiredParameters() <= count($arguments)) {
                    $actions = $method->invokeArgs(null, $arguments);
                    $operators = $this->normalizeActions($actions);
                    return $this->completeNativeStatusOperators(
                        $itemtype,
                        $field,
                        $options,
                        $operators
                    );
                }
            } catch (\Throwable $e) {
                return [];
            }
        }

        return [];
    }

    /**
     * Some GLPI 10/11 Ticket status Search Option variants publish only the
     * positive `equals` action for this finite dropdown. Expose the semantic
     * negative pair only after the server-built option proves all status
     * semantics. GlpiTicketStatusCriterionCodec translates it to GLPI's native
     * equals-plus-negative-link representation at execution/storage boundaries.
     *
     * @param int|string $field
     * @param array<int|string,mixed> $options
     * @param string[] $operators
     * @return string[]
     */
    private function completeNativeStatusOperators(
        string $itemtype,
        $field,
        array $options,
        array $operators
    ): array {
        if (
            $itemtype !== 'Ticket'
            || !is_numeric($field)
            || !is_array($options[(int) $field] ?? null)
            || !in_array('equals', $operators, true)
            || in_array('notequals', $operators, true)
        ) {
            return $operators;
        }

        /** @var array<string,mixed> $option */
        $option = $options[(int) $field];
        if (
            strtolower(trim((string) ($option['table'] ?? ''))) !== 'glpi_tickets'
            || strtolower(trim((string) ($option['field'] ?? ''))) !== 'status'
            || $this->localValueCatalog->valuesFor('Ticket', $option) === []
        ) {
            return $operators;
        }

        $operators[] = 'notequals';
        return $operators;
    }

    /**
     * @param mixed $actions
     * @return string[]
     */
    private function normalizeActions($actions): array
    {
        if (!is_array($actions)) {
            return [];
        }

        $operators = [];
        foreach ($actions as $key => $value) {
            $candidate = '';
            if (is_string($key)) {
                $candidate = strtolower(trim($key));
            } elseif (is_array($value) && is_scalar($value['value'] ?? null)) {
                $candidate = strtolower(trim((string) $value['value']));
            } elseif (is_scalar($value)) {
                $candidate = strtolower(trim((string) $value));
            }

            if (
                $candidate !== ''
                && !in_array($candidate, self::RESERVED_ACTION_KEYS, true)
                && in_array($candidate, self::HOMOLOGATED_OPERATORS, true)
            ) {
                $operators[$candidate] = $candidate;
            }
        }

        return array_values($operators);
    }

    /**
     * @param array<int,mixed> $descriptors
     * @return string[]
     */
    private function homologatedOperators(array $descriptors): array
    {
        $operators = [];
        foreach ($descriptors as $descriptor) {
            $operator = is_array($descriptor)
                ? (string) ($descriptor['value'] ?? '')
                : (is_scalar($descriptor) ? (string) $descriptor : '');
            $operator = strtolower(trim($operator));
            if (in_array($operator, self::HOMOLOGATED_OPERATORS, true)) {
                $operators[$operator] = $operator;
            }
        }
        return array_values($operators);
    }

    /**
     * @param array<int|string,mixed> $options
     * @param array<string,mixed> $option
     * @return array<int,array<string,mixed>>
     */
    private function operatorDescriptors(
        string $itemtype,
        int $field,
        array $options,
        array $option
    ): array {
        $labels = [];
        if (
            class_exists($this->searchClass)
            && method_exists($this->searchClass, 'getActionsFor')
        ) {
            try {
                $method = new \ReflectionMethod($this->searchClass, 'getActionsFor');
                $arguments = [$itemtype, $field, $options];
                if (!$method->isVariadic()) {
                    $arguments = array_slice($arguments, 0, $method->getNumberOfParameters());
                }
                if ($method->getNumberOfRequiredParameters() <= count($arguments)) {
                    $actions = $method->invokeArgs(null, $arguments);
                    if (is_array($actions)) {
                        foreach ($actions as $key => $value) {
                            $operator = is_string($key) ? strtolower(trim($key)) : '';
                            if (
                                $operator !== ''
                                && !in_array($operator, self::RESERVED_ACTION_KEYS, true)
                                && in_array($operator, self::HOMOLOGATED_OPERATORS, true)
                            ) {
                                $labels[$operator] = is_scalar($value)
                                    ? trim((string) $value)
                                    : '';
                            }
                        }
                    }
                }
            } catch (\Throwable $e) {
                $labels = [];
            }
        }

        $nativeOperators = $this->nativeOperators($itemtype, $field, $options);
        $fieldContract = $this->contractResolver->resolve(
            $itemtype,
            $field,
            $option,
            $nativeOperators
        );
        if ($fieldContract === null) {
            return [];
        }

        $result = [];
        foreach ($fieldContract->operators() as $operator => $contract) {
            $result[] = [
                'value' => $operator,
                'label' => trim((string) ($labels[$operator] ?? ''))
                    ?: $this->operatorFallbackLabel($operator),
                'value_contract' => $contract->toArray(),
            ];
        }
        return $result;
    }

    /** @return array<string,array<string,mixed>> */
    private function specialFieldContracts(string $field): array
    {
        $contracts = [];
        foreach ($this->operatorsFor('Ticket', $field) as $operator) {
            if (in_array($operator, ['empty', 'notempty'], true)) {
                $contracts[$operator] = [
                    'kind' => 'none',
                    'required' => false,
                    'canonical_value' => '',
                ];
            } elseif (in_array($operator, ['contains', 'notcontains', 'equals', 'notequals'], true)) {
                $contracts[$operator] = [
                    'kind' => 'text',
                    'required' => true,
                    'max_bytes' => 4096,
                    'allow_empty' => false,
                ];
            }
        }
        return $contracts;
    }

    private function specialSearchFieldEnabled(string $field): bool
    {
        global $CFG_GLPI;

        $key = $field === 'all'
            ? 'allow_search_all'
            : ($field === 'view' ? 'allow_search_view' : '');
        return $key !== '' && !empty($CFG_GLPI[$key]);
    }

    /**
     * @param array<int,mixed> $descriptors
     * @return array<string,array<string,mixed>>
     */
    private function operatorContracts(array $descriptors): array
    {
        $contracts = [];
        foreach ($descriptors as $descriptor) {
            if (!is_array($descriptor)) {
                continue;
            }
            $operator = strtolower(trim((string) ($descriptor['value'] ?? '')));
            $contract = $descriptor['value_contract'] ?? null;
            if (
                !in_array($operator, self::HOMOLOGATED_OPERATORS, true)
                || !is_array($contract)
            ) {
                continue;
            }
            $contracts[$operator] = $contract;
        }
        return $contracts;
    }

    /**
     * Contextual presentation columns backed by Ticket Search Options.
     *
     * @param array<int|string,mixed> $options
     * @return array<int,array<string,mixed>>
     */
    private function ticketColumnCatalog(array $options): array
    {
        $definitions = [
            'id' => ['label' => 'ID', 'category' => 'Identificação', 'required' => true],
            'name' => ['label' => 'Título', 'category' => 'Identificação', 'required' => true],
            'status' => ['label' => 'Status', 'category' => 'Características'],
            'priority' => ['label' => 'Prioridade', 'category' => 'Características'],
            'group' => ['label' => 'Grupo responsável', 'category' => 'Atores'],
            'requester' => ['label' => 'Requisitante', 'category' => 'Atores'],
            'assignee' => ['label' => 'Técnico', 'category' => 'Atores'],
            'date' => ['label' => 'Data de abertura', 'category' => 'Datas'],
            'date_mod' => ['label' => 'Última atualização', 'category' => 'Datas'],
            'category' => ['label' => 'Categoria', 'category' => 'Características'],
            'entity' => ['label' => 'Entidade', 'category' => 'Contexto'],
            'location' => ['label' => 'Localização', 'category' => 'Contexto'],
            'time_to_resolve' => ['label' => 'Tempo para solução', 'category' => 'Datas'],
        ];

        $matched = [];
        foreach ($options as $number => $option) {
            $id = is_numeric($number) ? (int) $number : 0;
            if (!is_array($option) || $id <= 0 || !$this->isSearchableOption($option, false)) {
                continue;
            }
            $identifier = $this->ticketColumnIdentifier($option);
            if ($identifier === '' || isset($matched[$identifier])) {
                continue;
            }
            $matched[$identifier] = $id;
        }

        $columns = [];
        foreach ($definitions as $identifier => $definition) {
            if (!isset($matched[$identifier])) {
                continue;
            }
            $columns[] = [
                'identifier' => $identifier,
                'key' => $identifier,
                'option_id' => $matched[$identifier],
                'label' => $definition['label'],
                'category' => $definition['category'],
                'required' => !empty($definition['required']),
                'available' => true,
            ];
        }
        return $columns;
    }

    /** @param array<string,mixed> $option */
    private function ticketColumnIdentifier(array $option): string
    {
        $field = strtolower(trim((string) ($option['field'] ?? '')));
        $table = strtolower(trim((string) ($option['table'] ?? '')));
        $linkfield = strtolower(trim((string) ($option['linkfield'] ?? '')));
        $serialized = strtolower(json_encode(
            $option,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        ) ?: '');

        if (in_array($table, ['', 'glpi_tickets'], true)) {
            $direct = [
                'id' => 'id', 'name' => 'name', 'status' => 'status',
                'priority' => 'priority', 'date' => 'date', 'date_mod' => 'date_mod',
                'time_to_resolve' => 'time_to_resolve',
            ];
            if (isset($direct[$field])) {
                return $direct[$field];
            }
        }
        if (
            $table === 'glpi_itilcategories'
            && $linkfield === 'itilcategories_id'
            && in_array($field, ['name', 'completename'], true)
        ) {
            return 'category';
        }
        if (
            $table === 'glpi_entities'
            && $linkfield === 'entities_id'
            && in_array($field, ['name', 'completename'], true)
        ) {
            return 'entity';
        }
        if (
            $table === 'glpi_locations'
            && $linkfield === 'locations_id'
            && in_array($field, ['name', 'completename'], true)
        ) {
            return 'location';
        }
        $actorRole = (new GlpiTicketActorSearchOptionResolver())->roleForOption($option);
        if ($actorRole === GlpiTicketActorSearchOptionResolver::REQUESTER) {
            return 'requester';
        }
        if ($actorRole === GlpiTicketActorSearchOptionResolver::ASSIGNEE) {
            return 'assignee';
        }
        if (
            in_array($table, ['glpi_groups_tickets', 'glpi_groups'], true)
            && str_contains($serialized, 'glpi_groups_tickets')
            && ($this->serializedRelationType($serialized, 2) || str_contains($serialized, 'groups_id_assign'))
        ) {
            return 'group';
        }
        return '';
    }

    private function serializedRelationType(string $serialized, int $type): bool
    {
        return preg_match(
            '/(?:"type"|type|tickets_users\.type|groups_tickets\.type)[^0-9]{0,40}'
            . preg_quote((string) $type, '/')
            . '(?:[^0-9]|$)/',
            $serialized
        ) === 1;
    }

    /** @param array<string,mixed> $option */
    private function isSearchableOption(array $option, bool $metaContext): bool
    {
        return empty($option['nosearch'])
            && (!$metaContext || empty($option['nometa']));
    }

    /** @param array<string,mixed> $option */
    private function groupLabel(array $option): string
    {
        if (count($option) !== 1) {
            return '';
        }
        $label = $option['name'] ?? $option['label'] ?? '';
        return is_scalar($label) ? trim((string) $label) : '';
    }

    private function operatorFallbackLabel(string $operator): string
    {
        $labels = [
            'contains' => 'contém',
            'notcontains' => 'não contém',
            'equals' => 'é',
            'notequals' => 'não é',
            'under' => 'está abaixo de',
            'notunder' => 'não está abaixo de',
            'lessthan' => 'antes de',
            'morethan' => 'depois de',
            'empty' => 'está vazio',
            'notempty' => 'não está vazio',
        ];
        return $labels[$operator] ?? $operator;
    }

    /** @param array<string,mixed> $option */
    private function optionLabel(array $option, int $fallback): string
    {
        $label = $option['name'] ?? $option['label'] ?? $option['field'] ?? ('#' . $fallback);
        if (is_array($label)) {
            $label = implode(' - ', array_values(array_filter(array_map(
                static fn($part): string => is_scalar($part) ? trim((string) $part) : '',
                $label
            ))));
        }
        return trim(is_scalar($label) ? (string) $label : '') ?: ('#' . $fallback);
    }

    /** @param array<string,mixed> $option */
    private function datatype(array $option): string
    {
        $datatype = strtolower(trim((string) ($option['datatype'] ?? '')));
        if ($datatype !== '') {
            return $datatype;
        }

        $field = strtolower((string) ($option['field'] ?? ''));
        if (str_contains($field, 'date')) {
            return 'datetime';
        }
        if ($field === 'id' || str_ends_with($field, '_id')) {
            return 'number';
        }
        return 'text';
    }

    /**
     * @param array<string,mixed> $option
     * @param array<int,array<string,mixed>> $operators
     * @return array<string,mixed>
     */
    private function valueDescriptor(string $itemtype, array $option, array $operators): array
    {
        $values = $this->localValueCatalog->valuesFor($itemtype, $option);
        $kinds = [];
        foreach ($operators as $operator) {
            $kind = (string) (($operator['value_contract'] ?? [])['kind'] ?? '');
            if ($kind !== '') {
                $kinds[$kind] = true;
            }
        }

        if (isset($kinds['local_select']) && $values !== []) {
            $mode = 'select';
        } elseif (isset($kinds['remote_select'])) {
            $mode = 'remote';
        } elseif (isset($kinds['date']) || isset($kinds['datetime'])) {
            $mode = 'date';
        } elseif (isset($kinds['boolean'])) {
            $mode = 'boolean';
        } elseif (isset($kinds['integer']) || isset($kinds['decimal'])) {
            $mode = 'number';
        } else {
            $mode = 'text';
        }

        return [
            'mode' => $mode,
            'options' => $values,
        ];
    }
    /** @return string[] */
    private function metaItemtypes(string $itemtype): array
    {
        if (
            !class_exists($this->searchEngineClass)
            || !method_exists($this->searchEngineClass, 'getMetaItemtypeAvailable')
        ) {
            return [];
        }
        try {
            $available = call_user_func([$this->searchEngineClass, 'getMetaItemtypeAvailable'], $itemtype);
        } catch (\Throwable $e) {
            return [];
        }
        if (!is_array($available)) {
            return [];
        }

        $itemtypes = [];
        foreach ($available as $key => $value) {
            $candidate = is_string($key) && !is_numeric($key)
                ? $key
                : (is_scalar($value) ? (string) $value : '');
            if ($candidate !== '' && class_exists($candidate)) {
                $itemtypes[$candidate] = $candidate;
            }
        }
        return array_values($itemtypes);
    }

    private function itemtypeLabel(string $itemtype): string
    {
        if (class_exists($itemtype) && method_exists($itemtype, 'getTypeName')) {
            try {
                $label = $itemtype::getTypeName(2);
                if (is_scalar($label) && trim((string) $label) !== '') {
                    return trim((string) $label);
                }
            } catch (\Throwable $e) {
                // Use the stable itemtype identifier when no translated label is available.
            }
        }
        return $itemtype;
    }

    private function allowDeleted(bool $authorized): bool
    {
        if (!$authorized || !class_exists('\Ticket')) {
            return false;
        }
        $ticket = new \Ticket();
        if (!method_exists($ticket, 'maybeDeleted')) {
            return false;
        }
        try {
            if (!(bool) $ticket->maybeDeleted()) {
                return false;
            }
        } catch (\Throwable $e) {
            return false;
        }

        foreach (['canViewDeleted', 'canPurge'] as $capability) {
            if (!method_exists($ticket, $capability)) {
                continue;
            }
            try {
                return (bool) $ticket->{$capability}();
            } catch (\Throwable $e) {
                return false;
            }
        }

        if (
            class_exists('\Session')
            && method_exists('\Session', 'haveRight')
            && defined('PURGE')
        ) {
            try {
                return (bool) \Session::haveRight('ticket', (int) constant('PURGE'));
            } catch (\Throwable $e) {
                return false;
            }
        }

        return false;
    }

    /** @return array<string,mixed> */
    private function contextDescriptor(): array
    {
        $activeEntities = array_values(array_unique(array_map(
            'intval',
            (array) ($_SESSION['glpiactiveentities'] ?? [])
        )));
        sort($activeEntities, SORT_NUMERIC);

        return [
            'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'profiles_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'interface' => (string) ($_SESSION['glpiactiveprofile']['interface'] ?? ''),
            'entities_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
            'entity_recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
            'active_entities' => $activeEntities,
            'groups_hash' => $this->currentGroupsHash(),
            'language' => (string) ($_SESSION['glpilanguage'] ?? ''),
        ];
    }

    /**
     * Bind short-lived search tokens to group membership without serializing
     * group identifiers into the browser catalog. Normalization accepts the
     * scalar and keyed shapes used by supported GLPI 10/11 sessions.
     */
    private function currentGroupsHash(): string
    {
        $groupIds = [];
        foreach ((array) ($_SESSION['glpigroups'] ?? []) as $key => $value) {
            $candidate = 0;
            if (is_numeric($value)) {
                $candidate = (int) $value;
            } elseif (is_array($value) && is_numeric($value['id'] ?? null)) {
                $candidate = (int) $value['id'];
            } elseif (is_numeric($key)) {
                $candidate = (int) $key;
            }
            if ($candidate > 0) {
                $groupIds[$candidate] = $candidate;
            }
        }
        $groupIds = array_values($groupIds);
        sort($groupIds, SORT_NUMERIC);

        $sessionKey = $_SESSION['glpiacessivel_search_context_group_key'] ?? null;
        if (!is_string($sessionKey) || preg_match('/\A[a-f0-9]{64}\z/D', $sessionKey) !== 1) {
            $sessionKey = bin2hex(random_bytes(32));
            $_SESSION['glpiacessivel_search_context_group_key'] = $sessionKey;
        }

        return hash_hmac(
            'sha256',
            json_encode($groupIds, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '[]',
            $sessionKey
        );
    }
}
