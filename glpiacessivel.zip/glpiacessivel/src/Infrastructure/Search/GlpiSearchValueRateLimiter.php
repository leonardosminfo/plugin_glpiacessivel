<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Session-scoped limiter for the authenticated autocomplete endpoint.
 */
final class GlpiSearchValueRateLimiter
{
    private const CONTEXT_SESSION_KEY = 'glpiacessivel_search_value_rate';
    private const GLOBAL_SESSION_KEY = 'glpiacessivel_search_value_global_rate';
    private const MAX_CONTEXT_BUCKETS = 12;
    public const DEFAULT_LIMIT = 60;
    public const DEFAULT_WINDOW_SECONDS = 60;

    private int $limit;
    private int $windowSeconds;

    /** @var \Closure():int */
    private \Closure $clock;

    public function __construct(
        int $limit = self::DEFAULT_LIMIT,
        int $windowSeconds = self::DEFAULT_WINDOW_SECONDS,
        ?callable $clock = null
    ) {
        if ($limit < 1 || $windowSeconds < 1) {
            throw new \InvalidArgumentException('search_value_rate_limit_invalid');
        }
        $this->limit = $limit;
        $this->windowSeconds = $windowSeconds;
        $this->clock = $clock === null
            ? static fn(): int => time()
            : \Closure::fromCallable($clock);
    }

    /** @return array{allowed:bool,retry_after:int,reason:string} */
    public function consume(int $cost = 1, string $channel = 'autocomplete'): array
    {
        if ($cost < 1) {
            throw new \InvalidArgumentException('search_value_rate_cost_invalid');
        }
        if (!in_array($channel, ['autocomplete', 'authorization', 'resource_autocomplete', 'resource_authorization'], true)) {
            throw new \InvalidArgumentException('search_value_rate_channel_invalid');
        }

        $context = $this->context();
        if ($context === null) {
            return [
                'allowed' => false,
                'retry_after' => $this->windowSeconds,
                'reason' => 'context_unavailable',
            ];
        }

        $now = ($this->clock)();
        $encodedContext = json_encode([$channel, $context], JSON_UNESCAPED_SLASHES);
        $encodedGlobalContext = json_encode(
            [$channel, ['user' => $context['user']]],
            JSON_UNESCAPED_SLASHES
        );
        if (!is_string($encodedContext) || !is_string($encodedGlobalContext)) {
            return [
                'allowed' => false,
                'retry_after' => $this->windowSeconds,
                'reason' => 'context_unavailable',
            ];
        }

        $contextKey = hash('sha256', $encodedContext);
        $globalKey = hash('sha256', $encodedGlobalContext);
        $contextBuckets = $this->buckets(self::CONTEXT_SESSION_KEY);
        $globalBuckets = $this->buckets(self::GLOBAL_SESSION_KEY);
        $contextBucket = $this->currentBucket($contextBuckets, $contextKey, $now);
        $globalBucket = $this->currentBucket($globalBuckets, $globalKey, $now);
        $contextRetryAfter = $this->retryAfter($contextBucket, $cost, $now);
        $globalRetryAfter = $this->retryAfter($globalBucket, $cost, $now);

        if ($contextRetryAfter > 0 || $globalRetryAfter > 0) {
            $this->store(
                self::CONTEXT_SESSION_KEY,
                $contextBuckets,
                $contextKey,
                $contextBucket['started_at'],
                $contextBucket['count'],
                $now,
                self::MAX_CONTEXT_BUCKETS
            );
            $this->store(
                self::GLOBAL_SESSION_KEY,
                $globalBuckets,
                $globalKey,
                $globalBucket['started_at'],
                $globalBucket['count'],
                $now
            );
            return [
                'allowed' => false,
                'retry_after' => max($contextRetryAfter, $globalRetryAfter),
                'reason' => 'rate_limited',
            ];
        }

        $contextBucket['count'] += $cost;
        $globalBucket['count'] += $cost;
        $this->store(
            self::CONTEXT_SESSION_KEY,
            $contextBuckets,
            $contextKey,
            $contextBucket['started_at'],
            $contextBucket['count'],
            $now,
            self::MAX_CONTEXT_BUCKETS
        );
        $this->store(
            self::GLOBAL_SESSION_KEY,
            $globalBuckets,
            $globalKey,
            $globalBucket['started_at'],
            $globalBucket['count'],
            $now
        );
        return ['allowed' => true, 'retry_after' => 0, 'reason' => 'allowed'];
    }

    /** @return null|array{user:int,profile:int,entity:int,recursive:int,entities:string} */
    private function context(): ?array
    {
        $userId = class_exists('\Session') && method_exists('\Session', 'getLoginUserID')
            ? (int) \Session::getLoginUserID()
            : (int) ($_SESSION['glpiID'] ?? 0);
        $profileId = (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0);
        $hasEntity = array_key_exists('glpiactive_entity', $_SESSION)
            && is_numeric($_SESSION['glpiactive_entity'])
            && (int) $_SESSION['glpiactive_entity'] >= 0;
        if ($userId < 1 || $profileId < 1 || !$hasEntity) {
            return null;
        }

        $activeEntities = [];
        foreach ((array) ($_SESSION['glpiactiveentities'] ?? []) as $entity) {
            if (!is_numeric($entity) || (int) $entity < 0) {
                return null;
            }
            $activeEntities[(int) $entity] = (int) $entity;
        }
        if ($activeEntities === []) {
            $entity = (int) $_SESSION['glpiactive_entity'];
            $activeEntities[$entity] = $entity;
        }
        sort($activeEntities, SORT_NUMERIC);

        return [
            'user' => $userId,
            'profile' => $profileId,
            'entity' => (int) $_SESSION['glpiactive_entity'],
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']) ? 1 : 0,
            'entities' => hash('sha256', implode(',', $activeEntities)),
        ];
    }

    /** @return array<string,mixed> */
    private function buckets(string $sessionKey): array
    {
        $buckets = $_SESSION[$sessionKey] ?? [];
        return is_array($buckets) ? $buckets : [];
    }

    /** @return array{started_at:int,count:int} */
    private function currentBucket(array $buckets, string $key, int $now): array
    {
        $bucket = is_array($buckets[$key] ?? null)
            ? $buckets[$key]
            : ['started_at' => $now, 'count' => 0];
        $startedAt = is_numeric($bucket['started_at'] ?? null)
            ? (int) $bucket['started_at']
            : $now;
        $count = is_numeric($bucket['count'] ?? null)
            ? max(0, (int) $bucket['count'])
            : 0;
        if ($now < $startedAt || ($now - $startedAt) >= $this->windowSeconds) {
            return ['started_at' => $now, 'count' => 0];
        }
        return ['started_at' => $startedAt, 'count' => $count];
    }

    /** @param array{started_at:int,count:int} $bucket */
    private function retryAfter(array $bucket, int $cost, int $now): int
    {
        if ($cost <= $this->limit && $bucket['count'] <= ($this->limit - $cost)) {
            return 0;
        }
        return max(1, $this->windowSeconds - ($now - $bucket['started_at']));
    }

    /** @param array<string,mixed> $buckets */
    private function store(
        string $sessionKey,
        array $buckets,
        string $key,
        int $startedAt,
        int $count,
        int $now,
        ?int $maxBuckets = null
    ): void {
        foreach ($buckets as $bucketKey => $bucket) {
            if (
                !is_array($bucket)
                || !is_numeric($bucket['started_at'] ?? null)
                || ($now - (int) $bucket['started_at']) > ($this->windowSeconds * 2)
            ) {
                unset($buckets[$bucketKey]);
            }
        }
        $buckets[$key] = ['started_at' => $startedAt, 'count' => $count];
        if ($maxBuckets !== null && count($buckets) > $maxBuckets) {
            $buckets = array_slice($buckets, -$maxBuckets, null, true);
        }
        $_SESSION[$sessionKey] = $buckets;
    }
}
