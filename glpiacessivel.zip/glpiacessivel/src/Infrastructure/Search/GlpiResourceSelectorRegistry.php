<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Closed registry of selector purposes. The browser never supplies a table,
 * itemtype, right or native condition.
 */
final class GlpiResourceSelectorRegistry
{
    public const CATEGORY = 'category';
    public const LOCATION = 'location';
    public const ASSIGNED_USER = 'assigned_user';
    public const ASSIGNED_GROUP = 'assigned_group';
    public const OBSERVER_USER = 'observer_user';
    public const OBSERVER_GROUP = 'observer_group';

    public const PURPOSES = [
        self::CATEGORY,
        self::LOCATION,
        self::ASSIGNED_USER,
        self::ASSIGNED_GROUP,
        self::OBSERVER_USER,
        self::OBSERVER_GROUP,
    ];

    /** @var array<string,int> */
    private const MINIMUM_QUERY_LENGTHS = [
        self::CATEGORY => 0,
        self::LOCATION => 0,
        self::ASSIGNED_USER => 2,
        self::ASSIGNED_GROUP => 2,
        self::OBSERVER_USER => 2,
        self::OBSERVER_GROUP => 2,
    ];

    /**
     * @param array<string,int> $dependencies
     * @return array<string,mixed>
     */
    public function descriptor(string $purpose, array $dependencies = []): array
    {
        if (!in_array($purpose, self::PURPOSES, true)) {
            throw new \InvalidArgumentException('resource_selector_purpose_not_allowed');
        }

        $condition = [];
        $table = '';
        $linkfield = '';
        $itemtype = '';
        $right = null;

        switch ($purpose) {
            case self::CATEGORY:
                $table = 'glpi_itilcategories';
                $linkfield = 'itilcategories_id';
                $itemtype = 'ITILCategory';
                $condition = ['is_helpdesk_visible' => 1];
                $ticketType = (int) ($dependencies['ticket_type'] ?? 0);
                if ($ticketType === 1) {
                    $condition['is_incident'] = 1;
                } elseif ($ticketType === 2) {
                    $condition['is_request'] = 1;
                } elseif ($ticketType !== 0) {
                    throw new \InvalidArgumentException('resource_selector_dependency_invalid');
                }
                break;

            case self::LOCATION:
                $table = 'glpi_locations';
                $linkfield = 'locations_id';
                $itemtype = 'Location';
                break;

            case self::ASSIGNED_USER:
                $table = 'glpi_users';
                $linkfield = 'users_id';
                $itemtype = 'User';
                $right = 'own_ticket';
                break;

            case self::OBSERVER_USER:
                $table = 'glpi_users';
                $linkfield = 'users_id';
                $itemtype = 'User';
                // "id" is GLPI's least-privileged contextual user dropdown.
                $right = 'id';
                break;

            case self::ASSIGNED_GROUP:
                $table = 'glpi_groups';
                $linkfield = 'groups_id';
                $itemtype = 'Group';
                $condition = ['is_assign' => 1];
                break;

            case self::OBSERVER_GROUP:
                $table = 'glpi_groups';
                $linkfield = 'groups_id';
                $itemtype = 'Group';
                $condition = ['is_watcher' => 1];
                break;
        }

        return [
            'id' => 1,
            'table' => $table,
            'linkfield' => $linkfield,
            'value' => [
                'mode' => 'remote',
                'table' => $table,
                'linkfield' => $linkfield,
                'native' => [
                    'itemtype' => $itemtype,
                    'right' => $right,
                    'condition' => $condition,
                    'displaywith' => [],
                    'toadd' => [],
                ],
            ],
        ];
    }

    /** @return string[] */
    public function allowedDependencyKeys(string $purpose): array
    {
        if (!in_array($purpose, self::PURPOSES, true)) {
            throw new \InvalidArgumentException('resource_selector_purpose_not_allowed');
        }

        if ($purpose === self::CATEGORY) {
            return ['ticket_type'];
        }
        if (
            in_array($purpose, [
            self::ASSIGNED_USER,
            self::ASSIGNED_GROUP,
            self::OBSERVER_USER,
            self::OBSERVER_GROUP,
            ], true)
        ) {
            return ['ticket_id'];
        }

        return [];
    }

    public function requiresQuery(string $purpose): bool
    {
        return $this->minimumQueryLength($purpose) > 0;
    }

    public function minimumQueryLength(string $purpose): int
    {
        if (!array_key_exists($purpose, self::MINIMUM_QUERY_LENGTHS)) {
            throw new \InvalidArgumentException('resource_selector_purpose_not_allowed');
        }

        return self::MINIMUM_QUERY_LENGTHS[$purpose];
    }
}
