<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

use GlpiPlugin\Glpiacessivel\Infrastructure\Security\GlpiSessionContextSnapshot;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\TicketRepository;

/**
 * Permission-aware, paginated provider for ticket resource selectors.
 */
final class GlpiResourceSelectorProvider
{
    public const CONTRACT = 'resource_selector';
    public const VERSION = 1;
    public const PAGE_SIZE = 20;
    public const MAX_QUERY_LENGTH = 120;
    public const MAX_SELECTED_IDS = 20;

    private GlpiResourceSelectorRegistry $registry;
    private GlpiSessionContextSnapshot $context;
    private GlpiResourceSelectorCursor $cursor;

    /** @var null|\Closure(string,string,int,int,?int,array<string,mixed>):mixed */
    private ?\Closure $nativeLookup;

    public function __construct(
        ?GlpiResourceSelectorRegistry $registry = null,
        ?GlpiSessionContextSnapshot $context = null,
        ?GlpiResourceSelectorCursor $cursor = null,
        ?callable $nativeLookup = null
    ) {
        $this->registry = $registry ?? new GlpiResourceSelectorRegistry();
        $this->context = $context ?? new GlpiSessionContextSnapshot();
        $this->cursor = $cursor ?? new GlpiResourceSelectorCursor();
        $this->nativeLookup = $nativeLookup === null
            ? null
            : \Closure::fromCallable($nativeLookup);
    }

    public function contextRevision(): string
    {
        return $this->context->snapshot()['revision'];
    }

    public function minimumQueryLength(string $purpose): int
    {
        return $this->registry->minimumQueryLength($purpose);
    }

    /**
     * @param int[] $selectedIds
     * @param array<string,mixed> $dependencies
     * @return array{
     *   contract:string,
     *   version:int,
     *   purpose:string,
     *   context_revision:string,
     *   results:array<int,array{id:int,label:string}>,
     *   pagination:array{more:bool,cursor:?string}
     * }
     */
    public function search(
        string $purpose,
        string $query = '',
        ?string $cursor = null,
        array $selectedIds = [],
        array $dependencies = [],
        ?string $contextRevision = null
    ): array {
        $purpose = trim($purpose);
        $query = trim($query);
        $dependencies = $this->normalizeDependencies($purpose, $dependencies);
        $selectedIds = $this->normalizeSelectedIds($selectedIds);
        $this->validateQuery($purpose, $query, $selectedIds);

        $context = $this->context->snapshot();
        if (
            $contextRevision !== null
            && (
                preg_match('/\A[a-f0-9]{64}\z/D', $contextRevision) !== 1
                || !hash_equals($context['revision'], $contextRevision)
            )
        ) {
            throw new \InvalidArgumentException('resource_selector_context_stale');
        }

        if ($selectedIds !== [] && ($cursor !== null || $query !== '')) {
            throw new \InvalidArgumentException('resource_selector_hydration_invalid');
        }

        $binding = [
            'purpose' => $purpose,
            'query' => mb_strtolower($query, 'UTF-8'),
            'dependencies' => $dependencies,
            'context_revision' => $context['revision'],
        ];
        $page = $cursor === null || $cursor === ''
            ? 1
            : $this->cursor->resolve($cursor, $binding);
        if ($selectedIds !== [] && $page !== 1) {
            throw new \InvalidArgumentException('resource_selector_hydration_invalid');
        }

        $descriptor = $this->registry->descriptor($purpose, $dependencies);
        $targetContext = $this->targetContext($dependencies, $context);
        $valueProvider = new GlpiSearchValueProvider(
            null,
            $this->nativeLookup,
            static fn(): array => $descriptor,
            self::PAGE_SIZE,
            static fn(): array => $targetContext,
            $this->registry->minimumQueryLength($purpose)
        );

        $results = [];
        $more = false;
        if ($selectedIds !== []) {
            foreach ($selectedIds as $selectedId) {
                $result = $valueProvider->search('Ticket', 1, '', 1, $selectedId);
                foreach ((array) ($result['results'] ?? []) as $row) {
                    if (is_array($row) && (int) ($row['id'] ?? 0) === $selectedId) {
                        $results[$selectedId] = [
                            'id' => $selectedId,
                            'label' => (string) ($row['label'] ?? ''),
                        ];
                    }
                }
            }
        } else {
            $result = $valueProvider->search('Ticket', 1, $query, $page);
            foreach ((array) ($result['results'] ?? []) as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $id = (int) ($row['id'] ?? 0);
                $label = trim((string) ($row['label'] ?? ''));
                if ($id > 0 && $label !== '') {
                    $results[$id] = ['id' => $id, 'label' => $label];
                }
            }
            $more = !empty($result['pagination']['more']);
        }

        $nextCursor = $more
            ? $this->cursor->issue($page + 1, $binding)
            : null;

        return [
            'contract' => self::CONTRACT,
            'version' => self::VERSION,
            'purpose' => $purpose,
            'context_revision' => $context['revision'],
            'results' => array_values($results),
            'pagination' => [
                'more' => $more,
                'cursor' => $nextCursor,
            ],
        ];
    }

    /**
     * Revalidate the complete set against GLPI immediately before mutation.
     *
     * @param int[] $ids
     * @param array<string,mixed> $dependencies
     */
    public function authorizeAll(string $purpose, array $ids, array $dependencies = []): bool
    {
        $ids = $this->normalizeSelectedIds($ids);
        if ($ids === []) {
            return true;
        }
        $result = $this->search($purpose, '', null, $ids, $dependencies);
        $authorized = [];
        foreach ($result['results'] as $row) {
            $authorized[(int) $row['id']] = true;
        }
        foreach ($ids as $id) {
            if (!isset($authorized[$id])) {
                return false;
            }
        }

        return true;
    }

    /** @param array<string,mixed> $dependencies @return array<string,int> */
    private function normalizeDependencies(string $purpose, array $dependencies): array
    {
        $allowed = $this->registry->allowedDependencyKeys($purpose);
        $normalized = [];
        foreach ($dependencies as $key => $value) {
            if (!is_string($key) || !in_array($key, $allowed, true)) {
                throw new \InvalidArgumentException('resource_selector_dependency_not_allowed');
            }
            if (
                (!is_int($value) && !is_string($value))
                || preg_match('/\A(?:0|[1-9]\d*)\z/D', (string) $value) !== 1
                || strlen((string) $value) > 10
            ) {
                throw new \InvalidArgumentException('resource_selector_dependency_invalid');
            }
            $normalized[$key] = (int) $value;
        }
        foreach ($allowed as $key) {
            if (!array_key_exists($key, $normalized)) {
                $normalized[$key] = 0;
            }
        }
        ksort($normalized);

        return $normalized;
    }

    /**
     * A routing selector is constrained to the ticket entity after proving the
     * current session can route the ticket. The ticket id never comes from a
     * generic provider contract and never acts as authorization by itself.
     *
     * @param array<string,int> $dependencies
     * @param array<string,mixed> $sessionContext
     * @return array{active_entities:int[],active_entity:int,recursive:bool}
     */
    private function targetContext(array $dependencies, array $sessionContext): array
    {
        $ticketId = (int) ($dependencies['ticket_id'] ?? 0);
        if ($ticketId <= 0) {
            return [
                'active_entities' => (array) ($sessionContext['active_entities'] ?? []),
                'active_entity' => (int) ($sessionContext['active_entity'] ?? -1),
                'recursive' => !empty($sessionContext['recursive']),
            ];
        }

        if (!class_exists('\Ticket')) {
            throw new \RuntimeException('resource_selector_target_unavailable');
        }
        $repository = new TicketRepository();
        if (!$repository->canRouteTicket($ticketId)) {
            throw new \RuntimeException('resource_selector_target_forbidden');
        }
        $ticket = new \Ticket();
        if (!method_exists($ticket, 'getFromDB') || !$ticket->getFromDB($ticketId)) {
            throw new \RuntimeException('resource_selector_target_forbidden');
        }
        $entityId = (int) ($ticket->fields['entities_id'] ?? -1);
        if (
            $entityId < 0
            || (
                class_exists('\Session')
                && method_exists('\Session', 'haveAccessToEntity')
                && !\Session::haveAccessToEntity($entityId)
            )
        ) {
            throw new \RuntimeException('resource_selector_target_forbidden');
        }

        return [
            'active_entities' => [$entityId],
            'active_entity' => $entityId,
            'recursive' => false,
        ];
    }

    /** @param mixed[] $selectedIds @return int[] */
    private function normalizeSelectedIds(array $selectedIds): array
    {
        if (count($selectedIds) > self::MAX_SELECTED_IDS) {
            throw new \InvalidArgumentException('resource_selector_selected_limit');
        }
        $normalized = [];
        foreach ($selectedIds as $id) {
            if (
                (!is_int($id) && !is_string($id))
                || preg_match('/\A[1-9]\d*\z/D', (string) $id) !== 1
                || strlen((string) $id) > 10
            ) {
                throw new \InvalidArgumentException('resource_selector_selected_invalid');
            }
            $normalized[(int) $id] = (int) $id;
        }

        return array_values($normalized);
    }

    /** @param int[] $selectedIds */
    private function validateQuery(string $purpose, string $query, array $selectedIds): void
    {
        $validUtf8 = function_exists('mb_check_encoding')
            ? mb_check_encoding($query, 'UTF-8')
            : preg_match('//u', $query) === 1;
        if (
            !$validUtf8
            || mb_strlen($query) > self::MAX_QUERY_LENGTH
            || preg_match('/[\x00-\x1F\x7F]/u', $query) === 1
        ) {
            throw new \InvalidArgumentException('resource_selector_query_invalid');
        }
        if (
            $selectedIds === []
            && mb_strlen($query) < $this->registry->minimumQueryLength($purpose)
        ) {
            throw new \InvalidArgumentException('resource_selector_query_too_short');
        }
    }
}
