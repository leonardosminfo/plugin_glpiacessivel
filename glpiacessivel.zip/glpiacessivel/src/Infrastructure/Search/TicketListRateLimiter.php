<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/** Session-scoped limiter dedicated to ticket result retrieval. */
final class TicketListRateLimiter
{
    private const SESSION_KEY = 'glpiacessivel_ticket_list_rate_v1';
    private const LIMIT = 30;
    private const WINDOW_SECONDS = 60;

    /** @return array{allowed:bool,retry_after:int} */
    public function consume(): array
    {
        $now = time();
        $bucket = is_array($_SESSION[self::SESSION_KEY] ?? null)
            ? $_SESSION[self::SESSION_KEY]
            : ['started_at' => $now, 'count' => 0];
        $startedAt = is_numeric($bucket['started_at'] ?? null) ? (int) $bucket['started_at'] : $now;
        $count = is_numeric($bucket['count'] ?? null) ? max(0, (int) $bucket['count']) : 0;
        if ($now < $startedAt || ($now - $startedAt) >= self::WINDOW_SECONDS) {
            $startedAt = $now;
            $count = 0;
        }

        if ($count >= self::LIMIT) {
            return [
                'allowed' => false,
                'retry_after' => max(1, self::WINDOW_SECONDS - ($now - $startedAt)),
            ];
        }

        $_SESSION[self::SESSION_KEY] = [
            'started_at' => $startedAt,
            'count' => $count + 1,
        ];

        return ['allowed' => true, 'retry_after' => 0];
    }
}
