<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Sources finite Ticket values from the active GLPI generation.
 *
 * Labels always come from Search Options or GLPI core APIs. If the active
 * generation cannot prove a finite domain, the catalog returns no values.
 */
final class GlpiTicketLocalValueCatalog
{
    /**
     * @param array<string,mixed> $option
     * @return array<int,array{value:string,label:string}>
     */
    public function valuesFor(string $itemtype, array $option): array
    {
        $native = $this->optionValues($option);
        if ($native !== [] || $itemtype !== 'Ticket') {
            return $native;
        }

        $field = strtolower(trim((string) ($option['field'] ?? '')));
        if ($field === 'status') {
            return $this->statusValues();
        }
        if (in_array($field, ['priority', 'urgency', 'impact'], true)) {
            return $this->levelValues($field);
        }

        return [];
    }

    /**
     * @param array<string,mixed> $option
     * @return array<int,array{value:string,label:string}>
     */
    private function optionValues(array $option): array
    {
        foreach (['values', 'search_values'] as $key) {
            if (!is_array($option[$key] ?? null)) {
                continue;
            }
            return $this->normalizeMap($option[$key]);
        }
        return [];
    }

    /** @return array<int,array{value:string,label:string}> */
    private function statusValues(): array
    {
        if (!class_exists('\Ticket') || !method_exists('\Ticket', 'getAllStatusArray')) {
            return [];
        }
        try {
            /** @var mixed $raw */
            $raw = \Ticket::getAllStatusArray();
        } catch (\Throwable $e) {
            return [];
        }
        if (!is_array($raw)) {
            return [];
        }

        $values = $this->normalizeMap($raw, true);
        if ($values === []) {
            return [];
        }

        // Stable aggregate tokens; labels are resolved by GLPI's translator.
        return array_merge($values, [
            ['value' => 'notold', 'label' => $this->translate('Not solved')],
            ['value' => 'notclosed', 'label' => $this->translate('Not closed')],
            ['value' => 'process', 'label' => $this->translate('Processing')],
            ['value' => 'old', 'label' => $this->translate('Solved + Closed')],
            ['value' => 'all', 'label' => $this->translate('All')],
        ]);
    }

    /** @return array<int,array{value:string,label:string}> */
    private function levelValues(string $field): array
    {
        $method = 'get' . ucfirst($field) . 'Name';
        $class = $this->levelProviderClass($method);
        if ($class === '') {
            return [];
        }

        $levels = [];
        foreach (['VERYLOW', 'LOW', 'MEDIUM', 'HIGH', 'VERYHIGH', 'MAJOR'] as $constant) {
            $qualified = $class . '::' . $constant;
            if (!defined($qualified)) {
                continue;
            }
            $value = constant($qualified);
            if (!is_int($value) && !(is_string($value) && ctype_digit($value))) {
                continue;
            }
            $levels[(int) $value] = (int) $value;
        }
        ksort($levels, SORT_NUMERIC);

        $values = [];
        foreach ($levels as $level) {
            try {
                /** @var mixed $label */
                $label = call_user_func([$class, $method], $level);
            } catch (\Throwable $e) {
                return [];
            }
            if (!is_scalar($label) || trim((string) $label) === '') {
                return [];
            }
            $values[] = ['value' => (string) $level, 'label' => trim((string) $label)];
        }
        return $values;
    }

    private function levelProviderClass(string $method): string
    {
        foreach (['\Ticket', '\CommonITILObject'] as $class) {
            if (class_exists($class) && method_exists($class, $method)) {
                return $class;
            }
        }
        return '';
    }

    private function translate(string $message): string
    {
        if (function_exists('__')) {
            try {
                $translated = __($message);
                if (is_scalar($translated) && trim((string) $translated) !== '') {
                    return trim((string) $translated);
                }
            } catch (\Throwable $e) {
                // The stable English source string remains a safe fallback.
            }
        }
        return $message;
    }

    /**
     * @param array<mixed,mixed> $values
     * @return array<int,array{value:string,label:string}>
     */
    private function normalizeMap(array $values, bool $numericOnly = false): array
    {
        $normalized = [];
        foreach ($values as $value => $label) {
            if (
                !is_scalar($value)
                || !is_scalar($label)
                || ($numericOnly && !is_numeric($value))
            ) {
                continue;
            }
            $value = (string) $value;
            $label = trim((string) $label);
            if ($value === '' || $label === '' || isset($normalized[$value])) {
                continue;
            }
            $normalized[$value] = ['value' => $value, 'label' => $label];
        }
        return array_values($normalized);
    }
}
