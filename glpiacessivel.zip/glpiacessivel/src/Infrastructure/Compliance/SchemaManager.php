<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Compliance;

use DBmysql;
use DBConnection;
use Migration;

final class SchemaManager
{
    private const LEGACY_TICKET_VIEWS_TABLE = 'glpi_plugin_glpiacessivel_ticketviews';

    /** @var DBmysql */
    private $db;

    public function __construct(DBmysql $db)
    {
        $this->db = $db;
    }

    public function install(): bool
    {
        if (!$this->removeLegacyTicketViewsIfEmpty()) {
            return false;
        }

        $defaultCharset = DBConnection::getDefaultCharset();
        $defaultCollation = DBConnection::getDefaultCollation();
        $migration = new Migration(defined('PLUGIN_GLPIACESSIVEL_VERSION') ? PLUGIN_GLPIACESSIVEL_VERSION : '1.0.0');

        $queries = [
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_auditlogs` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `users_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `entities_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `tickets_id` INT UNSIGNED DEFAULT NULL,
                `action` VARCHAR(120) NOT NULL,
                `payload` LONGTEXT NULL,
                `ip` VARCHAR(64) NULL,
                `created_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_users_id` (`users_id`),
                KEY `idx_entities_id` (`entities_id`),
                KEY `idx_tickets_id` (`tickets_id`),
                KEY `idx_action` (`action`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_piireveals` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `users_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `entities_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `tickets_id` INT UNSIGNED DEFAULT NULL,
                `field_name` VARCHAR(100) NOT NULL,
                `reason` VARCHAR(255) NULL,
                `created_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_users_id` (`users_id`),
                KEY `idx_tickets_id` (`tickets_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_configs` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `key_name` VARCHAR(150) NOT NULL,
                `value_text` LONGTEXT NULL,
                `updated_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_key_name` (`key_name`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_playbookjobs` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `users_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `entities_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `job_type` VARCHAR(40) NOT NULL,
                `status` VARCHAR(30) NOT NULL,
                `source_scope` VARCHAR(60) NOT NULL,
                `options_json` LONGTEXT NULL,
                `cursor_json` LONGTEXT NULL,
                `processed_count` INT UNSIGNED NOT NULL DEFAULT 0,
                `suggestions_count` INT UNSIGNED NOT NULL DEFAULT 0,
                `message` VARCHAR(255) NULL,
                `started_at` DATETIME NULL,
                `finished_at` DATETIME NULL,
                `created_at` DATETIME NOT NULL,
                `updated_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_users_id` (`users_id`),
                KEY `idx_status` (`status`),
                KEY `idx_job_type` (`job_type`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_playbooksuggestions` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `jobs_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `entities_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `source_type` VARCHAR(40) NOT NULL,
                `title` VARCHAR(255) NOT NULL,
                `intent` VARCHAR(80) NOT NULL,
                `confidence` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
                `keywords_json` LONGTEXT NULL,
                `questions_json` LONGTEXT NULL,
                `kb_articles_json` LONGTEXT NULL,
                `category_hint` VARCHAR(255) NULL,
                `group_hint` VARCHAR(255) NULL,
                `ticket_template_json` LONGTEXT NULL,
                `status` VARCHAR(30) NOT NULL DEFAULT 'pending',
                `content_json` LONGTEXT NULL,
                `reviewed_by` INT UNSIGNED NOT NULL DEFAULT 0,
                `reviewed_at` DATETIME NULL,
                `created_at` DATETIME NOT NULL,
                `updated_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_jobs_id` (`jobs_id`),
                KEY `idx_status` (`status`),
                KEY `idx_intent` (`intent`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_playbooks` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `entities_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `name` VARCHAR(255) NOT NULL,
                `intent` VARCHAR(80) NOT NULL,
                `is_active` TINYINT(1) NOT NULL DEFAULT 1,
                `source_suggestion_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `keywords_json` LONGTEXT NULL,
                `questions_json` LONGTEXT NULL,
                `kb_articles_json` LONGTEXT NULL,
                `category_hint` VARCHAR(255) NULL,
                `group_hint` VARCHAR(255) NULL,
                `ticket_template_json` LONGTEXT NULL,
                `content_json` LONGTEXT NULL,
                `created_at` DATETIME NOT NULL,
                `updated_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_intent` (`intent`),
                KEY `idx_is_active` (`is_active`),
                KEY `idx_source_suggestion_id` (`source_suggestion_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_idempotency` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `scope_hash` CHAR(64) NOT NULL,
                `idempotency_key_hash` CHAR(64) NOT NULL,
                `request_hash` CHAR(64) NOT NULL,
                `reservation_token_hash` CHAR(64) NOT NULL,
                `status` VARCHAR(16) NOT NULL,
                `result_id` BIGINT UNSIGNED DEFAULT NULL,
                `expires_at` DATETIME NOT NULL,
                `created_at` DATETIME NOT NULL,
                `updated_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_scope_key` (`scope_hash`, `idempotency_key_hash`),
                KEY `idx_expires_at` (`expires_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
        ];

        foreach ($queries as $sql) {
            if (!$this->db->doQuery($sql)) {
                return false;
            }
        }

        $now = date('Y-m-d H:i:s');
        $legacyFormsEnabled = $this->existingConfigValue('forms_enabled', '1');
        $legacyChatbotEnabled = $this->existingConfigValue('chatbot_enabled', '1');
        $defaults = [
            'accessibility_mode' => 'hybrid',
            'plugin_fallback_locale' => 'pt_BR',
            'vlibras_scope' => 'plugin_pages',
            'forms_enabled' => '1',
            'pii_masking_enabled' => '0',
            'forms_native_flow_mode' => 'native_embedded',
            'chatbot_enabled' => '1',
            'module_ticket_create_state' => 'available',
            'module_forms_state' => $legacyFormsEnabled === '0' ? 'disabled' : 'available',
            'module_tickets_state' => 'available',
            'module_cockpit_state' => 'available',
            'module_knowledge_state' => 'available',
            'module_chatbot_state' => $legacyChatbotEnabled === '0' ? 'disabled' : 'available',
            'module_playbooks_state' => 'available',
            'chatbot_display_name' => 'Assistente',
            'chatbot_floating_button_enabled' => '1',
            'chatbot_floating_scope' => 'all_logged_pages',
            'chatbot_voice_enabled' => '1',
            'chatbot_voice_locale' => 'pt-BR',
            'chatbot_voice_asset_mode' => 'local_preferred',
            'chatbot_stt_engine' => 'vosklet',
            'chatbot_tts_engine' => 'browser_native',
            'chatbot_tts_browser_native_migration_applied' => '1',
            'chatbot_stt_script_local_path' => 'public/assets/vendor/vosklet/Vosklet.js',
            'chatbot_stt_model_local_path' => 'public/assets/voice/vosk/pt-BR/vosk-model-small-pt-0.3.zip',
            'chatbot_tts_script_local_path' => 'public/assets/vendor/piper/piper-tts-web.js',
            'chatbot_tts_onnx_runtime_local_path' => 'public/assets/vendor/onnxruntime-web/1.18.0/ort.esm.js',
            'chatbot_tts_onnx_wasm_local_path' => 'public/assets/vendor/onnxruntime-web/1.18.0',
            'chatbot_tts_piper_wasm_local_path' => 'public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.wasm',
            'chatbot_tts_piper_data_local_path' => 'public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.data',
            'chatbot_tts_voice_model_local_path' => 'public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx',
            'chatbot_tts_voice_config_local_path' => 'public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx.json',
            'chatbot_stt_script_url' => 'https://cdn.jsdelivr.net/gh/msqr1/Vosklet@1.2.1/Examples/Vosklet.js',
            'chatbot_stt_model_url' => 'https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip',
            'chatbot_stt_model_label' => 'Portugues (Brasil)',
            'chatbot_stt_model_cache_id' => 'glpi-vosk-ptbr',
            'chatbot_tts_script_url' => 'https://esm.run/@mintplex-labs/piper-tts-web',
            'chatbot_tts_voice_id' => 'pt_BR-faber-medium',
            'audit_retention_days' => '365',
        ];

        foreach ($defaults as $key => $value) {
            $existing = $this->db->request([
                'SELECT' => ['id'],
                'FROM'   => 'glpi_plugin_glpiacessivel_configs',
                'WHERE'  => ['key_name' => $key],
                'LIMIT'  => 1,
            ])->current();

            if ($existing) {
                continue;
            }

            if (
                !$this->db->insert('glpi_plugin_glpiacessivel_configs', [
                'key_name'   => $key,
                'value_text' => $value,
                'updated_at' => $now,
                ])
            ) {
                return false;
            }
        }

        $migration->executeMigration();

        return true;
    }

    private function removeLegacyTicketViewsIfEmpty(): bool
    {
        if (!method_exists($this->db, 'tableExists')) {
            return false;
        }

        try {
            if (!$this->db->tableExists(self::LEGACY_TICKET_VIEWS_TABLE)) {
                return true;
            }
        } catch (\Throwable $e) {
            return false;
        }

        $locked = false;
        try {
            $locked = (bool) $this->db->doQuery(
                'LOCK TABLES `' . self::LEGACY_TICKET_VIEWS_TABLE . '` WRITE'
            );
            if (!$locked) {
                return false;
            }

            $unexpectedRow = $this->db->request([
                'SELECT' => ['id'],
                'FROM' => self::LEGACY_TICKET_VIEWS_TABLE,
                'LIMIT' => 1,
            ])->current();
            if ($unexpectedRow !== false && $unexpectedRow !== null) {
                return false;
            }

            return (bool) $this->db->doQuery(
                'DROP TABLE `' . self::LEGACY_TICKET_VIEWS_TABLE . '`'
            );
        } catch (\Throwable $e) {
            return false;
        } finally {
            if ($locked) {
                try {
                    $this->db->doQuery('UNLOCK TABLES');
                } catch (\Throwable $e) {
                    // The installation has already failed closed or DROP released the lock.
                }
            }
        }
    }

    private function existingConfigValue(string $key, string $default): string
    {
        $row = $this->db->request([
            'SELECT' => ['value_text'],
            'FROM' => 'glpi_plugin_glpiacessivel_configs',
            'WHERE' => ['key_name' => $key],
            'LIMIT' => 1,
        ])->current();

        return is_array($row) && array_key_exists('value_text', $row)
            ? (string) $row['value_text']
            : $default;
    }
    public function uninstall(): bool
    {
        $queries = [
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_ticketviews`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_idempotency`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_playbooks`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_playbooksuggestions`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_playbookjobs`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_auditlogs`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_piireveals`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_configs`',
        ];

        foreach ($queries as $sql) {
            if (!$this->db->doQuery($sql)) {
                return false;
            }
        }

        return true;
    }
}
