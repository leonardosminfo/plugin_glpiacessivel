# Declaração de acessibilidade

Versão de referência: 0.2.39-beta.

O GLPI Acessível busca atender às WCAG 2.2 nível AA e ao eMAG 3.1 nas telas sob seu controle. O plugin oferece navegação por teclado, foco visível, modos de contraste, atalhos opcionais, mensagens anunciáveis e compatibilidade progressiva com leitores de tela.

Esta declaração registra o objetivo e as evidências exigidas do projeto. Ela não constitui certificação de conformidade e não substitui a homologação da instalação, da versão do GLPI, dos plugins integrados, dos perfis, das entidades e das tecnologias assistivas efetivamente utilizadas.

## Limites conhecidos

- Formulários nativos incorporados preservam o motor e os componentes da fonte GLPI/Formcreator. No GLPI 11, origem, rota, identificador, método e endpoint de envio precisam corresponder ao contrato esperado; no Formcreator, a apresentação mínima continua opcional e conservadora. Divergências mantêm a interface nativa e a alternativa de página completa.
- Recursos cuja fonte nativa está indisponível mantêm uma alternativa para o GLPI. Uma falha de consulta ou um contexto de grupos não comprovado não deve ser apresentado como resultado vazio ou como contagem zero; somente a ausência oficial de grupos confirmada no perfil e na entidade atuais produz vazio e zero exatos.
- Voz e VLibras são opcionais; falhas ou indisponibilidade não impedem a operação principal.
- A conformidade final depende da matriz assistiva e da homologação da versão GLPI instalada.

## Evidências obrigatórias por versão

- Axe e revisão manual nas rotas autenticadas, sem tratar resultados incompletos como violações confirmadas;
- teclado, reflow em 320 pixels CSS sem overflow horizontal do documento, zoom de 200% e 400% e contraste forçado;
- NVDA, JAWS e, quando fizer parte da matriz institucional, VoiceOver nos fluxos críticos;
- testes de tarefa com pessoas cegas representativas dos perfis de autoatendimento, técnico e supervisão;
- registro de exceções, responsável, impacto e prazo de correção.
- revisão linguística das superfícies visíveis, nomes acessíveis, placeholders e regiões vivas, com acentuação, mojibake, placeholders, catálogos Gettext e artefatos MO validados no pacote.
- verificação de plurais naturais e de anúncio único por mudança de estado, sem mensagens duplicadas para leitores de tela;
- mensagens de sessão expirada e CSRF orientadas à recuperação, sem revelar tokens, exceções ou detalhes administrativos ao usuário comum.
