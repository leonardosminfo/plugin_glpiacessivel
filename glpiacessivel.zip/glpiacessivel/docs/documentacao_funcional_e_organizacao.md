# Documentacao funcional e organizacao do GLPI Acessivel

## Visao funcional

O GLPI Acessivel oferece uma interface alternativa e integrada ao GLPI. O usuario continua sujeito ao mesmo login, perfil, entidade, recursividade e permissoes. A interface acessivel organiza as tarefas mais frequentes sem copiar os dados operacionais para outro sistema.

## Funcionalidades

### Portal e contexto

- entrada acessivel com navegacao consistente;
- configuracao da entrada anonima entre login unificado do GLPI, recomendado, e formulario alternativo de compatibilidade;
- redirecionamento direto ao login oficial do GLPI quando o modo unificado esta ativo, preservando SSO, MFA e retorno ao portal;
- nota estatica e opcional imediatamente depois de `Entrar` no login nativo, identificada semanticamente, sem link, foco, anuncio intrusivo, formulario ou rota alternativa; uma melhoria progressiva restrita move a nota no DOM e conserva a area do hook como fallback;
- identificacao autenticada por login e primeiro nome nativo do GLPI, com fallback para somente o login;
- troca autorizada de perfil e entidade;
- indicacao do contexto ativo;
- atalhos de teclado, tema noturno, alto contraste e ampliacao;
- alternativa explicita para abrir a tela nativa do GLPI quando necessario.

### Chamados

- criacao assistida com campos autorizados, anexos e validacao acessivel;
- listagem com pesquisa textual, escopo, criterios, grupos e metacriterios;
- operadores e valores derivados das Search Options do GLPI;
- autocomplete remoto autorizado para usuarios, grupos, categorias e demais dropdowns;
- multiplas ordenacoes, quantidade por pagina e escolha/reordenacao de colunas;
- exibicao autorizada de chamados ativos ou excluidos;
- resumo separado da consulta em edicao e da pesquisa aplicada;
- paginacao, selecao e abertura do chamado;
- detalhe com acompanhamentos, tarefas, solucao, documentos e acoes permitidas.
- selecao separada de grupos tecnicos e grupos observadores, limitada aos grupos elegiveis para cada papel e para a entidade do chamado;
- recuperacao dos grupos ja vinculados e substituicao por papel sem alterar usuarios, fornecedores ou outros atores.

### Pesquisas salvas

- catalogo paginado das pesquisas autorizadas do GLPI;
- pesquisa por nome;
- aplicacao direta da definicao nativa;
- criacao, renomeacao, definicao como padrao e exclusao no proprio GLPI;
- classificacao conservadora de pesquisas que precisam ser abertas na interface nativa;
- nenhuma copia ou sincronizacao local de `SavedSearch`.

### Conhecimento, formularios e atendimento

- consulta acessivel da base de conhecimento;
- descoberta e renderizacao delegada de formularios nativos, Service Catalog e Formcreator quando o contrato e comprovado;
- chatbot operacional com politicas de intencao, mascaramento de dados e encaminhamento seguro;
- FAQ, cockpit e playbooks para orientar atendimento e operacao;
- configuracao administrativa e diagnostico local de acessibilidade.

## Fluxo de uma requisicao

1. Um arquivo em `front/` carrega o bootstrap do GLPI; na entrada anonima, a politica decide entre redirecionamento nativo e ponte compativel antes de preparar o formulario.
2. O controlador confirma sessao, contexto, CSRF quando aplicavel e permissao.
3. Um servico de aplicacao coordena o caso de uso.
4. Regras de dominio validam a entrada e o contrato.
5. Um repositorio ou adaptador consulta as APIs e tabelas do GLPI.
6. Um presenter prepara informacao sem metadados internos.
7. O template gera HTML semantico e os ativos adicionam interacao progressiva.

## Organizacao das pastas

| Pasta | Responsabilidade |
|---|---|
| `front/` | Pontos de entrada HTTP do plugin |
| `src/Application/` | Casos de uso e orquestracao |
| `src/Domain/` | Politicas, entidades e contratos de negocio |
| `src/Infrastructure/` | Repositorios, pesquisa, auditoria, seguranca e persistencia |
| `src/Model/` | Modelos de tabelas proprias do plugin |
| `src/Security/` | CSRF, sanitizacao e guarda de contexto |
| `src/Support/` | Bootstrap, conteiner, compatibilidade e utilitarios |
| `src/UI/` | Controladores, presenters e mecanismo de views |
| `templates/` | Paginas e componentes HTML renderizados no servidor |
| `assets/` | Fontes de CSS, JavaScript, imagens e dependencias inventariadas |
| `public/` | Ativos publicados para o navegador |
| `locales/` | Catalogos Gettext |
| `sql/` | Instalacao e remocao das tabelas proprias |
| `tests/` | Testes unitarios, de integracao e navegador |
| `tools/` | Compilacao, verificacao, i18n, acessibilidade e homologacao |
| `docs/` | Arquitetura, operacao, seguranca, testes, roadmaps e notas de versao |

## Inventario dos arquivos de execucao

### Raiz

| Arquivo | Finalidade |
|---|---|
| `setup.php` | Metadados, versao, compatibilidade, inicializacao, politica cacheada da entrada pre-login e registro do ativo anonimo oficial |
| `hook.php` | Hooks e integracao de menu/ativos com o GLPI, incluindo a ponte compativel e o HTML estatico do aviso pre-login |
| `glpiacessivel.xml` | Metadados de publicacao e compatibilidade |
| `glpiacessivel.png` | Identidade visual em alta resolucao usada na documentacao |
| `logo.png` | Icone local otimizado, nativo no GLPI 11 e usado pelo fallback progressivo do cartao ativo no GLPI 10 |
| `composer.json` | Dependencias, autoload PSR-4 e comandos de QA PHP |
| `glpiacessivel_chatbot_check.php` | Diagnostico de requisitos do chatbot |

### Pontos de entrada `front/`

| Arquivo | Finalidade |
|---|---|
| `acessivel.php` | Entrada principal do portal |
| `chatbot.php` | Jornada do chatbot |
| `cockpit.php` | Visao operacional |
| `config.php` | Configuracao administrativa |
| `context.php` | Troca autorizada de perfil e entidade |
| `faq.php` | Perguntas frequentes |
| `form.open.php` | Resolucao e abertura segura de formulario |
| `form.render.php` | Renderizacao ou delegacao do formulario |
| `forms.php` | Catalogo de formularios |
| `knowledge.php` | Base de conhecimento |
| `playbooks.php` | Playbooks operacionais |
| `runtime-config.js.php` | Configuracao JavaScript gerada no contexto da sessao |
| `ticket.action.php` | Acoes mutaveis autorizadas sobre chamados |
| `ticket.create.php` | Criacao de chamado |
| `ticket.php` | Lista e detalhe de chamado |
| `ticket.saved-search.php` | Mutacoes de pesquisas salvas nativas |
| `ticket.search-values.php` | Endpoint protegido do autocomplete de filtros |

### Aplicacao `src/Application/`

| Arquivo | Finalidade |
|---|---|
| `AdvancedTicketSearchRequest.php` | Traduz a submissao da busca para AST canonica |
| `ChatbotIntentPolicy.php` | Politica de intencoes permitidas |
| `ChatbotPlaybookService.php` | Integra chatbot e playbooks |
| `ChatbotService.php` | Fluxo conversacional e respostas operacionais |
| `ConfigService.php` | Leitura, gravacao e validacao fechada dos modos e preferencias de configuracao |
| `ContextService.php` | Usuario, perfil, entidade e contexto ativo a partir da sessao GLPI |
| `FormService.php` | Catalogo e acesso a formularios |
| `KnowledgeBaseService.php` | Pesquisa e apresentacao da base de conhecimento |
| `PortalModulePolicy.php` | Disponibilidade dos modulos do portal |
| `RemoteSearchValueAuthorizer.php` | Reautoriza valores remotos de filtros |
| `SavedTicketSearchService.php` | Casos de uso de pesquisas salvas do GLPI |
| `TicketSearchStateStore.php` | Tokens opacos e estado temporario da pesquisa |
| `TicketService.php` | Casos de uso de chamados |

### Formularios dinamicos `src/Application/DynamicForm/`

| Arquivo | Finalidade |
|---|---|
| `DynamicFormFacade.php` | Seleciona o adaptador de formulario adequado |
| `FormcreatorSchemaAdapter.php` | Adapta Formcreator quando disponivel |
| `FormSubmissionGate.php` | Autoriza e valida a submissao |
| `NativeTicketSchemaAdapter.php` | Adapta o formulario nativo de chamado |
| `ServiceCatalogSchemaAdapter.php` | Adapta o Service Catalog do GLPI 11 |
| `TicketTemplateSchemaAdapter.php` | Adapta modelos de chamado |

### Dominio `src/Domain/`

| Arquivo | Finalidade |
|---|---|
| `DynamicForm/DynamicFormAdapterInterface.php` | Contrato dos adaptadores de formulario |
| `DynamicForm/DynamicFormCondition.php` | Condicao de exibicao/validacao |
| `DynamicForm/DynamicFormField.php` | Campo normalizado |
| `DynamicForm/DynamicFormSchema.php` | Esquema versionado do formulario |
| `DynamicForm/DynamicFormSection.php` | Secao normalizada |
| `DynamicForm/DynamicFormSubmissionResult.php` | Resultado da submissao |
| `DynamicForm/FormCapability.php` | Capacidades comprovadas do adaptador |
| `Pii/PiiMasker.php` | Mascaramento de informacao pessoal |
| `Security/Authorization.php` | Regras comuns de autorizacao |
| `Ticket/NativeSearchDefinitionValidator.php` | Valida a AST e parametros nativos da busca |
| `Ticket/NativeSearchValidationException.php` | Erro controlado de definicao de busca |
| `Ticket/SearchCriterionValueValidator.php` | Valida valores por campo e operador |
| `Ticket/SearchFieldContract.php` | Contrato autorizado de um campo |
| `Ticket/SearchOperatorValueContract.php` | Contrato de valor por operador |
| `Ticket/SearchValueKind.php` | Tipos suportados de valor |
| `Ticket/TicketCreationPolicy.php` | Politica de criacao de chamado |
| `Ticket/TicketPolicy.php` | Politicas de acesso e acao sobre chamado |

### Infraestrutura `src/Infrastructure/`

| Arquivo | Finalidade |
|---|---|
| `Audit/AuditLogger.php` | Registro de auditoria com minimizacao de dados |
| `Compliance/SchemaManager.php` | Instalacao e evolucao do esquema proprio |
| `Repository/FormRepository.php` | Acesso aos formularios disponiveis |
| `Repository/NativeSavedSearchGateway.php` | Integracao com `SavedSearch` do GLPI |
| `Repository/PlaybookRepository.php` | Persistencia de playbooks e sugestoes |
| `Repository/SavedTicketSearchRepository.php` | Compatibilidade historica de pesquisas |
| `Repository/TicketRepository.php` | Pesquisa, leitura e gravacao de chamados via GLPI |
| `Search/GlpiSearchContractResolver.php` | Resolve o contrato campo/operador/valor |
| `Search/GlpiSearchOptionCatalog.php` | Catalogo contextual de Search Options |
| `Search/GlpiSearchValueProvider.php` | Consulta paginada de valores remotos |
| `Search/GlpiSearchValueRateLimiter.php` | Limites de requisicao do autocomplete |
| `Search/GlpiTicketLocalValueCatalog.php` | Valores locais como status e prioridade |
| `Security/IdempotencyClaim.php` | Representa uma reserva idempotente |
| `Security/IdempotencyLedger.php` | Evita repeticao de mutacoes |

### Modelos, seguranca e suporte

| Arquivo | Finalidade |
|---|---|
| `src/Model/AuditLog.php` | Modelo do registro de auditoria |
| `src/Model/Config.php` | Modelo de configuracao |
| `src/Model/PiiReveal.php` | Modelo de revelacao controlada de PII |
| `src/Model/Playbook.php` | Modelo de playbook |
| `src/Model/PlaybookJob.php` | Modelo de execucao de playbook |
| `src/Model/PlaybookSuggestion.php` | Modelo de sugestao operacional |
| `src/Security/CsrfGuard.php` | Compatibilidade e verificacao CSRF |
| `src/Security/InputSanitizer.php` | Normalizacao de entrada |
| `src/Security/SessionContextGuard.php` | Confirma contexto da sessao |
| `src/Support/Bootstrap.php` | Carregamento do plugin |
| `src/Support/Container.php` | Resolucao das dependencias internas |
| `src/Support/FormValidationException.php` | Erros controlados de formulario |
| `src/Support/GlpiCompatibility.php` | Diferencas suportadas entre GLPI 10 e 11 |
| `src/Support/I18n.php` | Traducao Gettext |
| `src/Support/LoginSourceDiscovery.php` | Descoberta das fontes de autenticacao |
| `src/Support/RichTextFormatter.php` | Formatacao segura de texto rico |
| `src/Support/TextNormalizer.php` | Normalizacao semantica de texto |
| `src/Support/TicketStatusLabels.php` | Rotulos consistentes de status |
| `src/Support/UploadedFileMapper.php` | Mapeamento seguro de anexos |
| `src/Support/Url.php` | Construcao de URLs do plugin |
| `src/Support/ValidationErrorNormalizer.php` | Mensagens de validacao apresentaveis |

### Interface `src/UI/`

| Arquivo | Finalidade |
|---|---|
| `Controller/BaseController.php` | Comportamentos comuns dos controladores |
| `Controller/ChatbotController.php` | Controla o chatbot |
| `Controller/CockpitController.php` | Controla o cockpit |
| `Controller/ConfigController.php` | Controla configuracoes, modos suportados e auditoria de alteracoes |
| `Controller/ContextController.php` | Controla perfil e entidade |
| `Controller/FormController.php` | Controla formularios |
| `Controller/KnowledgeController.php` | Controla conhecimento |
| `Controller/MenuController.php` | Monta a navegacao permitida |
| `Controller/PlaybookController.php` | Controla playbooks |
| `Controller/PortalController.php` | Controla a entrada do portal e o redirecionamento anonimo ao login nativo |
| `Controller/SavedTicketSearchController.php` | Lista e gerencia pesquisas salvas |
| `Controller/TicketController.php` | Controla lista, detalhe, criacao e acoes de chamados |
| `Controller/TicketSearchValueController.php` | Controla valores remotos da pesquisa |
| `Presenter/TicketSearchSummaryPresenter.php` | Produz o resumo acessivel da consulta aplicada |
| `View/View.php` | Renderiza templates com dados controlados |

### Templates `templates/`

| Arquivo | Finalidade |
|---|---|
| `layout/header.php` e `layout/footer.php` | Estrutura, navegacao, ativos e rodape comuns |
| `portal/index.php`, `portal/login.php` e `portal/faq.php` | Entrada, autenticacao e FAQ |
| `tickets/list.php` | Busca, pesquisas salvas, resumo e tabela de chamados |
| `tickets/create.php` | Criacao assistida |
| `tickets/detail.php` | Detalhe e linha do tempo |
| `forms/index.php` e `forms/render.php` | Catalogo e renderizacao de formularios |
| `knowledge/index.php` | Base de conhecimento |
| `chatbot/index.php` | Interface conversacional |
| `cockpit/index.php` | Indicadores operacionais |
| `playbooks/index.php` | Playbooks e sugestoes |
| `config/index.php` | Configuracao administrativa, inclusive a politica de entrada e o aviso estatico de acessibilidade no login |
| `errors/permission.php` e `errors/unavailable.php` | Erros seguros de permissao e indisponibilidade |

### Ativos, traducoes e banco

| Arquivo/pasta | Finalidade |
|---|---|
| `assets/css/glpiacessivel.css` | Estilos compartilhados |
| `assets/css/portal.css` | Layout do portal |
| `assets/css/a11y-audit.css` | Interface da auditoria local |
| `assets/js/glpiacessivel.js` | Comportamentos acessiveis e busca |
| `assets/js/login-accessibility-notice.js` | Reposiciona a nota depois do submit oficial, sem ler campos, com fallback na area do hook |
| `assets/js/a11y-audit.js` | Execucao local do axe |
| `assets/images/readme/` | Capturas publicas da documentacao |
| `assets/vendor/axe-core/` | axe-core e licencas inventariadas |
| `public/assets/` | Copias publicadas e ativos opcionais de voz |
| `locales/glpiacessivel.pot` | Catalogo mestre de mensagens |
| `locales/pt_BR.po` e `locales/pt_BR.mo` | Portugues do Brasil |
| `locales/en_GB.po` e `locales/en_GB.mo` | Ingles britanico |
| `sql/install.php` | Cria/atualiza estruturas proprias |
| `sql/uninstall.php` | Remove estruturas conforme politica do plugin |

## Arquivos de desenvolvimento, qualidade e distribuicao

| Arquivo/pasta | Finalidade |
|---|---|
| `tests/unit/` | Testes isolados de contratos, servicos e apresentacao |
| `tests/integration/` | Testes de colaboracao entre camadas |
| `tests/browser/` | Testes Puppeteer de teclado, foco e componentes |
| `phpunit.xml` | Configuracao PHPUnit |
| `phpstan.neon` | Configuracao PHPStan |
| `phpcs.xml` | Padrao PHP_CodeSniffer |
| `package.json` e `package-lock.json` | Ferramentas JavaScript de teste |
| `tools/build-release.ps1` | Gera o pacote de distribuicao |
| `tools/verify-release.ps1` | Verifica o pacote gerado |
| `tools/compile-locales.ps1` | Compila catalogos Gettext |
| `tools/i18n-audit.ps1` | Verifica consistencia das traducoes |
| `tools/a11y/` | Captura autenticada e execucao Pa11y |
| `tools/homologation/` | Preparacao de massa sintetica de homologacao |
| `tools/phpstan/` | Stubs de compatibilidade com GLPI |
| `README.md` e `README.en.md` | Apresentacao e instalacao |
| `CHANGELOG.md` | Historico funcional das versoes |
| `SECURITY.md` | Politica de seguranca e reporte |
| `CONTRIBUTING.md`, `DCO.md` e `AUTHORS.md` | Colaboracao, autoria e certificacao |
| `LICENSE`, `LICENSE_POLICY.md` e `THIRD_PARTY_NOTICES.md` | Licencas e conformidade de dependencias |
| `CITATION.cff` | Citacao academica do software |

## Operacao e manutencao

- Instalar sempre o ZIP completo e executar a atualizacao de plugins do GLPI.
- Limpar caches do GLPI e do navegador quando uma versao alterar CSS ou JavaScript.
- Nao copiar apenas arquivos isolados entre versoes.
- Manter backups do banco e do diretorio de plugins antes da atualizacao.
- Repetir homologacao com perfis, entidades, recursividade, GLPI 10/11, teclado e leitores de tela representativos.
- Consultar a nota da versao em `docs/release_<versao>_<tema>.md` para mudancas, testes e limitacoes especificas.
