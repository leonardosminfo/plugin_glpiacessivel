# Solucao tecnologica do GLPI Acessivel

## Finalidade

O GLPI Acessivel e um plugin para GLPI 10 e 11 que oferece uma jornada alternativa de central de servicos, com prioridade para navegacao por teclado, leitores de tela, ampliacao, alto contraste e linguagem compreensivel. O plugin reutiliza autenticacao, perfis, entidades, permissoes, chamados, pesquisas, formularios e base de conhecimento do GLPI; ele nao cria uma central de servicos paralela.

Este documento descreve a arquitetura, as tecnologias e os controles tecnicos da versao distribuida. A compatibilidade declarada e GLPI `>= 10.0` e `< 12.0`, com PHP `>= 8.1`.

## Arquitetura

O codigo segue uma separacao em camadas:

1. os pontos de entrada em `front/` inicializam o ambiente do GLPI e encaminham a requisicao;
2. os controladores em `src/UI/Controller/` validam contexto, autorizacao e intencao da requisicao;
3. os servicos em `src/Application/` coordenam os casos de uso;
4. as regras em `src/Domain/` mantem contratos independentes de apresentacao;
5. os adaptadores em `src/Infrastructure/` usam as APIs, modelos e banco do GLPI;
6. os presenters e templates em `src/UI/Presenter/` e `templates/` produzem HTML semantico;
7. `assets/` fornece os fontes de CSS e JavaScript, publicados em `public/assets/` durante o empacotamento.

O conteiner leve em `src/Support/Container.php` liga controladores, servicos e repositorios. Nao ha framework web adicional nem ORM paralelo: o plugin e executado dentro do ciclo de vida do GLPI.

## Tecnologias e ferramentas

| Area | Tecnologia | Uso na solucao |
|---|---|---|
| Plataforma | PHP 8.1 ou superior | Regras de negocio, integracao, seguranca, controladores e renderizacao |
| Sistema hospedeiro | GLPI 10 e 11 | Sessao, autenticacao, perfis, entidades, ACL, Search API, SavedSearch, chamados e base de conhecimento |
| Interface | HTML5 semantico | Landmarks, formularios, tabelas, dialogos, regioes e mensagens acessiveis |
| Estilos | CSS responsivo | Reflow, foco visivel, alto contraste, modo noturno e `forced-colors` |
| Interacao | JavaScript sem framework | Divulgacao progressiva, foco, dialogos, autocomplete, resumos e auditoria local |
| Internacionalizacao | Gettext, arquivos POT/PO/MO | Portugues do Brasil e ingles britanico |
| Auditoria automatica | axe-core 4.10.3 local | Diagnostico de acessibilidade sem dependencia de CDN |
| Voz opcional/offline | Piper, ONNX Runtime Web e Vosklet | Sintese e reconhecimento local quando os ativos offline sao instalados |
| Testes PHP | PHPUnit 10 | Testes unitarios e de integracao |
| Analise estatica | PHPStan | Tipos, contratos e fluxos PHP |
| Padrao de codigo | PHP_CodeSniffer | Validacao automatica do estilo PHP |
| Testes de interface | Puppeteer e Node.js | Regressao de teclado, foco, autocomplete, reflow e paineis |
| Auditoria externa | Pa11y | Capturas e verificacoes complementares em ambientes de homologacao |
| Empacotamento | PowerShell e Compress-Archive | Compilacao de traducoes, copia de ativos, ZIP, manifesto e SHA-256 |

## Integracao com o GLPI

- A sessao ativa, o usuario, o perfil, a entidade e a recursividade sao os mesmos do GLPI.
- A entrada pre-autenticacao usa uma politica unica: `native_only` delega login, SSO e MFA integralmente ao GLPI; `accessible_bridge` preserva o formulario alternativo somente para compatibilidade.
- Em `native_only`, uma nota estatica e nao acionavel pode ser habilitada no login nativo; usa `role="note"`, nome acessivel, classes visuais do GLPI e icone decorativo. O hook oficial `add_javascript_anonymous_page` carrega um ativo externo, de mesma origem e sem acesso aos valores do formulario, que move progressivamente a propria nota para depois de `Entrar`; se o formulario oficial nao for reconhecido, a nota permanece na area do hook. O plugin nao recebe credenciais nem cria rota de autenticacao.
- O rotulo autenticado do usuario combina `glpiname` e `glpifirstname`, campos que GLPI 10 e 11 ja mantem na sessao, e recua para o login quando o primeiro nome estiver vazio.
- O modo futuro `strict_authenticated_portal` e conhecido pelo dominio, mas nao e suportado nem configuravel antes da separacao fisica das rotas.
- A autorizacao e verificada antes do caso de uso e novamente sobre os objetos retornados.
- A lista de chamados usa os mecanismos de pesquisa do GLPI; criterios, metacriterios, operadores, ordenacoes, colunas e valores sao derivados das Search Options autorizadas.
- As pesquisas salvas usam `SavedSearch` como fonte de verdade. O plugin nao mantem copia local das pesquisas.
- A busca de valores remotos reutiliza provedores do GLPI e revalida o identificador selecionado no contexto atual.
- Os adaptadores de formularios detectam os recursos disponiveis no GLPI 10, GLPI 11, Service Catalog e Formcreator e falham de forma conservadora quando o contrato nao e comprovado.
- Os grupos de chamados sao separados por papel (`is_assign` e `is_watcher`), filtrados pela entidade real do chamado e revalidados antes da gravacao.
- A substituicao de grupos usa o contrato nativo de atores do `Ticket::update`, inclusive os IDs de relacao exigidos para exclusoes, sem apagar usuarios, fornecedores ou o papel oposto.

## Seguranca e privacidade

- Todas as operacoes protegidas exigem sessao autenticada e autorizacao do GLPI.
- A configuracao ausente, invalida ou indisponivel da entrada falha de forma fechada para `native_only`.
- No modo `native_only`, o hook pre-login so e registrado quando a nota estatica e explicitamente habilitada; mesmo assim, ele nao produz link, formulario, campo, `tabindex`, `aria-live` ou script. A URL publica direta continua redirecionando antes de preparar credenciais ou descobrir origens de autenticacao.
- Mutacoes usam `POST`, protecao CSRF, validacao de entrada, idempotencia e redirecionamento apos gravacao.
- Chamados, pesquisas salvas e valores remotos sao reautorizados pelo identificador para reduzir risco de IDOR.
- A AST de pesquisa tem versao, profundidade, quantidade, campos, operadores, colunas e tipos de valor limitados por listas permitidas.
- Tokens opacos de curta duracao mantem definicoes de pesquisa na sessao sem publicar a consulta completa na URL.
- Saidas HTML sao escapadas e mensagens de erro nao reproduzem excecoes internas ou consultas nativas.
- O mascaramento de PII e os registros de auditoria evitam armazenar desnecessariamente termos livres e conteudo de chamados.
- Dependencias de interface incluidas no pacote possuem licencas e hashes controlados em `THIRD_PARTY_NOTICES.md` e `LICENSE_POLICY.md`.

## Acessibilidade

A interface prioriza WCAG, eMAG e ARIA apenas quando a semantica HTML nativa nao e suficiente. Os principais recursos sao:

- atalhos para conteudo, menu e busca;
- landmarks, titulos e nomes acessiveis;
- operacao completa por teclado e foco visivel;
- retorno de foco em dialogos e paineis;
- resumos textuais da consulta em edicao e da pesquisa aplicada;
- mensagens de estado e erro associadas aos controles;
- tabelas com legenda, cabecalhos e ordenacao anunciada;
- reflow em largura reduzida, ampliacao, modo noturno, alto contraste e cores forcadas;
- auditoria axe local, sem envio do conteudo da pagina a servicos externos.

Testes automatizados reduzem regressao, mas nao substituem homologacao manual com NVDA, JAWS ou VoiceOver e perfis representativos.

## Dados e persistencia

O plugin usa tabelas proprias apenas para configuracao, auditoria, recursos operacionais e idempotencia previstos em `sql/install.php`. Chamados, usuarios, grupos, entidades, base de conhecimento, formularios nativos e pesquisas salvas permanecem nas estruturas oficiais do GLPI.

`authentication_entry_mode` e `show_login_accessibility_notice` utilizam a tabela chave/valor existente, sem alteracao de esquema. A auditoria registra apenas os valores anterior e atual quando cada preferencia muda.

Nao existe sincronizacao ou duplicacao local de `SavedSearch`: criar, renomear, definir como padrao ou excluir uma pesquisa atua diretamente no objeto autorizado do GLPI.

## Compilacao e distribuicao

`tools/build-release.ps1` executa auditoria de traducoes, publica os ativos, seleciona os documentos de distribuicao, remove ativos offline no perfil Marketplace, cria `glpiacessivel.zip`, calcula SHA-256 e gera `RELEASE_MANIFEST.json`.

`tools/verify-release.ps1` confirma estrutura, versao, arquivos proibidos, perfil, manifesto e hash antes da entrega. O ZIP possui uma unica pasta raiz `glpiacessivel/`, conforme o formato de plugins do GLPI.

A raiz distribuida contem `logo.png`, uma versao quadrada e otimizada da identidade visual. O GLPI 11 reconhece o arquivo local de forma nativa. No GLPI 10, quando o plugin esta ativo, uma melhoria progressiva restrita ao gerenciador substitui as iniciais `GA`, aceita caminhos `/plugins` e `/marketplace` e restaura o fallback textual se a imagem falhar. Antes da ativacao no GLPI 10, o logotipo depende do catalogo oficial do Marketplace.

## Limites de compatibilidade

- Recursos nativos variam entre GLPI 10 e 11; toda deteccao de classe ou metodo usa adaptadores e fallback fechado.
- No GLPI 10, `front/acessivel.php` permanece publico apenas para poder redirecionar; no GLPI 11, conserva a estrategia publica declarada. Em `native_only`, nenhum dos dois caminhos renderiza senha pelo plugin.
- Metacriterios ou filtros sem representacao fiel na interface acessivel devem oferecer abertura explicita no GLPI, nunca aproximacao silenciosa.
- Voz e reconhecimento offline dependem de ativos opcionais e da capacidade do navegador.
- A liberacao continua beta ate a homologacao externa nos navegadores, leitores de tela, perfis, entidades, recursividade e volumes previstos pela organizacao.
