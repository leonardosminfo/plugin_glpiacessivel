# Solução tecnológica do GLPI Acessível

## Finalidade

O GLPI Acessível é um plugin para GLPI 10 e 11 que oferece uma jornada alternativa de central de serviços, com prioridade para navegação por teclado, leitores de tela, ampliação, alto contraste e linguagem compreensível. O plugin reutiliza autenticação, perfis, entidades, permissões, chamados, pesquisas, formulários e base de conhecimento do GLPI; ele não cria uma central de serviços paralela.

Este documento descreve a arquitetura, as tecnologias e os controles técnicos da versão distribuída. A compatibilidade declarada é GLPI `>= 10.0` e `< 12.0`, com PHP `>= 8.1`.

## Arquitetura

O código segue uma separação em camadas:

1. os pontos de entrada em `front/` inicializam o ambiente do GLPI e encaminham a requisição;
2. os controladores em `src/UI/Controller/` validam contexto, autorização e intenção da requisição;
3. os serviços em `src/Application/` coordenam os casos de uso;
4. as regras em `src/Domain/` mantêm contratos independentes de apresentação;
5. os adaptadores em `src/Infrastructure/` usam as APIs, modelos e banco do GLPI;
6. os presenters e templates em `src/UI/Presenter/` e `templates/` produzem HTML semântico;
7. `assets/` fornece as fontes de CSS e JavaScript, publicadas em `public/assets/` durante o empacotamento.

O contêiner leve em `src/Support/Container.php` liga controladores, serviços e repositórios. Não há framework web adicional nem ORM paralelo: o plugin é executado dentro do ciclo de vida do GLPI.

## Tecnologias e ferramentas

| Área | Tecnologia | Uso na solução |
|---|---|---|
| Plataforma | PHP 8.1 ou superior | Regras de negócio, integração, segurança, controladores e renderização |
| Sistema hospedeiro | GLPI 10 e 11 | Sessão, autenticação, perfis, entidades, ACL, Search API, SavedSearch, chamados e base de conhecimento |
| Interface | HTML5 semântico | Landmarks, formulários, tabelas, diálogos, regiões e mensagens acessíveis |
| Estilos | CSS responsivo | Reflow, foco visível, alto contraste, modo noturno e `forced-colors` |
| Interação | JavaScript sem framework | Divulgação progressiva, foco, diálogos, autocomplete, resumos e auditoria local |
| Internacionalização | Gettext, arquivos POT/PO/MO | Português do Brasil e inglês britânico |
| Auditoria automática | axe-core 4.10.3 local | Diagnóstico de acessibilidade sem dependência de CDN |
| Voz opcional/offline | Piper, ONNX Runtime Web e Vosklet | Síntese e reconhecimento local quando os ativos offline são instalados |
| Testes PHP | PHPUnit 10 | Testes unitários e de integração |
| Análise estática | PHPStan | Tipos, contratos e fluxos PHP |
| Padrão de código | PHP_CodeSniffer | Validação automática do estilo PHP |
| Testes de interface | Puppeteer e Node.js | Regressão de teclado, foco, autocomplete, reflow e painéis |
| Auditoria externa | Pa11y | Capturas e verificações complementares em ambientes de homologação |
| Empacotamento | PowerShell e Compress-Archive | Compilação de traduções, cópia de ativos, ZIP, manifesto e SHA-256 |

## Integração com o GLPI

- A sessão ativa, o usuário, o perfil, a entidade e a recursividade são os mesmos do GLPI.
- A entrada pré-autenticação usa uma política única: `native_only` delega login, SSO e MFA integralmente ao GLPI; `accessible_bridge` preserva o formulário alternativo somente para compatibilidade.
- Em `native_only`, uma nota estática e não acionável pode ser habilitada no login nativo; usa `role="note"`, nome acessível, classes visuais do GLPI e ícone decorativo. O hook oficial `add_javascript_anonymous_page` carrega um ativo externo, de mesma origem e sem acesso aos valores do formulário, que move progressivamente a própria nota para depois de `Entrar`; se o formulário oficial não for reconhecido, a nota permanece na área do hook. O plugin não recebe credenciais nem cria rota de autenticação.
- O rótulo autenticado do usuário combina `glpiname` e `glpifirstname`, campos que GLPI 10 e 11 já mantêm na sessão, e recua para o login quando o primeiro nome estiver vazio.
- O modo futuro `strict_authenticated_portal` é conhecido pelo domínio, mas não é suportado nem configurável antes da separação física das rotas.
- A autorização é verificada antes do caso de uso e novamente sobre os objetos retornados.
- A lista de chamados usa os mecanismos de pesquisa do GLPI; critérios, metacritérios, operadores, ordenações, colunas e valores são derivados das Search Options autorizadas.
- Desde a `0.2.25-beta`, a lista pode entregar primeiro a estrutura acessível e buscar os resultados por contrato JSON versionado. A Search API continua definindo IDs, ordem e total, enquanto uma hidratação em lote monta apenas a página autorizada, sem o N+1 anterior.
- Na `0.2.26-beta`, o módulo assíncrono passa a pertencer à própria página de chamados, inclusive nos layouts standalone. O HTML inicial conserva uma alternativa nativa visível e somente declara `aria-busy` depois que o módulo e a configuração foram validados; timeout, resposta tardia ou ativo indisponível terminam em estado utilizável.
- As pesquisas salvas usam `SavedSearch` como fonte de verdade. O plugin não mantém cópia local das pesquisas.
- A busca de valores remotos reutiliza provedores do GLPI e revalida o identificador selecionado no contexto atual.
- Os seletores de categoria, localização, técnico, grupo e observador compartilham um componente de combobox, mas mantêm provedores, listas permitidas, limites e autorização separados. Usuários e grupos exigem termo mínimo; todas as fontes usam página curta e cursor opaco vinculado ao contexto.
- Na `0.2.27-beta`, o comprimento mínimo passa a ser definido pelo registro server-side: categoria e localização aceitam navegação vazia ou consulta curta, enquanto pessoas e grupos conservam o mínimo de dois caracteres. O endpoint publica somente códigos de erro permitidos e a interface sincroniza o resumo depois da primeira tentativa de envio sem deslocar o foco.
- Na `0.2.28-beta`, busca rápida, acesso recorrente, filtros e configuração de exibição passam a ser apresentados como camadas progressivas do mesmo formulário e da mesma definição canônica. O cockpit abandona a varredura limitada a 500 chamados e as consultas por linha: cada indicador usa uma consulta agregada independente na Search API, conserva o contexto de autorização e abre um detalhamento por estado opaco revalidado.
- Na `0.2.29-beta`, o resultado técnico das fontes de formulários é projetado no servidor em duas audiências. A audiência pública recebe somente estados funcionais, conteúdo autorizado e ações seguras; códigos, versões, razões e métricas sanitizadas só existem no bloco administrativo. A audiência administrativa depende exclusivamente do direito nativo `config/UPDATE`, com falha fechada e sem inferência pelo nome do perfil.
- Na `0.2.30-beta`, o iframe Formcreator volta a usar altura limitada por CSS, sem `ResizeObserver`, eliminando a realimentação entre `100vh` do documento filho e a altura do elemento pai. A seleção tolerante do formulário exige o ID Formcreator esperado e ignora formulários auxiliares do chrome GLPI.
- Na `0.2.31-beta`, a rota canônica de chamados passa a ser `front/tickets.php`. A rota legada redireciona antes do bootstrap, impedindo que o `replace_helpdesk` do Formcreator capture por substring a jornada do plugin em perfis Self-Service. Os fallbacks nativos continuam separados em `/front/ticket.php`.
- Na `0.2.32-beta`, a homologação real acrescenta restauração de foco no diálogo de colunas, condição negativa de status validada pelo catálogo, apresentação incorporada conservadora do Formcreator, revisão linguística e autorização explícita antes das ações de pesquisas salvas.
- Na `0.2.33-beta`, a condição negativa de Status passa por um compilador semântico compartilhado: a AST conserva `não é`, mas a fronteira do GLPI usa `equals` com conector negativo, conforme o tratamento especial de `glpi_tickets.status` no GLPI 10. O mesmo contrato cobre lista, cockpit e pesquisas salvas. Um fingerprint vertical versionado reconhece a estrutura institucional do Formcreator somente quando formulário, ID, CSRF e envio são comprovados.
- Na `0.2.34-beta`, a troca de perfil e entidade usa o gateway nativo do GLPI e um ciclo PRG em duas requisições. A primeira altera e grava a sessão; a segunda consome um marcador opaco de uso único e só confirma o sucesso quando perfil, entidade, recursividade e conjunto autorizado persistidos correspondem ao fingerprint esperado. URLs de retorno têm os parâmetros de troca removidos e todos os estados vinculados ao contexto anterior são invalidados.
- Na `0.2.35-beta`, os textos críticos da criação e do detalhe de chamados e as mensagens dinâmicas de busca, seletores e diagnóstico passam pelo mesmo contrato Gettext. Testes de regressão verificam acentuação, chaves JavaScript, placeholders, regiões vivas, paridade dos ativos públicos e catálogos compilados.
- Na `0.2.36-beta`, pesquisa avançada, pesquisas salvas e criação calculam o destino dentro do fluxo protegido e chamam o redirect de resultado depois do `catch` operacional correspondente, porque o GLPI 11 implementa `Html::redirect()` por `RedirectException`. O token opaco e o foco dos resultados são preservados. A mesma versão formaliza o contrato do iframe do Service Catalog, contém o documento em 320 pixels CSS e amplia a inspeção linguística do runtime.
- Na `0.2.37-beta`, o mesmo contrato Gettext cobre as jornadas públicas, a administração e os diagnósticos dos adaptadores de formulários dinâmicos. Contagens usam plurais naturais em pt-BR e en-GB, e cada mudança de estado relevante produz um único anúncio. Falhas de sessão e CSRF oferecem recuperação em linguagem funcional, enquanto detalhes técnicos permanecem restritos ao diagnóstico administrativo autorizado. O gate global cruza PHP, templates, JavaScript, POT/PO/MO, placeholders, plurais, mojibake e ativos publicados, sem alterar ACL, payloads ou protocolos nativos.
- Na `0.2.38-beta`, o bootstrap do cliente conecta uma única vez o diálogo de confirmação crítica. O envio interrompido não anuncia processamento; Cancelar recebe o foco inicial; descrição e consequência compõem o `alertdialog`; o submitter escolhido fornece a ação e o token ao `requestSubmit`. A validação continua no servidor por ACL, CSRF e nonce de uso único.
- Na `0.2.39-beta`, o escopo de grupos usa `glpigroups` do contexto ativo como fonte oficial em GLPI 10 e 11. Grupos válidos são normalizados; um conjunto vazio comprovado encerra a lista como `scope_empty` e produz `group_open` zero exato sem consultar esse indicador. Chave ausente, valor malformado ou falha registrada de `Session::loadGroups()` permanece indisponível. Um `group_id` explícito precisa pertencer ao conjunto atual, enquanto `group_by` não altera `scope=all` ou `scope=mine`.
- O escopo `mine` deixa de depender de IDs ou rótulos das Search Options. `GlpiTicketActorSearchOptionResolver` reconhece requisitante, técnico e observador pela tabela de relação `glpi_tickets_users` e pelo tipo estrutural do vínculo, exige uma opção inequívoca por papel e compila um único grupo OR com o usuário atual. Catálogo ausente ou ambíguo falha fechado.
- Lista assíncrona e autocomplete remoto consomem exclusivamente o catálogo JavaScript emitido por `I18n::javascriptCatalog()`. Se ele estiver ausente, o enhancement não inicia e os controles/alternativas renderizados pelo servidor permanecem disponíveis. O pipeline compara chaves, msgids, placeholders, UTF-8, MO e os espelhos `assets/public`.
- Quando a lista assíncrona está habilitada, uma falha na emissão do estado contextual não chama mais a listagem síncrona pesada. O cliente recebe um estado de bootstrap indisponível, conserva a alternativa nativa e permite recarregar a página.
- O gateway `Formcreator213CatalogGateway` parte da consulta coletiva nativa, carrega cada objeto antes da autorização e pagina sem copiar o catálogo. Um resolvedor server-side reutiliza `FORMCREATOR_ROOTDOC` ou `Plugin::getWebDir('formcreator')`, valida que a raiz pertence ao GLPI e aceita as instalações oficiais em `plugins` ou `marketplace`; catálogo, abertura e envio usam a mesma raiz comprovada. No GLPI 11, o Service Catalog nativo permanece a fonte suportada.
- A apresentação `native_embedded_minimal` do Formcreator é uma melhoria progressiva separada do modo de abertura. Ela exige gate server-side, iframe same-origin, rotas, ID, versões e fingerprint conhecidos; somente adiciona uma classe CSS escopada e falha aberta para a interface nativa completa quando o contrato visual não é comprovado. Autorização, CSRF, campos, anexos, validação e envio permanecem no motor nativo.
- No GLPI 11, a incorporação do Service Catalog usa um contrato distinto e nunca aplica a apresentação mínima do Formcreator. A inspeção same-origin exige a rota, o `forms_id`, o método `POST` e a `action` `/Form/SubmitAnswers` esperados. Divergências publicam falha recuperável, mantêm iframe e página completa e permitem repetir somente o GET de renderização; o plugin não sintetiza submissões.
- A área incorporada usa um único canal de estado, `aria-busy` somente durante uma tentativa real, nova tentativa explícita, descarte de respostas tardias e redimensionamento progressivo. A validação estrita continua obrigatória para reduzir a interface; uma estrutura funcional reconhecida pode permanecer incorporada com a interface completa, sem expor a decisão técnica ao usuário comum.
- Os adaptadores de formulários detectam os recursos disponíveis no GLPI 10, GLPI 11, Service Catalog e Formcreator e falham de forma conservadora quando o contrato não é comprovado.
- O diagnóstico Axe executa apenas na aba atual. Na `0.2.27-beta`, violações confirmadas e resultados incompletos são separados, e os detalhes por alvo mostram somente tag, ID, nomes de atributos, referências ARIA por ID e razões técnicas limitadas. HTML, texto, valores de campos e resumos possivelmente sensíveis são omitidos; não há rede nem armazenamento. A execução tem timeout lógico, descarta resultado tardio e somente cria links HTTPS para a documentação oficial permitida da Deque.
- Os grupos de chamados são separados por papel (`is_assign` e `is_watcher`), filtrados pela entidade real do chamado e revalidados antes da gravação.
- A substituição de grupos usa o contrato nativo de atores do `Ticket::update`, inclusive os IDs de relação exigidos para exclusões, sem apagar usuários, fornecedores ou o papel oposto.

## Segurança e privacidade

- Todas as operações protegidas exigem sessão autenticada e autorização do GLPI.
- A configuração ausente, inválida ou indisponível da entrada falha de forma fechada para `native_only`.
- No modo `native_only`, o hook pré-login só é registrado quando a nota estática é explicitamente habilitada; mesmo assim, ele não produz link, formulário, campo, `tabindex`, `aria-live` ou script. A URL pública direta continua redirecionando antes de preparar credenciais ou descobrir origens de autenticação.
- Mutações usam `POST`, proteção CSRF, validação de entrada, idempotência e redirecionamento após gravação; nos controladores compatíveis com GLPI 11, o redirect fica fora dos blocos que capturam falhas da operação.
- Chamados, pesquisas salvas e valores remotos são reautorizados pelo identificador para reduzir risco de IDOR.
- Endpoints assíncronos aceitam somente o método e o tipo de conteúdo previstos, mesma origem, contrato JSON versionado e contexto vigente. Respostas personalizadas usam `private, no-store`, códigos de erro estruturados e limite de frequência independente por finalidade.
- O navegador envia somente IDs confirmados. O servidor deriva rótulo, papel, entidade e elegibilidade, revalida o conjunto imediatamente antes da operação e não produz alteração parcial se qualquer item falhar.
- Estado de lista, cursores e revisões de contexto são opacos, curtos e não valem como autorização. Troca de usuário, perfil, entidade, recursividade, idioma, direitos ou grupos invalida respostas pendentes.
- A AST de pesquisa tem versão, profundidade, quantidade, campos, operadores, colunas e tipos de valor limitados por listas permitidas.
- Tokens opacos de curta duração mantêm definições de pesquisa na sessão sem publicar a consulta completa na URL.
- Saídas HTML são escapadas e mensagens de erro não reproduzem exceções internas ou consultas nativas.
- O mascaramento de PII e os registros de auditoria evitam armazenar desnecessariamente termos livres e conteúdo de chamados.
- Dependências de interface incluídas no pacote possuem licenças e hashes controlados em `THIRD_PARTY_NOTICES.md` e `LICENSE_POLICY.md`.

## Acessibilidade

A interface prioriza WCAG, eMAG e ARIA apenas quando a semântica HTML nativa não é suficiente. Os principais recursos são:

- atalhos para conteúdo, menu e busca;
- landmarks, títulos e nomes acessíveis;
- operação completa por teclado e foco visível;
- retorno de foco em diálogos e painéis;
- resumos textuais da consulta em edição e da pesquisa aplicada;
- mensagens de estado e erro associadas aos controles;
- plurais naturais e uma única mensagem anunciada por mudança relevante de estado;
- comboboxes paginados com sugestão ativa separada do valor confirmado, selecionados múltiplos em lista externa e botão real de carregamento adicional fora da `listbox`;
- tabelas com legenda, cabeçalhos e ordenação anunciada;
- reflow em 320 pixels CSS sem overflow do documento, com controles de 44 pixels e rolagem localizada em tabelas extensas, além de ampliação, modo noturno, alto contraste e cores forçadas;
- auditoria axe local, sem envio do conteúdo da página a serviços externos.

Testes automatizados reduzem regressão, mas não substituem homologação manual com NVDA, JAWS ou VoiceOver e perfis representativos.

## Dados e persistência

O plugin usa tabelas próprias apenas para configuração, auditoria, recursos operacionais e idempotência previstos em `sql/install.php`. Chamados, usuários, grupos, entidades, base de conhecimento, formulários nativos e pesquisas salvas permanecem nas estruturas oficiais do GLPI.

`authentication_entry_mode`, `show_login_accessibility_notice` e as flags `ticket_async_list_enabled`, `resource_selector_enabled`, `resource_selector_create_enabled`, `resource_selector_routing_enabled` e `form_catalog_v2_enabled` utilizam a tabela chave/valor existente, sem alteração de esquema. A auditoria registra apenas os valores anterior e atual quando cada preferência muda.

As versões `0.2.25-beta` a `0.2.39-beta` não criam tabela nem cópia de resultados, atores, formulários, indicadores, diagnósticos ou pesquisas. Estados opacos de curta duração permanecem somente na sessão PHP; respostas personalizadas não devem ser persistidas pelo navegador ou por intermediários.

Não existe sincronização ou duplicação local de `SavedSearch`: criar, renomear, definir como padrão ou excluir uma pesquisa atua diretamente no objeto autorizado do GLPI.

## Compilação e distribuição

`tools/build-release.ps1` executa auditoria de traduções, publica os ativos, seleciona os documentos de distribuição, remove ativos offline no perfil Marketplace, cria `glpiacessivel.zip`, calcula SHA-256 e gera `RELEASE_MANIFEST.json`.

`tools/verify-release.ps1` confirma estrutura, versão, arquivos proibidos, perfil, manifesto, hash e contratos críticos de redirect, iframe, reflow e distribuição antes da entrega. O ZIP possui uma única pasta raiz `glpiacessivel/`, conforme o formato de plugins do GLPI.

A raiz distribuída contém `logo.png`, uma versão quadrada e otimizada da identidade visual. O GLPI 11 reconhece o arquivo local de forma nativa. No GLPI 10, quando o plugin está ativo, uma melhoria progressiva restrita ao gerenciador substitui as iniciais `GA`, aceita caminhos `/plugins` e `/marketplace` e restaura o fallback textual se a imagem falhar. Antes da ativação no GLPI 10, o logotipo depende do catálogo oficial do Marketplace.

## Limites de compatibilidade

- Recursos nativos variam entre GLPI 10 e 11; toda detecção de classe ou método usa adaptadores e fallback fechado.
- No GLPI 10, `front/acessivel.php` permanece público apenas para poder redirecionar; no GLPI 11, conserva a estratégia pública declarada. Em `native_only`, nenhum dos dois caminhos renderiza senha pelo plugin.
- Metacritérios ou filtros sem representação fiel na interface acessível devem oferecer abertura explícita no GLPI, nunca aproximação silenciosa.
- Voz e reconhecimento offline dependem de ativos opcionais e da capacidade do navegador.
- A liberação continua beta até a homologação externa nos navegadores, leitores de tela, perfis, entidades, recursividade e volumes previstos pela organização.
