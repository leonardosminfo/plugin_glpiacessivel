<?php

// SPDX-License-Identifier: GPL-2.0-or-later

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {

    $prefixes = [
        'GlpiPlugin\\Glpiacessivel\\' => __DIR__ . '/src/',
    ];
    foreach ($prefixes as $prefix => $baseDir) {
        if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
            continue;
        }

        $relative = substr($class, strlen($prefix));
        $path = $baseDir . str_replace('\\', '/', $relative) . '.php';
        if (is_file($path)) {
            require_once $path;
        }
        return;
    }
});
if (is_file(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
}


function glpiacessivel_t(string $text): string
{
    return \GlpiPlugin\Glpiacessivel\Support\I18n::translate($text);
}

function glpiacessivel_n(string $single, string $plural, int $count): string
{
    return \GlpiPlugin\Glpiacessivel\Support\I18n::plural($single, $plural, $count);
}

function glpiacessivel_x(string $context, string $text): string
{
    return \GlpiPlugin\Glpiacessivel\Support\I18n::context($context, $text);
}

function glpiacessivel_html_lang(?string $locale = null): string
{
    return \GlpiPlugin\Glpiacessivel\Support\I18n::htmlLang($locale);
}

function glpiacessivel_i18n_catalog(): array
{
    return \GlpiPlugin\Glpiacessivel\Support\I18n::javascriptCatalog();
}

function glpiacessivel_json_for_script($value): string
{
    $json = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    return is_string($json) ? $json : 'null';
}

function plugin_glpiacessivel_portal_icon_markup(int $size = 62): string
{
    $size = min(96, max(16, $size));
    $safeSize = (string) $size;

    return '<svg class="glpiacessivel-portal-icon" viewBox="0 0 100 100" width="' . $safeSize . '" height="' . $safeSize . '" aria-hidden="true" focusable="false">'
        . '<path d="M20 34 A38 38 0 0 1 80 34" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<path d="M20 43 Q50 57 80 43" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<path d="M18 52 A38 38 0 0 0 33 81" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<path d="M82 52 A38 38 0 0 1 67 81" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<path d="M42 87 A20 20 0 0 0 58 87" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<path d="M50 57 L35 82" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<path d="M50 57 L65 82" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<circle cx="50" cy="33" r="10.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
        . '<circle cx="20" cy="43" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
        . '<circle cx="80" cy="43" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
        . '<circle cx="35" cy="82" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
        . '<circle cx="65" cy="82" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
        . '</svg>';
}

function plugin_glpiacessivel_display_login(): void
{
    if (
        function_exists('plugin_glpiacessivel_is_accessible_login_bridge_enabled')
        && plugin_glpiacessivel_is_accessible_login_bridge_enabled()
    ) {
        plugin_glpiacessivel_display_accessible_login_bridge();
        return;
    }

    if (
        function_exists('plugin_glpiacessivel_should_display_login_accessibility_notice')
        && plugin_glpiacessivel_should_display_login_accessibility_notice()
    ) {
        plugin_glpiacessivel_display_login_accessibility_notice();
    }
}

function plugin_glpiacessivel_display_login_accessibility_notice(): void
{
    $message = glpiacessivel_t(
        'Portal Acessível disponível após o login.'
    );
    $label = glpiacessivel_t('Informacao de acessibilidade');

    echo '<div id="glpiacessivel-login-accessibility-notice" role="note" aria-label="' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '" class="glpiacessivel-login-accessibility-notice alert alert-info d-flex align-items-start gap-2 mt-2 mb-0 text-start">';
    echo '<span class="glpiacessivel-login-accessibility-notice-icon d-inline-flex flex-shrink-0" aria-hidden="true">';
    echo plugin_glpiacessivel_portal_icon_markup(32);
    echo '</span>';
    echo '<p class="mb-0 small">' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</p>';
    echo '</div>';
}

function plugin_glpiacessivel_display_accessible_login_bridge(): void
{
    if (
        !function_exists('plugin_glpiacessivel_is_accessible_login_bridge_enabled')
        || !plugin_glpiacessivel_is_accessible_login_bridge_enabled()
    ) {
        return;
    }

    $url = \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/acessivel.php');
    $safeUrl = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
    $chatbotFloating = plugin_glpiacessivel_is_chatbot_floating_button_enabled() ? 'true' : 'false';
    $mode = plugin_glpiacessivel_get_accessibility_mode();
    $sessionStatus = (new \GlpiPlugin\Glpiacessivel\Security\SessionContextGuard())->status();
    $runtimeConfig = [
        'accessibilityMode' => $mode,
        'chatbotEnabled' => plugin_glpiacessivel_is_chatbot_enabled(),
        'portalModules' => plugin_glpiacessivel_get_portal_module_states(),
        'chatbotFloatingScope' => plugin_glpiacessivel_get_chatbot_floating_scope(),
        'isLogged' => !empty($sessionStatus['is_authenticated']),
        'sessionReady' => !empty($sessionStatus['session_ready']),
        'contextValid' => !empty($sessionStatus['context_valid']),
        'sessionIssueCode' => (string) ($sessionStatus['issue_code'] ?? 'unknown'),
        'activeProfileId' => (int) ($sessionStatus['profile_id'] ?? 0),
        'activeEntityId' => (int) ($sessionStatus['entity_id'] ?? 0),
        'locale' => \GlpiPlugin\Glpiacessivel\Support\I18n::locale(),
        'htmlLang' => \GlpiPlugin\Glpiacessivel\Support\I18n::htmlLang(),
        'fallbackLocale' => \GlpiPlugin\Glpiacessivel\Support\I18n::fallbackLocale(),
        'vlibrasScope' => function_exists('plugin_glpiacessivel_get_vlibras_scope') ? plugin_glpiacessivel_get_vlibras_scope() : 'plugin_pages',
        'vlibrasEnabled' => function_exists('plugin_glpiacessivel_is_vlibras_enabled_for_context') ? plugin_glpiacessivel_is_vlibras_enabled_for_context(false, true) : false,
    ];
    $entryLabel = $mode === 'embedded'
        ? glpiacessivel_t('Entrar com apoio acessível')
        : glpiacessivel_t('Entrar pelo portal acessível');
    echo '<script>document.documentElement.setAttribute("data-glpiacessivel-chatbot-floating",' . ($chatbotFloating === 'true' ? '"1"' : '"0"') . ');'
        . 'window.__glpiacessivelChatbotFloatingEnabled=' . $chatbotFloating . ';'
        . 'window.__glpiacessivelRuntimeConfig=' . glpiacessivel_json_for_script($runtimeConfig) . ';'
        . 'window.__glpiacessivelRuntimeConfigLoaded=true;'
        . 'window.__glpiacessivelI18n=' . glpiacessivel_json_for_script(glpiacessivel_i18n_catalog()) . ';'
        . 'window.__glpiacessivelI18nLoaded=true;</script>';
    echo '<div id="glpiacessivel-login-entry" class="glpiacessivel-login-entry glpiacessivel-login-entry-inline" role="region" aria-label="' . htmlspecialchars(glpiacessivel_t('Acesso acessível'), ENT_QUOTES, 'UTF-8') . '">';
    echo '<a class="glpiacessivel-login-entry-link" href="' . $safeUrl . '" aria-label="' . htmlspecialchars($entryLabel . ' ' . glpiacessivel_t('do GLPI'), ENT_QUOTES, 'UTF-8') . '">';
    echo plugin_glpiacessivel_portal_icon_markup();
    echo '<span>' . htmlspecialchars($entryLabel, ENT_QUOTES, 'UTF-8') . '</span>';
    echo '</a>';
    echo '</div>';
    echo '<script>(function(){'
        . 'function placePortalEntry(){'
        . 'var entry=document.getElementById("glpiacessivel-login-entry");'
        . 'if(!entry){return;}'
        . 'var loginButton=document.querySelector("button[type=\'submit\'], input[type=\'submit\']");'
        . 'if(!loginButton){return;}'
        . 'var anchor=loginButton.closest(".form-group, .mb-3, .mb-4, .input-group, p, div") || loginButton;'
        . 'if(anchor && anchor.parentNode && entry.previousElementSibling !== anchor){'
        . 'anchor.insertAdjacentElement("afterend", entry);'
        . '}'
        . '}'
        . 'function retryPlace(attempt){'
        . 'placePortalEntry();'
        . 'if(document.getElementById("glpiacessivel-login-entry") && document.querySelector("button[type=\'submit\'], input[type=\'submit\']")){return;}'
        . 'if(attempt>=12){return;}'
        . 'window.setTimeout(function(){retryPlace(attempt+1);},250);'
        . '}'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",function(){retryPlace(0);});}else{retryPlace(0);}'
        . '})();</script>';
}

function plugin_glpiacessivel_display_central(): void
{
    $url = \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/acessivel.php');
    $safeUrl = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
    $chatbotFloating = plugin_glpiacessivel_is_chatbot_floating_button_enabled() ? 'true' : 'false';
    $mode = plugin_glpiacessivel_get_accessibility_mode();
    $sessionStatus = (new \GlpiPlugin\Glpiacessivel\Security\SessionContextGuard())->status();
    $runtimeConfig = [
        'accessibilityMode' => $mode,
        'chatbotEnabled' => plugin_glpiacessivel_is_chatbot_enabled(),
        'portalModules' => plugin_glpiacessivel_get_portal_module_states(),
        'chatbotFloatingScope' => plugin_glpiacessivel_get_chatbot_floating_scope(),
        'isLogged' => !empty($sessionStatus['is_authenticated']),
        'sessionReady' => !empty($sessionStatus['session_ready']),
        'contextValid' => !empty($sessionStatus['context_valid']),
        'sessionIssueCode' => (string) ($sessionStatus['issue_code'] ?? 'unknown'),
        'activeProfileId' => (int) ($sessionStatus['profile_id'] ?? 0),
        'activeEntityId' => (int) ($sessionStatus['entity_id'] ?? 0),
        'locale' => \GlpiPlugin\Glpiacessivel\Support\I18n::locale(),
        'htmlLang' => \GlpiPlugin\Glpiacessivel\Support\I18n::htmlLang(),
        'fallbackLocale' => \GlpiPlugin\Glpiacessivel\Support\I18n::fallbackLocale(),
        'vlibrasScope' => function_exists('plugin_glpiacessivel_get_vlibras_scope') ? plugin_glpiacessivel_get_vlibras_scope() : 'plugin_pages',
        'vlibrasEnabled' => function_exists('plugin_glpiacessivel_is_vlibras_enabled_for_context') ? plugin_glpiacessivel_is_vlibras_enabled_for_context(false, false) : false,
    ];
    $portalLabel = $mode === 'embedded'
        ? glpiacessivel_t('Ir para modo acessível do GLPI')
        : glpiacessivel_t('Abrir portal acessível do GLPI');
    $portalTitle = $mode === 'embedded'
        ? glpiacessivel_t('Ir para modo acessível (Alt+A)')
        : glpiacessivel_t('Abrir portal acessível (Alt+A)');
    echo '<script>document.documentElement.setAttribute("data-glpiacessivel-chatbot-floating",' . ($chatbotFloating === 'true' ? '"1"' : '"0"') . ');'
        . 'window.__glpiacessivelChatbotFloatingEnabled=' . $chatbotFloating . ';'
        . 'window.__glpiacessivelRuntimeConfig=' . glpiacessivel_json_for_script($runtimeConfig) . ';'
        . 'window.__glpiacessivelRuntimeConfigLoaded=true;'
        . 'window.__glpiacessivelI18n=' . glpiacessivel_json_for_script(glpiacessivel_i18n_catalog()) . ';'
        . 'window.__glpiacessivelI18nLoaded=true;</script>';
    echo '<a id="glpiacessivel-portal-button" class="glpiacessivel-portal-button" href="' . $safeUrl . '" aria-label="' . htmlspecialchars($portalLabel, ENT_QUOTES, 'UTF-8') . '" aria-keyshortcuts="Alt+A" title="' . htmlspecialchars($portalTitle, ENT_QUOTES, 'UTF-8') . '">';
    echo plugin_glpiacessivel_portal_icon_markup();
    echo '<span class="glpiacessivel-sr-only">' . htmlspecialchars($portalLabel, ENT_QUOTES, 'UTF-8') . '</span>';
    echo '</a>';
}
