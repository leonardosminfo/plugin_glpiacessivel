(function () {
  'use strict';

  const LABEL_KEYS = {
    id: 'ticket.column.id', name: 'ticket.column.title', status: 'ticket.column.status',
    priority: 'ticket.column.priority', group: 'ticket.column.group',
    requester: 'ticket.column.requester', assignee: 'ticket.column.assignee',
    category: 'ticket.column.category', entity: 'ticket.column.entity',
    location: 'ticket.column.location', date: 'ticket.column.opened_at',
    date_mod: 'ticket.column.updated_at', time_to_resolve: 'ticket.column.resolve_by'
  };

  const i18n = window.__glpiacessivelI18n && window.__glpiacessivelI18n.messages
    ? window.__glpiacessivelI18n.messages
    : null;

  function message(key, replacements) {
    if (!i18n || typeof i18n[key] !== 'string' || i18n[key] === '') {
      return '';
    }
    let value = i18n[key];
    Object.keys(replacements || {}).forEach(function (name) {
      value = value.split('{' + name + '}').join(String(replacements[name]));
    });
    return value;
  }

  function readConfig() {
    const node = document.querySelector('[data-glpiacessivel-ticket-results-config]');
    if (!(node instanceof HTMLScriptElement)) {
      return { config: null, error: 'config_missing' };
    }
    try {
      const config = JSON.parse(node.textContent || '{}');
      return config && config.enabled === true
        ? { config: config, error: '' }
        : { config: null, error: 'config_disabled' };
    } catch (error) {
      return { config: null, error: 'config_invalid' };
    }
  }

  function textCell(value) {
    const cell = document.createElement('td');
    cell.textContent = String(value == null ? '' : value);
    return cell;
  }

  function detailLink(item, button) {
    const link = document.createElement('a');
    link.href = String(item.detail_url || '#');
    link.className = button
      ? 'glpiacessivel-button glpiacessivel-button-secondary'
      : 'glpiacessivel-ticket-title-link';
    link.textContent = button ? message('ticket.action.open') : String(item.name || '');
    if (button) {
      link.setAttribute('aria-label', message('ticket.action.open_named', {
        id: String(item.id || ''),
        title: String(item.name || '')
      }));
    }
    return link;
  }

  function badgeCell(item, field) {
    const cell = document.createElement('td');
    const badge = document.createElement('span');
    const kind = field === 'status' ? 'status' : 'priority';
    badge.className = 'glpiacessivel-badge glpiacessivel-badge-' + kind + '-' + String(item[field + '_class'] || 'neutral');
    badge.textContent = String(item[field + '_label'] || item[field] || '');
    cell.appendChild(badge);
    return cell;
  }

  function ticketRow(item, columns, showGroup, onSelection) {
    const row = document.createElement('tr');
    const selectCell = document.createElement('td');
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'glpiacessivel-ticket-select';
    checkbox.value = String(item.id || '');
    checkbox.setAttribute('aria-label', message('ticket.action.select', { id: String(item.id || '') }));
    checkbox.addEventListener('change', onSelection);
    selectCell.appendChild(checkbox);
    row.appendChild(selectCell);

    columns.forEach(function (column) {
      if (!showGroup && column === 'group') {
        return;
      }
      if (column === 'name') {
        const cell = document.createElement('td');
        cell.appendChild(detailLink(item, false));
        row.appendChild(cell);
      } else if (column === 'status' || column === 'priority') {
        row.appendChild(badgeCell(item, column));
      } else {
        const values = {
          id: item.id,
          group: item.primary_group_name || message('ticket.value.no_group'),
          requester: item.requester_name,
          assignee: item.assignee_name,
          category: item.category_name,
          entity: item.entity_name,
          location: item.location_name,
          date: item.date,
          date_mod: item.date_mod,
          time_to_resolve: item.time_to_resolve
        };
        row.appendChild(textCell(values[column]));
      }
    });

    const actionCell = document.createElement('td');
    actionCell.appendChild(detailLink(item, true));
    row.appendChild(actionCell);
    return row;
  }

  function ticketTable(items, columns, showGroup, labelledBy, onSelection) {
    const wrap = document.createElement('div');
    wrap.className = 'glpiacessivel-table-wrap';
    wrap.setAttribute('role', 'region');
    wrap.setAttribute('tabindex', '0');
    if (labelledBy) {
      wrap.setAttribute('aria-labelledby', labelledBy);
    } else {
      wrap.setAttribute('aria-label', message('ticket.table.label'));
    }
    const table = document.createElement('table');
    table.className = 'tab_cadre_fixehov glpiacessivel-ticket-table';
    const caption = document.createElement('caption');
    caption.className = 'glpiacessivel-sr-only';
    caption.textContent = message('ticket.table.caption');
    table.appendChild(caption);
    const head = document.createElement('thead');
    const headRow = document.createElement('tr');
    const selectionHead = document.createElement('th');
    selectionHead.scope = 'col';
    const selectionLabel = document.createElement('span');
    selectionLabel.className = 'glpiacessivel-sr-only';
    selectionLabel.textContent = message('ticket.action.select_short');
    selectionHead.appendChild(selectionLabel);
    headRow.appendChild(selectionHead);
    columns.forEach(function (column) {
      if (!showGroup && column === 'group') {
        return;
      }
      const cell = document.createElement('th');
      cell.scope = 'col';
      cell.textContent = message(LABEL_KEYS[column]) || column;
      headRow.appendChild(cell);
    });
    const actionHead = document.createElement('th');
    actionHead.scope = 'col';
    actionHead.textContent = message('ticket.column.action');
    headRow.appendChild(actionHead);
    head.appendChild(headRow);
    table.appendChild(head);
    const body = document.createElement('tbody');
    items.forEach(function (item) {
      body.appendChild(ticketRow(item, columns, showGroup, onSelection));
    });
    table.appendChild(body);
    wrap.appendChild(table);
    return wrap;
  }

  function renderItems(container, result, config, onSelection) {
    const items = Array.isArray(result.items) ? result.items : [];
    const backendReason = String(result.backend_reason || '');
    container.replaceChildren();
    if (items.length === 0) {
      if (backendReason === 'group_scope_without_current_groups') {
        return;
      }
      const empty = document.createElement('div');
      empty.className = 'glpiacessivel-empty';
      empty.setAttribute('role', 'status');
      const messageNode = document.createElement('p');
      messageNode.textContent = message('ticket.results.empty');
      empty.appendChild(messageNode);
      container.appendChild(empty);
      return;
    }

    const columns = Array.isArray(config.columns) ? config.columns.map(String) : ['id', 'name', 'status', 'priority', 'group', 'date_mod'];
    if (config.group_by === 'group') {
      const groups = new Map();
      items.forEach(function (item) {
        const label = String(item.primary_group_name || message('ticket.value.no_group'));
        if (!groups.has(label)) {
          groups.set(label, []);
        }
        groups.get(label).push(item);
      });
      const grouped = document.createElement('div');
      grouped.className = 'glpiacessivel-ticket-grouped';
      Array.from(groups.keys()).sort(function (a, b) { return a.localeCompare(b, 'pt-BR'); }).forEach(function (label, index) {
        const section = document.createElement('section');
        section.className = 'glpiacessivel-ticket-group';
        const heading = document.createElement('h3');
        heading.id = 'tickets-grupo-async-' + String(index);
        heading.textContent = label + ' (' + String(groups.get(label).length) + ')';
        section.setAttribute('aria-labelledby', heading.id);
        section.appendChild(heading);
        section.appendChild(ticketTable(groups.get(label), columns, false, heading.id, onSelection));
        grouped.appendChild(section);
      });
      container.appendChild(grouped);
      return;
    }
    container.appendChild(ticketTable(items, columns, true, '', onSelection));
  }

  function pageUrl(page) {
    const url = new URL(window.location.href);
    url.searchParams.set('page', String(page));
    return url.pathname + '?' + url.searchParams.toString();
  }

  function renderPagination(node, result) {
    const page = Math.max(1, Number(result.page || 1));
    const pages = Math.max(1, Number(result.pages || 1));
    node.replaceChildren();
    const label = document.createElement('span');
    label.textContent = message('pagination.page_of', { page: page, pages: pages });
    node.appendChild(label);
    [
      [message('pagination.first'), 1, page > 1],
      [message('pagination.previous'), page - 1, page > 1],
      [message('pagination.next'), page + 1, page < pages],
      [message('pagination.last'), pages, page < pages]
    ].forEach(function (entry) {
      if (entry[2]) {
        const link = document.createElement('a');
        link.href = pageUrl(entry[1]);
        link.textContent = entry[0];
        node.appendChild(link);
      } else {
        const disabled = document.createElement('span');
        disabled.setAttribute('aria-disabled', 'true');
        disabled.textContent = entry[0];
        node.appendChild(disabled);
      }
    });
  }

  function start() {
    const section = document.querySelector('[data-glpiacessivel-ticket-results]');
    const content = document.querySelector('[data-glpiacessivel-ticket-results-content]');
    const summary = document.querySelector('[data-glpiacessivel-ticket-results-summary]');
    const pagination = document.querySelector('[data-glpiacessivel-ticket-results-pagination]');
    if (!(section instanceof HTMLElement) || !(content instanceof HTMLElement)) {
      return;
    }
    if (!i18n || !message('ticket.table.caption')) {
      return;
    }
    if (section.dataset.glpiacessivelAsyncStarted === '1') {
      return;
    }
    section.dataset.glpiacessivelAsyncStarted = '1';
    section.removeAttribute('aria-busy');

    const parsed = readConfig();
    const config = parsed.config;
    const nativeFallbackUrl = String(
      (config && config.native_fallback_url)
      || section.dataset.nativeFallbackUrl
      || '/front/ticket.php'
    );

    function failureMessage(code) {
      const messages = {
        session_expired: 'ticket.error.session_expired',
        forbidden: 'ticket.error.forbidden',
        context_stale: 'ticket.error.context_stale',
        state_expired: 'ticket.error.state_expired',
        invalid_request: 'ticket.error.invalid_request',
        rate_limited: 'ticket.error.rate_limited',
        unavailable: 'ticket.error.unavailable',
        temporarily_unavailable: 'ticket.error.unavailable',
        origin_not_allowed: 'ticket.error.origin_not_allowed',
        timed_out: 'ticket.error.timed_out',
        config_invalid: 'ticket.error.config_invalid',
        config_missing: 'ticket.error.config_missing',
        unexpected_content_type: 'ticket.error.unexpected_content_type',
        invalid_response: 'ticket.error.invalid_response'
      };
      return message(messages[code] || 'ticket.error.generic');
    }

    let generation = 0;
    function renderFailure(code) {
      const alert = document.createElement('div');
      alert.className = 'glpiacessivel-alert glpiacessivel-alert-error';
      alert.setAttribute('role', 'alert');
      const messageNode = document.createElement('p');
      messageNode.textContent = failureMessage(code);
      const actions = document.createElement('p');
      const retry = document.createElement('button');
      retry.type = 'button';
      retry.className = 'glpiacessivel-button';
      retry.textContent = message('button.retry');
      retry.addEventListener('click', function () {
        if (config && config.bootstrap_error) {
          window.location.reload();
          return;
        }
        runRequest();
      });
      const link = document.createElement('a');
      link.className = 'glpiacessivel-button glpiacessivel-button-secondary';
      link.href = nativeFallbackUrl;
      link.textContent = message('ticket.action.open_native_list');
      actions.append(retry, link);
      alert.append(messageNode, actions);
      content.replaceChildren(alert);
      if (summary) {
        summary.textContent = failureMessage(code) + ' ' + message('ticket.error.native_fallback_help');
      }
      section.removeAttribute('aria-busy');
    }

    if (!config) {
      renderFailure(parsed.error || 'config_invalid');
      return;
    }
    if (config.bootstrap_error) {
      renderFailure(String(config.bootstrap_error));
      return;
    }

    const selectedCount = document.querySelector('[data-glpiacessivel-selected-count]');
    const copyButton = document.querySelector('[data-glpiacessivel-copy-selected]');
    function selectedIds() {
      return Array.from(content.querySelectorAll('.glpiacessivel-ticket-select:checked')).map(function (checkbox) {
        return String(checkbox.value || '');
      }).filter(Boolean);
    }
    function refreshSelection() {
      const ids = selectedIds();
      if (selectedCount) {
        selectedCount.textContent = String(ids.length);
      }
      if (copyButton instanceof HTMLButtonElement) {
        copyButton.disabled = ids.length === 0;
      }
    }
    if (copyButton instanceof HTMLButtonElement && copyButton.dataset.glpiacessivelAsyncBound !== '1') {
      copyButton.dataset.glpiacessivelAsyncBound = '1';
      copyButton.addEventListener('click', function () {
        const text = selectedIds().join(', ');
        if (text && navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
          navigator.clipboard.writeText(text).catch(function () {});
        }
      });
    }

    function runRequest() {
      generation += 1;
      const currentGeneration = generation;
      const requestId = 'tickets_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
      const controller = new AbortController();
      const deadline = Math.min(6000, Math.max(1000, Number(config.request_timeout_ms || 5000)));
      let terminal = false;

      section.setAttribute('aria-busy', 'true');
      const loading = document.createElement('div');
      loading.className = 'glpiacessivel-empty';
      loading.setAttribute('role', 'status');
      loading.textContent = message('ticket.results.loading');
      content.replaceChildren(loading);
      if (summary) {
        summary.textContent = message('ticket.results.loading_summary');
      }

      const timeout = window.setTimeout(function () {
        if (terminal || currentGeneration !== generation) {
          return;
        }
        terminal = true;
        controller.abort();
        renderFailure('timed_out');
      }, deadline);

      fetch(String(config.url || ''), {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        signal: controller.signal,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
          'X-GLPI-CSRF-TOKEN': String(config.csrf_token || '')
        },
        body: JSON.stringify({
          contract: 'ticket_results', version: 1,
          state_token: String(config.state_token || ''),
          context_revision: String(config.context_revision || ''),
          request_id: requestId
        })
      }).then(function (response) {
        if (!String(response.headers.get('content-type') || '').toLowerCase().includes('application/json')) {
          throw new Error('unexpected_content_type');
        }
        return response.json().then(function (payload) {
          if (!response.ok) {
            throw new Error(String(payload.error || 'http_' + response.status));
          }
          if (payload.success !== true || payload.request_id !== requestId || payload.context_revision !== config.context_revision) {
            throw new Error(String(payload.error || 'invalid_response'));
          }
          return payload.result || {};
        });
      }).then(function (result) {
        if (terminal || currentGeneration !== generation) {
          return;
        }
        terminal = true;
        renderItems(content, result, config, refreshSelection);
        const total = Math.max(0, Number(result.total || 0));
        const page = Math.max(1, Number(result.page || 1));
        const size = Math.max(1, Number(result.page_size || 20));
        const first = total > 0 ? ((page - 1) * size) + 1 : 0;
        const last = total > 0 ? Math.min(total, first + (Array.isArray(result.items) ? result.items.length : 0) - 1) : 0;
        if (summary) {
          summary.textContent = String(result.backend_reason || '') === 'group_scope_without_current_groups'
            ? message('ticket.results.group_scope_without_current_groups')
            : (total > 0
              ? message('ticket.results.range', { first: first, last: last, total: total })
              : message('ticket.results.none_visible'));
        }
        if (pagination instanceof HTMLElement) {
          renderPagination(pagination, result);
        }
        refreshSelection();
        section.removeAttribute('aria-busy');
      }).catch(function (error) {
        if (terminal || currentGeneration !== generation) {
          return;
        }
        terminal = true;
        renderFailure(String(error && error.message ? error.message : 'unavailable'));
      }).finally(function () {
        window.clearTimeout(timeout);
      });
    }

    runRequest();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
