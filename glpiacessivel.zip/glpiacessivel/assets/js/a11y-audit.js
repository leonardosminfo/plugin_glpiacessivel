(function () {
  'use strict';

  var axeLoadPromise = null;
  var MAX_FINDINGS_PER_SECTION = 20;
  var MAX_NODES_PER_FINDING = 5;
  var MAX_DIAGNOSTIC_LENGTH = 280;
  var DEFAULT_AXE_RUN_TIMEOUT = 15000;
  var ID_REFERENCE_ATTRIBUTES = [
    'aria-activedescendant',
    'aria-controls',
    'aria-describedby',
    'aria-errormessage',
    'aria-labelledby',
    'aria-owns'
  ];

  function message(key, replacements, fallback) {
    var catalog = window.__glpiacessivelI18n && window.__glpiacessivelI18n.messages
      ? window.__glpiacessivelI18n.messages
      : null;
    var value = catalog && typeof catalog[key] === 'string' && catalog[key] !== ''
      ? catalog[key]
      : String(fallback || '');
    Object.keys(replacements || {}).forEach(function (name) {
      value = value.split('{' + name + '}').join(String(replacements[name]));
    });
    return value;
  }

  function loadAxe(sourceUrl) {
    if (window.axe && typeof window.axe.run === 'function') {
      return Promise.resolve(window.axe);
    }
    if (axeLoadPromise) {
      return axeLoadPromise;
    }
    if (!sourceUrl) {
      return Promise.reject(new Error('axe source is unavailable'));
    }

    axeLoadPromise = new Promise(function (resolve, reject) {
      var existing = document.getElementById('glpiacessivel-axe-core');
      if (existing) {
        existing.remove();
      }

      var script = document.createElement('script');
      var timeoutId = window.setTimeout(function () {
        script.remove();
        reject(new Error('axe load timed out'));
      }, 10000);

      function fail() {
        window.clearTimeout(timeoutId);
        script.remove();
        reject(new Error('axe load failed'));
      }

      script.id = 'glpiacessivel-axe-core';
      script.src = sourceUrl;
      script.async = true;
      script.onload = function () {
        window.clearTimeout(timeoutId);
        if (window.axe && typeof window.axe.run === 'function') {
          resolve(window.axe);
        } else {
          fail();
        }
      };
      script.onerror = fail;
      document.head.appendChild(script);
    }).catch(function (error) {
      axeLoadPromise = null;
      throw error;
    });

    return axeLoadPromise;
  }

  function appendText(parent, tag, text, className) {
    var node = document.createElement(tag);
    if (className) {
      node.className = className;
    }
    node.textContent = text;
    parent.appendChild(node);
    return node;
  }

  function boundedText(value, maximum) {
    var normalized = String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
    if (normalized.length <= maximum) {
      return normalized;
    }
    return normalized.slice(0, Math.max(0, maximum - 1)).trimEnd() + '\u2026';
  }

  function safeHelpUrl(value) {
    var raw = String(value == null ? '' : value).trim();
    if (!/^https:\/\//i.test(raw)) {
      return '';
    }
    try {
      var parsed = new URL(raw);
      if (
        parsed.protocol !== 'https:'
        || parsed.hostname !== 'dequeuniversity.com'
        || parsed.port !== ''
        || parsed.username !== ''
        || parsed.password !== ''
        || parsed.pathname.indexOf('/rules/axe/') !== 0
      ) {
        return '';
      }
      return parsed.href;
    } catch (error) {
      return '';
    }
  }

  function axeRunTimeout(button) {
    var configured = Number(button && button.dataset.axeRunTimeout);
    if (!Number.isFinite(configured)) {
      return DEFAULT_AXE_RUN_TIMEOUT;
    }
    return Math.max(20, Math.min(30000, Math.floor(configured)));
  }

  function runAxeWithTimeout(axe, context, options, timeout) {
    return new Promise(function (resolve, reject) {
      var settled = false;
      var timeoutId = window.setTimeout(function () {
        if (settled) {
          return;
        }
        settled = true;
        reject(new Error('axe run timed out'));
      }, timeout);

      Promise.resolve().then(function () {
        return axe.run(context, options);
      }).then(function (result) {
        if (settled) {
          return;
        }
        settled = true;
        window.clearTimeout(timeoutId);
        resolve(result);
      }, function (error) {
        if (settled) {
          return;
        }
        settled = true;
        window.clearTimeout(timeoutId);
        reject(error);
      });
    });
  }

  function safeIdentifier(value) {
    var normalized = String(value == null ? '' : value).trim();
    return /^[A-Za-z_][A-Za-z0-9_.:-]{0,79}$/.test(normalized) ? normalized : '';
  }

  function targetParts(node) {
    var targets = Array.isArray(node && node.target) ? node.target : [];
    var tag = '';
    var id = '';
    var attributes = [];

    targets.forEach(function (target) {
      if (typeof target !== 'string' || target.length > 500) {
        return;
      }
      if (!tag) {
        var tagMatch = target.match(/(?:^|[\s>+~])([A-Za-z][A-Za-z0-9-]*)/);
        tag = tagMatch ? tagMatch[1].toLowerCase() : '';
      }
      if (!id) {
        var idMatch = target.match(/#([A-Za-z_][A-Za-z0-9_.:-]{0,79})/);
        id = idMatch ? safeIdentifier(idMatch[1]) : '';
      }
      var matcher = /\[\s*([A-Za-z_:][A-Za-z0-9_.:-]*)/g;
      var attributeMatch;
      while ((attributeMatch = matcher.exec(target)) !== null) {
        var attribute = attributeMatch[1].toLowerCase();
        if (attributes.indexOf(attribute) === -1 && attributes.length < 6) {
          attributes.push(attribute);
        }
      }
    });

    if (id) {
      var element = document.getElementById(id);
      if (element instanceof Element) {
        tag = element.tagName.toLowerCase();
        Array.prototype.slice.call(element.attributes).forEach(function (attribute) {
          var name = String(attribute && attribute.name || '').toLowerCase();
          if (
            (name.indexOf('aria-') === 0 || name === 'role' || name === 'tabindex')
            && attributes.indexOf(name) === -1
            && attributes.length < 6
          ) {
            attributes.push(name);
          }
        });
      }
    }

    return { tag: tag, id: id, attributes: attributes };
  }

  function targetDescription(node, index) {
    var parts = targetParts(node);
    var target = parts.tag || message('a11y.audit.target.element', null, 'elemento');
    if (parts.id) {
      target += '#' + parts.id;
    }
    if (parts.attributes.length) {
      target += '; ' + message(
        'a11y.audit.target.attributes',
        { attributes: parts.attributes.join(', ') },
        'atributos: {attributes}'
      );
    }
    return message(
      'a11y.audit.target.local',
      { index: index + 1, target: target },
      'Alvo local {index}: {target}.'
    );
  }

  function checksFor(node) {
    return ['any', 'all', 'none'].reduce(function (checks, group) {
      return checks.concat(Array.isArray(node && node[group]) ? node[group] : []);
    }, []);
  }

  function ariaReviewDescription(check) {
    var data = check && check.data;
    var candidates = [];
    if (data && typeof data === 'object' && !Array.isArray(data) && typeof data.needsReview === 'string') {
      candidates.push(data.needsReview);
    }
    if (Array.isArray(data)) {
      candidates = candidates.concat(data.filter(function (item) { return typeof item === 'string'; }));
    }

    for (var index = 0; index < candidates.length; index += 1) {
      var candidate = candidates[index];
      var match = candidate.match(/^\s*(aria-[a-z0-9-]+)(?:\s*=\s*"([^"]*)")?/i);
      if (!match) {
        continue;
      }
      var attribute = match[1].toLowerCase();
      var value = match[2] || '';
      if (ID_REFERENCE_ATTRIBUTES.indexOf(attribute) !== -1 && value) {
        var references = value.split(/\s+/).map(safeIdentifier).filter(Boolean).slice(0, 4);
        if (references.length) {
          return message(
            'a11y.audit.aria.references',
            { attribute: attribute, references: references.join(', #') },
            'Atributo ARIA a revisar: {attribute}; IDs referenciados: #{references}.'
          );
        }
      }
      return message(
        'a11y.audit.aria.omitted',
        { attribute: attribute },
        'Atributo ARIA a revisar: {attribute}. O valor foi omitido.'
      );
    }
    return '';
  }

  function finiteNumber(value) {
    var number = Number(value);
    return Number.isFinite(number) ? number : null;
  }

  function colorContrastDescriptions(node) {
    var reasonLabels = {
      bgImage: message('a11y.audit.contrast.bg_image', null, 'O Axe não determinou a cor de fundo por causa de uma imagem.'),
      bgGradient: message('a11y.audit.contrast.bg_gradient', null, 'O Axe não determinou a cor de fundo por causa de um gradiente.'),
      bgOverlap: message('a11y.audit.contrast.bg_overlap', null, 'O Axe não determinou o contraste por causa de sobreposição de elementos.'),
      complexTextShadows: message('a11y.audit.contrast.text_shadows', null, 'O Axe não determinou o contraste por causa de sombras de texto complexas.'),
      elmPartiallyObscured: message('a11y.audit.contrast.partially_obscured', null, 'O elemento está parcialmente encoberto; o contraste exige revisão manual.'),
      elmPartiallyObscuring: message('a11y.audit.contrast.partially_obscuring', null, 'O elemento encobre parcialmente outro conteúdo; o contraste exige revisão manual.'),
      fgAlpha: message('a11y.audit.contrast.alpha', null, 'A transparência da cor do texto impede o cálculo automático do contraste.'),
      outsideViewport: message('a11y.audit.contrast.outside_viewport', null, 'O elemento está fora da área visível e exige revisão manual de contraste.'),
      pseudoContent: message('a11y.audit.contrast.pseudo_content', null, 'Um pseudo-elemento impede a determinação automática do contraste.'),
      shortTextContent: message('a11y.audit.contrast.short_text', null, 'O conteúdo é curto demais para o Axe confirmar que se trata de texto.'),
      equalRatio: message('a11y.audit.contrast.equal_ratio', null, 'O Axe encontrou razão de contraste 1:1 e exige confirmação manual.')
    };
    var descriptions = [];
    checksFor(node).forEach(function (check) {
      var data = check && check.data;
      if (!data || typeof data !== 'object' || Array.isArray(data)) {
        return;
      }
      var ratio = finiteNumber(data.contrastRatio);
      var expected = boundedText(data.expectedContrastRatio || data.requiredContrastRatio || '', 20);
      if (ratio !== null) {
        var ratioText = message(
          'a11y.audit.contrast.calculated',
          { ratio: ratio },
          'Contraste calculado pelo Axe: {ratio}:1.'
        );
        if (/^\d+(?:\.\d+)?:1$/.test(expected)) {
          ratioText += ' ' + message(
            'a11y.audit.contrast.minimum',
            { expected: expected },
            'Mínimo esperado: {expected}.'
          );
        } else {
          var expectedNumber = finiteNumber(data.expectedContrastRatio || data.requiredContrastRatio);
          if (expectedNumber !== null) {
            ratioText += ' ' + message(
              'a11y.audit.contrast.minimum',
              { expected: String(expectedNumber) + ':1' },
              'Mínimo esperado: {expected}.'
            );
          }
        }
        descriptions.push(ratioText);
      }
      var reason = reasonLabels[String(data.messageKey || '')];
      if (reason) {
        descriptions.push(reason);
      }
    });
    return descriptions.filter(function (description, index, all) {
      return all.indexOf(description) === index;
    }).slice(0, 2);
  }

  function safeFailureSummary(value) {
    var summary = boundedText(value, MAX_DIAGNOSTIC_LENGTH);
    if (!summary) {
      return '';
    }
    if (/(?:field\s+)?(?:value|text|content|valor|texto|conteudo)\s*[:=]/i.test(summary)) {
      return '';
    }
    summary = summary.replace(/(["'`])[^"'`\r\n]{1,160}\1/g, '$1[valor omitido]$1');
    return boundedText(summary, MAX_DIAGNOSTIC_LENGTH);
  }

  function nodeDescriptions(finding, node) {
    var descriptions = [];
    if (finding.id === 'aria-valid-attr-value') {
      checksFor(node).some(function (check) {
        var description = ariaReviewDescription(check);
        if (description) {
          descriptions.push(description);
          return true;
        }
        return false;
      });
    }
    if (finding.id === 'color-contrast' || finding.id === 'color-contrast-enhanced') {
      descriptions = descriptions.concat(colorContrastDescriptions(node));
    }
    if (!descriptions.length) {
      var summary = safeFailureSummary(node && node.failureSummary);
      if (summary) {
        descriptions.push(message(
          'a11y.audit.technical_summary',
          { summary: summary },
          'Resumo técnico do Axe: {summary}'
        ));
      }
    }
    if (!descriptions.length) {
      var checkIds = checksFor(node).map(function (check) {
        return safeIdentifier(check && check.id);
      }).filter(Boolean).slice(0, 4);
      if (checkIds.length) {
        descriptions.push(message(
          'a11y.audit.technical_checks',
          { checks: checkIds.join(', ') },
          'Verificações técnicas: {checks}.'
        ));
      }
    }
    return descriptions.slice(0, 2);
  }

  function renderNodeDetails(item, finding) {
    var nodes = Array.isArray(finding.nodes) ? finding.nodes : [];
    if (!nodes.length) {
      return;
    }
    var shown = nodes.slice(0, MAX_NODES_PER_FINDING);
    var details = document.createElement('details');
    details.className = 'glpiacessivel-a11y-audit-node-details';
    appendText(
      details,
      'summary',
      message(
        'a11y.audit.node_details',
        { shown: shown.length, total: nodes.length },
        'Detalhes locais por elemento ({shown} de {total}).'
      )
    );
    var list = document.createElement('ol');
    list.className = 'glpiacessivel-a11y-audit-node-list';
    shown.forEach(function (node, index) {
      var nodeItem = document.createElement('li');
      appendText(nodeItem, 'p', targetDescription(node, index), 'glpiacessivel-a11y-audit-target');
      nodeDescriptions(finding, node).forEach(function (description) {
        appendText(nodeItem, 'p', description, 'glpiacessivel-a11y-audit-node-message');
      });
      list.appendChild(nodeItem);
    });
    details.appendChild(list);
    if (nodes.length > shown.length) {
      var omittedNodeCount = nodes.length - shown.length;
      appendText(
        details,
        'p',
        message(
          omittedNodeCount === 1 ? 'a11y.audit.one_node_omitted' : 'a11y.audit.many_nodes_omitted',
          { count: omittedNodeCount },
          omittedNodeCount === 1
            ? '1 elemento adicional omitido para limitar o diagnóstico.'
            : '{count} elementos adicionais omitidos para limitar o diagnóstico.'
        ),
        'glpiacessivel-a11y-audit-truncated'
      );
    }
    item.appendChild(details);
  }

  function renderFindingList(container, findings, messages, linkLabel, kind) {
    if (!Array.isArray(findings) || findings.length === 0) {
      return;
    }

    var list = document.createElement('ol');
    list.className = 'glpiacessivel-a11y-audit-list';
    var shownFindings = findings.slice(0, MAX_FINDINGS_PER_SECTION);
    shownFindings.forEach(function (finding) {
      var item = document.createElement('li');
      item.dataset.auditFindingKind = kind;
      var findingId = safeIdentifier(finding.id) || 'regra-axe';
      var heading = appendText(item, 'h3', boundedText(finding.help || findingId, 180));
      appendText(
        item,
        'p',
        kind === 'confirmed'
          ? message(
            'a11y.audit.confirmed_classification',
            null,
            'Violação automatizada confirmada pelo Axe.'
          )
          : message(
            'a11y.audit.manual_classification',
            null,
            'Revisão manual: o Axe não confirmou uma violação.'
          ),
        'glpiacessivel-a11y-audit-classification'
      );
      var detail = appendText(
        item,
        'p',
        boundedText(messages.impacts[finding.impact] || messages.impactUnknown, 40) + ': '
          + boundedText(
            finding.description || message(
              'a11y.audit.review_rule',
              null,
              'Consulte a regra para revisar o resultado.'
            ),
            260
          )
      );
      detail.className = 'glpiacessivel-a11y-audit-detail';
      var affectedCount = (finding.nodes || []).length;
      appendText(
        item,
        'p',
        (affectedCount === 1 ? messages.affectedOne : messages.affectedMany)
          .replace('{count}', String(affectedCount))
      );
      renderNodeDetails(item, finding);
      var helpUrl = safeHelpUrl(finding.helpUrl);
      if (helpUrl) {
        var link = document.createElement('a');
        link.href = helpUrl;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.textContent = linkLabel.replace('{rule}', findingId);
        item.appendChild(link);
      }
      list.appendChild(item);
      heading.tabIndex = -1;
    });
    container.appendChild(list);
    if (findings.length > shownFindings.length) {
      var omittedRuleCount = findings.length - shownFindings.length;
      appendText(
        container,
        'p',
        message(
          omittedRuleCount === 1 ? 'a11y.audit.one_rule_omitted' : 'a11y.audit.many_rules_omitted',
          { count: omittedRuleCount },
          omittedRuleCount === 1
            ? '1 regra adicional omitida para limitar o diagnóstico local.'
            : '{count} regras adicionais omitidas para limitar o diagnóstico local.'
        ),
        'glpiacessivel-a11y-audit-truncated'
      );
    }
  }

  function renderResults(container, result, messages) {
    container.replaceChildren();
    container.removeAttribute('role');
    container.removeAttribute('aria-live');
    container.removeAttribute('aria-atomic');
    var violations = Array.isArray(result.violations) ? result.violations : [];
    var incomplete = Array.isArray(result.incomplete) ? result.incomplete : [];
    var confirmedSummary = violations.length === 0
      ? messages.none
      : (violations.length === 1 ? messages.completeOne : messages.completeMany)
        .replace('{count}', String(violations.length));
    var manualSummary = incomplete.length > 0
      ? ' ' + (incomplete.length === 1 ? messages.incompleteOne : messages.incompleteMany)
        .replace('{count}', String(incomplete.length))
      : '';
    var liveSummary = appendText(
      container,
      'p',
      confirmedSummary + manualSummary,
      'glpiacessivel-a11y-audit-summary'
    );
    liveSummary.setAttribute('role', 'status');
    liveSummary.setAttribute('aria-live', 'polite');
    liveSummary.setAttribute('aria-atomic', 'true');
    if (violations.length > 0) {
      appendText(
        container,
        'h3',
        message(
          'a11y.audit.confirmed_heading',
          null,
          'Violações automatizadas confirmadas'
        )
      );
      renderFindingList(container, violations, messages, messages.rule, 'confirmed');
    }

    if (incomplete.length > 0) {
      appendText(
        container,
        'h3',
        message(
          'a11y.audit.manual_heading',
          null,
          'Itens para revisão manual (não confirmados)'
        )
      );
      renderFindingList(container, incomplete, messages, messages.review, 'manual');
    }

    appendText(container, 'p', messages.limit, 'glpiacessivel-a11y-audit-limit');
  }
  function init() {
    var button = document.querySelector('[data-glpiacessivel-a11y-audit]');
    var panel = document.getElementById('glpiacessivel-a11y-audit-panel');
    var results = document.getElementById('glpiacessivel-a11y-audit-results');
    var title = document.getElementById('glpiacessivel-a11y-audit-title');
    if (!(button instanceof HTMLButtonElement) || !(panel instanceof HTMLElement) || !(results instanceof HTMLElement) || !(title instanceof HTMLElement)) {
      return;
    }

    var closeButtons = panel.querySelectorAll('[data-glpiacessivel-a11y-audit-close]');
    var messages = {
      running: button.dataset.runningLabel || message(
        'a11y.audit.running', null, 'Auditoria em execução.'
      ),
      failed: button.dataset.failedLabel || message(
        'a11y.audit.failed', null, 'Não foi possível executar a auditoria local.'
      ),
      completeOne: button.dataset.completeOneLabel || message(
        'a11y.audit.complete_one', null, 'Foi encontrada 1 regra com violação.'
      ),
      completeMany: button.dataset.completeManyLabel || message(
        'a11y.audit.complete_many', null, 'Foram encontradas {count} regras com violação.'
      ),
      none: button.dataset.noneLabel || message(
        'a11y.audit.none', null, 'Nenhuma violação automatizada foi encontrada nesta página.'
      ),
      incompleteOne: button.dataset.incompleteOneLabel || message(
        'a11y.audit.incomplete_one', null,
        'A auditoria encontrou 1 regra que exige revisão manual.'
      ),
      incompleteMany: button.dataset.incompleteManyLabel || message(
        'a11y.audit.incomplete_many', null,
        'A auditoria encontrou {count} regras que exigem revisão manual.'
      ),
      limit: button.dataset.limitLabel || message(
        'a11y.audit.limit', null, 'O resultado é local e não substitui avaliação manual.'
      ),
      affectedOne: button.dataset.affectedOneLabel || message(
        'a11y.audit.affected_one', null, '1 elemento afetado.'
      ),
      affectedMany: button.dataset.affectedManyLabel || message(
        'a11y.audit.affected_many', null, '{count} elementos afetados.'
      ),
      rule: button.dataset.ruleLabel || message(
        'a11y.audit.rule', null, 'Ver regra {rule}.'
      ),
      review: button.dataset.reviewLabel || message(
        'a11y.audit.review', null, 'Revisar regra {rule}.'
      ),
      impactUnknown: button.dataset.impactUnknownLabel || message(
        'a11y.audit.impact_unknown', null, 'Impacto não classificado'
      ),
      impacts: {
        critical: message('a11y.audit.impact.critical', null, 'crítico'),
        serious: message('a11y.audit.impact.serious', null, 'grave'),
        moderate: message('a11y.audit.impact.moderate', null, 'moderado'),
        minor: message('a11y.audit.impact.minor', null, 'leve')
      }
    };
    var originalLabel = button.textContent;
    var restoreFocusWhenReady = false;

    function closePanel() {
      panel.hidden = true;
      button.setAttribute('aria-expanded', 'false');
      if (button.disabled) {
        restoreFocusWhenReady = true;
        return;
      }
      restoreFocusWhenReady = false;
      button.focus();
    }

    closeButtons.forEach(function (closeButton) {
      closeButton.addEventListener('click', closePanel);
    });
    panel.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        event.preventDefault();
        closePanel();
      }
    });

    button.addEventListener('click', function () {
      restoreFocusWhenReady = false;
      button.disabled = true;
      button.setAttribute('aria-busy', 'true');
      button.textContent = messages.running;
      panel.hidden = false;
      panel.setAttribute('aria-busy', 'true');
      button.setAttribute('aria-expanded', 'true');
      results.setAttribute('role', 'status');
      results.setAttribute('aria-live', 'polite');
      results.setAttribute('aria-atomic', 'true');
      results.replaceChildren();
      appendText(results, 'p', messages.running);
      title.focus();

      loadAxe(button.dataset.axeSourceUrl || '')
        .then(function (axe) {
          var auditRootSelector = document.getElementById('conteudo-principal')
            ? '#conteudo-principal'
            : 'html';

          var context = {
            include: [[auditRootSelector]],
            exclude: [['#glpiacessivel-a11y-audit-panel']]
          };
          var options = {
            runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22a', 'wcag22aa'] },
            resultTypes: ['violations', 'incomplete']
          };
          return runAxeWithTimeout(axe, context, options, axeRunTimeout(button));
        })
        .then(function (result) {
          if (!panel.hidden) {
            renderResults(results, result, messages);
          }
        })
        .catch(function () {
          if (!panel.hidden) {
            results.setAttribute('role', 'alert');
            results.setAttribute('aria-live', 'assertive');
            results.replaceChildren();
            appendText(results, 'p', messages.failed);
          }
        })
        .finally(function () {
          panel.removeAttribute('aria-busy');
          button.disabled = false;
          button.removeAttribute('aria-busy');
          button.textContent = originalLabel;
          if (restoreFocusWhenReady && panel.hidden) {
            restoreFocusWhenReady = false;
            button.focus();
          }
        });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
