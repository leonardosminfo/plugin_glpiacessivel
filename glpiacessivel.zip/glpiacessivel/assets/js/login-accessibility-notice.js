(function () {
  'use strict';

  var noticeId = 'glpiacessivel-login-accessibility-notice';
  var placementValue = 'below-submit';
  var maximumAttempts = 8;

  function placeNoticeBelowLoginSubmit() {
    var notice = document.getElementById(noticeId);
    var loginName = document.getElementById('login_name');
    if (!notice || !loginName || typeof loginName.closest !== 'function') {
      return false;
    }

    var loginForm = loginName.closest('form');
    if (!loginForm) {
      return false;
    }

    var submit = loginForm.querySelector(
      'button[type="submit"][name="submit"], input[type="submit"][name="submit"]'
    );
    if (!submit || !loginForm.contains(submit)) {
      return false;
    }

    if (submit.nextElementSibling !== notice) {
      submit.insertAdjacentElement('afterend', notice);
    }
    notice.setAttribute('data-glpiacessivel-placement', placementValue);
    return true;
  }

  function retryPlacement(attempt) {
    if (placeNoticeBelowLoginSubmit() || attempt >= maximumAttempts) {
      return;
    }
    window.setTimeout(function () {
      retryPlacement(attempt + 1);
    }, 125);
  }

  if (!placeNoticeBelowLoginSubmit()) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () {
        retryPlacement(0);
      }, { once: true });
    } else {
      retryPlacement(0);
    }
  }
}());
