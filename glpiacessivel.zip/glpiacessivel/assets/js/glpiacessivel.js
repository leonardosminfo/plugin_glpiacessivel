(function () {
  const DEFAULT_I18N = {
    'portal.open.label': 'Abrir portal acessível do GLPI',
    'portal.open.sr': 'Abrir portal acessível',
    'portal.embedded.label': 'Ir para modo acessível do GLPI',
    'portal.embedded.sr': 'Ir para modo acessível',
    'portal.open.title': 'Abrir portal acessível',
    'portal.embedded.title': 'Ir para modo acessível',
    'chatbot.open.label': 'Abrir chatbot operacional do GLPI acessível',
    'chatbot.open.sr': 'Abrir chatbot operacional',
    'status.processing': 'Processando ação, aguarde.',
    'status.opening_accessible_journey': 'Abrindo jornada acessível principal.',
    'status.opening_accessible_mode': 'Abrindo modo acessível.',
    'status.opening_chatbot': 'Abrindo chatbot operacional.',
    'status.shortcut_executed': 'Atalho executado: {shortcut}.',
    'status.theme_night_enabled': 'Tema noturno ativado.',
    'status.theme_light_enabled': 'Tema claro ativado.',
    'status.contrast_enabled': 'Alto contraste ativado.',
    'status.contrast_disabled': 'Alto contraste desativado.',
    'status.help_opened': 'Painel de ajuda aberto.',
    'status.help_closed': 'Painel de ajuda fechado.',
    'status.focus_main': 'Foco movido para o conteúdo principal.',
    'status.focus_menu': 'Foco movido para o menu.',
    'status.focus_search': 'Foco movido para a busca ou formulário principal.',
    'status.opening_my_tickets': 'Abrindo meus chamados.',
    'status.opening_all_tickets': 'Abrindo todos os chamados permitidos.',
    'status.opening_new_ticket': 'Abrindo novo chamado.',
    'status.opening_forms': 'Abrindo formulários.',
    'status.opening_kb': 'Abrindo base de conhecimento.',
    'status.opening_cockpit': 'Abrindo cockpit operacional.',
    'status.opening_public_faq': 'Abrindo FAQ pública acessível.',
    'status.no_ticket_selected': 'Nenhum chamado selecionado.',
    'status.ticket_ids_copied': 'IDs dos chamados selecionados copiados.',
    'status.ticket_ids_selected': 'IDs selecionados: {ids}.',
    'status.ticket_count_selected': '{count} chamados selecionados.',
    'status.dynamic_form_updated': 'Regras dinâmicas do formulário atualizadas.',
    'status.dynamic_form_visibility_failed': 'Não foi possível atualizar a visibilidade dinâmica do formulário.',
    'status.form_validation_failed': 'Corrija os campos indicados antes de enviar.',
    'status.form_field_invalid': 'Campo inválido.',
    'status.form_submitted': 'Formulário enviado com sucesso pelo GLPI.',
    'status.form_submitted_with_links': 'Formulário enviado com sucesso. Itens criados: {links}.',
    'status.form_submit_failed': 'Não foi possível enviar o formulário nesta página. Abra-o em página completa ou contate o administrador.',
    'status.form_unexpected_response': 'O servidor retornou uma resposta inesperada. Abra o formulário em página completa para concluir.',
    'status.native_form_loading': 'Carregando o formulário…',
    'status.native_form_loaded': 'Formulário carregado.',
    'status.native_form_loaded_minimal': 'Formulário carregado.',
    'status.native_form_full_chrome': 'Formulário carregado.',
    'status.native_form_session_expired': 'Sua sessão terminou. Abra o formulário em página completa para entrar novamente.',
    'status.native_form_navigated': 'O formulário avançou para outra etapa. Confira o conteúdo exibido.',
    'status.native_form_unverified': 'Não foi possível abrir o formulário nesta página. Abra-o em página completa para continuar.',
    'status.native_form_timeout': 'O formulário está demorando para carregar. Você pode tentar novamente ou abri-lo em página completa.',
    'critical.required': 'Confirmação obrigatória',
    'critical.title': 'Confirmar ação crítica',
    'critical.review': 'Revise os dados antes de executar esta ação.',
    'critical.consequence': 'Esta ação será registrada no GLPI.',
    'critical.opened': 'Confirmação obrigatória aberta. Revise a ação antes de continuar.',
    'critical.cancelled': 'Ação crítica cancelada.',
    'critical.confirmed': 'Ação crítica confirmada. Enviando formulário.',
    'critical.none_pending': 'Nenhuma ação pendente para confirmar.',
    'button.cancel': 'Cancelar',
    'button.confirm_action': 'Confirmar ação',
    'shortcut.help': 'Abrir ajuda de acessibilidade',
    'shortcut.theme': 'Alternar tema claro e noturno',
    'shortcut.contrast': 'Ativar ou desativar alto contraste',
    'shortcut.font_decrease': 'Diminuir tamanho da fonte',
    'shortcut.font_reset': 'Restaurar tamanho da fonte',
    'shortcut.font_increase': 'Aumentar tamanho da fonte',
    'vlibras.ready': 'VLibras carregado.',
    'vlibras.unavailable': 'VLibras indisponível no momento.',
    'vlibras.retrying': 'Conexão restaurada. Tentando carregar VLibras.'
  };

  function i18n(key, params) {
    const catalog = window.__glpiacessivelI18n && typeof window.__glpiacessivelI18n === 'object'
      ? window.__glpiacessivelI18n.messages
      : null;
    const source = catalog && Object.prototype.hasOwnProperty.call(catalog, key)
      ? catalog[key]
      : DEFAULT_I18N[key];
    const template = String(source || '');
    const values = params && typeof params === 'object' ? params : {};
    return template.replace(/\{([a-zA-Z0-9_]+)\}/g, function (match, name) {
      return Object.prototype.hasOwnProperty.call(values, name) ? String(values[name]) : match;
    });
  }

  function hasI18nMessage(key) {
    const catalog = window.__glpiacessivelI18n && typeof window.__glpiacessivelI18n === 'object'
      ? window.__glpiacessivelI18n.messages
      : null;
    return Boolean(
      (catalog && typeof catalog[key] === 'string' && catalog[key] !== '')
      || (typeof DEFAULT_I18N[key] === 'string' && DEFAULT_I18N[key] !== '')
    );
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function portalButtonMarkup(srLabel) {
    return ''
      + '<svg class="glpiacessivel-portal-icon" viewBox="0 0 100 100" width="62" height="62" aria-hidden="true" focusable="false">'
      + '<path d="M20 34 A38 38 0 0 1 80 34" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<path d="M20 43 Q50 57 80 43" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<path d="M18 52 A38 38 0 0 0 33 81" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<path d="M82 52 A38 38 0 0 1 67 81" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<path d="M42 87 A20 20 0 0 0 58 87" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<path d="M50 57 L35 82" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<path d="M50 57 L65 82" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
      + '<circle cx="50" cy="33" r="10.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
      + '<circle cx="20" cy="43" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
      + '<circle cx="80" cy="43" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
      + '<circle cx="35" cy="82" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
      + '<circle cx="65" cy="82" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
      + '</svg>'
      + '<span class="glpiacessivel-sr-only">' + escapeHtml(srLabel || i18n('portal.open.sr')) + '</span>';
  }

  function chatbotButtonMarkup(srLabel) {
    return ''
      + '<svg class="glpiacessivel-chatbot-icon" viewBox="0 0 100 100" width="54" height="54" aria-hidden="true" focusable="false">'
      + '<path d="M18 28 C18 18, 26 12, 36 12 H64 C74 12, 82 18, 82 28 V54 C82 64, 74 72, 64 72 H45 L26 86 L30 72 H36 C26 72, 18 64, 18 54 Z" fill="#ffffff" stroke="#0a3f7a" stroke-width="5"></path>'
      + '<circle cx="38" cy="42" r="4.5" fill="#0a3f7a"></circle>'
      + '<circle cx="50" cy="42" r="4.5" fill="#0a3f7a"></circle>'
      + '<circle cx="62" cy="42" r="4.5" fill="#0a3f7a"></circle>'
      + '</svg>'
      + '<span class="glpiacessivel-sr-only">' + escapeHtml(srLabel || i18n('chatbot.open.sr')) + '</span>';
  }

  const VLIBRAS_SCRIPT_URL = 'https://vlibras.gov.br/app/vlibras-plugin.js';
  const VLIBRAS_APP_URL = 'https://vlibras.gov.br/app';
  const VLIBRAS_LOAD_TIMEOUT_MS = 8000;
  const VLIBRAS_RETRY_DELAY_MS = 1200;
  const VLIBRAS_RETRY_COOLDOWN_MS = 300000;
  const VLIBRAS_COOLDOWN_STORAGE_KEY = 'glpiacessivel-vlibras-retry-after';

  function vlibrasRuntimeConfig() {
    return window.__glpiacessivelRuntimeConfig && typeof window.__glpiacessivelRuntimeConfig === 'object'
      ? window.__glpiacessivelRuntimeConfig
      : {};
  }

  function updateVlibrasDiagnostics(status, detail) {
    const runtime = vlibrasRuntimeConfig();
    const previous = window.__glpiacessivelDiagnostics && window.__glpiacessivelDiagnostics.vlibras
      ? window.__glpiacessivelDiagnostics.vlibras
      : {};
    window.__glpiacessivelDiagnostics = window.__glpiacessivelDiagnostics || {};
    window.__glpiacessivelDiagnostics.vlibras = {
      enabled: shouldLoadVlibrasWidget(),
      scope: runtime.vlibrasScope || document.documentElement.getAttribute('data-glpiacessivel-vlibras') || '',
      src: VLIBRAS_SCRIPT_URL,
      status: status,
      reason: detail || '',
      startedAt: status === 'loading' ? new Date().toISOString() : (previous.startedAt || ''),
      endedAt: ['ready', 'timeout', 'error', 'unavailable', 'disabled', 'skipped-cooldown'].indexOf(status) !== -1
        ? new Date().toISOString()
        : '',
      timeoutMs: VLIBRAS_LOAD_TIMEOUT_MS,
      retryCooldownMs: VLIBRAS_RETRY_COOLDOWN_MS
    };
  }

  function vlibrasStatusRegion() {
    let region = document.getElementById('glpiacessivel-vlibras-status');
    if (region instanceof HTMLElement) {
      return region;
    }

    region = document.createElement('div');
    region.id = 'glpiacessivel-vlibras-status';
    region.className = 'glpiacessivel-sr-only sr-only';
    region.setAttribute('aria-live', 'polite');
    region.setAttribute('aria-atomic', 'true');
    document.body.appendChild(region);
    return region;
  }

  function announceVlibrasStatus(status) {
    const messages = {
      ready: i18n('vlibras.ready'),
      timeout: i18n('vlibras.unavailable'),
      error: i18n('vlibras.unavailable'),
      unavailable: i18n('vlibras.unavailable'),
      retrying: i18n('vlibras.retrying')
    };
    const message = messages[status];
    if (!message || window.__glpiacessivelVlibrasLastAnnouncement === message) {
      return;
    }

    window.__glpiacessivelVlibrasLastAnnouncement = message;
    vlibrasStatusRegion().textContent = message;
  }

  function setVlibrasStatus(status, detail) {
    updateVlibrasDiagnostics(status, detail);
    window.__glpiacessivelVlibrasStatus = {
      status: status,
      detail: detail || '',
      updatedAt: new Date().toISOString()
    };
    document.documentElement.setAttribute('data-glpiacessivel-vlibras-status', status);
    announceVlibrasStatus(status);
    try {
      window.dispatchEvent(new CustomEvent('glpiacessivel:vlibras-status', {
        detail: window.__glpiacessivelVlibrasStatus
      }));
    } catch (error) {
      // CustomEvent can be unavailable in older embedded browsers; status attributes remain available.
    }
  }

  function createVlibrasHost() {
    if (document.querySelector('[vw]')) {
      return;
    }

    const host = document.createElement('div');
    host.className = 'enabled';
    host.setAttribute('vw', '');
    host.dataset.glpiacessivelVlibrasHost = '1';
    host.innerHTML = ''
      + '<div vw-access-button class="active"></div>'
      + '<div vw-plugin-wrapper><div class="vw-plugin-top-wrapper"></div></div>';
    document.body.appendChild(host);
  }

  function removeVlibrasHostIfInactive() {
    if (window.__glpiacessivelVlibrasInitialized) {
      return;
    }

    document.querySelectorAll('[vw][data-glpiacessivel-vlibras-host="1"]').forEach(function (host) {
      if (host instanceof HTMLElement) {
        host.remove();
      }
    });
  }

  function initVlibrasWidget() {
    if (window.__glpiacessivelVlibrasInitialized) {
      return true;
    }

    if (!window.VLibras || typeof window.VLibras.Widget !== 'function') {
      return false;
    }

    if (isVlibrasWidgetFunctional()) {
      window.__glpiacessivelVlibrasInitialized = true;
      window.__glpiacessivelVlibrasLoading = false;
      setVlibrasStatus('ready');
      return true;
    }

    if (window.__glpiacessivelVlibrasInitializing) {
      return true;
    }

    createVlibrasHost();
    window.__glpiacessivelVlibrasInitializing = true;
    new window.VLibras.Widget(VLIBRAS_APP_URL);
    validateVlibrasWidgetReady(0);
    return true;
  }

  function isVlibrasWidgetFunctional() {
    return !!document.querySelector('[vw-access-button] img, [vp]');
  }

  function validateVlibrasWidgetReady(attempt) {
    if (isVlibrasWidgetFunctional()) {
      window.__glpiacessivelVlibrasInitialized = true;
      window.__glpiacessivelVlibrasInitializing = false;
      window.__glpiacessivelVlibrasLoading = false;
      setVlibrasStatus('ready');
      return;
    }

    if (
      attempt === 0
      && document.readyState === 'complete'
      && typeof window.onload === 'function'
      && !window.__glpiacessivelVlibrasForcedLoad
    ) {
      window.__glpiacessivelVlibrasForcedLoad = true;
      try {
        window.onload();
      } catch (error) {
        // The official widget uses window.onload internally; failures are reported by the validation below.
      }
    }

    if (attempt < 8) {
      window.setTimeout(function () {
        validateVlibrasWidgetReady(attempt + 1);
      }, 250);
      return;
    }

    window.__glpiacessivelVlibrasInitialized = false;
    window.__glpiacessivelVlibrasInitializing = false;
    window.__glpiacessivelVlibrasLoading = false;
    setVlibrasRetryCooldown();
    setVlibrasStatus('unavailable', 'vlibras-widget-dom');
    removeVlibrasHostIfInactive();
  }

  function vlibrasRetryAfter() {
    try {
      return Number(window.sessionStorage.getItem(VLIBRAS_COOLDOWN_STORAGE_KEY) || '0');
    } catch (error) {
      return 0;
    }
  }

  function setVlibrasRetryCooldown() {
    try {
      window.sessionStorage.setItem(VLIBRAS_COOLDOWN_STORAGE_KEY, String(Date.now() + VLIBRAS_RETRY_COOLDOWN_MS));
    } catch (error) {
      // sessionStorage can be blocked; cooldown is best-effort only.
    }
  }

  function clearVlibrasRetryCooldown() {
    try {
      window.sessionStorage.removeItem(VLIBRAS_COOLDOWN_STORAGE_KEY);
    } catch (error) {
      // sessionStorage can be blocked; retry still works without persisted cooldown.
    }
  }

  function clearVlibrasScript(script) {
    if (script && script.parentNode) {
      script.parentNode.removeChild(script);
    }
    window.__glpiacessivelVlibrasLoadBound = false;
    window.__glpiacessivelVlibrasLoading = false;
  }

  function bindVlibrasScript(script) {
    if (!(script instanceof HTMLScriptElement)) {
      return;
    }

    if (script.dataset.glpiacessivelVlibrasBound === '1') {
      return;
    }

    script.dataset.glpiacessivelVlibrasBound = '1';
    window.__glpiacessivelVlibrasLoadBound = true;
    window.__glpiacessivelVlibrasLoading = true;
    setVlibrasStatus('loading');

    const timeoutId = window.setTimeout(function () {
      if (window.__glpiacessivelVlibrasInitialized || isVlibrasWidgetFunctional()) {
        return;
      }
      script.dataset.glpiacessivelVlibrasExpired = '1';
      setVlibrasRetryCooldown();
      setVlibrasStatus('timeout', 'vlibras-plugin.js');
      removeVlibrasHostIfInactive();
      clearVlibrasScript(script);
    }, VLIBRAS_LOAD_TIMEOUT_MS);

    script.addEventListener('load', function () {
      window.clearTimeout(timeoutId);
      if (script.dataset.glpiacessivelVlibrasExpired === '1') {
        return;
      }
      if (!initVlibrasWidget()) {
        setVlibrasStatus('unavailable', 'VLibras.Widget');
        removeVlibrasHostIfInactive();
      }
      window.__glpiacessivelVlibrasLoading = false;
    }, { once: true });

    script.addEventListener('error', function () {
      window.clearTimeout(timeoutId);
      setVlibrasRetryCooldown();
      setVlibrasStatus('error', 'vlibras-plugin.js');
      removeVlibrasHostIfInactive();
      clearVlibrasScript(script);
    }, { once: true });
  }

  function ensureVlibrasWidget() {
    if (!shouldLoadVlibrasWidget()) {
      removeVlibrasHostIfInactive();
      setVlibrasStatus('disabled');
      return;
    }

    if (window.__glpiacessivelVlibrasInitialized) {
      setVlibrasStatus('ready');
      return;
    }

    const retryAfter = vlibrasRetryAfter();
    if (retryAfter > Date.now()) {
      setVlibrasStatus('skipped-cooldown', 'vlibras-plugin.js');
      return;
    }

    if (window.VLibras && typeof window.VLibras.Widget === 'function') {
      initVlibrasWidget();
      return;
    }

    if (window.__glpiacessivelVlibrasLoading) {
      return;
    }

    let existingScript = document.querySelector('script[src="' + VLIBRAS_SCRIPT_URL + '"]');
    if (existingScript instanceof HTMLScriptElement) {
      bindVlibrasScript(existingScript);
      return;
    }

    const script = document.createElement('script');
    script.src = VLIBRAS_SCRIPT_URL;
    script.async = true;
    script.dataset.glpiacessivelVlibras = '1';
    bindVlibrasScript(script);
    document.body.appendChild(script);
  }

  function pluginBasePath() {
    const sourceMarkers = [
      '/plugins/glpiacessivel/',
      '/marketplace/glpiacessivel/',
    ];
    const scripts = Array.from(document.scripts || []);
    const ownScript = scripts.find(function (script) {
      return script.src && sourceMarkers.some(function (marker) {
        return script.src.indexOf(marker) !== -1;
      });
    });

    if (!ownScript) {
      return '/plugins/glpiacessivel';
    }

    const url = new URL(ownScript.src, window.location.href);
    const marker = sourceMarkers.find(function (candidate) {
      return url.pathname.indexOf(candidate) !== -1;
    });
    if (!marker) {
      return '/plugins/glpiacessivel';
    }

    return url.pathname.slice(0, url.pathname.indexOf(marker)) + marker.slice(0, -1);
  }

  function loadRuntimeConfig() {
    if (window.__glpiacessivelRuntimeConfig && typeof window.__glpiacessivelRuntimeConfig === 'object') {
      window.__glpiacessivelRuntimeConfigLoaded = true;
      return Promise.resolve(window.__glpiacessivelRuntimeConfig);
    }

    if (window.__glpiacessivelRuntimeConfigLoaded) {
      return Promise.resolve(window.__glpiacessivelRuntimeConfig || {});
    }

    return new Promise(function (resolve) {
      const src = pluginBasePath() + '/front/runtime-config.js.php';
      const existing = document.querySelector('script[data-glpiacessivel-runtime-config], script[src*="/front/runtime-config.js.php"]');
      if (existing) {
        if (window.__glpiacessivelRuntimeConfigLoaded) {
          resolve(window.__glpiacessivelRuntimeConfig || {});
          return;
        }

        existing.addEventListener('load', function () {
          window.__glpiacessivelRuntimeConfigLoaded = true;
          resolve(window.__glpiacessivelRuntimeConfig || {});
        }, { once: true });
        existing.addEventListener('error', function () {
          resolve({});
        }, { once: true });
        return;
      }

      const script = document.createElement('script');
      script.src = src;
      script.async = false;
      script.defer = false;
      script.dataset.glpiacessivelRuntimeConfig = '1';
      script.onload = function () {
        window.__glpiacessivelRuntimeConfigLoaded = true;
        resolve(window.__glpiacessivelRuntimeConfig || {});
      };
      script.onerror = function () {
        resolve({});
      };
      document.head.appendChild(script);
    });
  }

  function portalModuleState(module) {
    const runtime = window.__glpiacessivelRuntimeConfig || {};
    const modules = runtime.portalModules && typeof runtime.portalModules === 'object'
      ? runtime.portalModules
      : {};
    const state = String(modules[module] || 'available');
    return ['available', 'hidden', 'disabled'].indexOf(state) !== -1 ? state : 'available';
  }

  function isPortalModuleVisible(module) {
    return portalModuleState(module) === 'available';
  }
  function isChatbotFloatingEnabled() {
    const runtime = window.__glpiacessivelRuntimeConfig || {};
    const scope = String(runtime.chatbotFloatingScope || '').trim();
    const isPluginPage = window.location.pathname.indexOf('/plugins/glpiacessivel/') !== -1;
    const isLogged = runtime.isLogged === true;
    const chatbotEnabled = runtime.chatbotEnabled !== false;

    if (!chatbotEnabled || !isPortalModuleVisible('chatbot')) {
      return false;
    }

    if (scope === 'disabled') {
      return false;
    }
    if (scope === 'plugin_only') {
      return isPluginPage;
    }
    if (scope === 'all_logged_pages') {
      return isLogged;
    }

    if (window.__glpiacessivelChatbotFloatingEnabled === false) {
      return false;
    }

    const attr = document.documentElement.getAttribute('data-glpiacessivel-chatbot-floating');
    return attr !== '0';
  }

  function accessibilityMode() {
    const runtime = window.__glpiacessivelRuntimeConfig || {};
    return String(runtime.accessibilityMode || 'hybrid').trim() || 'hybrid';
  }

  function portalButtonCopy() {
    if (accessibilityMode() === 'embedded') {
      return {
        label: i18n('portal.embedded.label'),
        srLabel: i18n('portal.embedded.sr'),
        title: i18n('portal.embedded.title')
      };
    }

    return {
      label: i18n('portal.open.label'),
      srLabel: i18n('portal.open.sr'),
      title: i18n('portal.open.title')
    };
  }

  function currentAccessibleTarget() {
    const path = window.location.pathname || '';
    const search = new URLSearchParams(window.location.search || '');
    const base = pluginBasePath();

    if (path.indexOf('/plugins/glpiacessivel/') !== -1) {
      return null;
    }

    if (path.indexOf('/front/ticket.form.php') !== -1) {
      const ticketId = String(search.get('id') || '').trim();
      if (ticketId) {
        return base + '/front/tickets.php?id=' + encodeURIComponent(ticketId);
      }

      return base + '/front/ticket.create.php';
    }

    if (path.indexOf('/front/ticket.php') !== -1) {
      const scope = String(search.get('scope') || '').trim();
      if (scope === 'mine') {
        return base + '/front/tickets.php?scope=mine';
      }

      return base + '/front/tickets.php';
    }

    if (path.indexOf('/front/knowbaseitem.form.php') !== -1) {
      const articleId = String(search.get('id') || '').trim();
      if (articleId) {
        return base + '/front/knowledge.php?article_id=' + encodeURIComponent(articleId);
      }

      return base + '/front/knowledge.php';
    }

    if (path.indexOf('/front/knowbaseitem.php') !== -1) {
      return base + '/front/knowledge.php';
    }

    if (path.indexOf('/front/login.php') !== -1 || path.indexOf('/index.php') !== -1) {
      return base + '/front/acessivel.php';
    }

    return base + '/front/acessivel.php';
  }

  function shouldShowPortalButton() {
    return true;
  }

  function shouldLoadVlibrasWidget() {
    const runtime = window.__glpiacessivelRuntimeConfig || {};
    if (typeof runtime.vlibrasEnabled === 'boolean') {
      return runtime.vlibrasEnabled;
    }

    const scope = String(runtime.vlibrasScope || '');
    const path = window.location.pathname || '';
    if (scope === 'disabled') {
      return false;
    }
    if (scope === 'all_pages') {
      return true;
    }
    if (scope === 'plugin_pages' && path.indexOf('/plugins/glpiacessivel/') !== -1) {
      return true;
    }

    return document.documentElement.getAttribute('data-glpiacessivel-vlibras') === '1';
  }

  function ensureFloatingButtonStyles() {
    if (document.getElementById('glpiacessivel-floating-button-fallback-styles')) {
      return;
    }

    const style = document.createElement('style');
    style.id = 'glpiacessivel-floating-button-fallback-styles';
    style.textContent = [
      '.glpiacessivel-portal-button,.glpiacessivel-chatbot-button{position:fixed!important;bottom:1.25rem!important;width:clamp(64px,10vw,92px)!important;height:clamp(64px,10vw,92px)!important;border-radius:999px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;padding:0!important;text-decoration:none!important;box-sizing:border-box!important;opacity:1!important;visibility:visible!important;overflow:visible!important;line-height:1!important;}',
      '.glpiacessivel-portal-button{right:1.25rem!important;z-index:100050!important;background:#fff!important;border:3px solid #111!important;color:#111!important;box-shadow:0 10px 28px rgba(16,32,51,.28)!important;}',
      '.glpiacessivel-chatbot-button{left:1.25rem!important;z-index:100049!important;background:#0f63c6!important;border:3px solid #fff!important;color:#fff!important;box-shadow:0 10px 28px rgba(16,32,51,.28)!important;}',
      '.glpiacessivel-portal-button svg,.glpiacessivel-chatbot-button svg{display:block!important;flex:0 0 auto!important;max-width:none!important;max-height:none!important;opacity:1!important;visibility:visible!important;overflow:visible!important;}',
      '.glpiacessivel-portal-icon{width:clamp(42px,6.8vw,62px)!important;height:clamp(42px,6.8vw,62px)!important;}',
      '.glpiacessivel-chatbot-icon{width:clamp(38px,6vw,54px)!important;height:clamp(38px,6vw,54px)!important;}',
      '.glpiacessivel-portal-button:focus-visible,.glpiacessivel-chatbot-button:focus-visible{outline:3px solid #fff!important;outline-offset:2px!important;box-shadow:0 0 0 6px #000!important;}'
    ].join('\n');
    document.head.appendChild(style);
  }

  function addLiveRegion() {
    if (document.getElementById('glpiacessivel-live-region')) {
      return document.getElementById('glpiacessivel-live-region');
    }

    const liveRegion = document.createElement('div');
    liveRegion.id = 'glpiacessivel-live-region';
    liveRegion.setAttribute('aria-live', 'polite');
    liveRegion.setAttribute('aria-atomic', 'true');
    liveRegion.className = 'sr-only';
    liveRegion.style.position = 'absolute';
    liveRegion.style.left = '-9999px';
    document.body.appendChild(liveRegion);
    return liveRegion;
  }

  function addPortalButton() {
    const path = window.location.pathname;
    if (path.indexOf('/plugins/glpiacessivel/') !== -1) {
      return;
    }

    if (!shouldShowPortalButton()) {
      const existing = document.getElementById('glpiacessivel-portal-button');
      if (existing) {
        existing.remove();
      }
      document.body.classList.remove('glpiacessivel-has-portal-button');
      return;
    }

    const targetUrl = currentAccessibleTarget();
    if (!targetUrl) {
      return;
    }

    const copy = portalButtonCopy();
    const existing = document.getElementById('glpiacessivel-portal-button');
    if (existing instanceof HTMLAnchorElement) {
      existing.href = targetUrl;
      existing.setAttribute('aria-label', copy.label);
      existing.setAttribute('aria-keyshortcuts', 'Alt+A');
      existing.removeAttribute('title');
      existing.innerHTML = portalButtonMarkup(copy.srLabel);
      document.body.classList.add('glpiacessivel-has-portal-button');
      return;
    }

    const link = document.createElement('a');
    link.id = 'glpiacessivel-portal-button';
    link.href = targetUrl;
    link.setAttribute('aria-label', copy.label);
    link.setAttribute('aria-keyshortcuts', 'Alt+A');
    link.removeAttribute('title');
    link.className = 'glpiacessivel-portal-button';
    link.innerHTML = portalButtonMarkup(copy.srLabel);
    document.body.appendChild(link);
    document.body.classList.add('glpiacessivel-has-portal-button');
  }

  function addChatbotButton() {
    if (!isChatbotFloatingEnabled()) {
      return;
    }

    const path = window.location.pathname;
    if (path.indexOf('/plugins/glpiacessivel/front/chatbot.php') !== -1) {
      return;
    }

    if (document.getElementById('glpiacessivel-chatbot-button')) {
      return;
    }

    const link = document.createElement('a');
    link.id = 'glpiacessivel-chatbot-button';
    link.href = pluginBasePath() + '/front/chatbot.php';
    link.setAttribute('aria-label', i18n('chatbot.open.label'));
    link.setAttribute('aria-keyshortcuts', 'Alt+V Control+Alt+Shift+V');
    link.removeAttribute('title');
    link.className = 'glpiacessivel-chatbot-button';
    link.innerHTML = chatbotButtonMarkup(i18n('chatbot.open.sr'));
    document.body.appendChild(link);
    document.body.classList.add('glpiacessivel-has-chatbot-button');
  }

  function bindSubmitAnnouncements(liveRegion) {
    document.addEventListener('submit', function (event) {
      if (event.defaultPrevented) {
        return;
      }

      const form = event.target;
      if (!(form instanceof HTMLFormElement)) {
        return;
      }

      liveRegion.textContent = i18n('status.processing');
    });
  }

  function bindAccessibilityShortcut(liveRegion) {
    if (window.__glpiacessivelShortcutAttached) {
      return;
    }

    document.addEventListener('keydown', function (event) {
      const target = event.target;
      const isEditable = target instanceof HTMLElement && (
        target.tagName === 'INPUT'
        || target.tagName === 'TEXTAREA'
        || target.tagName === 'SELECT'
        || target.isContentEditable
      );

      if (isEditable) {
        return;
      }

      const key = normalizeShortcutKey(event);
      const isLegacy = isLegacyShortcut(event) && key === 'a';
      const isPrimary = isPortalShortcut(event) && key === 'a' && window.location.pathname.indexOf('/plugins/glpiacessivel/') === -1;

      if (!isPrimary && !isLegacy) {
        return;
      }

      event.preventDefault();
      const button = document.getElementById('glpiacessivel-portal-button');
      const targetUrl = button instanceof HTMLAnchorElement
        ? button.href
        : (currentAccessibleTarget() || (pluginBasePath() + '/front/acessivel.php'));

      liveRegion.textContent = accessibilityMode() === 'portal'
        ? i18n('status.opening_accessible_journey')
        : i18n('status.opening_accessible_mode');
      if (button instanceof HTMLElement) {
        button.focus();
      }
      window.location.href = targetUrl;
    });

    window.__glpiacessivelShortcutAttached = true;
  }

  function bindChatbotShortcut(liveRegion) {
    if (window.__glpiacessivelChatbotShortcutAttached) {
      return;
    }

    document.addEventListener('keydown', function (event) {
      const target = event.target;
      const isEditable = target instanceof HTMLElement && (
        target.tagName === 'INPUT'
        || target.tagName === 'TEXTAREA'
        || target.tagName === 'SELECT'
        || target.isContentEditable
      );

      if (isEditable) {
        return;
      }

      const key = normalizeShortcutKey(event);
      const isPluginPage = window.location.pathname.indexOf('/plugins/glpiacessivel/') !== -1;
      const isLegacy = isLegacyShortcut(event) && key === 'c' && !isPluginPage;
      const isLegacyChatbot = isLegacyShortcut(event) && key === 'v';
      const isPrimary = isPortalShortcut(event) && key === 'v';
      if (!isPrimary && !isLegacy && !isLegacyChatbot) {
        return;
      }

      if (!isPortalModuleVisible('chatbot')) {
        return;
      }

      event.preventDefault();
      const button = document.getElementById('glpiacessivel-chatbot-button');
      const targetUrl = button instanceof HTMLAnchorElement
        ? button.href
        : (pluginBasePath() + '/front/chatbot.php');

      liveRegion.textContent = i18n('status.opening_chatbot');
      if (button instanceof HTMLElement) {
        button.focus();
      }
      window.location.href = targetUrl;
    });

    window.__glpiacessivelChatbotShortcutAttached = true;
  }

  function isPortalShortcut(event) {
    return event.altKey && !event.ctrlKey && !event.shiftKey && !event.metaKey;
  }

  function isLegacyShortcut(event) {
    return event.ctrlKey && event.altKey && event.shiftKey && !event.metaKey;
  }

  function normalizeShortcutKey(event) {
    const key = String(event.key || '').toLowerCase();
    const code = String(event.code || '').toLowerCase();
    if (key === '=' || key === 'add') {
      return '+';
    }
    if (key === '_' || key === 'subtract') {
      return '-';
    }
    if (key.length === 1) {
      return key;
    }
    if (code.startsWith('key') && code.length === 4) {
      return code.charAt(3);
    }
    if (code.startsWith('digit') && code.length === 6) {
      return code.charAt(5);
    }
    if (code === 'equal' || code === 'numpadadd') {
      return '+';
    }
    if (code === 'minus' || code === 'numpadsubtract') {
      return '-';
    }
    return key;
  }

  function isEditableShortcutTarget(target) {
    if (!(target instanceof HTMLElement)) {
      return false;
    }

    const tag = String(target.tagName || '').toLowerCase();
    return tag === 'input'
      || tag === 'textarea'
      || tag === 'select'
      || target.isContentEditable;
  }

  function focusShortcutTarget(selectors, liveRegion, message) {
    const target = selectors
      .map(function (selector) { return document.querySelector(selector); })
      .find(function (element) { return element instanceof HTMLElement; });

    if (!(target instanceof HTMLElement)) {
      return false;
    }

    if (!target.hasAttribute('tabindex')) {
      target.setAttribute('tabindex', '-1');
    }
    target.focus({ preventScroll: false });
    const reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    target.scrollIntoView({ block: 'start', behavior: reducedMotion ? 'auto' : 'smooth' });
    liveRegion.textContent = message;
    return true;
  }

  function setShortcutMetadata() {
    const metadata = [
      ['button[data-glpiacessivel-theme], [role="button"][data-glpiacessivel-theme]', 'Alt+T Control+Alt+Shift+T', i18n('shortcut.theme')],
      ['button[data-glpiacessivel-contrast], [role="button"][data-glpiacessivel-contrast]', 'Alt+C Control+Alt+Shift+K', i18n('shortcut.contrast')],
      ['[data-glpiacessivel-font="decrease"]', 'Alt+-', i18n('shortcut.font_decrease')],
      ['[data-glpiacessivel-font="reset"]', 'Alt+0', i18n('shortcut.font_reset')],
      ['[data-glpiacessivel-font="increase"]', 'Alt++', i18n('shortcut.font_increase')],
      ['button[data-glpiacessivel-help], [role="button"][data-glpiacessivel-help]', 'Alt+H Control+Alt+Shift+H', i18n('shortcut.help')]
    ];

    metadata.forEach(function (item) {
      const element = document.querySelector(item[0]);
      if (!(element instanceof HTMLElement)) {
        return;
      }
      element.setAttribute('aria-keyshortcuts', item[1]);
      element.removeAttribute('title');
    });

    const skipLinks = [
      ['a[href="#conteudo-principal"], a[href="#login-principal"], a[href="#faq-principal"]', 'Alt+1'],
      ['a[href="#glpiacessivel-menu"], a[href="#glpiacessivel-login-header"], a[href="#glpiacessivel-faq-header"]', 'Alt+2'],
      ['a[href="#glpiacessivel-search-anchor"], a[href="#glpiacessivel-login-form"], a[href="#faq-search-form"]', 'Alt+3']
    ];

    skipLinks.forEach(function (item) {
      document.querySelectorAll(item[0]).forEach(function (element) {
        if (element instanceof HTMLElement) {
          element.setAttribute('aria-keyshortcuts', item[1]);
        }
      });
    });
  }

  function goToPluginPage(path, liveRegion, message) {
    liveRegion.textContent = message;
    window.location.href = pluginBasePath() + path;
    return true;
  }

  function toggleTheme(liveRegion) {
    if (typeof window.glpiacessivelToggleTheme === 'function') {
      return window.glpiacessivelToggleTheme(liveRegion);
    }

    const button = document.querySelector('button[data-glpiacessivel-theme], [role="button"][data-glpiacessivel-theme]');
    if (!(button instanceof HTMLElement)) {
      return false;
    }

    button.click();
    button.focus();
    if (liveRegion) {
      liveRegion.textContent = i18n(
        button.getAttribute('aria-pressed') === 'true'
          ? 'status.theme_night_enabled'
          : 'status.theme_light_enabled'
      );
    }
    return true;
  }

  function toggleContrast(liveRegion) {
    if (typeof window.glpiacessivelToggleContrast === 'function') {
      return window.glpiacessivelToggleContrast(liveRegion);
    }

    const button = document.querySelector('button[data-glpiacessivel-contrast], [role="button"][data-glpiacessivel-contrast]');
    if (!(button instanceof HTMLElement)) {
      return false;
    }

    button.click();
    button.focus();
    if (liveRegion) {
      liveRegion.textContent = i18n(
        button.getAttribute('aria-pressed') === 'true'
          ? 'status.contrast_enabled'
          : 'status.contrast_disabled'
      );
    }
    return true;
  }

  function isHelpPanelOpen() {
    const helpButton = document.querySelector('button[data-glpiacessivel-help], [role="button"][data-glpiacessivel-help]');
    const helpPanel = document.getElementById('glpiacessivel-help-panel')
      || document.getElementById('glpiacessivel-login-help')
      || document.getElementById('glpiacessivel-faq-help');
    return helpButton instanceof HTMLElement
      && helpPanel instanceof HTMLElement
      && helpButton.getAttribute('aria-expanded') === 'true'
      && helpPanel.hidden === false;
  }

  function toggleHelpPanel(liveRegion) {
    if (typeof window.glpiacessivelToggleHelp === 'function') {
      return window.glpiacessivelToggleHelp(liveRegion);
    }

    const button = document.querySelector('button[data-glpiacessivel-help], [role="button"][data-glpiacessivel-help]');
    if (!(button instanceof HTMLElement)) {
      return false;
    }

    const panelId = button.getAttribute('aria-controls');
    const panel = panelId ? document.getElementById(panelId) : null;
    if (panel instanceof HTMLElement) {
      const isOpen = button.getAttribute('aria-expanded') === 'true' || !panel.hidden;
      const willOpen = !isOpen;
      button.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
      panel.hidden = !willOpen;
      if (willOpen) {
        const closeButton = panel.querySelector('[data-glpiacessivel-help-close]');
        if (closeButton instanceof HTMLElement) {
          closeButton.focus();
        } else {
          panel.focus();
        }
      } else {
        button.focus();
      }
      if (liveRegion) {
        liveRegion.textContent = willOpen ? i18n('status.help_opened') : i18n('status.help_closed');
      }
      return true;
    }

    button.click();
    return true;
  }
  function bindPageShortcuts(liveRegion) {
    if (window.__glpiacessivelPageShortcutsAttached) {
      return;
    }

    setShortcutMetadata();

    const hasPluginShortcutShell = document.querySelector('.glpiacessivel-toolbar, .glpiacessivel-login-topbar, [data-glpiacessivel-help], #glpiacessivel-help-panel');
    if (!(hasPluginShortcutShell instanceof HTMLElement)) {
      window.__glpiacessivelPageShortcutsAttached = true;
      return;
    }

    document.addEventListener('keydown', function (event) {
      const key = normalizeShortcutKey(event);
      const isPortalCombo = isPortalShortcut(event);
      const isThemeFallbackCombo = isLegacyShortcut(event) && key === 't';
      const isContrastFallbackCombo = isLegacyShortcut(event) && key === 'k';
      const isHelpFallbackCombo = isLegacyShortcut(event) && key === 'h';
      const isFallbackCombo = isThemeFallbackCombo || isContrastFallbackCombo || isHelpFallbackCombo;
      if (!isPortalCombo && !isFallbackCombo) {
        return;
      }

      const safeInFields = ['t', 'c', 'k', 'h', '+', '-', '0'];
      const actions = {
        '1': function () {
          return focusShortcutTarget(
            ['#conteudo-principal', '#login-principal', '#faq-principal'],
            liveRegion,
            i18n('status.focus_main')
          );
        },
        '2': function () {
          return focusShortcutTarget(
            ['#glpiacessivel-menu', '#glpiacessivel-login-header', '#glpiacessivel-faq-header'],
            liveRegion,
            i18n('status.focus_menu')
          );
        },
        '3': function () {
          return focusShortcutTarget(
            [
              '#q',
              '#faq-search-form input[name="q"]',
              '#glpiacessivel-login-form input[type="text"]',
              'input[type="search"]',
              'form[method="get"] input[type="text"]',
              '[role="search"] input',
              '#glpiacessivel-search-anchor',
              '#faq-search-form',
              '#glpiacessivel-login-form'
            ],
            liveRegion,
            i18n('status.focus_search')
          );
        },
        't': function () {
          return toggleTheme(liveRegion);
        },
        'c': function () {
          return toggleContrast(liveRegion);
        },
        'k': function () {
          return toggleContrast(liveRegion);
        },
        '-': function () {
          const button = document.querySelector('[data-glpiacessivel-font="decrease"]');
          if (button instanceof HTMLElement) {
            button.click();
            button.focus();
            return true;
          }
          return false;
        },
        '0': function () {
          const button = document.querySelector('[data-glpiacessivel-font="reset"]');
          if (button instanceof HTMLElement) {
            button.click();
            button.focus();
            return true;
          }
          return false;
        },
        '+': function () {
          const button = document.querySelector('[data-glpiacessivel-font="increase"]');
          if (button instanceof HTMLElement) {
            button.click();
            button.focus();
            return true;
          }
          return false;
        },
        'h': function () {
          return toggleHelpPanel(liveRegion);
        },
        'a': function () {
          return goToPluginPage('/front/acessivel.php', liveRegion, i18n('status.opening_accessible_journey'));
        },
        'p': function () {
          return isPortalModuleVisible('tickets')
            && goToPluginPage('/front/tickets.php?scope=mine', liveRegion, i18n('status.opening_my_tickets'));
        },
        'g': function () {
          return isPortalModuleVisible('tickets')
            && goToPluginPage('/front/tickets.php', liveRegion, i18n('status.opening_all_tickets'));
        },
        'n': function () {
          return isPortalModuleVisible('ticket_create')
            && goToPluginPage('/front/ticket.create.php', liveRegion, i18n('status.opening_new_ticket'));
        },
        'm': function () {
          return isPortalModuleVisible('forms')
            && goToPluginPage('/front/forms.php', liveRegion, i18n('status.opening_forms'));
        },
        'b': function () {
          return isPortalModuleVisible('knowledge')
            && goToPluginPage('/front/knowledge.php', liveRegion, i18n('status.opening_kb'));
        },
        'o': function () {
          return isPortalModuleVisible('cockpit')
            && goToPluginPage('/front/cockpit.php', liveRegion, i18n('status.opening_cockpit'));
        },
        'f': function () {
          return goToPluginPage('/front/faq.php', liveRegion, i18n('status.opening_public_faq'));
        }
      };

      if (!Object.prototype.hasOwnProperty.call(actions, key)) {
        return;
      }

      if (isHelpPanelOpen() && key !== 'h') {
        return;
      }

      if (key === 'k' && !isContrastFallbackCombo) {
        return;
      }

      if (isEditableShortcutTarget(event.target) && safeInFields.indexOf(key) === -1) {
        return;
      }

      const handled = actions[key]();
      if (!handled) {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === 'function') {
        event.stopImmediatePropagation();
      }
      const shortcutLabel = isFallbackCombo ? 'Ctrl+Alt+Shift+' : 'Alt+';
      liveRegion.textContent = i18n('status.shortcut_executed', { shortcut: shortcutLabel + key.toUpperCase() });
    }, true);

    window.__glpiacessivelPageShortcutsAttached = true;
  }

  function bindCriticalConfirmations(liveRegion) {
    if (window.__glpiacessivelCriticalConfirmationsAttached) {
      return;
    }

    const forms = Array.from(document.querySelectorAll('[data-glpiacessivel-critical-form]'));
    if (forms.length === 0) {
      return;
    }

    let dialog = document.getElementById('glpiacessivel-critical-confirmation-dialog');
    if (!(dialog instanceof HTMLElement)) {
      dialog = document.createElement('div');
      dialog.id = 'glpiacessivel-critical-confirmation-dialog';
      dialog.className = 'glpiacessivel-critical-confirmation';
      dialog.hidden = true;
      dialog.innerHTML = ''
        + '<div class="glpiacessivel-critical-confirmation-backdrop" data-critical-cancel></div>'
        + '<section class="glpiacessivel-critical-confirmation-panel" role="alertdialog" aria-modal="true" aria-labelledby="glpiacessivel-critical-confirmation-title" aria-describedby="glpiacessivel-critical-confirmation-description glpiacessivel-critical-confirmation-consequence" tabindex="-1">'
        + '<p class="glpiacessivel-eyebrow">' + escapeHtml(i18n('critical.required')) + '</p>'
        + '<h2 id="glpiacessivel-critical-confirmation-title">' + escapeHtml(i18n('critical.title')) + '</h2>'
        + '<p id="glpiacessivel-critical-confirmation-description"></p>'
        + '<p id="glpiacessivel-critical-confirmation-consequence" class="glpiacessivel-alert glpiacessivel-alert-warning"></p>'
        + '<div class="glpiacessivel-action-row">'
        + '<button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-critical-cancel>' + escapeHtml(i18n('button.cancel')) + '</button>'
        + '<button type="button" class="glpiacessivel-button glpiacessivel-button-danger" data-critical-confirm>' + escapeHtml(i18n('button.confirm_action')) + '</button>'
        + '</div>'
        + '</section>';
      document.body.appendChild(dialog);
    }

    const panel = dialog.querySelector('.glpiacessivel-critical-confirmation-panel');
    const title = dialog.querySelector('#glpiacessivel-critical-confirmation-title');
    const description = dialog.querySelector('#glpiacessivel-critical-confirmation-description');
    const consequence = dialog.querySelector('#glpiacessivel-critical-confirmation-consequence');
    const cancelButton = dialog.querySelector('button[data-critical-cancel]');
    const confirmButton = dialog.querySelector('[data-critical-confirm]');
    let pendingForm = null;
    let pendingSubmitter = null;
    let returnFocus = null;

    function focusableElements() {
      return Array.from(dialog.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'))
        .filter(function (element) { return element instanceof HTMLElement && !element.hidden && element.offsetParent !== null; });
    }

    function setDialogOpen(open) {
      dialog.hidden = !open;
      document.body.classList.toggle('glpiacessivel-has-critical-dialog', open);
      if (open) {
        if (cancelButton instanceof HTMLElement) {
          cancelButton.focus();
        } else if (panel instanceof HTMLElement) {
          panel.focus();
        }
      } else if (returnFocus instanceof HTMLElement) {
        returnFocus.focus();
      }
    }

    function closeDialog(message) {
      pendingForm = null;
      pendingSubmitter = null;
      setDialogOpen(false);
      if (message && liveRegion) {
        liveRegion.textContent = message;
      }
    }

    function showDialog(form, submitter) {
      pendingForm = form;
      pendingSubmitter = submitter;
      returnFocus = submitter instanceof HTMLElement ? submitter : document.activeElement;
      const submitterMessage = submitter instanceof HTMLElement ? String(submitter.dataset.criticalMessage || '').trim() : '';
      const formMessage = String(form.dataset.criticalMessage || '').trim();
      const message = submitterMessage || formMessage || i18n('critical.review');
      if (title) {
        title.textContent = String(form.dataset.criticalTitle || i18n('critical.title'));
      }
      if (description) {
        description.textContent = message;
      }
      if (consequence) {
        consequence.textContent = String(form.dataset.criticalConsequence || i18n('critical.consequence'));
      }
      setDialogOpen(true);
      if (liveRegion) {
        liveRegion.textContent = i18n('critical.opened');
      }
    }

    dialog.addEventListener('keydown', function (event) {
      if (dialog.hidden) {
        return;
      }
      if (event.key === 'Escape') {
        event.preventDefault();
        closeDialog(i18n('critical.cancelled'));
        return;
      }
      if (event.key !== 'Tab') {
        return;
      }
      const focusable = focusableElements();
      if (focusable.length === 0) {
        event.preventDefault();
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });

    dialog.querySelectorAll('[data-critical-cancel]').forEach(function (button) {
      button.addEventListener('click', function () {
        closeDialog(i18n('critical.cancelled'));
      });
    });

    if (confirmButton instanceof HTMLElement) {
      confirmButton.addEventListener('click', function () {
        if (!(pendingForm instanceof HTMLFormElement)) {
          closeDialog(i18n('critical.none_pending'));
          return;
        }
        const confirmedField = pendingForm.querySelector('input[name="critical_confirmed"]');
        const tokenField = pendingForm.querySelector('input[name="critical_confirmation_token"]');
        const submitterToken = pendingSubmitter instanceof HTMLElement ? String(pendingSubmitter.dataset.criticalConfirmationToken || '') : '';
        if (confirmedField instanceof HTMLInputElement) {
          confirmedField.value = '1';
        }
        if (tokenField instanceof HTMLInputElement && submitterToken !== '') {
          tokenField.value = submitterToken;
        }
        const form = pendingForm;
        const submitter = pendingSubmitter;
        setDialogOpen(false);
        if (liveRegion) {
          liveRegion.textContent = i18n('critical.confirmed');
        }
        if (submitter instanceof HTMLElement && typeof form.requestSubmit === 'function') {
          form.requestSubmit(submitter);
        } else if (typeof form.requestSubmit === 'function') {
          form.requestSubmit();
        } else {
          form.submit();
        }
      });
    }

    forms.forEach(function (form) {
      if (!(form instanceof HTMLFormElement)) {
        return;
      }
      form.addEventListener('click', function (event) {
        const target = event.target;
        if (target instanceof HTMLElement) {
          const submitter = target.closest('button[type="submit"], input[type="submit"]');
          if (submitter instanceof HTMLElement) {
            form.__glpiacessivelCriticalSubmitter = submitter;
          }
        }
      }, true);
      form.addEventListener('submit', function (event) {
        const confirmedField = form.querySelector('input[name="critical_confirmed"]');
        if (confirmedField instanceof HTMLInputElement && confirmedField.value === '1') {
          return;
        }
        event.preventDefault();
        const submitter = event.submitter instanceof HTMLElement
          ? event.submitter
          : (form.__glpiacessivelCriticalSubmitter instanceof HTMLElement ? form.__glpiacessivelCriticalSubmitter : null);
        showDialog(form, submitter);
      });
    });

    window.__glpiacessivelCriticalConfirmationsAttached = true;
  }

  function bindTicketSelection(liveRegion) {
    const checkboxes = Array.from(document.querySelectorAll('.glpiacessivel-ticket-select'));
    if (checkboxes.length === 0) {
      return;
    }

    const countNode = document.querySelector('[data-glpiacessivel-selected-count]');
    const copyButton = document.querySelector('[data-glpiacessivel-copy-selected]');

    function selectedIds() {
      return checkboxes
        .filter(function (checkbox) { return checkbox.checked; })
        .map(function (checkbox) { return String(checkbox.value || '').trim(); })
        .filter(Boolean);
    }

    function refresh() {
      const ids = selectedIds();
      if (countNode) {
        countNode.textContent = String(ids.length);
      }
      if (copyButton) {
        copyButton.disabled = ids.length === 0;
      }
    }

    checkboxes.forEach(function (checkbox) {
      checkbox.addEventListener('change', refresh);
    });

    if (copyButton) {
      copyButton.addEventListener('click', function () {
        const ids = selectedIds();
        if (ids.length === 0) {
          liveRegion.textContent = i18n('status.no_ticket_selected');
          return;
        }

        const text = ids.join(', ');
        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
          navigator.clipboard.writeText(text).then(function () {
            liveRegion.textContent = i18n('status.ticket_ids_copied');
          }).catch(function () {
            liveRegion.textContent = ids.length > 3
              ? i18n('status.ticket_count_selected', { count: ids.length })
              : i18n('status.ticket_ids_selected', { ids: text });
          });
          return;
        }

        liveRegion.textContent = ids.length > 3
          ? i18n('status.ticket_count_selected', { count: ids.length })
          : i18n('status.ticket_ids_selected', { ids: text });
      });
    }

    refresh();
  }

  function bindDynamicFormRenderer(liveRegion) {
    const form = document.querySelector('[data-glpiacessivel-dynamic-form-renderer]');
    const conditionsNode = document.getElementById('form-render-conditions-json');
    if (!(form instanceof HTMLFormElement)) {
      return;
    }
    if (form.dataset.glpiacessivelDynamicBound === '1') {
      return;
    }
    form.dataset.glpiacessivelDynamicBound = '1';

    let conditions = [];
    if (conditionsNode instanceof HTMLElement) {
      try {
        conditions = JSON.parse(conditionsNode.textContent || '[]');
      } catch (error) {
        conditions = [];
      }
    }
    conditions = conditions.filter(function (condition) {
      return condition
        && condition.supported === true
        && ['show', 'hide', 'require', 'disable'].indexOf(String(condition.effect || '')) !== -1
        && condition.expression
        && typeof condition.expression === 'object';
    });
    function bindNativeDelegatedSubmission() {
      if (form.dataset.glpiacessivelNativeSubmit !== '1' || form.dataset.glpiacessivelNativeSubmitBound === '1') {
        return;
      }
      form.dataset.glpiacessivelNativeSubmitBound = '1';

      const submitButton = form.querySelector('[data-glpiacessivel-native-submit-button]');
      const errorSummary = document.getElementById('form-render-error-summary');
      const submitStatus = document.getElementById('form-render-submit-status');
      const validateUrl = form.dataset.glpiacessivelValidateUrl || '';
      const conditionUrl = form.dataset.glpiacessivelConditionUrl || '';
      const formId = form.dataset.glpiacessivelFormId || '';

      function csrfToken() {
        if (typeof window.getAjaxCsrfToken === 'function') {
          return window.getAjaxCsrfToken();
        }
        const tokenInput = document.querySelector('input[name="_glpi_csrf_token"]');
        return tokenInput instanceof HTMLInputElement ? tokenInput.value : '';
      }

      function clearNativeErrors() {
        form.querySelectorAll('.glpiacessivel-field-error').forEach(function (node) { node.remove(); });
        form.querySelectorAll('[aria-invalid="true"]').forEach(function (control) {
          control.removeAttribute('aria-invalid');
          control.removeAttribute('aria-errormessage');
        });
        form.querySelectorAll('[aria-describedby]').forEach(function (control) {
          const describedBy = (control.getAttribute('aria-describedby') || '').split(/\s+/).filter(function (id) {
            return id && id.indexOf('form-render-error-') !== 0;
          });
          if (describedBy.length > 0) {
            control.setAttribute('aria-describedby', describedBy.join(' '));
          } else {
            control.removeAttribute('aria-describedby');
          }
        });
        if (errorSummary) {
          errorSummary.hidden = true;
          errorSummary.textContent = '';
        }
      }
      function escapeSelectorValue(value) {
        return window.CSS && typeof window.CSS.escape === 'function'
          ? window.CSS.escape(String(value))
          : String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
      }

      function controlsForNativeQuestion(questionId) {
        const safe = escapeSelectorValue(questionId);
        return Array.from(form.querySelectorAll('[name="answers_' + safe + '"], [name="answers_' + safe + '[]"]'));
      }

      function controlsForField(field) {
        const safe = escapeSelectorValue(field);
        const wrapper = form.querySelector('[data-field-name="' + safe + '"]');
        return wrapper instanceof HTMLElement ? Array.from(wrapper.querySelectorAll('input, select, textarea')) : [];
      }

      function normalizeNativeErrors(errors) {
        const source = Array.isArray(errors) ? errors : Object.entries(errors || {}).map(function (entry) {
          const value = entry[1];
          if (value && typeof value === 'object' && !Array.isArray(value)) {
            return Object.assign({ field: entry[0] }, value);
          }
          return { field: entry[0], message: value };
        });
        return source.map(function (error) {
          const item = error && typeof error === 'object' ? error : { message: error };
          const field = String(item.field || item.name || '');
          const questionMatch = String(item.question_id || field).match(/^answers_(\d+)/);
          return {
            field: field,
            code: String(item.code || item.error_code || item.type || 'validation_error'),
            message: String(item.message || item.detail || item.error || i18n('status.form_field_invalid')),
            question_id: item.question_id ? String(item.question_id) : (questionMatch ? questionMatch[1] : '')
          };
        }).filter(function (error) { return error.message !== ''; });
      }

      function showValidationErrors(errors) {
        clearNativeErrors();
        const normalized = normalizeNativeErrors(errors);
        if (normalized.length === 0) {
          return;
        }

        if (errorSummary) {
          const title = document.createElement('strong');
          title.textContent = i18n('status.form_validation_failed');
          const list = document.createElement('ul');
          normalized.forEach(function (error) {
            const item = document.createElement('li');
            const questionId = error.question_id;
            const controls = questionId !== '' ? controlsForNativeQuestion(questionId) : controlsForField(error.field);
            const target = controls.find(function (control) { return control instanceof HTMLElement && control.id !== ''; });
            if (target instanceof HTMLElement) {
              const link = document.createElement('a');
              link.href = '#' + target.id;
              link.textContent = error.message;
              item.appendChild(link);
            } else {
              item.textContent = error.message;
            }
            list.appendChild(item);
          });
          errorSummary.replaceChildren(title, list);
          errorSummary.hidden = false;
        }

        let firstControl = null;
        normalized.forEach(function (error, index) {
          const questionId = error.question_id;
          const field = error.field;
          const key = questionId || field || 'form';
          const controls = questionId !== '' ? controlsForNativeQuestion(questionId) : controlsForField(field);
          const selector = questionId !== ''
            ? '[data-native-question-id="' + escapeSelectorValue(questionId) + '"]'
            : '[data-field-name="' + escapeSelectorValue(field) + '"]';
          const wrapper = form.querySelector(selector);
          const errorId = 'form-render-error-' + escapeSelectorValue(key) + '-' + index;
          const message = document.createElement('p');
          message.id = errorId;
          message.className = 'glpiacessivel-field-error';
          message.textContent = error.message;
          if (wrapper instanceof HTMLElement) { wrapper.appendChild(message); }
          controls.forEach(function (control) {
            if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement) {
              control.setAttribute('aria-invalid', 'true');
              control.setAttribute('aria-errormessage', errorId);
              const describedBy = (control.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
              if (describedBy.indexOf(errorId) === -1) {
                describedBy.push(errorId);
                control.setAttribute('aria-describedby', describedBy.join(' '));
              }
              if (firstControl === null) { firstControl = control; }
            }
          });
        });

        if (errorSummary) { errorSummary.focus(); } else if (firstControl) { firstControl.focus(); }
      }


      async function postFormData(url, data) {
        const headers = { 'X-Requested-With': 'XMLHttpRequest' };
        const token = csrfToken();
        if (token !== '') {
          headers['X-Glpi-Csrf-Token'] = token;
        }
        const response = await fetch(url, {
          method: 'POST',
          body: data,
          credentials: 'same-origin',
          headers: headers
        });
        const contentType = String(response.headers.get('content-type') || '').toLowerCase();
        let payload = {};
        let isJson = contentType.indexOf('json') !== -1;
        if (isJson) {
          try {
            payload = await response.json();
          } catch (error) {
            isJson = false;
          }
        } else {
          await response.text();
        }
        if (!response.ok) {
          const failure = new Error(String(response.status));
          failure.payload = isJson ? payload : { message: i18n('status.form_submit_failed') };
          throw failure;
        }
        if (response.redirected && response.url !== '') {
          return { redirect: response.url };
        }
        if (!isJson) {
          const failure = new Error('unexpected_native_response');
          failure.payload = { message: i18n('status.form_unexpected_response') };
          throw failure;
        }
        return payload;
      }

      async function validateNativeAnswers() {
        if (validateUrl === '') {
          return true;
        }
        const payload = await postFormData(validateUrl, new FormData(form));
        if (payload && payload.success === false) {
          showValidationErrors(payload.errors || []);
          return false;
        }
        clearNativeErrors();
        return true;
      }

      function applyNativeVisibilityResult(payload) {
        if (!payload || typeof payload !== 'object') {
          return;
        }
        const activeElement = document.activeElement instanceof HTMLElement ? document.activeElement : null;
        const activeWrapper = activeElement ? activeElement.closest('[data-glpiacessivel-field-wrapper], [data-glpiacessivel-section-wrapper]') : null;
        let focusTarget = null;

        function focusableIn(wrapper) {
          if (!(wrapper instanceof HTMLElement) || wrapper.hidden) {
            return null;
          }
          const candidates = Array.from(wrapper.querySelectorAll('input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), [tabindex]:not([tabindex="-1"])'));
          return candidates.find(function (candidate) {
            return candidate instanceof HTMLElement && !candidate.hidden && candidate.offsetParent !== null;
          }) || null;
        }

        function rememberFocusBeforeHiding(wrapper, visible) {
          if (visible || !(activeWrapper instanceof HTMLElement) || activeWrapper !== wrapper || focusTarget !== null) {
            return;
          }
          const wrappers = Array.from(form.querySelectorAll('[data-glpiacessivel-field-wrapper], [data-glpiacessivel-section-wrapper]'));
          const currentIndex = wrappers.indexOf(wrapper);
          for (let index = currentIndex + 1; index < wrappers.length; index += 1) {
            const candidate = focusableIn(wrappers[index]);
            if (candidate !== null) {
              focusTarget = candidate;
              return;
            }
          }
          const heading = form.querySelector('h3, legend');
          if (heading instanceof HTMLElement) {
            heading.setAttribute('tabindex', '-1');
            focusTarget = heading;
          }
        }

        const questionVisibility = payload.questions_visibility || {};
        Object.keys(questionVisibility).forEach(function (questionId) {
          const wrapper = form.querySelector('[data-native-question-id="' + String(questionId).replace(/"/g, '\\"') + '"]');
          if (!(wrapper instanceof HTMLElement)) {
            return;
          }
          const visible = Boolean(questionVisibility[questionId]);
          rememberFocusBeforeHiding(wrapper, visible);
          wrapper.hidden = !visible;
          wrapper.setAttribute('aria-hidden', visible ? 'false' : 'true');
          wrapper.querySelectorAll('input, select, textarea').forEach(function (control) {
            if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement) {
              control.disabled = !visible || control.closest('[data-original-disabled="1"]') !== null;
            }
          });
        });

        const sectionVisibility = payload.sections_visibility || {};
        Object.keys(sectionVisibility).forEach(function (sectionId) {
          const wrapper = form.querySelector('[data-native-section-id="' + String(sectionId).replace(/"/g, '\\"') + '"]');
          if (!(wrapper instanceof HTMLElement)) {
            return;
          }
          const visible = Boolean(sectionVisibility[sectionId]);
          rememberFocusBeforeHiding(wrapper, visible);
          wrapper.hidden = !visible;
          wrapper.setAttribute('aria-hidden', visible ? 'false' : 'true');
        });
        if (focusTarget instanceof HTMLElement) {
          focusTarget.focus({ preventScroll: false });
          if (liveRegion) {
            liveRegion.textContent = i18n('status.dynamic_form_updated');
          }
        }
      }

      function applyQuestionBooleanMap(map, attribute) {
        Object.keys(map || {}).forEach(function (questionId) {
          const wrapper = form.querySelector('[data-native-question-id="' + escapeSelectorValue(questionId) + '"]');
          if (!(wrapper instanceof HTMLElement)) {
            return;
          }
          const enabled = Boolean(map[questionId]);
          wrapper.querySelectorAll('input, select, textarea').forEach(function (control) {
            if (!(control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement)) {
              return;
            }
            if (attribute === 'required') {
              control.required = enabled;
              control.setAttribute('aria-required', enabled ? 'true' : 'false');
            } else {
              control.disabled = enabled || wrapper.hidden || control.closest('[data-original-disabled="1"]') !== null;
            }
          });
          if (attribute === 'required') {
            wrapper.setAttribute('data-dynamic-required', enabled ? '1' : '0');
            const choiceGroup = wrapper.querySelector('fieldset.glpiacessivel-dynamic-renderer-choice');
            if (choiceGroup instanceof HTMLElement) {
              choiceGroup.setAttribute('aria-required', enabled ? 'true' : 'false');
            }
          }
        });
      }

      function applyNativeBooleanMaps(payload) {
        applyQuestionBooleanMap(payload.questions_required || payload.questions_mandatory || {}, 'required');
        applyQuestionBooleanMap(payload.questions_disabled || {}, 'disabled');
      }
      function buildConditionEnginePayload() {
        const output = new FormData();
        output.append('form_id', formId);
        const data = new FormData(form);
        for (const entry of data.entries()) {
          const key = String(entry[0]);
          const value = entry[1];
          const match = /^answers_(\d+)(\[\])?$/.exec(key);
          if (!match) {
            continue;
          }
          const outputKey = match[2] ? 'answers[' + match[1] + '][]' : 'answers[' + match[1] + ']';
          output.append(outputKey, value);
        }
        return output;
      }

      async function computeNativeVisibility() {
        if (conditionUrl === '' || formId === '') {
          return null;
        }
        try {
          const payload = await postFormData(conditionUrl, buildConditionEnginePayload());
          applyNativeVisibilityResult(payload);
          applyNativeBooleanMaps(payload);
          if (submitButton instanceof HTMLButtonElement) {
            submitButton.disabled = false;
            submitButton.removeAttribute('aria-disabled');
          }
          return payload;
        } catch (error) {
          if (liveRegion) {
            liveRegion.textContent = i18n('status.dynamic_form_visibility_failed');
          }
          if (submitButton instanceof HTMLButtonElement) {
            submitButton.disabled = true;
            submitButton.setAttribute('aria-disabled', 'true');
          }
          if (submitStatus) {
            submitStatus.hidden = false;
            submitStatus.textContent = i18n('status.dynamic_form_visibility_failed');
          }
          return null;
        }
      }

      form.addEventListener('input', function () { computeNativeVisibility(); });
      form.addEventListener('change', function () { computeNativeVisibility(); });
      computeNativeVisibility();

      form.addEventListener('submit', async function (event) {
        event.preventDefault();
        clearNativeErrors();
        if (submitStatus) {
          submitStatus.hidden = true;
          submitStatus.textContent = '';
        }
        if (submitButton instanceof HTMLButtonElement) {
          submitButton.disabled = true;
          submitButton.setAttribute('aria-busy', 'true');
        }
        try {
          await computeNativeVisibility();
          const valid = await validateNativeAnswers();
          if (!valid) {
            return;
          }
          const payload = await postFormData(form.action, new FormData(form));
          if (payload && typeof payload.redirect === 'string' && payload.redirect !== '') {
            window.location.assign(payload.redirect);
            return;
          }
          if (submitStatus) {
            const links = Array.isArray(payload.links_to_created_items) ? payload.links_to_created_items : [];
            submitStatus.textContent = links.length > 0
              ? i18n('status.form_submitted_with_links', { links: links.join(', ') })
              : i18n('status.form_submitted');
            submitStatus.hidden = false;
            submitStatus.focus();
          }
          if (liveRegion) {
            liveRegion.textContent = i18n('status.form_submitted');
          }
          form.querySelectorAll('input, select, textarea, button').forEach(function (control) {
            if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement || control instanceof HTMLButtonElement) {
              control.disabled = true;
            }
          });
        } catch (error) {
          const payload = error && error.payload ? error.payload : {};
          if (payload && payload.errors) {
            showValidationErrors(payload.errors);
          } else if (errorSummary) {
            errorSummary.textContent = payload && payload.message ? String(payload.message) : i18n('status.form_submit_failed');
            errorSummary.hidden = false;
            errorSummary.focus();
          }
        } finally {
          if (submitButton instanceof HTMLButtonElement && submitStatus && submitStatus.hidden) {
            submitButton.disabled = false;
            submitButton.removeAttribute('aria-busy');
          }
        }
      });
    }

    bindNativeDelegatedSubmission();

    if (conditions.length === 0) {
      return;
    }

    const status = document.getElementById('form-render-condition-status') || liveRegion;

    function escapeSelectorValue(value) {
      if (window.CSS && typeof window.CSS.escape === 'function') {
        return window.CSS.escape(String(value));
      }
      return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    }

    function fieldWrapper(name) {
      return form.querySelector('[data-glpiacessivel-field-wrapper][data-field-name="' + escapeSelectorValue(name) + '"]');
    }

    function sectionWrapper(id) {
      return form.querySelector('[data-glpiacessivel-section-wrapper][data-section-id="' + escapeSelectorValue(id) + '"]');
    }

    function targetWrapper(condition) {
      const expression = condition.expression || {};
      const targetType = String(expression.target_type || condition.target_type || 'field');
      if (targetType === 'section') {
        return sectionWrapper(condition.target_field);
      }
      return fieldWrapper(condition.target_field);
    }

    function controlsFor(name) {
      const safe = escapeSelectorValue(name);
      return Array.from(form.querySelectorAll('[name="' + safe + '"], [name="' + safe + '[]"]'));
    }

    function fieldValue(name) {
      const controls = controlsFor(name);
      const values = [];
      controls.forEach(function (control) {
        if (!(control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement)) {
          return;
        }
        if ((control.type === 'checkbox' || control.type === 'radio') && !control.checked) {
          return;
        }
        if (control instanceof HTMLSelectElement && control.multiple) {
          Array.from(control.selectedOptions).forEach(function (option) { values.push(String(option.value)); });
          return;
        }
        values.push(String(control.value || ''));
      });
      return values;
    }

    function comparisonMatches(expression) {
      const values = fieldValue(expression.field);
      const expected = expression.values && expression.values.length ? expression.values.map(String) : [String(expression.value ?? '')];
      const operator = String(expression.operator || 'equals');
      const hasValue = values.some(function (value) { return value !== ''; });
      if (operator === 'empty') {
        return !hasValue;
      }
      if (operator === 'not_empty') {
        return hasValue;
      }
      if (operator === 'equals') {
        return values.some(function (value) { return value === expected[0]; });
      }
      if (operator === 'not_equals') {
        return values.every(function (value) { return value !== expected[0]; });
      }
      if (operator === 'contains') {
        return values.some(function (value) { return value.indexOf(expected[0]) !== -1; });
      }
      if (operator === 'in') {
        return values.some(function (value) { return expected.indexOf(value) !== -1; });
      }
      if (operator === 'not_in') {
        return values.every(function (value) { return expected.indexOf(value) === -1; });
      }
      return false;
    }

    function expressionMatches(expression) {
      if (!expression || typeof expression !== 'object') {
        return false;
      }
      if (Array.isArray(expression.all)) {
        return expression.all.every(expressionMatches);
      }
      if (Array.isArray(expression.any)) {
        return expression.any.some(expressionMatches);
      }
      if (expression.not && typeof expression.not === 'object') {
        return !expressionMatches(expression.not);
      }
      if (String(expression.field || '') !== '') {
        return comparisonMatches(expression);
      }
      return false;
    }

    function collectExpressionFields(expression, output) {
      if (!expression || typeof expression !== 'object') {
        return;
      }
      if (String(expression.field || '') !== '') {
        output.add(String(expression.field));
      }
      ['all', 'any'].forEach(function (key) {
        if (Array.isArray(expression[key])) {
          expression[key].forEach(function (child) { collectExpressionFields(child, output); });
        }
      });
      if (expression.not && typeof expression.not === 'object') {
        collectExpressionFields(expression.not, output);
      }
    }

    function controlsInWrapper(wrapper) {
      return Array.from(wrapper.querySelectorAll('input, select, textarea'));
    }

    function setRequired(wrapper, required) {
      wrapper.dataset.dynamicRequired = required ? '1' : '0';
      controlsFor(wrapper.dataset.fieldName || '').forEach(function (control) {
        if (!(control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement)) {
          return;
        }
        control.required = required;
        control.setAttribute('aria-required', required ? 'true' : 'false');
      });
      const label = wrapper.querySelector('label, legend');
      if (label instanceof HTMLElement) {
        const base = label.dataset.baseLabel || label.textContent || '';
        label.dataset.baseLabel = base.replace(/\s\*$/, '');
        label.textContent = label.dataset.baseLabel + (required ? ' *' : '');
      }
    }

    function setDisabled(wrapper, disabled) {
      const controls = wrapper.dataset.fieldName ? controlsFor(wrapper.dataset.fieldName || '') : controlsInWrapper(wrapper);
      controls.forEach(function (control) {
        if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement) {
          const originalDisabled = control.closest('[data-original-disabled="1"]') !== null;
          control.disabled = disabled || originalDisabled;
        }
      });
      wrapper.classList.toggle('glpiacessivel-dynamic-disabled', disabled);
    }

    function setVisible(wrapper, visible) {
      const activeElement = document.activeElement instanceof HTMLElement ? document.activeElement : null;
      const moveFocus = !visible && activeElement !== null && wrapper.contains(activeElement);
      wrapper.hidden = !visible;
      wrapper.setAttribute('aria-hidden', visible ? 'false' : 'true');
      const controls = wrapper.dataset.fieldName ? controlsFor(wrapper.dataset.fieldName || '') : controlsInWrapper(wrapper);
      controls.forEach(function (control) {
        if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement) {
          const originalDisabled = control.closest('[data-original-disabled="1"]') !== null;
          control.disabled = !visible || wrapper.dataset.dynamicDisabled === '1' || originalDisabled;
          if (!visible) {
            control.required = false;
            control.setAttribute('aria-required', 'false');
            control.removeAttribute('aria-invalid');
            control.removeAttribute('aria-errormessage');
          } else {
            const required = wrapper.dataset.dynamicRequired === '1' || wrapper.dataset.originalRequired === '1';
            control.required = required;
            control.setAttribute('aria-required', required ? 'true' : 'false');
          }
        }
      });

      if (moveFocus) {
        const wrappers = Array.from(form.querySelectorAll('[data-glpiacessivel-field-wrapper], [data-glpiacessivel-section-wrapper]'));
        const currentIndex = wrappers.indexOf(wrapper);
        let nextControl = null;
        for (let index = currentIndex + 1; index < wrappers.length; index += 1) {
          if (wrappers[index] instanceof HTMLElement && !wrappers[index].hidden) {
            nextControl = wrappers[index].querySelector('input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled])');
            if (nextControl instanceof HTMLElement) {
              break;
            }
          }
        }
        if (!(nextControl instanceof HTMLElement)) {
          nextControl = form.querySelector('h3, legend');
        }
        if (nextControl instanceof HTMLElement) {
          nextControl.setAttribute('tabindex', '-1');
          nextControl.focus({ preventScroll: false });
          if (status) {
            status.textContent = i18n('status.dynamic_form_updated');
          }
        }
      }
    }

    function applyConditions() {
      let changed = 0;
      conditions.forEach(function (condition) {
        const wrapper = targetWrapper(condition);
        if (!(wrapper instanceof HTMLElement)) {
          return;
        }
        const matches = expressionMatches(condition.expression || {});
        const effect = String(condition.effect || '');
        if (effect === 'show') {
          setVisible(wrapper, matches);
          changed += 1;
        } else if (effect === 'hide') {
          setVisible(wrapper, !matches);
          changed += 1;
        } else if (effect === 'require' && wrapper.dataset.fieldName) {
          setRequired(wrapper, matches || wrapper.dataset.originalRequired === '1');
          changed += 1;
        } else if (effect === 'disable') {
          wrapper.dataset.dynamicDisabled = matches ? '1' : '0';
          setDisabled(wrapper, matches);
          changed += 1;
        }
      });
      if (changed > 0 && status) {
        status.textContent = i18n('status.dynamic_form_updated');
      }
    }

    const sourceFieldSet = new Set();
    conditions.forEach(function (condition) {
      collectExpressionFields(condition.expression || {}, sourceFieldSet);
    });
    Array.from(sourceFieldSet).forEach(function (name) {
      controlsFor(name).forEach(function (control) {
        control.addEventListener('change', applyConditions);
        control.addEventListener('input', applyConditions);
      });
    });
    applyConditions();
  }

  function bindNativeEmbeddedForms() {
    document.querySelectorAll('[data-glpiacessivel-native-frame]').forEach(function (frame) {
      if (!(frame instanceof HTMLIFrameElement) || frame.dataset.glpiacessivelNativeFrameBound === '1') {
        return;
      }
      frame.dataset.glpiacessivelNativeFrameBound = '1';
      const status = document.getElementById('form-render-native-frame-status');
      const embed = frame.closest('[data-glpiacessivel-native-embed]');
      const fallbackLink = document.querySelector('[data-glpiacessivel-native-full-link]');
      const retryButton = embed && embed.querySelector('[data-glpiacessivel-native-retry]');
      const focusControl = embed && embed.querySelector('[data-glpiacessivel-focus-native-frame]');
      const expectedParentPath = String(frame.dataset.glpiacessivelExpectedParentPath || '');
      const expectedChildPath = String(frame.dataset.glpiacessivelExpectedChildPath || '');
      const expectedSubmitPath = String(frame.dataset.glpiacessivelExpectedSubmitPath || '');
      const expectedFormId = String(frame.dataset.glpiacessivelExpectedFormId || '');
      const source = String(frame.dataset.glpiacessivelNativeSource || '');
      const minimalRequested = frame.dataset.glpiacessivelMinimalRequested === '1';
      const minimalGateEnabled = frame.dataset.glpiacessivelMinimalGateEnabled === '1';
      const minimalProfile = String(frame.dataset.glpiacessivelMinimalProfile || '');
      const glpiVersion = String(frame.dataset.glpiacessivelGlpiVersion || '');
      const formcreatorVersion = String(frame.dataset.glpiacessivelFormcreatorVersion || '');
      let verifiedNativeForm = false;
      let inspectedDocument = null;
      let inspectionInProgress = false;
      let timeoutId = null;
      let attempt = 1;
      let terminalAttempt = 0;
      let retryWasUsed = false;
      let stateSignature = status instanceof HTMLElement
        ? 'loading|' + status.textContent.trim()
        : '';

      function cancelFrameTimeout() {
        if (timeoutId !== null) {
          window.clearTimeout(timeoutId);
          timeoutId = null;
        }
      }

      function setBusy(busy) {
        if (embed instanceof HTMLElement) {
          embed.setAttribute('aria-busy', busy ? 'true' : 'false');
        }
      }

      function publishState(state, messageKey, options) {
        const settings = Object.assign({ busy: false, failed: false, retryable: false }, options || {});
        const message = i18n(messageKey);
        const signature = state + '|' + message;
        if (status instanceof HTMLElement) {
          status.dataset.glpiacessivelNativeState = state;
          status.classList.toggle('glpiacessivel-alert', settings.failed);
          status.classList.toggle('glpiacessivel-alert-warning', settings.failed);
          if (signature !== stateSignature) {
            status.textContent = message;
            stateSignature = signature;
          }
        }
        setBusy(settings.busy);
        if (retryButton instanceof HTMLButtonElement) {
          retryButton.hidden = !(settings.retryable || (retryWasUsed && state === 'ready'));
          retryButton.disabled = settings.busy;
        }
        if (fallbackLink instanceof HTMLElement) {
          fallbackLink.toggleAttribute('data-glpiacessivel-native-fallback-active', settings.failed);
        }
      }

      function showFailure(messageKey, expectedAttempt) {
        if (expectedAttempt !== undefined && expectedAttempt !== attempt) {
          return;
        }
        cancelFrameTimeout();
        terminalAttempt = attempt;
        removeEmbeddedPresentation();
        publishState('failed', messageKey, { failed: true, retryable: true });
      }

      function removeEmbeddedPresentation() {
        try {
          const childBody = frame.contentDocument && frame.contentDocument.body;
          if (childBody) {
            childBody.classList.remove(
              'glpiacessivel-native-embedded-page',
              'glpiacessivel-formcreator-embedded-minimal'
            );
          }
        } catch (error) {
          return;
        }
      }

      function isLoginDocument(childUrl, childDocument) {
        return /\/front\/login\.php$/i.test(childUrl.pathname)
          || Boolean(childDocument.querySelector('form[name="login_form"], input[name="login_name"], #login_name'));
      }

      function findUsableFormcreatorForm(childDocument) {
        const candidates = Array.from(childDocument.querySelectorAll('form')).filter(function (candidate) {
          const submit = candidate.querySelector('button[type="submit"], input[type="submit"], button[name="add"]');
          const idField = candidate.querySelector('input[name="plugin_formcreator_forms_id"]');
          return Boolean(submit) && Boolean(idField) && idField.value === expectedFormId;
        });
        return candidates.length === 1 ? candidates[0] : null;
      }

      function findExpectedFormcreatorForm(childDocument, childUrl) {
        const matches = Array.from(childDocument.querySelectorAll(
          'form#plugin_formcreator_form.plugin_formcreator_form[role="form"]'
        )).filter(function (candidate) {
          const idFields = candidate.querySelectorAll('input[name="plugin_formcreator_forms_id"]');
          const csrfFields = candidate.querySelectorAll('input[name="_glpi_csrf_token"]');
          const idField = idFields.length === 1 ? idFields[0] : null;
          const csrfField = csrfFields.length === 1 ? csrfFields[0] : null;
          const submits = candidate.querySelectorAll(
            'button[type="submit"], input[type="submit"], button[name="add"]'
          );
          const rawAction = candidate.getAttribute('action');
          let effectiveAction;
          try {
            effectiveAction = new URL(candidate.action || childUrl.href, childUrl.href);
          } catch (error) {
            return false;
          }
          return String(candidate.getAttribute('method') || '').toLowerCase() === 'post'
            && (rawAction === null || rawAction.trim() === '')
            && effectiveAction.origin === window.location.origin
            && effectiveAction.pathname === expectedChildPath
            && idField && idField.tagName === 'INPUT'
            && idField.type === 'hidden'
            && idField.value === expectedFormId
            && csrfField && csrfField.tagName === 'INPUT'
            && csrfField.type === 'hidden'
            && csrfField.value.trim() !== ''
            && submits.length === 1;
        });
        return matches.length === 1 ? matches[0] : null;
      }

      function hasExpectedNativeFormIdentity(childUrl) {
        if (!/^\d+$/.test(expectedFormId) || childUrl.pathname !== expectedChildPath) {
          return false;
        }
        if (source === 'formcreator_glpi10') {
          return childUrl.searchParams.get('id') === expectedFormId;
        }
        if (source === 'glpi11_service_catalog') {
          return childUrl.pathname.endsWith('/Form/Render/' + expectedFormId);
        }
        return false;
      }

      function findExpectedGlpi11Form(childDocument, childUrl) {
        if (source !== 'glpi11_service_catalog' || expectedSubmitPath === '') {
          return null;
        }
        const matches = Array.from(childDocument.querySelectorAll(
          'form#forms_form_answers[data-glpi-form-render-layout]'
        )).filter(function (candidate) {
          const idFields = candidate.querySelectorAll('input[type="hidden"][name="forms_id"]');
          const idField = idFields.length === 1 ? idFields[0] : null;
          const answerFields = candidate.querySelectorAll(
            'input[name^="answers_"], select[name^="answers_"], textarea[name^="answers_"]'
          );
          const rawAction = candidate.getAttribute('action');
          let effectiveAction;
          try {
            effectiveAction = new URL(candidate.action || childUrl.href, childUrl.href);
          } catch (error) {
            return false;
          }
          return String(candidate.getAttribute('method') || '').toLowerCase() === 'post'
            && rawAction !== null
            && rawAction.trim() !== ''
            && effectiveAction.origin === window.location.origin
            && effectiveAction.pathname === expectedSubmitPath
            && idField
            && idField.value === expectedFormId
            && answerFields.length > 0;
        });
        return matches.length === 1 ? matches[0] : null;
      }

      function resolveExpectedNativeForm(childDocument, childUrl) {
        if (source === 'glpi11_service_catalog') {
          return {
            form: findExpectedGlpi11Form(childDocument, childUrl),
            minimalCandidate: null
          };
        }
        if (source === 'formcreator_glpi10') {
          const strictForm = findExpectedFormcreatorForm(childDocument, childUrl);
          return {
            form: strictForm || findUsableFormcreatorForm(childDocument),
            minimalCandidate: strictForm
          };
        }
        return { form: null, minimalCandidate: null };
      }

      function hasRecognizedFormcreatorStructure(childDocument, expectedForm) {
        const body = childDocument.body;
        const pages = childDocument.querySelectorAll('body > .page');
        const pageWrappers = childDocument.querySelectorAll('body > .page > .page-wrapper.mb-0');
        const pageBodies = childDocument.querySelectorAll(
          'body > .page > .page-wrapper.mb-0 > .page-body.container-fluid'
        );
        const headers = childDocument.querySelectorAll(
          'body > .page > header.navbar.d-print-none.sticky-lg-top.shadow-sm.navbar-light.navbar-expand-md'
        );
        const sidebars = childDocument.querySelectorAll(
          'body > .page > aside.navbar.navbar-vertical.navbar-expand-lg.sticky-lg-top.sidebar'
        );
        const mainContents = childDocument.querySelectorAll(
          'body > .page > .page-wrapper.mb-0 > .page-body.container-fluid > main#page.legacy[role="main"]'
        );
        const childWindow = childDocument.defaultView;
        const asset = expectedForm.parentElement;
        const sidebarMenu = sidebars.length === 1
          ? sidebars[0].querySelectorAll('#navbar-menu.collapse.navbar-collapse')
          : [];
        return body.classList.contains('vertical-layout')
          && !body.classList.contains('horizontal-layout')
          && pages.length === 1
          && pageWrappers.length === 1
          && pageBodies.length === 1
          && headers.length === 1
          && sidebars.length === 1
          && sidebarMenu.length === 1
          && mainContents.length === 1
          && childWindow
          && asset instanceof childWindow.HTMLElement
          && asset.classList.contains('asset')
          && asset.parentElement === mainContents[0]
          && mainContents[0].contains(expectedForm)
          && !headers[0].contains(expectedForm)
          && !sidebars[0].contains(expectedForm);
      }

      function mayApplyMinimalPresentation(childDocument, childUrl, expectedForm) {
        if (!minimalRequested || !minimalGateEnabled) {
          return false;
        }
        if (minimalProfile !== 'formcreator-glpi10-2.13-vertical-dom-v2') {
          return false;
        }
        if (!/^10\.\d+\.\d+(?:[-+].*)?$/.test(glpiVersion)
          || !/^2\.13\.\d+(?:[-+].*)?$/.test(formcreatorVersion)) {
          return false;
        }
        if (window.location.pathname !== expectedParentPath) {
          return false;
        }
        if (source !== 'formcreator_glpi10') {
          return false;
        }
        if (!/(?:^|\/)(?:plugins|marketplace)\/formcreator\/front\/formdisplay\.php$/i.test(childUrl.pathname)) {
          return false;
        }
        if (childUrl.searchParams.get('glpiacessivel_native_embed') !== '1') {
          return false;
        }
        return hasRecognizedFormcreatorStructure(childDocument, expectedForm);
      }

      function scheduleTimeout(expectedAttempt) {
        cancelFrameTimeout();
        timeoutId = window.setTimeout(function () {
          showFailure('status.native_form_timeout', expectedAttempt);
        }, 8000);
      }

      function inspectFrame() {
        if (inspectionInProgress || terminalAttempt === attempt) {
          return;
        }
        try {
          const childDocument = frame.contentDocument;
          const childLocation = frame.contentWindow && frame.contentWindow.location;
          if (!childDocument || !childDocument.body || !childLocation) {
            showFailure('status.native_form_unverified', attempt);
            return;
          }
          const childUrl = new URL(childLocation.href);
          if (childUrl.href === 'about:blank' || inspectedDocument === childDocument) {
            return;
          }
          inspectionInProgress = true;
          inspectedDocument = childDocument;
          cancelFrameTimeout();
          removeEmbeddedPresentation();
          if (childUrl.origin !== window.location.origin) {
            showFailure('status.native_form_unverified', attempt);
            return;
          }
          if (isLoginDocument(childUrl, childDocument)) {
            showFailure('status.native_form_session_expired', attempt);
            return;
          }
          if (childUrl.pathname !== expectedChildPath) {
            if (verifiedNativeForm) {
              publishState('navigated', 'status.native_form_navigated');
            } else {
              showFailure('status.native_form_unverified', attempt);
            }
            return;
          }
          if (!hasExpectedNativeFormIdentity(childUrl)) {
            showFailure('status.native_form_unverified', attempt);
            return;
          }
          const resolvedForm = resolveExpectedNativeForm(childDocument, childUrl);
          const usableForm = resolvedForm.form;
          if (!usableForm) {
            showFailure('status.native_form_unverified', attempt);
            return;
          }
          verifiedNativeForm = true;
          const minimalApplied = resolvedForm.minimalCandidate
            ? mayApplyMinimalPresentation(childDocument, childUrl, resolvedForm.minimalCandidate)
            : false;
          if (minimalApplied) {
            childDocument.body.classList.add(
              'glpiacessivel-native-embedded-page',
              'glpiacessivel-formcreator-embedded-minimal'
            );
            publishState('ready', 'status.native_form_loaded_minimal');
          } else {
            publishState('ready', 'status.native_form_loaded');
          }
        } catch (error) {
          showFailure('status.native_form_unverified', attempt);
        } finally {
          inspectionInProgress = false;
        }
      }

      frame.addEventListener('load', function () {
        inspectFrame();
      });

      frame.addEventListener('error', function () {
        showFailure('status.native_form_unverified', attempt);
      });

      if (focusControl instanceof HTMLElement) {
        focusControl.addEventListener('click', function (event) {
          event.preventDefault();
          frame.focus();
          frame.scrollIntoView({ block: 'nearest' });
        });
      }

      if (retryButton instanceof HTMLButtonElement) {
        retryButton.addEventListener('click', function () {
          retryWasUsed = true;
          attempt += 1;
          terminalAttempt = 0;
          inspectedDocument = null;
          verifiedNativeForm = false;
          inspectionInProgress = false;
          removeEmbeddedPresentation();
          publishState('loading', 'status.native_form_loading', { busy: true, retryable: true });
          scheduleTimeout(attempt);
          try {
            const retryUrl = new URL(frame.src, window.location.href);
            retryUrl.searchParams.set('glpiacessivel_retry', String(attempt));
            frame.src = retryUrl.href;
          } catch (error) {
            showFailure('status.native_form_unverified', attempt);
          }
        });
      }

      publishState('loading', 'status.native_form_loading', { busy: true });
      scheduleTimeout(attempt);

      try {
        const currentDocument = frame.contentDocument;
        const currentLocation = frame.contentWindow && frame.contentWindow.location;
        if (
          currentDocument
          && currentLocation
          && currentLocation.href !== 'about:blank'
          && (currentDocument.readyState === 'interactive' || currentDocument.readyState === 'complete')
        ) {
          window.queueMicrotask(inspectFrame);
        }
      } catch (error) {
        // The timeout/fallback remains active when the child cannot be read.
      }
    });
  }

  function bindModulePresetControls(liveRegion) {
    const select = document.querySelector('[data-glpiacessivel-module-preset]');
    const button = document.querySelector('[data-glpiacessivel-module-preset-apply]');
    if (!(select instanceof HTMLSelectElement) || !(button instanceof HTMLButtonElement) || button.dataset.bound === '1') {
      return;
    }

    button.dataset.bound = '1';
    const status = document.querySelector('[data-glpiacessivel-module-status]');
    const dependency = document.querySelector('[data-glpiacessivel-module-dependency]');
    let presets = {};
    try {
      presets = JSON.parse(select.dataset.presets || '{}');
    } catch (error) {
      presets = {};
    }

    function updateDependency() {
      if (!(dependency instanceof HTMLElement)) {
        return;
      }
      const tickets = document.querySelector('input[name="module_states[tickets]"]:checked');
      const state = tickets instanceof HTMLInputElement ? tickets.value : 'available';
      if (state === 'disabled') {
        dependency.textContent = dependency.dataset.disabledMessage || '';
        dependency.hidden = false;
      } else if (state === 'hidden') {
        dependency.textContent = dependency.dataset.hiddenMessage || '';
        dependency.hidden = false;
      } else {
        dependency.textContent = '';
        dependency.hidden = true;
      }
    }

    document.querySelectorAll('input[name="module_states[tickets]"]').forEach(function (control) {
      control.addEventListener('change', updateDependency);
    });

    button.addEventListener('click', function () {
      const states = presets[select.value];
      if (!states || typeof states !== 'object') {
        return;
      }
      Object.keys(states).forEach(function (module) {
        const selector = 'input[name="module_states[' + module + ']"][value="' + states[module] + '"]';
        const radio = document.querySelector(selector);
        if (radio instanceof HTMLInputElement) {
          radio.checked = true;
        }
      });
      updateDependency();
      const message = button.dataset.announcement || '';
      if (status instanceof HTMLElement) {
        status.textContent = message;
      }
      if (liveRegion && message) {
        liveRegion.textContent = message;
      }
    });

    updateDependency();
  }
  function bindAdvancedTicketSearch(liveRegion) {

    const advancedForm = document.querySelector('[data-glpiacessivel-advanced-search-form]');
    const configNode = document.getElementById('ticket-advanced-search-config');

    function announce(message) {
      if (!liveRegion || !message) {
        return;
      }
      liveRegion.textContent = '';
      window.requestAnimationFrame(function () {
        liveRegion.textContent = message;
      });
    }


    if (!(advancedForm instanceof HTMLFormElement) || !(configNode instanceof HTMLElement)) {
      return;
    }
    if (!hasI18nMessage('search.value.label')) {
      return;
    }

    let config = {};
    try {
      config = JSON.parse(configNode.textContent || '{}');
    } catch (error) {
      config = {};
    }

    const catalog = config.catalog && typeof config.catalog === 'object' ? config.catalog : {};
    const catalogContextRevision = String(
      catalog.context_revision || config.context_revision || ''
    );
    const catalogOptions = Array.isArray(catalog.options) ? catalog.options : [];
    const catalogColumns = Array.isArray(catalog.columns) ? catalog.columns : [];
    const metaCatalogs = Array.isArray(catalog.meta_itemtypes) ? catalog.meta_itemtypes : [];
    const capabilities = catalog.capabilities && typeof catalog.capabilities === 'object'
      ? catalog.capabilities
      : {};
    const nativeSearchUrl = String(config.native_search_url || '');
    const remoteValueUrl = String(config.remote_value_url || '');
    const remoteCsrfToken = String(config.csrf_token || '');
    const configuredRemoteTimeout = Number(config.remote_timeout_ms);
    const remoteRequestTimeoutMs = Number.isFinite(configuredRemoteTimeout)
      ? Math.min(60000, Math.max(1000, configuredRemoteTimeout))
      : 12000;
    const limits = config.limits && typeof config.limits === 'object' ? config.limits : {};
    const maxCriteria = Math.min(25, Math.max(1, Number(limits.criteria) || 25));
    const maxMetaCriteria = Math.min(25, Math.max(1, Number(limits.metacriteria) || 25));
    const maxDepth = Math.min(3, Math.max(1, Number(limits.depth) || 3));
    const maxSorts = Math.min(5, Math.max(
      1,
      Number(capabilities.max_sorts) || Number(limits.sorts) || 5
    ));
    const editable = config.editable !== false && advancedForm.dataset.editable !== '0';
    const criteriaList = advancedForm.querySelector('[data-glpiacessivel-criteria-list]');
    const globalRulesList = advancedForm.querySelector('[data-glpiacessivel-global-rules-list]');
    const sortsList = advancedForm.querySelector('[data-glpiacessivel-sorts-list]');
    const addCriterionButton = advancedForm.querySelector('[data-glpiacessivel-add-criterion]');
    const addGroupButton = advancedForm.querySelector('[data-glpiacessivel-add-group]');
    const addGlobalRuleButton = advancedForm.querySelector('[data-glpiacessivel-add-global-rule]');
    const addSortButton = advancedForm.querySelector('[data-glpiacessivel-add-sort]');
    const summary = advancedForm.querySelector('[data-glpiacessivel-advanced-summary]');
    const advancedRuleCount = advancedForm.querySelector('[data-glpiacessivel-advanced-rule-count]');
    const resultOptionsSummary = advancedForm.querySelector('[data-glpiacessivel-result-options-summary]');
    const pageSizeControl = advancedForm.querySelector('#advanced_page_size');
    const groupingControl = advancedForm.querySelector('select[name="group_by"]');
    const filterLayerState = advancedForm.querySelector(
      '[data-glpiacessivel-layer-state="filters"]'
    );
    const displayLayerState = advancedForm.querySelector(
      '[data-glpiacessivel-layer-state="display"]'
    );
    const configuredDefaultColumns = Array.isArray(config.default_columns)
      ? config.default_columns.map(function (identifier) {
        return String(identifier || '');
      })
      : ['id', 'name', 'status', 'priority', 'group', 'date_mod'];
    const errorPanel = document.querySelector('[data-glpiacessivel-advanced-errors]');
    const advancedRulesDetails = criteriaList instanceof HTMLElement
      ? criteriaList.closest('details')
      : null;
    let controlSequence = 0;
    let committedColumns = [];
    let columnDialogBound = false;
    const searchToolTriggers = Array.from(document.querySelectorAll(
      '[data-glpiacessivel-search-tool-trigger]'
    ));
    const searchToolPanels = Array.from(document.querySelectorAll(
      '[data-glpiacessivel-search-tool-panel]'
    ));
    let activeSearchTool = '';
    let lastFocusedSearchTool = '';

    function triggerForSearchTool(name) {
      return searchToolTriggers.find(function (trigger) {
        return trigger.dataset.glpiacessivelSearchToolTrigger === name;
      }) || null;
    }

    function panelForSearchTool(name) {
      return searchToolPanels.find(function (panel) {
        return panel.dataset.glpiacessivelSearchToolPanel === name;
      }) || null;
    }

    function closeSearchTool(name, restoreFocus) {
      const panel = panelForSearchTool(name);
      const trigger = triggerForSearchTool(name);
      if (panel instanceof HTMLElement) {
        panel.hidden = true;
      }
      if (trigger instanceof HTMLElement) {
        trigger.setAttribute('aria-expanded', 'false');
      }
      if (activeSearchTool === name) {
        activeSearchTool = '';
      }
      if (restoreFocus && trigger instanceof HTMLElement) {
        window.requestAnimationFrame(function () {
          trigger.focus();
        });
      }
    }

    function openSearchTool(name, moveFocus) {
      const panel = panelForSearchTool(name);
      const trigger = triggerForSearchTool(name);
      if (!(panel instanceof HTMLElement) || !(trigger instanceof HTMLElement)) {
        return false;
      }
      searchToolPanels.forEach(function (candidate) {
        const candidateName = candidate.dataset.glpiacessivelSearchToolPanel || '';
        if (candidateName !== name) {
          const restoreCandidateFocus = candidate.contains(document.activeElement)
            || (
              document.activeElement === document.body
              && (candidateName === activeSearchTool || candidateName === lastFocusedSearchTool)
            );
          closeSearchTool(candidateName, restoreCandidateFocus);
        }
      });
      panel.hidden = false;
      trigger.setAttribute('aria-expanded', 'true');
      activeSearchTool = name;
      if (moveFocus) {
        window.requestAnimationFrame(function () {
          panel.focus();
        });
      }
      return true;
    }

    function searchToolForHash(hash) {
      if ([
        '#ticket-search-tool-saved-searches',
        '#tickets-pesquisas-salvas',
        '#create-native-saved-search',
        '#saved-search-catalog-results',
        '#saved-search-unavailable',
      ].includes(hash)) {
        return 'saved-searches';
      }
      if (hash === '#ticket-search-tool-result-options') {
        return 'result-options';
      }
      if (hash === '#ticket-search-tool-filters') {
        return 'filters';
      }
      if (hash === '#ticket-search-tool-record-scope') {
        return 'result-options';
      }
      return '';
    }

    function revealSearchToolHashTarget(moveFocus) {
      const hash = window.location.hash || '';
      const name = searchToolForHash(hash);
      if (!name || !openSearchTool(name, false)) {
        return false;
      }
      const target = hash !== '' ? document.querySelector(hash) : null;
      if (target instanceof HTMLDetailsElement) {
        target.open = true;
      }
      if (moveFocus && target instanceof HTMLElement) {
        window.requestAnimationFrame(function () {
          if (!target.hasAttribute('tabindex') && !target.matches(
            'a, button, input, select, textarea, summary'
          )) {
            target.setAttribute('tabindex', '-1');
          }
          target.focus();
        });
      }
      return true;
    }

    document.documentElement.classList.add('glpiacessivel-search-tools-enhanced');
    searchToolPanels.forEach(function (panel) {
      if (panel instanceof HTMLElement) {
        panel.hidden = true;
      }
    });
    searchToolTriggers.forEach(function (trigger) {
      if (!(trigger instanceof HTMLButtonElement)) {
        return;
      }
      const name = trigger.dataset.glpiacessivelSearchToolTrigger || '';
      trigger.setAttribute('aria-expanded', 'false');
      trigger.addEventListener('click', function () {
        if (trigger.getAttribute('aria-expanded') === 'true') {
          closeSearchTool(name, false);
        } else {
          openSearchTool(name, name === 'saved-searches');
        }
      });
    });
    searchToolPanels.forEach(function (panel) {
      if (!(panel instanceof HTMLElement)) {
        return;
      }
      const name = panel.dataset.glpiacessivelSearchToolPanel || '';
      panel.addEventListener('focusin', function () {
        lastFocusedSearchTool = name;
      });
      panel.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
          event.preventDefault();
          closeSearchTool(name, true);
        }
      });
      const closer = panel.querySelector(
        '[data-glpiacessivel-search-tool-close="' + name + '"]'
      );
      if (closer instanceof HTMLButtonElement) {
        closer.addEventListener('click', function () {
          closeSearchTool(name, true);
        });
      }
    });

    const initiallyOpenTool = searchToolPanels.find(function (panel) {
      return panel instanceof HTMLElement
        && panel.dataset.glpiacessivelSearchToolInitialOpen === '1';
    });
    if (!revealSearchToolHashTarget(true) && initiallyOpenTool instanceof HTMLElement) {
      openSearchTool(initiallyOpenTool.dataset.glpiacessivelSearchToolPanel || '', false);
    }
    window.addEventListener('hashchange', function () {
      revealSearchToolHashTarget(true);
    });

    const requestedResultsFocus = document.querySelector(
      '[data-glpiacessivel-advanced-results-focus], '
      + '[data-glpiacessivel-catalog-results-focus]'
    );
    if (requestedResultsFocus instanceof HTMLElement) {
      window.requestAnimationFrame(function () {
        requestedResultsFocus.focus();
      });
    }

    const relationOptions = [
      { value: 'AND', label: i18n('search.relation.and') },
      { value: 'OR', label: i18n('search.relation.or') },
      { value: 'AND NOT', label: i18n('search.relation.and_not') },
      { value: 'OR NOT', label: i18n('search.relation.or_not') },
    ];

    function normalizedOptions(options) {
      return (Array.isArray(options) ? options : []).filter(function (option) {
        return option && typeof option === 'object' && String(option.id || '') !== '';
      });
    }

    const homologatedOperatorValues = new Set([
      'contains', 'notcontains', 'equals', 'notequals', 'under', 'notunder',
      'lessthan', 'morethan',
    ]);
    const remoteBrowseOperatorValues = new Set([
      'equals', 'notequals', 'under', 'notunder',
    ]);
    const valueContractKinds = new Set([
      'none', 'text', 'integer', 'decimal', 'date', 'datetime', 'boolean',
      'local_select', 'remote_select',
    ]);

    function legacyValueContract(option) {
      const valueConfig = option && option.value && typeof option.value === 'object'
        ? option.value
        : {};
      const legacyMode = String(valueConfig.mode || '').toLowerCase();
      const kindByLegacyMode = {
        boolean: 'boolean',
        date: 'date',
        datetime: 'datetime',
        number: 'integer',
        remote: 'remote_select',
        select: 'local_select',
      };
      return {
        kind: kindByLegacyMode[legacyMode] || 'text',
        required: true,
      };
    }

    function normalizedValueContract(operator, option) {
      const fallback = legacyValueContract(option);
      const raw = operator && operator.value_contract
        && typeof operator.value_contract === 'object'
        ? operator.value_contract
        : null;
      if (!raw) {
        return fallback;
      }
      const requestedKind = String(raw.kind || '').toLowerCase();
      const kind = valueContractKinds.has(requestedKind)
        ? requestedKind
        : fallback.kind;
      return Object.assign({}, raw, {
        kind: kind,
        required: typeof raw.required === 'boolean'
          ? raw.required
          : kind !== 'none',
      });
    }

    function normalizedOperators(option) {
      return (option && Array.isArray(option.operators) ? option.operators : [])
        .filter(function (operator) {
          const value = operator && typeof operator === 'object'
            ? String(operator.value || '').toLowerCase()
            : '';
          const valueContract = normalizedValueContract(operator, option);
          const noValueOperator = (value === 'empty' || value === 'notempty')
            && valueContract.kind === 'none';
          return value !== 'searchopt'
            && (homologatedOperatorValues.has(value) || noValueOperator);
        })
        .map(function (operator) {
          return {
            value: String(operator.value).toLowerCase(),
            label: String(operator.label || operator.value),
            value_contract: normalizedValueContract(operator, option),
          };
        });
    }

    function operatorValueContract(option, operatorValue) {
      const descriptor = normalizedOperators(option).find(function (operator) {
        return operator.value === String(operatorValue || '').toLowerCase();
      });
      return descriptor && descriptor.value_contract
        ? descriptor.value_contract
        : legacyValueContract(option);
    }

    function optionCategory(option) {
      const category = option && typeof option === 'object'
        ? String(option.category || '').trim()
        : '';
      return category || i18n('search.option.other');
    }

    function searchableOptions(options) {
      return normalizedOptions(options).filter(function (option) {
        return normalizedOperators(option).length > 0;
      });
    }

    function appendGroupedOptions(select, options, selectedValue, preserveMissing) {
      select.textContent = '';
      const groups = new Map();
      options.forEach(function (item) {
        const category = optionCategory(item);
        if (!groups.has(category)) {
          const group = document.createElement('optgroup');
          group.label = category;
          groups.set(category, group);
          select.appendChild(group);
        }
        const option = document.createElement('option');
        option.value = String(item.id);
        option.textContent = String(item.label || item.field || item.id);
        option.selected = String(item.id) === String(selectedValue);
        groups.get(category).appendChild(option);
      });
      const selectedFound = Array.from(select.options).some(function (option) {
        return option.selected;
      });
      if (
        preserveMissing === true
        && String(selectedValue || '') !== ''
        && !selectedFound
      ) {
        const group = document.createElement('optgroup');
        group.label = i18n('search.saved.group');
        const preserved = document.createElement('option');
        preserved.value = String(selectedValue);
        preserved.textContent = i18n('search.saved.field', { value: String(selectedValue) });
        preserved.selected = true;
        group.appendChild(preserved);
        select.insertBefore(group, select.firstChild);
      }
      if (select.options.length > 0 && select.selectedIndex < 0) {
        select.selectedIndex = 0;
      }
    }
    function normalizedValueOptions(option) {
      const valueConfig = option && option.value && typeof option.value === 'object'
        ? option.value
        : {};
      return (Array.isArray(valueConfig.options) ? valueConfig.options : [])
        .filter(function (valueOption) {
          return valueOption && typeof valueOption === 'object'
            && Object.prototype.hasOwnProperty.call(valueOption, 'value');
        })
        .map(function (valueOption) {
          return {
            value: String(valueOption.value),
            label: String(valueOption.label || valueOption.value),
          };
        });
    }

    function directItems(list) {
      if (!(list instanceof HTMLElement)) {
        return [];
      }
      return Array.from(list.children).filter(function (child) {
        return child instanceof HTMLElement && child.hasAttribute('data-advanced-kind');
      });
    }

    function metaCatalogFor(itemtype) {
      return metaCatalogs.find(function (entry) {
        return entry && typeof entry === 'object'
          && String(entry.itemtype || '') === String(itemtype || '');
      }) || null;
    }

    function optionsFor(itemtype, globalRule) {
      if (!globalRule) {
        return normalizedOptions(catalogOptions);
      }
      const metaCatalog = metaCatalogFor(itemtype);
      return normalizedOptions(metaCatalog && metaCatalog.options);
    }

    function fieldOption(itemtype, fieldId, globalRule) {
      return optionsFor(itemtype, globalRule).find(function (option) {
        return String(option.id) === String(fieldId);
      }) || null;
    }

    function createElement(tag, className, text) {
      const element = document.createElement(tag);
      if (className) {
        element.className = className;
      }
      if (typeof text === 'string') {
        element.textContent = text;
      }
      return element;
    }

    function appendOptions(select, options, selectedValue, preserveMissing) {
      select.textContent = '';
      let selectedFound = false;
      options.forEach(function (item) {
        const option = document.createElement('option');
        option.value = String(item.value);
        option.textContent = String(item.label);
        option.selected = String(item.value) === String(selectedValue);
        selectedFound = selectedFound || option.selected;
        select.appendChild(option);
      });
      if (preserveMissing === true && String(selectedValue || '') !== '' && !selectedFound) {
        const preserved = document.createElement('option');
        preserved.value = String(selectedValue);
        preserved.textContent = i18n('search.saved.value', { value: String(selectedValue) });
        preserved.selected = true;
        select.insertBefore(preserved, select.firstChild);
      }
      if (select.options.length > 0 && select.selectedIndex < 0) {
        select.selectedIndex = 0;
      }
    }

    function labeledSelect(labelText, role, values, selectedValue) {
      const wrapper = createElement('div', 'glpiacessivel-field');
      wrapper.classList.add('glpiacessivel-advanced-field-' + String(role).replace(/[^a-z-]/g, ''));
      const label = document.createElement('label');
      const select = document.createElement('select');
      const id = 'advanced-search-control-' + (++controlSequence);
      label.htmlFor = id;
      label.textContent = labelText;
      select.id = id;
      select.dataset.advancedRole = role;
      appendOptions(select, values, selectedValue);
      wrapper.appendChild(label);
      wrapper.appendChild(select);
      return { wrapper: wrapper, label: label, control: select };
    }

    function selectedText(select) {
      if (!(select instanceof HTMLSelectElement) || select.selectedIndex < 0) {
        return '';
      }
      return (select.options[select.selectedIndex].textContent || '').trim();
    }

    function currentValue(item) {
      const control = item.querySelector('[data-advanced-role="value"]');
      return control instanceof HTMLInputElement || control instanceof HTMLSelectElement
        ? control.value
        : '';
    }

    function valueControlContext(item) {
      const host = item instanceof HTMLElement
        ? item.querySelector('[data-advanced-value-host]')
        : null;
      const submittedControl = host instanceof HTMLElement
        ? host.querySelector('[data-advanced-role="value"]')
        : null;
      const visibleRemoteControl = host instanceof HTMLElement
        ? host.querySelector('[data-advanced-remote-input]')
        : null;
      const remote = visibleRemoteControl instanceof HTMLInputElement
        && submittedControl instanceof HTMLInputElement
        && submittedControl.type === 'hidden';
      return {
        host: host,
        submittedControl: submittedControl,
        focusControl: remote ? visibleRemoteControl : submittedControl,
        remote: remote,
        required: !(host instanceof HTMLElement)
          || host.dataset.advancedValueRequired !== '0',
        kind: host instanceof HTMLElement
          ? String(host.dataset.advancedValueKind || 'text')
          : 'text',
      };
    }

    function buildValueControl(item, option, value, operator, itemtype) {
      const host = item.querySelector('[data-advanced-value-host]');
      if (!(host instanceof HTMLElement)) {
        return;
      }
      if (typeof host._glpiacessivelRemoteCleanup === 'function') {
        host._glpiacessivelRemoteCleanup();
        delete host._glpiacessivelRemoteCleanup;
      }
      host.textContent = '';
      const id = 'advanced-search-control-' + (++controlSequence);
      const valueConfig = option && option.value && typeof option.value === 'object'
        ? option.value
        : {};
      const valueContract = operatorValueContract(option, operator);
      const valueKind = valueContract.kind;
      const valueRequired = valueContract.required === true;
      host.dataset.advancedValueKind = valueKind;
      host.dataset.advancedValueRequired = valueRequired ? '1' : '0';

      if (valueKind === 'none') {
        const hiddenInput = document.createElement('input');
        const description = createElement(
          'p',
          'glpiacessivel-help-text',
          i18n('search.value.none_required')
        );
        hiddenInput.type = 'hidden';
        hiddenInput.value = String(valueContract.canonical_value || '');
        hiddenInput.dataset.advancedRole = 'value';
        host.appendChild(hiddenInput);
        host.appendChild(description);
        return;
      }

      const label = document.createElement('label');
      label.htmlFor = id;
      label.textContent = i18n('search.value.label');
      host.appendChild(label);

      let valueOptions = Array.isArray(valueContract.options)
        ? valueContract.options.filter(function (valueOption) {
          return valueOption && typeof valueOption === 'object'
            && Object.prototype.hasOwnProperty.call(valueOption, 'value');
        }).map(function (valueOption) {
          return {
            value: String(valueOption.value),
            label: String(valueOption.label || valueOption.value),
          };
        })
        : normalizedValueOptions(option);
      if (valueKind === 'boolean' && valueOptions.length === 0) {
        valueOptions = [
          { value: '1', label: i18n('search.value.yes') },
          { value: '0', label: i18n('search.value.no') },
        ];
      }
      if ((valueKind === 'local_select' || valueKind === 'boolean') && valueOptions.length > 0) {
        const select = document.createElement('select');
        select.id = id;
        select.dataset.advancedRole = 'value';
        select.setAttribute('aria-required', valueRequired ? 'true' : 'false');
        appendOptions(select, valueOptions, value, true);
        host.appendChild(select);
        return;
      }

      if (valueKind === 'remote_select') {
        const browseRemoteOptions = remoteBrowseOperatorValues.has(
          String(operator || '').toLowerCase()
        );
        const initialId = String(value == null ? '' : value).trim();
        const configuredLabel = String(valueConfig.selected_label || '').trim();
        const initialLabel = initialId !== '' ? configuredLabel : '';
        const listboxId = id + '-listbox';
        const helpId = id + '-help';
        const statusId = id + '-status';
        const wrapper = createElement('div', 'glpiacessivel-remote-combobox');
        const inputRow = createElement('div', 'glpiacessivel-remote-combobox-input-row');
        const visibleInput = document.createElement('input');
        const hiddenInput = document.createElement('input');
        const clearButton = createElement(
          'button',
          'glpiacessivel-button glpiacessivel-button-secondary '
            + 'glpiacessivel-remote-combobox-clear',
          i18n('search.value.clear')
        );
        const listbox = createElement('ul', 'glpiacessivel-remote-combobox-listbox');
        const moreButton = createElement(
          'button',
          'glpiacessivel-button glpiacessivel-button-secondary '
            + 'glpiacessivel-remote-combobox-more',
          i18n('selector.action.load_more')
        );
        const retryButton = createElement(
          'button',
          'glpiacessivel-button glpiacessivel-button-secondary '
            + 'glpiacessivel-remote-combobox-more glpiacessivel-remote-combobox-retry',
          i18n('button.retry')
        );
        const help = createElement(
          'p',
          'glpiacessivel-help-text glpiacessivel-remote-combobox-help',
          browseRemoteOptions
            ? i18n('search.value.help_browse', { count: 2 })
            : i18n('search.value.help_search', { count: 2 })
        );
        const status = createElement('p', 'glpiacessivel-remote-combobox-status');

        label.textContent = browseRemoteOptions
          ? i18n('search.value.select')
          : i18n('search.value.search');
        visibleInput.type = 'text';
        visibleInput.id = id;
        visibleInput.value = initialLabel || (initialId !== '' ? 'ID ' + initialId : '');
        visibleInput.maxLength = 120;
        visibleInput.autocomplete = 'off';
        visibleInput.spellcheck = false;
        visibleInput.dataset.advancedRemoteInput = '1';
        visibleInput.setAttribute('role', 'combobox');
        visibleInput.setAttribute('aria-autocomplete', 'list');
        visibleInput.setAttribute('aria-haspopup', 'listbox');
        visibleInput.setAttribute('aria-expanded', 'false');
        visibleInput.setAttribute('aria-controls', listboxId);
        visibleInput.setAttribute('aria-describedby', helpId + ' ' + statusId);
        visibleInput.setAttribute('aria-required', valueRequired ? 'true' : 'false');
        if (browseRemoteOptions) {
          visibleInput.placeholder = i18n('selector.placeholder.choose_or_type');
        }

        hiddenInput.type = 'hidden';
        hiddenInput.value = initialId;
        hiddenInput.dataset.advancedRole = 'value';

        clearButton.type = 'button';
        clearButton.setAttribute('aria-label', i18n('search.value.clear_selected'));
        listbox.id = listboxId;
        listbox.setAttribute('role', 'listbox');
        listbox.setAttribute('aria-label', i18n('search.value.results'));
        listbox.hidden = true;
        moreButton.type = 'button';
        moreButton.hidden = true;
        moreButton.setAttribute('aria-controls', listboxId);
        retryButton.type = 'button';
        retryButton.hidden = true;
        retryButton.setAttribute('aria-describedby', statusId);
        help.id = helpId;
        status.id = statusId;
        status.setAttribute('role', 'status');
        status.setAttribute('aria-live', 'polite');
        status.setAttribute('aria-atomic', 'true');

        inputRow.appendChild(visibleInput);
        inputRow.appendChild(hiddenInput);
        inputRow.appendChild(clearButton);
        wrapper.appendChild(inputRow);
        wrapper.appendChild(listbox);
        wrapper.appendChild(moreButton);
        wrapper.appendChild(retryButton);
        wrapper.appendChild(help);
        wrapper.appendChild(status);
        host.appendChild(wrapper);

        let selectedId = initialId;
        let selectedLabel = initialLabel;
        let results = [];
        let activeIndex = -1;
        let currentPage = 0;
        let currentQuery = '';
        let hasMore = false;
        let debounceTimer = 0;
        let blurTimer = 0;
        let retryTimer = 0;
        let requestTimeoutTimer = 0;
        let abortController = null;
        let requestSequence = 0;
        let requestInFlight = false;
        let retryRequest = null;

        function setStatus(message) {
          status.textContent = String(message || '');
        }

        function setBusyState(busy) {
          requestInFlight = busy;
          if (busy) {
            visibleInput.setAttribute('aria-busy', 'true');
            listbox.setAttribute('aria-busy', 'true');
          } else {
            visibleInput.removeAttribute('aria-busy');
            listbox.removeAttribute('aria-busy');
          }
          moreButton.disabled = busy || !hasMore;
          moreButton.setAttribute('aria-disabled', moreButton.disabled ? 'true' : 'false');
          if (busy) {
            retryButton.disabled = true;
          } else if (retryButton.hidden) {
            retryButton.disabled = false;
          }
        }

        function hideRetry() {
          window.clearTimeout(retryTimer);
          retryButton.hidden = true;
          retryButton.disabled = false;
          retryButton.textContent = i18n('button.retry');
          retryRequest = null;
        }

        function showRetry(request, delaySeconds, label, action) {
          window.clearTimeout(retryTimer);
          retryRequest = Object.assign({}, request, { action: action || 'retry' });
          retryButton.textContent = String(label || i18n('button.retry'));
          retryButton.hidden = false;
          const delay = Math.max(0, Math.min(300, Number(delaySeconds) || 0));
          retryButton.disabled = delay > 0;
          if (delay > 0) {
            retryTimer = window.setTimeout(function () {
              retryButton.disabled = false;
              setStatus(i18n('search.value.retry_ready'));
            }, delay * 1000);
          }
        }

        function cancelPendingRemoteRequest() {
          window.clearTimeout(debounceTimer);
          window.clearTimeout(requestTimeoutTimer);
          requestSequence += 1;
          if (abortController) {
            abortController.abort();
            abortController = null;
          }
          setBusyState(false);
        }

        function updateClearButton() {
          clearButton.disabled = visibleInput.value.trim() === '' && hiddenInput.value === '';
        }

        function dispatchValueChange() {
          hiddenInput.dispatchEvent(new Event('change', { bubbles: true }));
        }

        function closeListbox() {
          listbox.hidden = true;
          visibleInput.setAttribute('aria-expanded', 'false');
          visibleInput.removeAttribute('aria-activedescendant');
          activeIndex = -1;
          Array.from(listbox.querySelectorAll('[role="option"]')).forEach(function (node) {
            node.classList.remove('is-active');
          });
        }

        function openListbox() {
          if (results.length === 0) {
            closeListbox();
            return;
          }
          listbox.hidden = false;
          visibleInput.setAttribute('aria-expanded', 'true');
        }

        function setActiveResult(index) {
          if (results.length === 0) {
            return;
          }
          const boundedIndex = Math.max(0, Math.min(results.length - 1, index));
          activeIndex = boundedIndex;
          Array.from(listbox.querySelectorAll('[role="option"]')).forEach(function (node, nodeIndex) {
            node.classList.toggle('is-active', nodeIndex === activeIndex);
          });
          const activeOption = listbox.querySelector('#' + listboxId + '-option-' + activeIndex);
          if (activeOption instanceof HTMLElement) {
            visibleInput.setAttribute('aria-activedescendant', activeOption.id);
            if (typeof activeOption.scrollIntoView === 'function') {
              activeOption.scrollIntoView({ block: 'nearest' });
            }
          }
        }

        function renderResults() {
          listbox.textContent = '';
          results.forEach(function (result, index) {
            const resultOption = createElement(
              'li',
              'glpiacessivel-remote-combobox-option',
              result.label
            );
            resultOption.id = listboxId + '-option-' + index;
            resultOption.dataset.remoteResultIndex = String(index);
            resultOption.setAttribute('role', 'option');
            resultOption.setAttribute('aria-selected', result.id === selectedId ? 'true' : 'false');
            listbox.appendChild(resultOption);
          });
          activeIndex = -1;
          visibleInput.removeAttribute('aria-activedescendant');
          moreButton.hidden = !hasMore;
          moreButton.disabled = requestInFlight || !hasMore;
          moreButton.setAttribute('aria-disabled', moreButton.disabled ? 'true' : 'false');
        }

        function selectResult(result) {
          if (!result) {
            return;
          }
          selectedId = result.id;
          selectedLabel = result.label;
          hiddenInput.value = selectedId;
          visibleInput.value = selectedLabel;
          renderResults();
          closeListbox();
          updateClearButton();
          setStatus(i18n('selector.status.selected', { value: selectedLabel }));
          dispatchValueChange();
        }

        function clearSelection(announce) {
          selectedId = '';
          selectedLabel = '';
          hiddenInput.value = '';
          visibleInput.value = '';
          results = [];
          hasMore = false;
          renderResults();
          closeListbox();
          updateClearButton();
          if (announce) {
            setStatus(i18n('search.value.selection_removed'));
          }
          dispatchValueChange();
        }

        clearButton.addEventListener('click', function () {
          cancelPendingRemoteRequest();
          hideRetry();
          clearSelection(true);
          visibleInput.focus();
        });

        if (nativeSearchUrl !== '') {
          const nativeLink = document.createElement('a');
          nativeLink.href = nativeSearchUrl;
          nativeLink.target = '_blank';
          nativeLink.rel = 'noopener noreferrer';
          nativeLink.textContent = i18n('search.value.native_new_tab');
          help.appendChild(document.createTextNode(' '));
          help.appendChild(nativeLink);
        }

        if (remoteValueUrl === '' || remoteCsrfToken === '') {
          label.textContent = i18n('search.value.fallback_label');
          visibleInput.inputMode = 'numeric';
          visibleInput.pattern = '[0-9]*';
          visibleInput.maxLength = 10;
          visibleInput.value = initialId;
          visibleInput.dataset.advancedRemoteFallback = '1';
          visibleInput.removeAttribute('role');
          visibleInput.removeAttribute('aria-autocomplete');
          visibleInput.removeAttribute('aria-haspopup');
          visibleInput.removeAttribute('aria-expanded');
          visibleInput.removeAttribute('aria-controls');
          help.firstChild.textContent = i18n('search.value.fallback_help');
          setStatus(initialId !== '' ? i18n('search.value.saved_id_preserved') : '');
          visibleInput.addEventListener('input', function () {
            selectedId = visibleInput.value.trim();
            selectedLabel = selectedId;
            hiddenInput.value = selectedId;
            updateClearButton();
            dispatchValueChange();
          });
          updateClearButton();
          host._glpiacessivelRemoteCleanup = function () {
            window.clearTimeout(blurTimer);
          };
          return;
        }

        function normalizedRemoteResults(payload) {
          if (!payload || typeof payload !== 'object' || !Array.isArray(payload.results)) {
            throw new Error('Invalid remote value response.');
          }
          return payload.results.reduce(function (items, result) {
            if (!result || typeof result !== 'object') {
              return items;
            }
            const resultId = String(result.id == null ? '' : result.id).trim();
            const resultLabel = String(result.label == null ? '' : result.label).trim();
            if (resultId !== '' && resultLabel !== '') {
              items.push({ id: resultId, label: resultLabel });
            }
            return items;
          }, []);
        }

        function retryAfterSeconds(response) {
          if (!response || !response.headers || typeof response.headers.get !== 'function') {
            return 0;
          }
          const retryAfter = String(response.headers.get('Retry-After') || '').trim();
          if (/^\d+$/.test(retryAfter)) {
            return Math.min(300, Number(retryAfter));
          }
          const retryDate = Date.parse(retryAfter);
          return Number.isFinite(retryDate)
            ? Math.min(300, Math.max(0, Math.ceil((retryDate - Date.now()) / 1000)))
            : 0;
        }

        async function requestRemoteValues(query, page, selectedIdToResolve, append, resolving) {
          if (abortController) {
            abortController.abort();
          }
          window.clearTimeout(requestTimeoutTimer);
          abortController = typeof window.AbortController === 'function'
            ? new window.AbortController()
            : null;
          requestSequence += 1;
          const thisRequest = requestSequence;
          const previousCount = results.length;
          let requestTimedOut = false;
          const request = {
            query: String(query || ''),
            page: page,
            selectedId: String(selectedIdToResolve || ''),
            append: append === true,
            resolving: resolving === true,
          };
          const formData = new window.FormData();
          formData.append('itemtype', String(itemtype || 'Ticket'));
          formData.append('field', String(option && option.id != null ? option.id : ''));
          formData.append('q', request.query);
          formData.append('page', String(page));
          formData.append('selected_id', request.selectedId);
          formData.append('operator', String(operator || ''));
          formData.append('context_revision', catalogContextRevision);
          formData.append('_glpi_csrf_token', remoteCsrfToken);
          hideRetry();
          setBusyState(true);
          setStatus(resolving
            ? i18n('search.value.loading_saved')
            : i18n(append ? 'selector.status.loading_more' : 'selector.status.loading'));

          try {
            const requestOptions = {
              method: 'POST',
              body: formData,
              credentials: 'same-origin',
              headers: { Accept: 'application/json' },
            };
            if (abortController) {
              requestOptions.signal = abortController.signal;
            }
            const timeoutPromise = new Promise(function (resolve, reject) {
              requestTimeoutTimer = window.setTimeout(function () {
                requestTimedOut = true;
                const timeoutError = new Error('Remote value request timed out.');
                timeoutError.name = 'TimeoutError';
                if (abortController) {
                  abortController.abort();
                }
                reject(timeoutError);
              }, remoteRequestTimeoutMs);
            });
            const response = await Promise.race([
              window.fetch(remoteValueUrl, requestOptions),
              timeoutPromise,
            ]);
            window.clearTimeout(requestTimeoutTimer);
            if (!response.ok) {
              const requestError = new Error('Remote value request failed.');
              requestError.status = Number(response.status) || 0;
              requestError.retryAfter = retryAfterSeconds(response);
              throw requestError;
            }
            const payload = await response.json();
            if (thisRequest !== requestSequence || !host.isConnected) {
              return;
            }
            const fetchedResults = normalizedRemoteResults(payload);

            if (resolving) {
              const resolved = fetchedResults.find(function (result) {
                return result.id === request.selectedId;
              }) || fetchedResults[0] || null;
              if (resolved) {
                selectedId = resolved.id;
                selectedLabel = resolved.label;
                hiddenInput.value = selectedId;
                visibleInput.value = selectedLabel;
                setStatus(i18n('selector.status.selected', { value: selectedLabel }));
              } else {
                setStatus(i18n('search.value.saved_name_missing'));
              }
              updateClearButton();
              updateSummary();
              return;
            }

            currentPage = page;
            currentQuery = request.query;
            hasMore = Boolean(
              payload.pagination
              && typeof payload.pagination === 'object'
              && payload.pagination.more === true
            );
            if (append) {
              const knownIds = new Set(results.map(function (result) {
                return result.id;
              }));
              fetchedResults.forEach(function (result) {
                if (!knownIds.has(result.id)) {
                  knownIds.add(result.id);
                  results.push(result);
                }
              });
            } else {
              results = fetchedResults;
            }
            const addedCount = Math.max(0, results.length - previousCount);
            renderResults();
            if (results.length === 0) {
              closeListbox();
              setStatus(i18n('selector.status.no_results'));
              return;
            }
            if (append) {
              visibleInput.focus();
              openListbox();
              if (addedCount > 0) {
                setActiveResult(Math.min(previousCount, results.length - 1));
              }
              setStatus(
                i18n('selector.status.more_loaded', {
                  added: addedCount,
                  total: results.length,
                }) + ' ' + i18n(hasMore ? 'selector.status.has_more' : 'selector.status.end')
              );
            } else {
              setStatus(
                i18n(
                  results.length === 1
                    ? 'selector.status.one_available'
                    : 'selector.status.many_available',
                  { count: results.length }
                ) + ' ' + i18n('selector.status.choose_help')
              );
              if (document.activeElement === visibleInput || wrapper.contains(document.activeElement)) {
                openListbox();
              }
            }
          } catch (error) {
            window.clearTimeout(requestTimeoutTimer);
            if (error && error.name === 'AbortError' && thisRequest !== requestSequence) {
              return;
            }
            if (thisRequest !== requestSequence || !host.isConnected) {
              return;
            }
            if (!append && !resolving) {
              results = [];
              hasMore = false;
              renderResults();
              closeListbox();
            }
            if (error && (error.name === 'TimeoutError'
              || (error.name === 'AbortError' && requestTimedOut))) {
              setStatus(i18n('selector.error.timeout'));
              showRetry(request, 0);
            } else if (error && Number(error.status) === 403) {
              setStatus(i18n('search.value.session_or_permission'));
              showRetry(request, 0, i18n('button.reload_page'), 'reload');
            } else if (error && Number(error.status) === 409) {
              setStatus(i18n('search.value.context_changed'));
              showRetry(request, 0, i18n('button.reload_page'), 'reload');
            } else if (error && Number(error.status) === 422) {
              setStatus(i18n('search.value.invalid_condition'));
              showRetry(request, 0, i18n('button.review_condition'), 'review');
            } else if (error && Number(error.status) === 429) {
              const delay = Number(error.retryAfter) || 0;
              setStatus(delay > 0
                ? i18n(
                  delay === 1
                    ? 'search.value.rate_limited_seconds'
                    : 'search.value.rate_limited_seconds_plural',
                  { seconds: delay }
                )
                : i18n('search.value.rate_limited_wait'));
              showRetry(request, delay);
            } else if (error && Number(error.status) === 503) {
              setStatus(i18n('search.value.service_unavailable'));
              showRetry(request, Number(error.retryAfter) || 0);
            } else if (resolving) {
              setStatus(i18n('search.value.name_missing'));
              showRetry(request, 0);
            } else {
              setStatus(i18n('selector.error.generic'));
              showRetry(request, 0);
            }
          } finally {
            if (thisRequest === requestSequence) {
              window.clearTimeout(requestTimeoutTimer);
              abortController = null;
              setBusyState(false);
            }
          }
        }
        function scheduleRemoteRequest() {
          window.clearTimeout(debounceTimer);
          const query = visibleInput.value.trim();
          if (browseRemoteOptions && query === '') {
            debounceTimer = window.setTimeout(function () {
              requestRemoteValues('', 1, '', false, false);
            }, 150);
            return;
          }
          if (query.length < 2) {
            results = [];
            hasMore = false;
            renderResults();
            closeListbox();
            setStatus(query === '' ? '' : i18n('selector.minimum_characters', { count: 2 }));
            return;
          }
          debounceTimer = window.setTimeout(function () {
            requestRemoteValues(query, 1, '', false, false);
          }, 300);
        }

        visibleInput.addEventListener('input', function () {
          cancelPendingRemoteRequest();
          hideRetry();
          results = [];
          hasMore = false;
          renderResults();
          closeListbox();
          if (selectedId !== '' && visibleInput.value.trim() !== selectedLabel) {
            selectedId = '';
            selectedLabel = '';
            hiddenInput.value = '';
            dispatchValueChange();
          }
          updateClearButton();
          scheduleRemoteRequest();
        });

        visibleInput.addEventListener('focus', function () {
          if (requestInFlight) {
            return;
          }
          if (results.length > 0) {
            openListbox();
          } else if (
            browseRemoteOptions
            && selectedId === ''
            && visibleInput.value.trim() === ''
          ) {
            requestRemoteValues('', 1, '', false, false);
          } else if (selectedId === '' && visibleInput.value.trim().length >= 2) {
            scheduleRemoteRequest();
          }
        });

        visibleInput.addEventListener('blur', function () {
          window.clearTimeout(blurTimer);
          blurTimer = window.setTimeout(function () {
            if (!wrapper.contains(document.activeElement)) {
              closeListbox();
            }
          }, 0);
        });

        visibleInput.addEventListener('keydown', function (event) {
          if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            if (results.length === 0) {
              if (
                browseRemoteOptions
                && selectedId === ''
                && visibleInput.value.trim() === ''
              ) {
                event.preventDefault();
                requestRemoteValues('', 1, '', false, false);
              }
              return;
            }
            event.preventDefault();
            openListbox();
            if (event.key === 'ArrowDown') {
              setActiveResult(activeIndex < results.length - 1 ? activeIndex + 1 : 0);
            } else {
              setActiveResult(activeIndex > 0 ? activeIndex - 1 : results.length - 1);
            }
            return;
          }
          if (event.key === 'Home' && !listbox.hidden && results.length > 0) {
            event.preventDefault();
            setActiveResult(0);
            return;
          }
          if (event.key === 'End' && !listbox.hidden && results.length > 0) {
            event.preventDefault();
            setActiveResult(results.length - 1);
            return;
          }
          if (event.key === 'Enter' && !listbox.hidden && activeIndex >= 0) {
            event.preventDefault();
            selectResult(results[activeIndex]);
            return;
          }
          if (event.key === 'Escape' && !listbox.hidden) {
            event.preventDefault();
            closeListbox();
          }
        });

        listbox.addEventListener('mousedown', function (event) {
          event.preventDefault();
        });

        listbox.addEventListener('click', function (event) {
          const target = event.target instanceof Element
            ? event.target.closest('[data-remote-result-index]')
            : null;
          if (!(target instanceof HTMLElement)) {
            return;
          }
          const index = Number(target.dataset.remoteResultIndex);
          if (Number.isInteger(index) && results[index]) {
            selectResult(results[index]);
            visibleInput.focus();
          }
        });

        moreButton.addEventListener('click', function () {
          if (requestInFlight || !hasMore || currentPage < 1) {
            return;
          }
          requestRemoteValues(currentQuery, currentPage + 1, '', true, false);
        });

        retryButton.addEventListener('click', function () {
          if (requestInFlight || retryButton.disabled || !retryRequest) {
            return;
          }
          const request = retryRequest;
          if (request.action === 'reload') {
            window.location.reload();
            return;
          }
          if (request.action === 'review') {
            const operatorControl = item.querySelector('[data-advanced-role="searchtype"]');
            if (operatorControl instanceof HTMLSelectElement) {
              operatorControl.focus();
            }
            return;
          }
          requestRemoteValues(
            request.query,
            request.page,
            request.selectedId,
            request.append,
            request.resolving
          );
          visibleInput.focus();
        });

        updateClearButton();
        if (selectedId !== '' && selectedLabel !== '') {
          setStatus(i18n('selector.status.selected', { value: selectedLabel }));
        } else if (selectedId !== '') {
          requestRemoteValues('', 1, selectedId, false, true);
        }

        host._glpiacessivelRemoteCleanup = function () {
          cancelPendingRemoteRequest();
          window.clearTimeout(blurTimer);
          window.clearTimeout(retryTimer);
          window.clearTimeout(requestTimeoutTimer);
        };
        return;
      }

      const input = document.createElement('input');
      input.type = 'text';
      input.id = id;
      input.value = String(value == null ? '' : value);
      input.maxLength = Math.min(4096, Math.max(1, Number(valueContract.max_bytes) || 4096));
      input.autocomplete = 'off';
      input.dataset.advancedRole = 'value';
      input.setAttribute('aria-required', valueRequired ? 'true' : 'false');
      if (valueKind === 'integer') {
        input.inputMode = 'numeric';
      } else if (valueKind === 'decimal') {
        input.inputMode = 'decimal';
      }
      if (valueKind === 'date' || valueKind === 'datetime') {
        const format = valueKind === 'date' ? 'AAAA-MM-DD' : 'AAAA-MM-DD HH:MM:SS';
        input.placeholder = format;
        input.setAttribute('aria-describedby', id + '-help');
        const help = createElement(
          'p',
          'glpiacessivel-help-text',
          i18n('search.value.format', { format: format })
        );
        help.id = id + '-help';
        host.appendChild(input);
        host.appendChild(help);
        return;
      }
      host.appendChild(input);
    }

    function updateCriterionFields(item, preferredField, preferredOperator, preferredValue) {
      const globalRule = item.dataset.advancedKind === 'global';
      const itemtypeControl = item.querySelector('[data-advanced-role=itemtype]');
      const itemtype = itemtypeControl instanceof HTMLSelectElement
        ? itemtypeControl.value
        : 'Ticket';
      const allFields = searchableOptions(optionsFor(itemtype, globalRule));
      const fieldControl = item.querySelector('[data-advanced-role=field]');
      if (!(fieldControl instanceof HTMLSelectElement)) {
        return;
      }

      appendGroupedOptions(fieldControl, allFields, preferredField, true);
      const option = fieldOption(itemtype, fieldControl.value, globalRule);
      const operatorControl = item.querySelector('[data-advanced-role=searchtype]');
      if (!(operatorControl instanceof HTMLSelectElement)) {
        return;
      }
      appendOptions(operatorControl, normalizedOperators(option), preferredOperator);
      buildValueControl(item, option, preferredValue, operatorControl.value, itemtype);
    }
    function updateCriterionValue(item, preserveValue) {
      const globalRule = item.dataset.advancedKind === 'global';
      const itemtypeControl = item.querySelector('[data-advanced-role="itemtype"]');
      const itemtype = itemtypeControl instanceof HTMLSelectElement
        ? itemtypeControl.value
        : 'Ticket';
      const fieldControl = item.querySelector('[data-advanced-role="field"]');
      const operatorControl = item.querySelector('[data-advanced-role="searchtype"]');
      if (!(fieldControl instanceof HTMLSelectElement)
        || !(operatorControl instanceof HTMLSelectElement)) {
        return;
      }
      buildValueControl(
        item,
        fieldOption(itemtype, fieldControl.value, globalRule),
        preserveValue ? currentValue(item) : '',
        operatorControl.value,
        itemtype
      );
    }

    function actionButton(text, action) {
      const button = createElement(
        'button',
        'glpiacessivel-button glpiacessivel-button-secondary',
        text
      );
      button.type = 'button';
      button.dataset.advancedAction = action;
      return button;
    }

    function normalizedColumnCatalog() {
      const seen = new Set();
      return catalogColumns.reduce(function (columns, entry) {
        if (
          !entry
          || typeof entry !== 'object'
          || entry.available === false
          || entry.available === 0
          || entry.available === '0'
        ) {
          return columns;
        }
        const identifier = String(
          entry.identifier || entry.key || entry.option_id || ''
        ).trim();
        if (identifier === '' || seen.has(identifier)) {
          return columns;
        }
        seen.add(identifier);
        const semanticKey = String(entry.key || entry.identifier || identifier).toLowerCase();
        columns.push({
          identifier: identifier,
          label: String(entry.label || entry.title || identifier),
          category: String(entry.category || i18n('search.option.other')),
          required: entry.required === true || entry.required === 1 || entry.required === '1'
            || ['id', 'name', 'title'].includes(semanticKey),
        });
        return columns;
      }, []);
    }

    function selectedColumnIdentifiers() {
      if (columnDialogBound) {
        return committedColumns.slice();
      }
      const values = [];
      const seen = new Set();
      advancedForm.querySelectorAll('input[name="advanced[columns][]"]').forEach(
        function (input) {
          if (
            input instanceof HTMLInputElement
            && (input.type !== 'checkbox' || input.checked)
            && input.value !== ''
            && !seen.has(input.value)
          ) {
            seen.add(input.value);
            values.push(input.value);
          }
        }
      );
      return values;
    }

    function selectedColumnCount() {
      return selectedColumnIdentifiers().length;
    }

    function bindColumnDialog() {
      const openButton = document.querySelector('[data-glpiacessivel-open-columns]');
      const dialog = document.querySelector('[data-glpiacessivel-column-dialog]');
      if (!(openButton instanceof HTMLButtonElement) || !(dialog instanceof HTMLElement)) {
        return;
      }
      const closeButtons = Array.from(dialog.querySelectorAll(
        '[data-glpiacessivel-close-columns], [data-glpiacessivel-column-close]'
      )).filter(function (button) {
        return button instanceof HTMLButtonElement;
      });
      const picker = dialog.querySelector(
        'select[data-glpiacessivel-column-add], select[data-glpiacessivel-add-column]'
      );
      const addButton = dialog.querySelector(
        'button[data-glpiacessivel-add-column], button[data-glpiacessivel-column-add]'
      );
      const list = dialog.querySelector('[data-glpiacessivel-column-list]');
      const applyButton = dialog.querySelector(
        'button[data-glpiacessivel-apply-columns], button[data-glpiacessivel-column-apply]'
      );
      const resetButton = dialog.querySelector(
        'button[data-glpiacessivel-reset-columns], button[data-glpiacessivel-column-reset]'
      );
      if (
        !(picker instanceof HTMLSelectElement)
        || !(addButton instanceof HTMLButtonElement)
        || !(list instanceof HTMLElement)
        || !(applyButton instanceof HTMLButtonElement)
        || !(resetButton instanceof HTMLButtonElement)
      ) {
        return;
      }

      const columns = normalizedColumnCatalog();
      if (columns.length === 0) {
        return;
      }
      const byIdentifier = new Map(columns.map(function (column) {
        return [column.identifier, column];
      }));
      list.querySelectorAll('[data-column-id][data-column-locked="1"]').forEach(
        function (item) {
          const column = byIdentifier.get(String(item.dataset.columnId || ''));
          if (column) {
            column.required = true;
          }
        }
      );

      const requiredIdentifiers = columns.filter(function (column) {
        return column.required;
      }).map(function (column) {
        return column.identifier;
      });
      const defaultColumnIdentifiers = normalizeSelection(configuredDefaultColumns);
      const namedInputs = Array.from(
        advancedForm.querySelectorAll('input[name="advanced[columns][]"]')
      );
      const initialIdentifiers = [];
      namedInputs.forEach(function (input) {
        if (
          input instanceof HTMLInputElement
          && (input.type !== 'checkbox' || input.checked)
        ) {
          initialIdentifiers.push(input.value);
        }
        input.removeAttribute('name');
      });
      if (initialIdentifiers.length === 0) {
        list.querySelectorAll('[data-column-id]').forEach(function (item) {
          initialIdentifiers.push(String(item.dataset.columnId || ''));
        });
      }
      if (initialIdentifiers.length === 0 && Array.isArray(config.columns)) {
        config.columns.forEach(function (identifier) {
          initialIdentifiers.push(String(identifier));
        });
      }

      function normalizeSelection(values) {
        const result = [];
        const selected = new Set();
        requiredIdentifiers.concat(values).forEach(function (identifier) {
          const value = String(identifier || '');
          if (value !== '' && byIdentifier.has(value) && !selected.has(value)) {
            selected.add(value);
            result.push(value);
          }
        });
        return result;
      }

      let draftColumns = [];
      committedColumns = normalizeSelection(initialIdentifiers);
      const hiddenHost = createElement('div', 'glpiacessivel-column-hidden-inputs');
      hiddenHost.hidden = true;
      hiddenHost.dataset.glpiacessivelColumnHiddenInputs = '1';
      const completionSentinel = advancedForm.querySelector(
        'input[name="advanced_request_complete"]'
      );
      advancedForm.insertBefore(hiddenHost, completionSentinel);

      function renderHiddenInputs() {
        hiddenHost.textContent = '';
        committedColumns.forEach(function (identifier) {
          const input = document.createElement('input');
          input.type = 'hidden';
          input.name = 'advanced[columns][]';
          input.value = identifier;
          hiddenHost.appendChild(input);
        });
        updateResultOptionsSummary();
      }

      function focusColumn(identifier) {
        const target = Array.from(list.querySelectorAll('[data-column-id]')).find(
          function (item) {
            return String(item.dataset.columnId || '') === String(identifier);
          }
        );
        const heading = target && target.querySelector('[data-glpiacessivel-column-heading]');
        if (heading instanceof HTMLElement) {
          heading.focus();
          return true;
        }
        return false;
      }

      function renderPicker() {
        const previous = picker.value;
        picker.textContent = '';
        const placeholder = document.createElement('option');
        placeholder.value = '';
        placeholder.textContent = i18n('search.column.choose');
        picker.appendChild(placeholder);
        const selected = new Set(draftColumns);
        const groups = new Map();
        columns.forEach(function (column) {
          if (selected.has(column.identifier)) {
            return;
          }
          if (!groups.has(column.category)) {
            const group = document.createElement('optgroup');
            group.label = column.category;
            groups.set(column.category, group);
            picker.appendChild(group);
          }
          const option = document.createElement('option');
          option.value = column.identifier;
          option.textContent = column.label;
          groups.get(column.category).appendChild(option);
        });
        if (Array.from(picker.options).some(function (option) {
          return option.value === previous;
        })) {
          picker.value = previous;
        }
        addButton.disabled = !editable || picker.value === '';
      }

      function renderColumnList() {
        list.textContent = '';
        draftColumns.forEach(function (identifier, index) {
          const column = byIdentifier.get(identifier);
          if (!column) {
            return;
          }
          const item = createElement('li', 'glpiacessivel-column-dialog-item');
          item.dataset.columnId = identifier;
          item.dataset.columnLabel = column.label;
          item.dataset.columnLocked = column.required ? '1' : '0';
          const heading = createElement('span', 'glpiacessivel-column-dialog-label', column.label);
          heading.tabIndex = -1;
          heading.dataset.glpiacessivelColumnHeading = '1';
          item.appendChild(heading);
          item.appendChild(createElement(
            'span',
            'glpiacessivel-column-dialog-position',
            i18n('search.column.position', {
              position: index + 1,
              total: draftColumns.length,
            })
          ));
          if (column.required) {
            item.appendChild(createElement(
              'span',
              'glpiacessivel-column-dialog-required',
              i18n('search.column.required')
            ));
          }
          const actions = createElement('div', 'glpiacessivel-column-dialog-actions');
          const up = actionButton(i18n('search.action.move_up'), 'column-up');
          const down = actionButton(i18n('search.action.move_down'), 'column-down');
          up.dataset.glpiacessivelColumnMove = 'up';
          down.dataset.glpiacessivelColumnMove = 'down';
          up.disabled = !editable || index === 0;
          down.disabled = !editable || index === draftColumns.length - 1;
          up.setAttribute(
            'aria-label',
            i18n('search.column.move_up', {
              label: column.label,
              position: i18n('search.column.position', {
                position: index + 1,
                total: draftColumns.length,
              }).toLocaleLowerCase(),
            })
          );
          down.setAttribute(
            'aria-label',
            i18n('search.column.move_down', {
              label: column.label,
              position: i18n('search.column.position', {
                position: index + 1,
                total: draftColumns.length,
              }).toLocaleLowerCase(),
            })
          );
          up.addEventListener('click', function () {
            if (index === 0) {
              return;
            }
            draftColumns.splice(index - 1, 0, draftColumns.splice(index, 1)[0]);
            renderColumnList();
            focusColumn(identifier);
            announce(i18n('search.column.moved', {
              label: column.label,
              position: i18n('search.column.position', {
                position: index,
                total: draftColumns.length,
              }).toLocaleLowerCase(),
            }));
          });
          down.addEventListener('click', function () {
            if (index >= draftColumns.length - 1) {
              return;
            }
            draftColumns.splice(index + 1, 0, draftColumns.splice(index, 1)[0]);
            renderColumnList();
            focusColumn(identifier);
            announce(i18n('search.column.moved', {
              label: column.label,
              position: i18n('search.column.position', {
                position: index + 2,
                total: draftColumns.length,
              }).toLocaleLowerCase(),
            }));
          });
          actions.appendChild(up);
          actions.appendChild(down);
          if (!column.required) {
            const remove = actionButton(i18n('search.action.remove'), 'column-remove');
            remove.dataset.glpiacessivelColumnRemove = '1';
            remove.disabled = !editable;
            remove.setAttribute(
              'aria-label',
              i18n('search.column.remove', {
                label: column.label,
                position: i18n('search.column.position', {
                  position: index + 1,
                  total: draftColumns.length,
                }).toLocaleLowerCase(),
              })
            );
            remove.addEventListener('click', function () {
              draftColumns.splice(index, 1);
              renderColumnList();
              const nextIdentifier = draftColumns[index] || draftColumns[index - 1] || '';
              if (!focusColumn(nextIdentifier)) {
                picker.focus();
              }
              announce(i18n('search.column.removed', {
                label: column.label,
                count: draftColumns.length,
              }));
            });
            actions.appendChild(remove);
          }
          item.appendChild(actions);
          list.appendChild(item);
        });
        renderPicker();
      }

      function closeDialog(returnValue) {
        if (typeof dialog.close === 'function') {
          dialog.close(returnValue);
        } else {
          dialog.hidden = true;
          dialog.removeAttribute('open');
        }
        window.requestAnimationFrame(function () {
          if (!dialog.hasAttribute('open') && document.contains(openButton)) {
            openButton.focus();
          }
        });
      }

      openButton.setAttribute('aria-haspopup', 'dialog');
      if (dialog.id) {
        openButton.setAttribute('aria-controls', dialog.id);
      }
      openButton.addEventListener('click', function () {
        draftColumns = committedColumns.slice();
        renderColumnList();
        if (typeof dialog.showModal === 'function') {
          if (!dialog.open) {
            dialog.showModal();
          }
        } else {
          dialog.hidden = false;
          dialog.setAttribute('open', '');
        }
        announce(i18n('search.column.dialog_opened', { count: draftColumns.length }));
        window.requestAnimationFrame(function () {
          picker.focus();
        });
      });
      picker.addEventListener('change', function () {
        addButton.disabled = !editable || picker.value === '';
      });
      addButton.addEventListener('click', function () {
        const identifier = picker.value;
        const column = byIdentifier.get(identifier);
        if (!column) {
          announce(i18n('search.column.choose_available'));
          picker.focus();
          return;
        }
        if (draftColumns.includes(identifier)) {
          announce(i18n('search.column.already_selected', { label: column.label }));
          return;
        }
        draftColumns.push(identifier);
        renderColumnList();
        focusColumn(identifier);
        announce(i18n('search.column.added', {
          label: column.label,
          position: i18n('search.column.position', {
            position: draftColumns.length,
            total: draftColumns.length,
          }).toLocaleLowerCase(),
        }));
      });
      resetButton.addEventListener('click', function () {
        draftColumns = defaultColumnIdentifiers.slice();
        renderColumnList();
        picker.focus();
        announce(i18n('search.column.defaults_restored', { count: draftColumns.length }));
      });
      applyButton.addEventListener('click', function () {
        committedColumns = normalizeSelection(draftColumns);
        renderHiddenInputs();
        closeDialog('apply');
        announce(i18n('search.column.applied', { count: committedColumns.length }));
      });
      closeButtons.forEach(function (closeButton) {
        closeButton.addEventListener('click', function () {
          draftColumns = committedColumns.slice();
          closeDialog('cancel');
        });
      });
      dialog.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') {
          return;
        }
        event.preventDefault();
        event.stopPropagation();
        draftColumns = committedColumns.slice();
        closeDialog('cancel');
      });
      dialog.addEventListener('cancel', function (event) {
        event.preventDefault();
        draftColumns = committedColumns.slice();
        closeDialog('cancel');
      });
      dialog.addEventListener('close', function () {
        window.requestAnimationFrame(function () {
          if (document.contains(openButton)) {
            openButton.focus();
          }
        });
      });

      columnDialogBound = true;
      applyButton.disabled = !editable;
      resetButton.disabled = !editable;
      renderHiddenInputs();
    }
    function moveItem(item, direction) {
      const list = item.parentElement;
      if (!(list instanceof HTMLElement)) {
        return;
      }
      const items = directItems(list);
      const index = items.indexOf(item);
      if (direction < 0 && index > 0) {
        list.insertBefore(item, items[index - 1]);
      } else if (direction > 0 && index >= 0 && index < items.length - 1) {
        list.insertBefore(items[index + 1], item);
      } else {
        return;
      }
      reindexAll();
      const heading = item.querySelector('[data-advanced-item-heading]');
      if (heading instanceof HTMLElement) {
        heading.focus();
      }
      const nextItems = directItems(list);
      const itemName = heading instanceof HTMLElement
        ? heading.textContent
        : i18n('search.item.generic');
      announce(i18n('search.status.moved', {
        item: itemName,
        position: nextItems.indexOf(item) + 1,
        total: nextItems.length,
      }));
    }

    function removeItem(item) {
      const list = item.parentElement;
      if (!(list instanceof HTMLElement)) {
        return;
      }
      const items = directItems(list);
      const index = items.indexOf(item);
      const kind = item.dataset.advancedKind || 'criterion';
      const itemHeading = item.querySelector('[data-advanced-item-heading]');
      const itemName = itemHeading instanceof HTMLElement
        ? itemHeading.textContent
        : '';
      item.querySelectorAll('[data-advanced-value-host]').forEach(function (valueHost) {
        if (typeof valueHost._glpiacessivelRemoteCleanup === 'function') {
          valueHost._glpiacessivelRemoteCleanup();
        }
      });
      item.remove();
      reindexAll();
      const remaining = directItems(list);
      const next = remaining[index] || remaining[index - 1] || null;
      const focusTarget = next
        ? next.querySelector('[data-advanced-item-heading]')
        : (
          kind === 'global' ? addGlobalRuleButton
            : kind === 'sort' ? addSortButton
              : list === criteriaList ? addCriterionButton
                : list.parentElement
                  && list.parentElement.querySelector('[data-advanced-add-child]')
        );
      if (focusTarget instanceof HTMLElement) {
        focusTarget.focus();
      }
      const removedItem = itemName !== ''
        ? itemName
        : i18n(kind === 'group' ? 'search.item.group'
          : kind === 'global' ? 'search.item.global_rule'
            : kind === 'sort' ? 'search.item.sort'
              : 'search.item.criterion');
      announce(i18n(
        remaining.length > 0 ? 'search.status.removed' : 'search.status.removed_empty',
        { item: removedItem, count: remaining.length }
      ));
    }

    function bindItemActions(item) {
      const up = item.querySelector('[data-advanced-action="up"]');
      const down = item.querySelector('[data-advanced-action="down"]');
      const remove = item.querySelector('[data-advanced-action="remove"]');
      if (up instanceof HTMLButtonElement) {
        up.addEventListener('click', function () {
          moveItem(item, -1);
        });
      }
      if (down instanceof HTMLButtonElement) {
        down.addEventListener('click', function () {
          moveItem(item, 1);
        });
      }
      if (remove instanceof HTMLButtonElement) {
        remove.addEventListener('click', function () {
          removeItem(item);
        });
      }
    }

    function createCriterion(data, list, depth, globalRule, focusNew) {
      if (!(list instanceof HTMLElement)) {
        return null;
      }
      const defaultMetaCatalog = metaCatalogs.find(function (entry) {
        return normalizedOptions(entry && entry.options).length > 0;
      }) || metaCatalogs[0] || null;
      const itemtype = globalRule
        ? String(
          data && data.itemtype
          || (defaultMetaCatalog && defaultMetaCatalog.itemtype)
          || ''
        )
        : 'Ticket';
      if (globalRule && itemtype === '') {
        return null;
      }

      const item = createElement('li', 'glpiacessivel-advanced-search-item');
      item.dataset.advancedKind = globalRule ? 'global' : 'criterion';
      item.dataset.advancedDepth = String(depth);
      const card = createElement('div', 'glpiacessivel-advanced-search-card');
      card.setAttribute('role', 'group');
      const heading = createElement(
        'h5',
        '',
        i18n(globalRule ? 'search.item.global_rule' : 'search.item.criterion')
      );
      heading.tabIndex = -1;
      heading.dataset.advancedItemHeading = '1';
      heading.id = 'advanced-search-item-' + (++controlSequence);
      card.setAttribute('aria-labelledby', heading.id);
      card.appendChild(heading);

      const fields = createElement('div', 'glpiacessivel-advanced-search-fields');
      const relation = labeledSelect(
        i18n(globalRule ? 'search.item.relation_global' : 'search.item.relation_criterion'),
        'link',
        relationOptions,
        data && data.link || 'AND'
      );
      const firstRule = createElement(
        'span',
        'glpiacessivel-advanced-first-rule',
        i18n('search.item.first_rule')
      );
      firstRule.dataset.advancedFirstRule = '1';
      firstRule.hidden = true;
      relation.wrapper.appendChild(firstRule);
      fields.appendChild(relation.wrapper);

      let itemtypeField = null;
      if (globalRule) {
        itemtypeField = labeledSelect(
          i18n('search.item.related_type'),
          'itemtype',
          metaCatalogs.map(function (entry) {
            return {
              value: String(entry.itemtype || ''),
              label: String(entry.label || entry.itemtype || ''),
            };
          }),
          itemtype
        );
        fields.appendChild(itemtypeField.wrapper);
      }

      const field = labeledSelect(
        i18n('search.item.field_grouped'),
        'field',
        [],
        data && data.field || ''
      );
      const operator = labeledSelect(
        i18n('search.item.condition'),
        'searchtype',
        [],
        data && data.searchtype || ''
      );
      const valueHost = createElement(
        'div',
        'glpiacessivel-field glpiacessivel-advanced-field-value'
      );
      valueHost.dataset.advancedValueHost = '1';
      fields.appendChild(field.wrapper);
      fields.appendChild(operator.wrapper);
      fields.appendChild(valueHost);
      card.appendChild(fields);

      const actions = createElement('div', 'glpiacessivel-advanced-search-item-actions');
      actions.appendChild(actionButton(i18n('search.action.move_up'), 'up'));
      actions.appendChild(actionButton(i18n('search.action.move_down'), 'down'));
      actions.appendChild(actionButton(
        i18n(globalRule ? 'search.item.remove_global' : 'search.item.remove_criterion'),
        'remove'
      ));
      card.appendChild(actions);
      item.appendChild(card);
      list.appendChild(item);

      updateCriterionFields(
        item,
        data && data.field || '',
        data && data.searchtype || '',
        data && data.value || ''
      );

      field.control.addEventListener('change', function () {
        updateCriterionFields(item, field.control.value, '', '');
        reindexAll();
        announce(i18n('search.status.field_changed'));
      });
      operator.control.addEventListener('change', function () {
        updateCriterionValue(item, false);
        reindexAll();
        const valueContext = valueControlContext(item);
        let valueInstruction = i18n('search.instruction.value');
        if (!valueContext.required) {
          valueInstruction = i18n('search.instruction.none');
        } else if (valueContext.remote) {
          valueInstruction = i18n('search.instruction.remote');
        }
        announce(i18n('search.status.condition_changed', {
          condition: selectedText(operator.control),
          instruction: valueInstruction,
        }));
      });
      if (itemtypeField) {
        itemtypeField.control.addEventListener('change', function () {
          updateCriterionFields(item, '', '', '');
          reindexAll();
          announce(i18n('search.status.related_type_changed'));
        });
      }
      item.addEventListener('change', updateSummary);
      bindItemActions(item);
      reindexAll();

      if (focusNew) {
        heading.focus();
        const siblings = directItems(list);
        announce(i18n('search.status.rule_added_position', {
          item: i18n(globalRule ? 'search.status.global_added' : 'search.status.criterion_added'),
          position: siblings.indexOf(item) + 1,
          total: siblings.length,
        }));
      }
      return item;
    }

    function createGroup(data, list, depth, focusNew) {
      if (!(list instanceof HTMLElement) || depth > maxDepth) {
        return null;
      }
      const group = createElement(
        'li',
        'glpiacessivel-advanced-search-item glpiacessivel-advanced-search-group'
      );
      group.dataset.advancedKind = 'group';
      group.dataset.advancedDepth = String(depth);
      const card = createElement('div', 'glpiacessivel-advanced-search-card');
      card.setAttribute('role', 'group');
      const heading = createElement('h5', '', i18n('search.item.group'));
      heading.tabIndex = -1;
      heading.dataset.advancedItemHeading = '1';
      heading.id = 'advanced-search-group-' + (++controlSequence);
      card.setAttribute('aria-labelledby', heading.id);
      card.appendChild(heading);

      const relation = labeledSelect(
        i18n('search.item.relation_group'),
        'link',
        relationOptions,
        data && data.link || 'AND'
      );
      card.appendChild(relation.wrapper);

      const childList = createElement(
        'ol',
        'glpiacessivel-advanced-search-list glpiacessivel-advanced-search-nested'
      );
      childList.dataset.advancedChildList = '1';
      childList.setAttribute('aria-label', i18n('search.item.group_criteria'));
      card.appendChild(childList);

      const childActions = createElement(
        'div',
        'glpiacessivel-advanced-search-add-actions'
      );
      const addChild = actionButton(i18n('search.item.add_criterion_group'), 'add-child');
      addChild.dataset.advancedAddChild = '1';
      const addNestedGroup = actionButton(i18n('search.item.add_nested_group'), 'add-group');
      addNestedGroup.dataset.advancedAddGroup = '1';
      if (depth >= maxDepth) {
        addNestedGroup.disabled = true;
        addNestedGroup.setAttribute('aria-describedby', heading.id);
      }
      childActions.appendChild(addChild);
      childActions.appendChild(addNestedGroup);
      card.appendChild(childActions);

      const actions = createElement('div', 'glpiacessivel-advanced-search-item-actions');
      actions.appendChild(actionButton(i18n('search.item.move_group_up'), 'up'));
      actions.appendChild(actionButton(i18n('search.item.move_group_down'), 'down'));
      actions.appendChild(actionButton(i18n('search.item.remove_group'), 'remove'));
      card.appendChild(actions);
      group.appendChild(card);
      list.appendChild(group);

      const children = data && Array.isArray(data.criteria) ? data.criteria : [];
      children.forEach(function (child) {
        if (child && Array.isArray(child.criteria)) {
          createGroup(child, childList, depth + 1, false);
        } else {
          createCriterion(child || {}, childList, depth, false, false);
        }
      });
      if (children.length === 0) {
        createCriterion({}, childList, depth, false, false);
      }

      relation.control.addEventListener('change', updateSummary);
      addChild.addEventListener('click', function () {
        if (countCriteria() >= maxCriteria) {
          announce(i18n('search.limit.criteria', { count: maxCriteria }));
          return;
        }
        createCriterion({}, childList, depth, false, true);
      });
      addNestedGroup.addEventListener('click', function () {
        if (depth >= maxDepth) {
          announce(i18n('search.limit.depth'));
          return;
        }
        if (countCriteria() >= maxCriteria) {
          announce(i18n('search.limit.criteria', { count: maxCriteria }));
          return;
        }
        createGroup({}, childList, depth + 1, true);
      });
      bindItemActions(group);
      reindexAll();
      if (focusNew) {
        heading.focus();
        announce(i18n('search.status.group_added', { depth: depth }));
      }
      return group;
    }

    function createSort(data, focusNew) {
      if (!(sortsList instanceof HTMLElement)) {
        return null;
      }
      const sortable = normalizedOptions(catalogOptions).filter(function (option) {
        return option.sortable === true || option.sortable === 1;
      });
      if (sortable.length === 0) {
        return null;
      }
      const item = createElement('li', 'glpiacessivel-advanced-sort-item');
      item.dataset.advancedKind = 'sort';
      const card = createElement('div', 'glpiacessivel-advanced-search-card');
      card.setAttribute('role', 'group');
      const heading = createElement('h5', '', i18n('search.item.sort'));
      heading.tabIndex = -1;
      heading.dataset.advancedItemHeading = '1';
      heading.id = 'advanced-search-sort-' + (++controlSequence);
      card.setAttribute('aria-labelledby', heading.id);
      card.appendChild(heading);

      const fields = createElement('div', 'glpiacessivel-advanced-search-fields');
      const field = labeledSelect(
        i18n('search.item.sort_field'),
        'sort-field',
        sortable.map(function (option) {
          return {
            value: option.id,
            label: optionCategory(option) + ' - ' + (option.label || option.field || option.id),
          };
        }),
        data && data.field || ''
      );
      const direction = labeledSelect(
        i18n('search.item.sort_direction'),
        'sort-direction',
        [
          { value: 'ASC', label: i18n('search.item.sort_ascending') },
          { value: 'DESC', label: i18n('search.item.sort_descending') },
        ],
        data && data.direction || 'ASC'
      );
      fields.appendChild(field.wrapper);
      fields.appendChild(direction.wrapper);
      card.appendChild(fields);

      const actions = createElement('div', 'glpiacessivel-advanced-search-item-actions');
      actions.appendChild(actionButton(i18n('search.item.sort_increase_priority'), 'up'));
      actions.appendChild(actionButton(i18n('search.item.sort_decrease_priority'), 'down'));
      actions.appendChild(actionButton(i18n('search.item.remove_sort'), 'remove'));
      card.appendChild(actions);
      item.appendChild(card);
      sortsList.appendChild(item);
      item.addEventListener('change', updateSummary);
      bindItemActions(item);
      reindexAll();
      if (focusNew) {
        field.control.focus();
        announce(i18n('search.status.sort_added'));
      }
      return item;
    }

    function countCriteria() {
      return advancedForm.querySelectorAll('[data-advanced-kind="criterion"]').length;
    }

    function countMetaCriteria() {
      return advancedForm.querySelectorAll('[data-advanced-kind="global"]').length;
    }

    function updateFirstRulePresentation(item, index) {
      const relation = item.querySelector('[data-advanced-role=link]');
      if (!(relation instanceof HTMLSelectElement)) {
        return;
      }
      const wrapper = relation.parentElement;
      if (!(wrapper instanceof HTMLElement)) {
        return;
      }
      const label = wrapper.querySelector('label');
      let marker = wrapper.querySelector('[data-advanced-first-rule]');
      if (!(marker instanceof HTMLElement)) {
        marker = createElement(
          'span',
          'glpiacessivel-advanced-first-rule',
          i18n('search.item.first_rule')
        );
        marker.dataset.advancedFirstRule = '1';
        wrapper.appendChild(marker);
      }
      const isFirst = index === 0;
      marker.hidden = !isFirst;
      relation.hidden = isFirst;
      if (label instanceof HTMLElement) {
        label.hidden = isFirst;
      }
    }

    function reindexCriteria(list, prefix, depth) {
      directItems(list).forEach(function (item, index) {
        const itemPrefix = prefix + '[' + index + ']';
        const relation = item.querySelector('[data-advanced-role="link"]');
        if (relation instanceof HTMLSelectElement) {
          relation.name = itemPrefix + '[link]';
        }
        updateFirstRulePresentation(item, index);
        if (item.dataset.advancedKind === 'group') {
          const childList = item.querySelector('[data-advanced-child-list]');
          if (childList instanceof HTMLElement) {
            reindexCriteria(childList, itemPrefix + '[criteria]', depth + 1);
          }
          return;
        }
        ['itemtype', 'field', 'searchtype', 'value'].forEach(function (role) {
          const control = item.querySelector(
            '[data-advanced-role="' + role + '"]'
          );
          if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement) {
            control.name = itemPrefix + '[' + role + ']';
          }
        });
      });
    }

    function reindexSorts() {
      if (!(sortsList instanceof HTMLElement)) {
        return;
      }
      directItems(sortsList).forEach(function (item, index) {
        const field = item.querySelector('[data-advanced-role="sort-field"]');
        const direction = item.querySelector('[data-advanced-role="sort-direction"]');
        if (field instanceof HTMLSelectElement) {
          field.name = 'advanced[sorts][' + index + '][field]';
        }
        if (direction instanceof HTMLSelectElement) {
          direction.name = 'advanced[sorts][' + index + '][direction]';
        }
      });
    }

    function updateActionState(list) {
      const items = directItems(list);
      items.forEach(function (item, index) {
        const up = item.querySelector('[data-advanced-action="up"]');
        const down = item.querySelector('[data-advanced-action="down"]');
        const remove = item.querySelector('[data-advanced-action="remove"]');
        if (up instanceof HTMLButtonElement) {
          up.disabled = !editable || index === 0;
        }
        if (down instanceof HTMLButtonElement) {
          down.disabled = !editable || index === items.length - 1;
        }
        if (remove instanceof HTMLButtonElement) {
          remove.disabled = !editable;
        }
        const childList = item.querySelector('[data-advanced-child-list]');
        if (childList instanceof HTMLElement) {
          updateActionState(childList);
        }
      });
    }

    function labelItemActions(item, itemName) {
      const up = item.querySelector('[data-advanced-action="up"]');
      const down = item.querySelector('[data-advanced-action="down"]');
      const remove = item.querySelector('[data-advanced-action="remove"]');
      if (up instanceof HTMLButtonElement) {
        up.setAttribute('aria-label', i18n('search.action.move_item_up', { item: itemName }));
      }
      if (down instanceof HTMLButtonElement) {
        down.setAttribute('aria-label', i18n('search.action.move_item_down', { item: itemName }));
      }
      if (remove instanceof HTMLButtonElement) {
        remove.setAttribute('aria-label', i18n('search.action.remove_item', { item: itemName }));
      }
    }

    function updateAdvancedRulesDisclosure() {
      if (!(advancedRulesDetails instanceof HTMLDetailsElement)) {
        return;
      }
      const disclosure = Array.from(advancedRulesDetails.children).find(function (child) {
        return child instanceof HTMLElement && child.tagName === 'SUMMARY';
      });
      if (!(disclosure instanceof HTMLElement)) {
        return;
      }
      const ruleCount = countCriteria() + countMetaCriteria();
      if (advancedRuleCount instanceof HTMLElement) {
        advancedRuleCount.textContent = ruleCount + ' ' + i18n(
          ruleCount === 1
            ? 'search.disclosure.one_rule_short'
            : 'search.disclosure.many_rules_short'
        );
      }
      disclosure.setAttribute(
        'aria-label',
        i18n('search.disclosure.advanced', {
          count: ruleCount,
          rules: i18n(
            ruleCount === 1
              ? 'search.disclosure.one_rule'
              : 'search.disclosure.many_rules'
          ),
        })
      );
    }

    function reindexAll() {
      if (criteriaList instanceof HTMLElement) {
        reindexCriteria(criteriaList, 'advanced[criteria]', 0);
        updateActionState(criteriaList);
      }
      if (globalRulesList instanceof HTMLElement) {
        reindexCriteria(globalRulesList, 'advanced[global_rules]', 0);
        updateActionState(globalRulesList);
      }
      reindexSorts();
      if (sortsList instanceof HTMLElement) {
        updateActionState(sortsList);
      }

      const criteria = Array.from(
        advancedForm.querySelectorAll('[data-advanced-kind="criterion"]')
      );
      criteria.forEach(function (item, index) {
        const heading = item.querySelector('[data-advanced-item-heading]');
        if (heading instanceof HTMLElement) {
          heading.textContent = i18n('search.item.criterion_number', {
            position: index + 1,
            total: criteria.length,
          });
          labelItemActions(item, heading.textContent);
        }
      });
      const globalRules = Array.from(
        advancedForm.querySelectorAll('[data-advanced-kind="global"]')
      );
      globalRules.forEach(function (item, index) {
        const heading = item.querySelector('[data-advanced-item-heading]');
        if (heading instanceof HTMLElement) {
          heading.textContent = i18n('search.item.global_number', {
            position: index + 1,
            total: globalRules.length,
          });
          labelItemActions(item, heading.textContent);
        }
      });
      const groups = Array.from(
        advancedForm.querySelectorAll('[data-advanced-kind="group"]')
      );
      groups.forEach(function (item, index) {
        const heading = item.querySelector('[data-advanced-item-heading]');
        const depth = Number(item.dataset.advancedDepth) || 1;
        if (heading instanceof HTMLElement) {
          heading.textContent = i18n('search.item.group_number', {
            position: index + 1,
            depth: depth,
          });
          labelItemActions(item, heading.textContent);
        }
      });
      const sorts = Array.from(
        advancedForm.querySelectorAll('[data-advanced-kind="sort"]')
      );
      sorts.forEach(function (item, index) {
        const heading = item.querySelector('[data-advanced-item-heading]');
        if (heading instanceof HTMLElement) {
          heading.textContent = i18n('search.item.sort_number', {
            position: index + 1,
            total: sorts.length,
          });
          labelItemActions(item, heading.textContent);
        }
      });

      if (addCriterionButton instanceof HTMLButtonElement) {
        addCriterionButton.disabled = !editable
          || countCriteria() >= maxCriteria
          || searchableOptions(catalogOptions).length === 0;
      }
      if (addGroupButton instanceof HTMLButtonElement) {
        addGroupButton.disabled = !editable
          || countCriteria() >= maxCriteria
          || searchableOptions(catalogOptions).length === 0;
      }
      if (addGlobalRuleButton instanceof HTMLButtonElement) {
        addGlobalRuleButton.disabled = !editable
          || countMetaCriteria() >= maxMetaCriteria
          || metaCatalogs.filter(function (entry) {
            return searchableOptions(entry && entry.options).length > 0;
          }).length === 0;
      }
      if (addSortButton instanceof HTMLButtonElement) {
        addSortButton.disabled = !editable
          || directItems(sortsList).length >= maxSorts
          || normalizedOptions(catalogOptions).filter(function (option) {
            return option.sortable === true || option.sortable === 1;
          }).length === 0;
      }
      updateAdvancedRulesDisclosure();
      updateSummary();
    }

    function criterionText(item) {
      const relation = item.querySelector('[data-advanced-role="link"]');
      const itemtype = item.querySelector('[data-advanced-role="itemtype"]');
      const field = item.querySelector('[data-advanced-role="field"]');
      const operator = item.querySelector('[data-advanced-role="searchtype"]');
      const value = item.querySelector('[data-advanced-role="value"]');
      const remoteValue = item.querySelector('[data-advanced-remote-input]');
      const parts = [];
      if (relation instanceof HTMLSelectElement) {
        const parentList = item.parentElement;
        const isFirst = parentList instanceof HTMLElement
          && directItems(parentList)[0] === item;
        parts.push(isFirst ? i18n('search.summary.first_rule') : selectedText(relation));
      }
      if (itemtype instanceof HTMLSelectElement) {
        parts.push(selectedText(itemtype) + ':');
      }
      if (field instanceof HTMLSelectElement) {
        parts.push(selectedText(field));
      }
      if (operator instanceof HTMLSelectElement) {
        parts.push(selectedText(operator));
      }
      if (
        value instanceof HTMLInputElement
        && value.type === 'hidden'
        && value.value.trim() !== ''
        && remoteValue instanceof HTMLInputElement
      ) {
        parts.push(remoteValue.value.trim() || value.value.trim());
      } else if (
        value instanceof HTMLInputElement
        && value.type !== 'hidden'
        && value.value.trim() !== ''
      ) {
        parts.push(value.value.trim());
      } else if (value instanceof HTMLSelectElement) {
        parts.push(selectedText(value));
      }
      return parts.join(' ');
    }

    function listText(list) {
      return directItems(list).map(function (item) {
        if (item.dataset.advancedKind === 'group') {
          const relation = item.querySelector('[data-advanced-role="link"]');
          const childList = item.querySelector('[data-advanced-child-list]');
          const isFirst = directItems(list)[0] === item;
          const relationText = relation instanceof HTMLSelectElement
            ? (isFirst ? i18n('search.summary.first_rule') : selectedText(relation))
            : '';
          const groupText = i18n('search.summary.group_expression', {
            value: childList instanceof HTMLElement ? listText(childList) : '',
          });
          return [relationText, groupText].filter(Boolean).join(' ');
        }
        return criterionText(item);
      }).filter(Boolean).join('; ');
    }

    function updateFilterLayerSummary() {
      let frequentCount = 0;
      const descriptions = [];
      const scopeControl = advancedForm.querySelector('select[name="scope"]');
      const statusControl = advancedForm.querySelector('select[name="status"]');
      const groupControl = advancedForm.querySelector('select[name="group_id"]');
      if (
        scopeControl instanceof HTMLSelectElement
        && scopeControl.value !== ''
        && scopeControl.value !== 'all'
      ) {
        frequentCount += 1;
        descriptions.push(i18n('search.summary.scope_lower', {
          value: selectedText(scopeControl),
        }));
      }
      if (statusControl instanceof HTMLSelectElement && statusControl.value !== '') {
        frequentCount += 1;
        descriptions.push(i18n('search.summary.status_lower', {
          value: selectedText(statusControl),
        }));
      }
      if (
        groupControl instanceof HTMLSelectElement
        && groupControl.value !== ''
        && groupControl.value !== '0'
      ) {
        frequentCount += 1;
        descriptions.push(i18n('search.summary.group_lower', {
          value: selectedText(groupControl),
        }));
      }
      const advancedCount = (criteriaList instanceof HTMLElement
        ? directItems(criteriaList).length
        : 0) + (globalRulesList instanceof HTMLElement
        ? directItems(globalRulesList).length
        : 0);
      const configuredCount = frequentCount + advancedCount;
      if (filterLayerState instanceof HTMLElement) {
        filterLayerState.textContent = i18n('search.summary.configured', {
          count: configuredCount,
        });
      }
      const filtersTrigger = triggerForSearchTool('filters');
      if (filtersTrigger instanceof HTMLElement) {
        const detail = descriptions.length > 0 ? '. ' + descriptions.join('; ') : '';
        filtersTrigger.setAttribute(
          'aria-label',
          i18n('search.summary.filters', {
            count: configuredCount,
            detail: detail,
          })
        );
      }
    }

    function updateResultOptionsSummary() {
      const sortCount = sortsList instanceof HTMLElement ? directItems(sortsList).length : 0;
      const pageSize = pageSizeControl instanceof HTMLSelectElement
        ? pageSizeControl.value
        : '20';
      const grouping = groupingControl instanceof HTMLSelectElement
        ? selectedText(groupingControl)
        : i18n('search.summary.none_grouping');
      const deleted = advancedForm.querySelector(
        'input[name="advanced[deleted_scope]"]:checked'
      );
      const deletedLabel = deleted instanceof HTMLInputElement && deleted.value === 'deleted'
        ? i18n('search.summary.deleted_tickets')
        : i18n('search.summary.active_tickets');
      const selectedColumns = selectedColumnIdentifiers();
      const columnCount = selectedColumnCount();
      let configuredCount = sortCount;
      if (pageSize !== '20') {
        configuredCount += 1;
      }
      if (groupingControl instanceof HTMLSelectElement && groupingControl.value !== 'none') {
        configuredCount += 1;
      }
      if (deleted instanceof HTMLInputElement && deleted.value === 'deleted') {
        configuredCount += 1;
      }
      if (selectedColumns.join('\u0000') !== configuredDefaultColumns.join('\u0000')) {
        configuredCount += 1;
      }
      const resultOptionsText = i18n('search.summary.result_options', {
        sorts: sortCount,
        page_size: pageSize,
        grouping: grouping,
        records: deletedLabel,
        columns: columnCount,
      });
      if (resultOptionsSummary instanceof HTMLElement) {
        resultOptionsSummary.textContent = resultOptionsText;
      }
      if (displayLayerState instanceof HTMLElement) {
        displayLayerState.textContent = i18n('search.summary.options', {
          count: configuredCount,
        });
      }
      const resultOptionsTrigger = triggerForSearchTool('result-options');
      if (resultOptionsTrigger instanceof HTMLElement) {
        resultOptionsTrigger.setAttribute(
          'aria-label',
          i18n('search.summary.result_options_aria', { summary: resultOptionsText })
        );
      }
    }

    function updateSummary() {
      updateFilterLayerSummary();
      updateResultOptionsSummary();
      if (!(summary instanceof HTMLElement)) {
        return;
      }
      const parts = [];
      const textControl = advancedForm.querySelector(
        'input[name="advanced[text]"], input[name="q"]'
      );
      if (textControl instanceof HTMLInputElement && textControl.value.trim() !== '') {
        parts.push(i18n('search.summary.text', { value: textControl.value.trim() }));
      }
      const scopeControl = advancedForm.querySelector(
        'select[name="scope"], select[name="advanced[scope]"]'
      );
      if (
        scopeControl instanceof HTMLSelectElement
        && scopeControl.value !== ''
        && scopeControl.value !== 'all'
      ) {
        parts.push(i18n('search.summary.scope', { value: selectedText(scopeControl) }));
      }
      const statusControl = advancedForm.querySelector('select[name="status"]');
      if (statusControl instanceof HTMLSelectElement && statusControl.value !== '') {
        parts.push(i18n('search.summary.status', { value: selectedText(statusControl) }));
      }
      const groupControl = advancedForm.querySelector('select[name="group_id"]');
      if (
        groupControl instanceof HTMLSelectElement
        && groupControl.value !== ''
        && groupControl.value !== '0'
      ) {
        parts.push(i18n('search.summary.group', { value: selectedText(groupControl) }));
      }
      if (criteriaList instanceof HTMLElement && directItems(criteriaList).length > 0) {
        parts.push(listText(criteriaList));
      }
      if (
        globalRulesList instanceof HTMLElement
        && directItems(globalRulesList).length > 0
      ) {
        parts.push(i18n('search.summary.global_rules', { value: listText(globalRulesList) }));
      }
      if (sortsList instanceof HTMLElement && directItems(sortsList).length > 0) {
        const sortText = directItems(sortsList).map(function (item) {
          const field = item.querySelector('[data-advanced-role="sort-field"]');
          const direction = item.querySelector('[data-advanced-role="sort-direction"]');
          return (field instanceof HTMLSelectElement ? selectedText(field) : '')
            + ' '
            + (direction instanceof HTMLSelectElement ? selectedText(direction) : '');
        }).join('; ');
        parts.push(i18n('search.summary.sort', { value: sortText }));
      }
      if (
        groupingControl instanceof HTMLSelectElement
        && groupingControl.value !== ''
        && groupingControl.value !== 'none'
      ) {
        parts.push(i18n('search.summary.grouping', { value: selectedText(groupingControl) }));
      }
      if (pageSizeControl instanceof HTMLSelectElement && pageSizeControl.value !== '20') {
        parts.push(i18n('search.summary.page_size', { value: pageSizeControl.value }));
      }
      const selectedColumns = selectedColumnIdentifiers();
      if (selectedColumns.join('\u0000') !== configuredDefaultColumns.join('\u0000')) {
        parts.push(i18n('search.summary.columns', { count: selectedColumns.length }));
      }
      const deleted = advancedForm.querySelector(
        'input[name="advanced[deleted_scope]"]:checked'
      );
      if (deleted instanceof HTMLInputElement && deleted.value === 'deleted') {
        parts.push(i18n('search.summary.only_deleted'));
      }
      summary.textContent = parts.length > 0
        ? parts.join('. ') + '.'
        : i18n('search.summary.none');
    }

    function clearInvalidState() {
      advancedForm.querySelectorAll('[aria-invalid], [aria-errormessage]').forEach(
        function (control) {
          control.removeAttribute('aria-invalid');
          control.removeAttribute('aria-errormessage');
        }
      );
    }

    function validationErrors() {
      const errors = [];
      clearInvalidState();

      if (countCriteria() > maxCriteria) {
        errors.push({
          message: i18n('search.validation.criteria_limit'),
          element: addCriterionButton,
        });
      }
      if (countMetaCriteria() > maxMetaCriteria) {
        errors.push({
          message: i18n('search.validation.global_limit'),
          element: addGlobalRuleButton,
        });
      }
      let criterionNumber = 0;
      let globalNumber = 0;
      advancedForm.querySelectorAll(
        '[data-advanced-kind=criterion], [data-advanced-kind=global]'
      ).forEach(function (item) {
        const globalRule = item.dataset.advancedKind === 'global';
        const number = globalRule ? ++globalNumber : ++criterionNumber;
        const contextLabel = i18n(
          globalRule ? 'search.validation.context_global' : 'search.validation.context_criterion',
          { number: number }
        );
        const field = item.querySelector('[data-advanced-role=field]');
        const operator = item.querySelector('[data-advanced-role=searchtype]');
        const valueContext = valueControlContext(item);
        const value = valueContext.submittedControl;
        const valueTarget = valueContext.focusControl instanceof HTMLElement
          ? valueContext.focusControl
          : value;
        if (!(field instanceof HTMLSelectElement) || field.value === '') {
          errors.push({
            message: i18n('search.validation.field', { context: contextLabel }),
            element: field,
          });
        }
        if (!(operator instanceof HTMLSelectElement) || operator.value === '') {
          errors.push({
            message: i18n('search.validation.condition', { context: contextLabel }),
            element: operator,
          });
        } else if (valueContext.required && (
          !(value instanceof HTMLInputElement || value instanceof HTMLSelectElement)
          || value.value.trim() === ''
        )) {
          errors.push({
            message: i18n(
              valueContext.remote
                ? 'search.validation.remote_value'
                : 'search.validation.value',
              { context: contextLabel }
            ),
            element: valueTarget,
          });
        } else if (
          valueContext.remote
          && valueContext.focusControl instanceof HTMLInputElement
          && valueContext.focusControl.dataset.advancedRemoteFallback === '1'
          && value instanceof HTMLInputElement
          && value.value.trim() !== ''
          && !/^\d{1,10}$/.test(value.value.trim())
        ) {
          errors.push({
            message: i18n('search.validation.numeric_id', { context: contextLabel }),
            element: valueTarget,
          });
        }
      });
      advancedForm.querySelectorAll('[data-advanced-kind="group"]').forEach(
        function (group) {
          const childList = group.querySelector('[data-advanced-child-list]');
          if (!(childList instanceof HTMLElement) || directItems(childList).length === 0) {
            errors.push({
              message: i18n('search.validation.empty_group'),
              element: group.querySelector('[data-advanced-add-child]'),
            });
          }
        }
      );
      if (sortsList instanceof HTMLElement && directItems(sortsList).length > maxSorts) {
        errors.push({
          message: i18n('search.validation.sort_limit'),
          element: addSortButton,
        });
      }
      errors.forEach(function (error) {
        if (
          error.element instanceof HTMLElement
          && error.element.matches('input, select, textarea')
        ) {
          error.element.setAttribute('aria-invalid', 'true');
        }
      });
      return errors;
    }

    function revealAndFocusControl(control) {
      const toolPanel = control instanceof HTMLElement
        ? control.closest('[data-glpiacessivel-search-tool-panel]')
        : null;
      if (toolPanel instanceof HTMLElement && toolPanel.hidden) {
        openSearchTool(toolPanel.dataset.glpiacessivelSearchToolPanel || '', false);
      }
      let ancestor = control instanceof HTMLElement ? control.parentElement : null;
      while (ancestor instanceof HTMLElement) {
        if (ancestor instanceof HTMLDetailsElement) {
          ancestor.open = true;
        }
        ancestor = ancestor.parentElement;
      }
      window.requestAnimationFrame(function () {
        if (!(control instanceof HTMLElement) || !control.isConnected) {
          return;
        }
        try {
          control.focus({ preventScroll: true });
        } catch (error) {
          control.focus();
        }
        if (typeof control.scrollIntoView === 'function') {
          control.scrollIntoView({ block: 'center' });
        }
      });
    }

    function showErrors(errors) {
      if (!(errorPanel instanceof HTMLElement)) {
        return;
      }
      const list = errorPanel.querySelector('ul');
      if (!(list instanceof HTMLElement)) {
        return;
      }
      list.textContent = '';
      errors.forEach(function (error) {
        const item = document.createElement('li');
        item.id = 'advanced-search-error-' + (++controlSequence);
        if (error.element instanceof HTMLElement) {
          if (error.element.matches('input, select, textarea')) {
            error.element.setAttribute('aria-errormessage', item.id);
          }
          if (!error.element.id) {
            error.element.id = 'advanced-search-error-control-' + (++controlSequence);
          }
          const link = document.createElement('a');
          link.href = '#' + error.element.id;
          link.textContent = error.message;
          link.addEventListener('click', function (event) {
            event.preventDefault();
            revealAndFocusControl(error.element);
          });
          item.appendChild(link);
        } else {
          item.textContent = error.message;
        }
        list.appendChild(item);
      });
      errorPanel.hidden = errors.length === 0;
      if (errors.length > 0) {
        errorPanel.focus();
        announce(i18n(
          errors.length === 1
            ? 'search.validation.one_error'
            : 'search.validation.many_errors',
          { count: errors.length }
        ));
      }
    }

    if (criteriaList instanceof HTMLElement) {
      const initialCriteria = Array.isArray(config.criteria) ? config.criteria : [];
      initialCriteria.forEach(function (criterion) {
        if (criterion && Array.isArray(criterion.criteria)) {
          createGroup(criterion, criteriaList, 1, false);
        } else {
          createCriterion(criterion || {}, criteriaList, 0, false, false);
        }
      });

    }

    if (globalRulesList instanceof HTMLElement) {
      const initialMeta = Array.isArray(config.metacriteria)
        ? config.metacriteria
        : [];
      initialMeta.forEach(function (criterion) {
        createCriterion(criterion || {}, globalRulesList, 0, true, false);
      });
    }

    const initialSort = Array.isArray(config.sort) ? config.sort : [];
    const initialOrder = Array.isArray(config.order) ? config.order : [];
    initialSort.slice(0, maxSorts).forEach(function (field, index) {
      createSort({
        field: field,
        direction: initialOrder[index] || 'ASC',
      }, false);
    });

    bindColumnDialog();

    if (advancedRulesDetails instanceof HTMLDetailsElement) {
      advancedRulesDetails.addEventListener('toggle', function () {
        updateAdvancedRulesDisclosure();
      });
    }

    if (addCriterionButton instanceof HTMLButtonElement) {
      addCriterionButton.addEventListener('click', function () {
        if (countCriteria() >= maxCriteria) {
          announce(i18n('search.limit.criteria', { count: maxCriteria }));
          return;
        }
        createCriterion({}, criteriaList, 0, false, true);
      });
    }
    if (addGroupButton instanceof HTMLButtonElement) {
      addGroupButton.addEventListener('click', function () {
        if (countCriteria() >= maxCriteria) {
          announce(i18n('search.limit.criteria', { count: maxCriteria }));
          return;
        }
        createGroup({}, criteriaList, 1, true);
      });
    }
    if (addGlobalRuleButton instanceof HTMLButtonElement) {
      addGlobalRuleButton.addEventListener('click', function () {
        if (countMetaCriteria() >= maxMetaCriteria) {
          announce(i18n('search.limit.global_rules', { count: maxMetaCriteria }));
          return;
        }
        createCriterion({}, globalRulesList, 0, true, true);
      });
    }
    if (addSortButton instanceof HTMLButtonElement) {
      addSortButton.addEventListener('click', function () {
        if (directItems(sortsList).length >= maxSorts) {
          announce(i18n('search.limit.sorts', { count: maxSorts }));
          return;
        }
        createSort({}, true);
      });
    }

    advancedForm.addEventListener('input', updateSummary);
    advancedForm.addEventListener('change', updateSummary);
    advancedForm.addEventListener('submit', function (event) {
      reindexAll();
      const errors = validationErrors();
      if (!editable || errors.length > 0) {
        event.preventDefault();
        showErrors(errors.length > 0 ? errors : [{
          message: i18n('search.validation.not_editable'),
          element: null,
        }]);
        return;
      }
      showErrors([]);
      announce(i18n('search.validation.submitting'));
    });

    reindexAll();

    if (!editable) {
      advancedForm.querySelectorAll('input:not([type="hidden"]), select').forEach(
        function (control) {
          control.disabled = true;
        }
      );
    }

    if (searchableOptions(catalogOptions).length === 0) {
      const submit = advancedForm.querySelector('button[type="submit"]');
      if (submit instanceof HTMLButtonElement) {
        submit.disabled = true;
      }
      if (summary instanceof HTMLElement) {
        summary.textContent = i18n('search.validation.catalog_unavailable');
      }
    }

  }




  function bindNativeSavedSearchCatalog(liveRegion) {
    const openers = Array.from(document.querySelectorAll('[data-glpiacessivel-native-delete-open]'));
    openers.forEach(function (opener) {
      if (!(opener instanceof HTMLButtonElement)) {
        return;
      }
      const panelId = opener.getAttribute('aria-controls') || '';
      const panel = panelId !== '' ? document.getElementById(panelId) : null;
      if (!(panel instanceof HTMLElement)) {
        return;
      }
      const cancel = panel.querySelector('[data-glpiacessivel-native-delete-cancel]');
      const heading = panel.querySelector('[tabindex="-1"]');
      const confirmation = panel.querySelector('input[name="confirm_delete"]');

      function announce(message) {
        if (liveRegion && message) {
          liveRegion.textContent = '';
          window.requestAnimationFrame(function () {
            liveRegion.textContent = message;
          });
        }
      }

      function closePanel() {
        panel.hidden = true;
        opener.setAttribute('aria-expanded', 'false');
        if (confirmation instanceof HTMLInputElement) {
          confirmation.checked = false;
        }
        announce(panel.dataset.cancelAnnouncement || '');
        opener.focus();
      }

      opener.addEventListener('click', function () {
        panel.hidden = false;
        opener.setAttribute('aria-expanded', 'true');
        announce(opener.dataset.openAnnouncement || '');
        window.requestAnimationFrame(function () {
          if (heading instanceof HTMLElement) {
            heading.focus();
          }
        });
      });

      if (cancel instanceof HTMLButtonElement) {
        cancel.addEventListener('click', closePanel);
      }
      panel.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
          event.preventDefault();
          closePanel();
        }
      });
    });
  }

  const GLPIACESSIVEL_PLUGIN_CARD_SELECTOR = "li.plugin[data-key='glpiacessivel']";
  const GLPIACESSIVEL_PLUGIN_CARD_OBSERVER_TIMEOUT_MS = 5000;

  function isGlpiPluginCatalogPage() {
    const path = String(window.location.pathname || '').toLowerCase();
    return /\/front\/(?:plugin|marketplace)\.php$/.test(path)
      || /\/marketplace(?:\/|$)/.test(path);
  }

  function pluginCardCandidates(root) {
    const cards = [];
    const seen = new Set();

    function add(card) {
      if (card instanceof HTMLElement && !seen.has(card)) {
        seen.add(card);
        cards.push(card);
      }
    }

    if (root instanceof Element) {
      add(root.matches(GLPIACESSIVEL_PLUGIN_CARD_SELECTOR) ? root : null);
      add(root.closest(GLPIACESSIVEL_PLUGIN_CARD_SELECTOR));
    } else if (root instanceof Node && root.parentElement) {
      add(root.parentElement.closest(GLPIACESSIVEL_PLUGIN_CARD_SELECTOR));
    }

    if (root && typeof root.querySelectorAll === 'function') {
      root.querySelectorAll(GLPIACESSIVEL_PLUGIN_CARD_SELECTOR).forEach(add);
    }

    return cards;
  }

  function replaceGlpi10PluginCardInitials(root, onSettled) {
    let handled = false;
    let pending = false;

    pluginCardCandidates(root).forEach(function (card) {
      if (card.dataset.glpiacessivelPluginLogoFailed === '1') {
        handled = true;
        return;
      }

      const icon = card.querySelector('.icon');
      if (!(icon instanceof HTMLElement)) {
        return;
      }
      const existingImage = card.querySelector('.icon > img');
      if (existingImage) {
        handled = true;
        pending = existingImage.dataset.glpiacessivelPluginLogoState === 'loading';
        return;
      }

      const walker = document.createTreeWalker(icon, NodeFilter.SHOW_TEXT);
      let initials = null;
      let match = null;
      while (walker.nextNode()) {
        const candidate = walker.currentNode;
        const candidateMatch = String(candidate.nodeValue || '').match(/^(\s*)GA(\s*)$/);
        if (candidateMatch) {
          initials = candidate;
          match = candidateMatch;
          break;
        }
      }
      if (!(initials instanceof Text) || !match || !initials.parentNode) {
        return;
      }

      handled = true;
      pending = true;
      const logo = document.createElement('img');
      logo.alt = '';
      logo.dataset.glpiacessivelPluginLogoFallback = '1';
      logo.dataset.glpiacessivelPluginLogoState = 'loading';
      logo.addEventListener('load', function () {
        logo.dataset.glpiacessivelPluginLogoState = 'loaded';
        if (typeof onSettled === 'function') {
          onSettled();
        }
      }, { once: true });
      logo.addEventListener('error', function () {
        card.dataset.glpiacessivelPluginLogoFailed = '1';
        if (logo.parentNode) {
          logo.replaceWith(document.createTextNode('GA'));
        }
        if (typeof onSettled === 'function') {
          onSettled();
        }
      }, { once: true });
      logo.src = pluginBasePath() + '/logo.png';

      const replacement = document.createDocumentFragment();
      if (match[1] !== '') {
        replacement.appendChild(document.createTextNode(match[1]));
      }
      replacement.appendChild(logo);
      if (match[2] !== '') {
        replacement.appendChild(document.createTextNode(match[2]));
      }
      initials.parentNode.replaceChild(replacement, initials);
    });

    return { handled: handled, pending: pending };
  }

  function bindPluginCardLogoFallback() {
    if (
      !isGlpiPluginCatalogPage()
      || window.__glpiacessivelPluginCardLogoFallbackBound
    ) {
      return;
    }
    window.__glpiacessivelPluginCardLogoFallbackBound = true;

    const initial = replaceGlpi10PluginCardInitials(document, null);
    if (initial.handled) {
      return;
    }
    const targetCard = document.querySelector(GLPIACESSIVEL_PLUGIN_CARD_SELECTOR);
    const firstPluginCard = document.querySelector('li.plugin');
    const observationRoot = targetCard
      || document.querySelector('#plugins, .plugins, [data-glpi-plugin-list]')
      || (firstPluginCard instanceof HTMLElement ? firstPluginCard.parentElement : null)
      || document.querySelector('main');
    if (typeof MutationObserver !== 'function' || !(observationRoot instanceof HTMLElement)) {
      return;
    }

    let settled = false;
    let timeoutId = 0;
    const observer = new MutationObserver(function (records) {
      records.forEach(function (record) {
        record.addedNodes.forEach(function (node) {
          if (settled) {
            return;
          }
          const result = replaceGlpi10PluginCardInitials(node, stopObserving);
          if (result.handled && !result.pending) {
            stopObserving();
          }
        });
      });
    });

    function stopObserving() {
      if (settled) {
        return;
      }
      settled = true;
      observer.disconnect();
      if (timeoutId) {
        window.clearTimeout(timeoutId);
      }
      window.__glpiacessivelPluginCardLogoObserver = null;
    }

    observer.observe(observationRoot, { childList: true, subtree: true });
    timeoutId = window.setTimeout(
      stopObserving,
      GLPIACESSIVEL_PLUGIN_CARD_OBSERVER_TIMEOUT_MS
    );
    window.__glpiacessivelPluginCardLogoObserver = observer;
  }
  function refreshFloatingUi() {
    ensureFloatingButtonStyles();
    addPortalButton();
    addChatbotButton();
    setShortcutMetadata();
  }

  function start() {
    bindPluginCardLogoFallback();
    const liveRegion = addLiveRegion();
    bindSubmitAnnouncements(liveRegion);
    bindCriticalConfirmations(liveRegion);
    bindModulePresetControls(liveRegion);
    bindPageShortcuts(liveRegion);
    bindTicketSelection(liveRegion);
    bindAdvancedTicketSearch(liveRegion);
    bindNativeSavedSearchCatalog(liveRegion);
    bindDynamicFormRenderer(liveRegion);
    bindNativeEmbeddedForms();
    bindAccessibilityShortcut(liveRegion);
    bindChatbotShortcut(liveRegion);
    loadRuntimeConfig().finally(function () {
      refreshFloatingUi();
      if (shouldLoadVlibrasWidget()) {
        window.setTimeout(ensureVlibrasWidget, 300);
      }
      window.setTimeout(refreshFloatingUi, 500);
      window.setTimeout(refreshFloatingUi, 1400);
    });

    window.addEventListener('online', function () {
      const state = window.__glpiacessivelVlibrasStatus && window.__glpiacessivelVlibrasStatus.status;
      if (['timeout', 'error', 'unavailable'].indexOf(state) === -1 || !shouldLoadVlibrasWidget()) {
        return;
      }
      clearVlibrasRetryCooldown();
      setVlibrasStatus('retrying');
      window.setTimeout(ensureVlibrasWidget, VLIBRAS_RETRY_DELAY_MS);
    });

    window.addEventListener('pageshow', refreshFloatingUi, { once: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
