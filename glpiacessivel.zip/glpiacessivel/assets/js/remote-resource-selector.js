(function (global) {
  'use strict';

  const instances = new WeakMap();
  let sequence = 0;
  const i18n = global.__glpiacessivelI18n && global.__glpiacessivelI18n.messages
    ? global.__glpiacessivelI18n.messages
    : null;

  function message(key, replacements) {
    if (!i18n || typeof i18n[key] !== 'string' || i18n[key] === '') {
      return '';
    }
    let value = i18n[key];
    Object.keys(replacements || {}).forEach(function (name) {
      value = value.split('{' + name + '}').join(String(replacements[name]));
    });
    return value;
  }

  function text(value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  }

  function create(tag, className, content) {
    const node = document.createElement(tag);
    if (className) {
      node.className = className;
    }
    if (content != null) {
      node.textContent = String(content);
    }
    return node;
  }

  function integer(value, fallback, min, max) {
    const number = Number(value);
    if (!Number.isFinite(number)) {
      return fallback;
    }
    return Math.max(min, Math.min(max, Math.floor(number)));
  }

  function readConfig(select) {
    const form = select.form;
    const source = form ? form.dataset : {};
    return {
      endpoint: text(select.dataset.resourceEndpoint || source.resourceSelectorUrl),
      csrfToken: text(select.dataset.resourceCsrf || source.resourceSelectorCsrf),
      contextRevision: text(
        select.dataset.resourceContextRevision || source.resourceSelectorContextRevision
      ),
      fallbackUrl: text(select.dataset.resourceFallbackUrl || source.resourceSelectorFallbackUrl),
      version: integer(
        select.dataset.resourceContractVersion || source.resourceSelectorVersion,
        1,
        1,
        1
      ),
      timeout: integer(
        select.dataset.resourceTimeout || source.resourceSelectorTimeout,
        5000,
        500,
        5000
      ),
      limit: integer(
        select.dataset.resourceLimit || source.resourceSelectorLimit,
        20,
        1,
        20
      ),
      minChars: integer(select.dataset.resourceMinChars, 0, 0, 10),
      browseEmpty: select.dataset.resourceBrowseEmpty === '1',
      emptyValue: Object.prototype.hasOwnProperty.call(select.dataset, 'resourceEmptyValue')
        ? String(select.dataset.resourceEmptyValue)
        : '',
      clearOnDependency: select.dataset.resourceClearOnDependency === '1',
    };
  }

  function selectedFromSelect(select, emptyValue) {
    return Array.from(select.options).filter(function (option) {
      return option.selected && option.value !== '' && option.value !== emptyValue;
    }).map(function (option) {
      return { id: String(option.value), label: text(option.textContent) || ('ID ' + option.value) };
    });
  }

  function dependenciesFor(select) {
    const result = {};
    text(select.dataset.resourceDependencies).split(',').forEach(function (entry) {
      const parts = entry.split(':');
      const name = text(parts.shift());
      const selector = text(parts.join(':'));
      const control = selector ? document.querySelector(selector) : null;
      if (name && (control instanceof HTMLInputElement || control instanceof HTMLSelectElement)) {
        result[name] = String(control.value || '');
      }
    });
    return result;
  }

  function normalizeItems(payload) {
    const raw = payload && Array.isArray(payload.items)
      ? payload.items
      : (payload && Array.isArray(payload.results) ? payload.results : []);
    const known = new Set();
    return raw.reduce(function (items, item) {
      if (!item || typeof item !== 'object') {
        return items;
      }
      const id = text(item.id != null ? item.id : item.value);
      const label = text(item.label != null ? item.label : item.name);
      if (!id || !label || known.has(id)) {
        return items;
      }
      known.add(id);
      items.push({
        id: id,
        label: label,
        description: text(item.description || item.context || item.complement),
      });
      return items;
    }, []);
  }

  class ResourceSelector {
    constructor(select) {
      this.select = select;
      this.form = select.form;
      this.config = readConfig(select);
      this.provider = text(select.dataset.resourceProvider);
      this.multiple = select.multiple;
      this.id = select.id || ('glpiacessivel-resource-' + (++sequence));
      this.label = this.select.labels && this.select.labels.length ? this.select.labels[0] : null;
      this.labelText = text(this.label ? this.label.textContent : this.provider)
        || message('selector.value.option');
      this.initialSelected = selectedFromSelect(select, this.config.emptyValue);
      this.selected = this.initialSelected.slice();
      this.results = [];
      this.activeIndex = -1;
      this.hasMore = false;
      this.nextCursor = '';
      this.total = null;
      this.query = '';
      this.requestSequence = 0;
      this.requestInFlight = false;
      this.abortController = null;
      this.debounceTimer = 0;
      this.timeoutTimer = 0;
      this.blurTimer = 0;
      this.build();
      this.bind();
      this.renderSelected();
    }

    build() {
      const inputId = this.id + '_remote_input';
      const listboxId = this.id + '_remote_listbox';
      const helpId = this.id + '_remote_help';
      const statusId = this.id + '_remote_status';
      const errorId = this.id + '_remote_error';
      const selectedId = this.id + '_remote_selected';
      const oldDescription = text(this.select.getAttribute('aria-describedby'));

      this.wrapper = create('div', 'glpiacessivel-resource-selector');
      this.wrapper.dataset.resourceSelectorEnhanced = '1';
      this.inputRow = create('div', 'glpiacessivel-resource-selector-input-row');
      this.input = create('input', 'glpiacessivel-resource-selector-input');
      this.input.type = 'text';
      this.input.id = inputId;
      this.input.autocomplete = 'off';
      this.input.spellcheck = false;
      this.input.maxLength = 120;
      this.input.setAttribute('role', 'combobox');
      this.input.setAttribute('aria-autocomplete', 'list');
      this.input.setAttribute('aria-haspopup', 'listbox');
      this.input.setAttribute('aria-expanded', 'false');
      this.input.setAttribute('aria-controls', listboxId);
      this.input.setAttribute(
        'aria-describedby',
        [oldDescription, helpId, statusId, errorId].filter(Boolean).join(' ')
      );
      this.input.setAttribute('aria-required', this.select.required ? 'true' : 'false');
      this.input.placeholder = this.config.browseEmpty
        ? message('selector.placeholder.choose_or_type')
        : message('selector.placeholder.type');

      this.clearButton = create(
        'button',
        'glpiacessivel-button glpiacessivel-button-secondary '
          + 'glpiacessivel-resource-selector-clear',
        message('button.clear')
      );
      this.clearButton.type = 'button';
      this.clearButton.setAttribute('aria-label', message('selector.action.clear', { label: this.labelText }));

      this.listbox = create('ul', 'glpiacessivel-resource-selector-listbox');
      this.listbox.id = listboxId;
      this.listbox.hidden = true;
      this.listbox.setAttribute('role', 'listbox');
      this.listbox.setAttribute('aria-label', message('selector.suggestions_for', { label: this.labelText }));

      this.actions = create('div', 'glpiacessivel-resource-selector-actions');
      this.moreButton = create(
        'button',
        'glpiacessivel-button glpiacessivel-button-secondary '
          + 'glpiacessivel-resource-selector-more',
        message('selector.action.load_more')
      );
      this.moreButton.type = 'button';
      this.moreButton.hidden = true;
      this.retryButton = create(
        'button',
        'glpiacessivel-button glpiacessivel-button-secondary '
          + 'glpiacessivel-resource-selector-retry',
        message('button.retry')
      );
      this.retryButton.type = 'button';
      this.retryButton.hidden = true;
      this.actions.appendChild(this.moreButton);
      this.actions.appendChild(this.retryButton);

      const minCharsText = this.config.minChars > 0
        ? message('selector.minimum_characters', { count: this.config.minChars }) + ' '
        : '';
      this.help = create(
        'p',
        'glpiacessivel-help-text glpiacessivel-resource-selector-help',
        minCharsText + message('selector.keyboard_help')
      );
      this.help.id = helpId;
      if (this.config.fallbackUrl) {
        const fallback = create('a', '', message('selector.action.open_glpi_flow'));
        fallback.href = this.config.fallbackUrl;
        this.help.appendChild(document.createTextNode(' '));
        this.help.appendChild(fallback);
      }

      this.status = create('p', 'glpiacessivel-resource-selector-status');
      this.status.id = statusId;
      this.status.setAttribute('role', 'status');
      this.status.setAttribute('aria-live', 'polite');
      this.status.setAttribute('aria-atomic', 'true');
      this.error = create('p', 'glpiacessivel-field-error glpiacessivel-resource-selector-error');
      this.error.id = errorId;
      this.error.hidden = true;

      this.selectedSummary = create('p', 'glpiacessivel-resource-selector-selected-summary');
      this.selectedList = create('ul', 'glpiacessivel-resource-selector-selected-list');
      this.selectedList.id = selectedId;
      this.selectedList.setAttribute('aria-label', message('selector.selected_list', { label: this.labelText }));

      this.inputRow.appendChild(this.input);
      if (!this.multiple) {
        this.inputRow.appendChild(this.clearButton);
      }
      this.wrapper.appendChild(this.inputRow);
      this.wrapper.appendChild(this.listbox);
      this.wrapper.appendChild(this.actions);
      if (this.multiple) {
        this.wrapper.appendChild(this.selectedSummary);
        this.wrapper.appendChild(this.selectedList);
      }
      this.wrapper.appendChild(this.help);
      this.wrapper.appendChild(this.error);
      this.wrapper.appendChild(this.status);

      this.select.parentNode.insertBefore(this.wrapper, this.select);
      this.select.dataset.glpiacessivelResourceEnhanced = '1';
      this.select.setAttribute('aria-hidden', 'true');
      this.select.tabIndex = -1;
      this.select.hidden = true;
      if (this.label) {
        this.label.htmlFor = inputId;
      }

      Array.from(this.select.options).forEach(function (option) {
        if (!option.selected && option.value !== '' && option.value !== this.config.emptyValue) {
          option.remove();
        }
      }, this);
    }

    bind() {
      const self = this;
      this.input.addEventListener('input', function () {
        self.cancelRequest();
        self.clearInvalid();
        self.results = [];
        self.hasMore = false;
        self.nextCursor = '';
        self.renderResults();
        self.close();
        self.schedule();
        syncFormValidationSummary(self.form);
      });
      this.input.addEventListener('focus', function () {
        if (self.results.length) {
          self.open();
          return;
        }
        self.schedule(true);
      });
      this.input.addEventListener('blur', function () {
        window.clearTimeout(self.blurTimer);
        self.blurTimer = window.setTimeout(function () {
          if (!self.wrapper.contains(document.activeElement)) {
            self.close();
          }
        }, 0);
      });
      this.input.addEventListener('keydown', function (event) {
        self.onKeydown(event);
      });
      this.listbox.addEventListener('mousedown', function (event) {
        event.preventDefault();
      });
      this.listbox.addEventListener('click', function (event) {
        const option = event.target instanceof Element
          ? event.target.closest('[data-resource-result-index]')
          : null;
        if (!(option instanceof HTMLElement)) {
          return;
        }
        const index = Number(option.dataset.resourceResultIndex);
        if (Number.isInteger(index) && self.results[index]) {
          self.confirm(self.results[index]);
          self.input.focus();
        }
      });
      this.moreButton.addEventListener('click', function () {
        if (!self.requestInFlight && self.hasMore) {
          self.request(true);
        }
      });
      this.retryButton.addEventListener('click', function () {
        if (!self.requestInFlight) {
          self.request(false);
        }
      });
      this.clearButton.addEventListener('click', function () {
        self.clearSelection(true);
        self.input.focus();
      });

      text(this.select.dataset.resourceDependencies).split(',').forEach(function (entry) {
        const selector = text(entry.split(':').slice(1).join(':'));
        const dependency = selector ? document.querySelector(selector) : null;
        if (dependency) {
          dependency.addEventListener('change', function () {
            self.cancelRequest();
            self.results = [];
            self.renderResults();
            self.close();
            if (self.config.clearOnDependency) {
              self.clearSelection(false);
              self.setStatus(message('selector.status.cleared_by_context', { label: self.labelText }));
            }
          });
        }
      });

      if (this.form) {
        this.form.addEventListener('reset', function () {
          window.setTimeout(function () {
            self.restoreInitial();
          }, 0);
        });
      }
    }

    setStatus(message) {
      this.status.textContent = text(message);
    }

    setBusy(busy) {
      this.requestInFlight = busy;
      if (busy) {
        this.input.setAttribute('aria-busy', 'true');
        this.listbox.setAttribute('aria-busy', 'true');
      } else {
        this.input.removeAttribute('aria-busy');
        this.listbox.removeAttribute('aria-busy');
      }
      this.moreButton.disabled = busy || !this.hasMore;
      this.retryButton.disabled = busy;
    }

    setInvalid(message) {
      this.input.setAttribute('aria-invalid', 'true');
      this.input.setAttribute('aria-errormessage', this.error.id);
      this.error.textContent = message;
      this.error.hidden = false;
    }

    clearInvalid() {
      this.input.removeAttribute('aria-invalid');
      this.input.removeAttribute('aria-errormessage');
      this.error.textContent = '';
      this.error.hidden = true;
    }

    close() {
      this.listbox.hidden = true;
      this.input.setAttribute('aria-expanded', 'false');
      this.input.removeAttribute('aria-activedescendant');
      this.activeIndex = -1;
      Array.from(this.listbox.querySelectorAll('[role="option"]')).forEach(function (node) {
        node.classList.remove('is-active');
      });
    }

    open() {
      if (!this.results.length) {
        this.close();
        return;
      }
      this.listbox.hidden = false;
      this.input.setAttribute('aria-expanded', 'true');
    }

    setActive(index) {
      if (!this.results.length) {
        return;
      }
      this.activeIndex = Math.max(0, Math.min(this.results.length - 1, index));
      const nodes = Array.from(this.listbox.querySelectorAll('[role="option"]'));
      nodes.forEach(function (node, optionIndex) {
        node.classList.toggle('is-active', optionIndex === this.activeIndex);
      }, this);
      const active = nodes[this.activeIndex];
      if (active) {
        this.input.setAttribute('aria-activedescendant', active.id);
        if (typeof active.scrollIntoView === 'function') {
          active.scrollIntoView({ block: 'nearest' });
        }
      }
    }

    renderResults() {
      const selectedIds = new Set(this.selected.map(function (item) { return item.id; }));
      this.listbox.textContent = '';
      this.results.forEach(function (result, index) {
        const option = create('li', 'glpiacessivel-resource-selector-option');
        option.id = this.listbox.id + '_option_' + index;
        option.dataset.resourceResultIndex = String(index);
        option.setAttribute('role', 'option');
        option.setAttribute('aria-selected', selectedIds.has(result.id) ? 'true' : 'false');
        option.setAttribute('aria-posinset', String(index + 1));
        option.setAttribute('aria-setsize', this.total == null ? '-1' : String(this.total));
        option.appendChild(create('span', 'glpiacessivel-resource-selector-option-label', result.label));
        if (result.description) {
          option.appendChild(create(
            'span',
            'glpiacessivel-resource-selector-option-description',
            result.description
          ));
        }
        this.listbox.appendChild(option);
      }, this);
      this.moreButton.hidden = !this.hasMore;
      this.moreButton.disabled = this.requestInFlight || !this.hasMore;
      this.activeIndex = -1;
      this.input.removeAttribute('aria-activedescendant');
    }

    renderSelected(focusIndex) {
      this.syncSelect();
      if (!this.multiple) {
        const confirmed = this.selected[0] || null;
        this.input.value = confirmed ? confirmed.label : '';
        this.clearButton.disabled = !confirmed;
        return;
      }
      this.selectedList.textContent = '';
      this.selectedSummary.textContent = this.selected.length
        ? message(this.selected.length === 1 ? 'selector.status.one_selected' : 'selector.status.many_selected', {
          count: this.selected.length,
          label: this.labelText
        })
        : message('selector.status.none_selected', { label: this.labelText });
      this.selected.forEach(function (selected, index) {
        const item = create('li', 'glpiacessivel-resource-selector-chip');
        item.appendChild(create('span', '', selected.label));
        const remove = create(
          'button',
          'glpiacessivel-resource-selector-remove',
          message('button.remove')
        );
        remove.type = 'button';
        remove.dataset.resourceSelectedIndex = String(index);
        remove.setAttribute('aria-label', message('selector.action.remove_named', {
          label: this.labelText,
          value: selected.label
        }));
        remove.addEventListener('click', function () {
          this.remove(index);
        }.bind(this));
        item.appendChild(remove);
        this.selectedList.appendChild(item);
      }, this);
      if (Number.isInteger(focusIndex)) {
        const buttons = this.selectedList.querySelectorAll('button');
        if (buttons.length) {
          buttons[Math.min(focusIndex, buttons.length - 1)].focus();
        } else {
          this.input.focus();
        }
      }
    }

    syncSelect() {
      const empty = Array.from(this.select.options).find(function (option) {
        return option.value === '' || option.value === this.config.emptyValue;
      }, this) || null;
      this.select.textContent = '';
      if (empty) {
        empty.selected = this.selected.length === 0;
        this.select.appendChild(empty);
      }
      this.selected.forEach(function (item) {
        const option = create('option', '', item.label);
        option.value = item.id;
        option.selected = true;
        this.select.appendChild(option);
      }, this);
      this.select.dispatchEvent(new Event('change', { bubbles: true }));
    }

    confirm(result) {
      if (!result) {
        return;
      }
      if (this.multiple) {
        if (!this.selected.some(function (item) { return item.id === result.id; })) {
          this.selected.push({ id: result.id, label: result.label });
        }
        this.input.value = '';
      } else {
        this.selected = [{ id: result.id, label: result.label }];
      }
      this.clearInvalid();
      this.renderSelected();
      this.results = this.multiple
        ? this.results.filter(function (item) { return item.id !== result.id; })
        : this.results;
      this.renderResults();
      this.close();
      this.setStatus(message('selector.status.selected', { value: result.label }));
      syncFormValidationSummary(this.form);
    }

    remove(index) {
      const removed = this.selected[index];
      if (!removed) {
        return;
      }
      this.selected.splice(index, 1);
      this.renderSelected(index);
      this.setStatus(
        message('selector.status.removed', {
          value: removed.label,
          count: this.selected.length
        })
      );
      syncFormValidationSummary(this.form);
    }

    clearSelection(announce) {
      this.selected = [];
      this.input.value = '';
      this.clearInvalid();
      this.renderSelected();
      if (announce) {
        this.setStatus(message('selector.status.selection_cleared', { label: this.labelText }));
      }
      syncFormValidationSummary(this.form);
    }

    restoreInitial() {
      this.cancelRequest();
      this.selected = this.initialSelected.slice();
      this.input.value = '';
      this.results = [];
      this.hasMore = false;
      this.renderResults();
      this.renderSelected();
      this.close();
      this.clearInvalid();
    }

    schedule(immediate) {
      window.clearTimeout(this.debounceTimer);
      const query = text(this.input.value);
      if (query.length < this.config.minChars && !(query === '' && this.config.browseEmpty)) {
        this.setStatus(query
          ? message('selector.minimum_characters', { count: this.config.minChars })
          : '');
        return;
      }
      this.debounceTimer = window.setTimeout(function () {
        this.request(false);
      }.bind(this), immediate ? 0 : 300);
    }

    cancelRequest() {
      window.clearTimeout(this.debounceTimer);
      window.clearTimeout(this.timeoutTimer);
      this.requestSequence += 1;
      if (this.abortController) {
        this.abortController.abort();
        this.abortController = null;
      }
      this.setBusy(false);
    }

    async request(append) {
      const query = text(this.input.value);
      if (!append && query.length < this.config.minChars && !(query === '' && this.config.browseEmpty)) {
        return;
      }
      if (!this.config.endpoint || !this.provider) {
        this.setStatus(message('selector.error.unavailable'));
        return;
      }
      this.cancelRequest();
      const requestId = String(++this.requestSequence);
      const logicalSequence = this.requestSequence;
      const previousLength = this.results.length;
      this.abortController = typeof AbortController === 'function' ? new AbortController() : null;
      this.retryButton.hidden = true;
      this.setBusy(true);
      this.setStatus(append
        ? message('selector.status.loading_more')
        : message('selector.status.loading'));
      const body = {
        contract: 'resource_selector',
        version: this.config.version,
        purpose: this.provider,
        q: query,
        cursor: append ? this.nextCursor : '',
        context_revision: this.config.contextRevision,
        // Hydration by IDs is a separate server-side contract. Interactive search
        // sends no selected IDs; confirmed values are filtered locally and every
        // submitted ID is revalidated by the canonical mutation.
        selected_ids: [],
        dependencies: dependenciesFor(this.select),
      };
      let timedOut = false;
      const timeoutPromise = new Promise(function (resolve, reject) {
        this.timeoutTimer = window.setTimeout(function () {
          timedOut = true;
          if (this.abortController) {
            this.abortController.abort();
          }
          const error = new Error('timeout');
          error.name = 'TimeoutError';
          reject(error);
        }.bind(this), this.config.timeout);
      }.bind(this));

      try {
        const options = {
          method: 'POST',
          credentials: 'same-origin',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            'X-GLPI-CSRF-TOKEN': this.config.csrfToken,
          },
          body: JSON.stringify(body),
        };
        if (this.abortController) {
          options.signal = this.abortController.signal;
        }
        const response = await Promise.race([global.fetch(this.config.endpoint, options), timeoutPromise]);
        window.clearTimeout(this.timeoutTimer);
        if (!response.ok) {
          const failure = new Error('http');
          failure.status = response.status;
          try {
            const errorPayload = await response.json();
            if (errorPayload
              && errorPayload.contract === 'resource_selector'
              && Number(errorPayload.version) === 1
              && errorPayload.error
              && typeof errorPayload.error === 'object') {
              failure.code = text(errorPayload.error.code);
              const details = errorPayload.error.details;
              if (details && typeof details === 'object') {
                failure.minimumLength = integer(
                  details.minimum_length,
                  this.config.minChars,
                  0,
                  10
                );
              }
            }
          } catch (parseError) {
            // HTTP status remains the safe fallback when an intermediary replaces the JSON body.
          }
          throw failure;
        }
        const payload = await response.json();
        if (logicalSequence !== this.requestSequence || !this.wrapper.isConnected) {
          return;
        }
        if (!payload || payload.contract !== 'resource_selector' || Number(payload.version) !== 1) {
          const invalidContract = new Error('invalid_contract');
          invalidContract.status = 502;
          throw invalidContract;
        }
        if (payload.request_id != null && String(payload.request_id) !== requestId) {
          return;
        }
        const responseRevision = text(payload && payload.context_revision);
        if (this.config.contextRevision && responseRevision
          && responseRevision !== this.config.contextRevision) {
          this.results = [];
          this.renderResults();
          this.close();
          this.setStatus(message('selector.error.context_changed'));
          return;
        }
        if (!this.config.contextRevision && responseRevision) {
          this.config.contextRevision = responseRevision;
        }
        const received = normalizeItems(payload);
        const selectedIds = new Set(this.selected.map(function (item) { return item.id; }));
        const available = received.filter(function (item) { return !selectedIds.has(item.id); });
        if (append) {
          const known = new Set(this.results.map(function (item) { return item.id; }));
          available.forEach(function (item) {
            if (!known.has(item.id)) {
              known.add(item.id);
              this.results.push(item);
            }
          }, this);
        } else {
          this.results = available;
        }
        const pagination = payload && payload.pagination && typeof payload.pagination === 'object'
          ? payload.pagination
          : {};
        this.hasMore = Boolean(payload && (payload.has_more === true || pagination.more === true));
        this.nextCursor = text(
          payload && payload.next_cursor != null
            ? payload.next_cursor
            : (pagination.next_cursor != null ? pagination.next_cursor : pagination.cursor)
        );
        const total = Number(payload && payload.total != null ? payload.total : pagination.total);
        this.total = Number.isFinite(total) && total >= 0 ? Math.floor(total) : null;
        this.renderResults();
        if (!this.results.length) {
          this.close();
          this.setStatus(message('selector.status.no_results'));
          return;
        }
        this.open();
        if (append) {
          this.setActive(Math.min(previousLength, this.results.length - 1));
          this.input.focus();
          const added = Math.max(0, this.results.length - previousLength);
          this.setStatus(
            message('selector.status.more_loaded', {
              added: added,
              total: this.results.length
            }) + ' ' + (this.hasMore
              ? message('selector.status.has_more')
              : message('selector.status.end'))
          );
        } else {
          this.setStatus(
            message(
              this.results.length === 1
                ? 'selector.status.one_available'
                : 'selector.status.many_available',
              { count: this.results.length }
            ) + ' ' + message('selector.status.choose_help')
          );
        }
      } catch (error) {
        window.clearTimeout(this.timeoutTimer);
        if (logicalSequence !== this.requestSequence || !this.wrapper.isConnected) {
          return;
        }
        if (error && error.name === 'AbortError' && !timedOut) {
          return;
        }
        if (!append) {
          this.results = [];
          this.hasMore = false;
          this.renderResults();
          this.close();
        }
        const status = Number(error && error.status) || 0;
        const errorCode = text(error && error.code);
        if (error && (error.name === 'TimeoutError' || timedOut)) {
          this.setStatus(message('selector.error.timeout'));
        } else if (status === 401 || status === 403) {
          this.setStatus(message('selector.error.session_or_permission'));
        } else if (status === 409) {
          this.setStatus(message('selector.error.context_changed_short'));
        } else if (status === 429) {
          this.setStatus(message('selector.error.rate_limited'));
        } else if (status === 422 && errorCode === 'query_too_short') {
          const minimumLength = integer(
            error && error.minimumLength,
            this.config.minChars > 0 ? this.config.minChars : 2,
            1,
            10
          );
          this.setStatus(message('selector.minimum_characters', { count: minimumLength }));
        } else if (status === 422 && errorCode === 'query_invalid') {
          this.setStatus(message('selector.error.query_invalid'));
        } else if (status === 422) {
          this.setStatus(message('selector.error.invalid'));
        } else {
          this.setStatus(message('selector.error.generic'));
        }
        this.retryButton.hidden = status === 401 || status === 403 || status === 409
          || errorCode === 'query_too_short' || errorCode === 'query_invalid';
      } finally {
        if (logicalSequence === this.requestSequence) {
          this.abortController = null;
          this.setBusy(false);
        }
      }
    }

    onKeydown(event) {
      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        if (!this.results.length) {
          this.schedule(true);
          return;
        }
        event.preventDefault();
        this.open();
        this.setActive(event.key === 'ArrowDown'
          ? (this.activeIndex < this.results.length - 1 ? this.activeIndex + 1 : 0)
          : (this.activeIndex > 0 ? this.activeIndex - 1 : this.results.length - 1));
        return;
      }
      if (event.key === 'Home' && !this.listbox.hidden && this.results.length) {
        event.preventDefault();
        this.setActive(0);
        return;
      }
      if (event.key === 'End' && !this.listbox.hidden && this.results.length) {
        event.preventDefault();
        this.setActive(this.results.length - 1);
        return;
      }
      if (event.key === 'Enter') {
        event.preventDefault();
        if (!this.listbox.hidden && this.activeIndex >= 0) {
          this.confirm(this.results[this.activeIndex]);
        }
        return;
      }
      if (event.key === 'Escape') {
        if (!this.listbox.hidden || this.input.value) {
          event.preventDefault();
          this.input.value = this.multiple ? '' : (this.selected[0] ? this.selected[0].label : '');
          this.close();
          this.clearInvalid();
          syncFormValidationSummary(this.form);
        }
        return;
      }
      if (event.key === 'Tab') {
        this.close();
      }
    }

    validate() {
      this.input.setAttribute('aria-required', this.select.required ? 'true' : 'false');
      const typed = text(this.input.value);
      const confirmedLabel = this.multiple ? '' : text(this.selected[0] && this.selected[0].label);
      if (typed && (this.multiple || typed !== confirmedLabel)) {
        const validationMessage = message('selector.validation.confirm_or_clear', {
          label: this.labelText
        });
        this.setInvalid(validationMessage);
        return validationMessage;
      }
      if (this.select.required && this.selected.length === 0) {
        const validationMessage = message('selector.validation.required', { label: this.labelText });
        this.setInvalid(validationMessage);
        return validationMessage;
      }
      this.clearInvalid();
      return '';
    }
  }

  function validationEntries(form) {
    if (!form) {
      return [];
    }
    return Array.from(form.querySelectorAll('[data-glpiacessivel-resource-select]'))
      .map(function (select) {
        const instance = instances.get(select);
        const message = instance ? instance.validate() : '';
        return message ? { instance: instance, message: message } : null;
      }).filter(Boolean);
  }

  function renderFormValidationSummary(form, focusSummary) {
    const invalid = validationEntries(form);
    const summarySelector = text(form && form.dataset.resourceSelectorErrorSummary);
    const summary = summarySelector ? document.querySelector(summarySelector) : null;
    if (!summary) {
      if (focusSummary && invalid.length) {
        invalid[0].instance.input.focus();
      }
      return invalid;
    }

    const list = summary.querySelector('ul') || summary.appendChild(create('ul'));
    const signature = invalid.map(function (entry) {
      return entry.instance.input.id + ':' + entry.message;
    }).join('|');
    if (!invalid.length) {
      list.textContent = '';
      summary.dataset.resourceSelectorErrorSignature = '';
      summary.hidden = true;
      return invalid;
    }

    if (summary.dataset.resourceSelectorErrorSignature !== signature) {
      list.textContent = '';
      invalid.forEach(function (entry) {
        const item = create('li');
        const link = create('a', '', entry.message);
        link.href = '#' + entry.instance.input.id;
        link.addEventListener('click', function () {
          entry.instance.input.focus();
        });
        item.appendChild(link);
        list.appendChild(item);
      });
      summary.dataset.resourceSelectorErrorSignature = signature;
    }
    summary.hidden = false;
    if (focusSummary && typeof summary.focus === 'function') {
      summary.focus();
    }
    return invalid;
  }

  function syncFormValidationSummary(form) {
    if (!form || form.dataset.resourceSelectorValidationAttempted !== '1') {
      return;
    }
    renderFormValidationSummary(form, false);
  }

  function clearFormValidationSummary(form) {
    const summarySelector = text(form && form.dataset.resourceSelectorErrorSummary);
    const summary = summarySelector ? document.querySelector(summarySelector) : null;
    if (!summary) {
      return;
    }
    const list = summary.querySelector('ul');
    if (list) {
      list.textContent = '';
    }
    summary.dataset.resourceSelectorErrorSignature = '';
    summary.hidden = true;
  }

  function bindFormValidation(form) {
    if (!form || form.dataset.resourceSelectorValidationBound === '1') {
      return;
    }
    form.dataset.resourceSelectorValidationBound = '1';
    form.addEventListener('submit', function (event) {
      form.dataset.resourceSelectorValidationAttempted = '1';
      const invalid = renderFormValidationSummary(form, true);
      if (!invalid.length) {
        return;
      }
      event.preventDefault();
    });
    form.addEventListener('reset', function () {
      form.dataset.resourceSelectorValidationAttempted = '0';
      window.setTimeout(function () {
        clearFormValidationSummary(form);
      }, 0);
    });
  }

  function enhance(root) {
    if (!i18n || !message('selector.keyboard_help')) {
      return [];
    }
    const scope = root && typeof root.querySelectorAll === 'function' ? root : document;
    const enhanced = [];
    Array.from(scope.querySelectorAll('[data-glpiacessivel-resource-select]')).forEach(function (select) {
      if (!(select instanceof HTMLSelectElement) || instances.has(select)) {
        return;
      }
      const config = readConfig(select);
      if (!config.endpoint || !text(select.dataset.resourceProvider)) {
        return;
      }
      const instance = new ResourceSelector(select);
      instances.set(select, instance);
      enhanced.push(instance);
      bindFormValidation(select.form);
    });
    return enhanced;
  }

  global.GlpiAccessibleResourceSelector = {
    enhance: enhance,
    get: function (select) { return instances.get(select) || null; },
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { enhance(document); });
  } else {
    enhance(document);
  }
}(window));
