<?php

// SPDX-License-Identifier: GPL-2.0-or-later

declare(strict_types=1);

use GlpiPlugin\Glpiacessivel\Support\Bootstrap;
use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\UI\Controller\MenuController;

const PLUGIN_GLPIACESSIVEL_VERSION = '0.2.24-beta';
const PLUGIN_GLPIACESSIVEL_MIN_GLPI = '10.0.0';
const PLUGIN_GLPIACESSIVEL_MAX_GLPI = '11.99.99';
const PLUGIN_GLPIACESSIVEL_MIN_PHP = '8.1.0';
require_once __DIR__ . '/hook.php';
function plugin_glpiacessivel_asset_version(string $assetPath = ''): string
{
    $version = PLUGIN_GLPIACESSIVEL_VERSION;
    $normalizedPath = ltrim(str_replace('\\', '/', $assetPath), '/');
    $fullPath = $normalizedPath !== '' ? __DIR__ . '/' . $normalizedPath : '';
    if ($fullPath !== '' && is_file($fullPath)) {
        $mtime = @filemtime($fullPath);
        if ($mtime !== false) {
            return $version . '-' . (string) $mtime;
        }
    }

    return $version;
}

function plugin_init_glpiacessivel(): void
{
    global $PLUGIN_HOOKS;
    $csrfHook = class_exists('\Glpi\Plugin\Hooks')
        ? \Glpi\Plugin\Hooks::CSRF_COMPLIANT
        : 'csrf_compliant';
    $PLUGIN_HOOKS[$csrfHook]['glpiacessivel'] = true;
    if (class_exists('Plugin') && method_exists('Plugin', 'loadLang')) {
        Plugin::loadLang('glpiacessivel');
    }

    Bootstrap::init();
    plugin_glpiacessivel_register_common_db_classes();
    if (plugin_glpiacessivel_is_glpi11() && class_exists(\Glpi\Http\Firewall::class)) {
        \Glpi\Http\Firewall::addPluginStrategyForLegacyScripts('glpiacessivel', '#^/front/(acessivel|faq|runtime-config\.js)\.php$#', \Glpi\Http\Firewall::STRATEGY_NO_CHECK);
        \Glpi\Http\Firewall::addPluginStrategyForLegacyScripts('glpiacessivel', '#^/front/(chatbot|cockpit|config|context|knowledge|playbooks|forms|form\.open|form\.render|ticket|ticket\.action|ticket\.create|ticket\.saved-search|ticket\.search-values)\.php$#', \Glpi\Http\Firewall::STRATEGY_AUTHENTICATED);
    }

    $PLUGIN_HOOKS['menu_toadd']['glpiacessivel'] = [
        'helpdesk' => MenuController::class,
        'plugins' => MenuController::class,
    ];
    $PLUGIN_HOOKS['config_page']['glpiacessivel'] = 'front/config.php';
    $PLUGIN_HOOKS['display_central']['glpiacessivel'] = 'plugin_glpiacessivel_display_central';
    if (plugin_glpiacessivel_should_register_login_hook()) {
        $PLUGIN_HOOKS['display_login']['glpiacessivel'] = 'plugin_glpiacessivel_display_login';
    }
    $cssPath = plugin_glpiacessivel_hook_asset_path('assets/css/glpiacessivel.css');
    $auditCssPath = plugin_glpiacessivel_hook_asset_path('assets/css/a11y-audit.css');
    $jsPath = plugin_glpiacessivel_hook_asset_path('assets/js/glpiacessivel.js');
    $auditJsPath = plugin_glpiacessivel_hook_asset_path('assets/js/a11y-audit.js');
    if (plugin_glpiacessivel_supports_anonymous_page_css()) {
        $PLUGIN_HOOKS['add_css_anonymous_page']['glpiacessivel'] = [$cssPath, $auditCssPath];
    }
    if (plugin_glpiacessivel_should_display_login_accessibility_notice()) {
        $PLUGIN_HOOKS['add_javascript_anonymous_page']['glpiacessivel'] = [
            plugin_glpiacessivel_hook_asset_path('assets/js/login-accessibility-notice.js'),
        ];
    }

    $PLUGIN_HOOKS['add_css']['glpiacessivel'] = [$cssPath, $auditCssPath];
    $PLUGIN_HOOKS['add_javascript']['glpiacessivel'] = [$jsPath, $auditJsPath];
}

function plugin_glpiacessivel_register_common_db_classes(): void
{
    if (!class_exists('Plugin') || !method_exists('Plugin', 'registerClass')) {
        return;
    }

    $classes = [
        \GlpiPlugin\Glpiacessivel\Model\Playbook::class,
        \GlpiPlugin\Glpiacessivel\Model\PlaybookSuggestion::class,
        \GlpiPlugin\Glpiacessivel\Model\PlaybookJob::class,
        \GlpiPlugin\Glpiacessivel\Model\AuditLog::class,
        \GlpiPlugin\Glpiacessivel\Model\Config::class,
        \GlpiPlugin\Glpiacessivel\Model\PiiReveal::class,
    ];
    foreach ($classes as $class) {
        if (class_exists($class)) {
            Plugin::registerClass($class);
        }
    }
}

function plugin_version_glpiacessivel(): array
{
    return [
        'name' => 'GLPI Acessivel',
        'version' => PLUGIN_GLPIACESSIVEL_VERSION,
        'author' => 'Leonardo da Silva Moreira',
        'license' => 'GPL-2.0-or-later',
        'homepage' => 'https://github.com/leonardosminfo/plugin_glpi_acessivel',
        'csrf_compliant' => true,
        'requirements' => [
            'php' => [
                'min' => PLUGIN_GLPIACESSIVEL_MIN_PHP,
            ],
            'glpi' => [
                'min' => PLUGIN_GLPIACESSIVEL_MIN_GLPI,
                'max' => PLUGIN_GLPIACESSIVEL_MAX_GLPI,
            ],
        ],
    ];
}

function plugin_glpiacessivel_check_prerequisites(): bool
{
    if (version_compare(PHP_VERSION, PLUGIN_GLPIACESSIVEL_MIN_PHP, '<')) {
        echo sprintf(__('Este plugin requer PHP >= %s', 'glpiacessivel'), PLUGIN_GLPIACESSIVEL_MIN_PHP);
        return false;
    }

    if (version_compare(GLPI_VERSION, PLUGIN_GLPIACESSIVEL_MIN_GLPI, '<')) {
        echo sprintf(__('Este plugin requer GLPI >= %s', 'glpiacessivel'), PLUGIN_GLPIACESSIVEL_MIN_GLPI);
        return false;
    }

    if (version_compare(GLPI_VERSION, PLUGIN_GLPIACESSIVEL_MAX_GLPI, '>')) {
        echo sprintf(__('Este plugin suporta GLPI ate %s', 'glpiacessivel'), PLUGIN_GLPIACESSIVEL_MAX_GLPI);
        return false;
    }

    return true;
}

function plugin_glpiacessivel_check_config(bool $verbose = false): bool
{
    if (!class_exists('Ticket')) {
        if ($verbose) {
            echo __('Core de tickets nao encontrado no GLPI.', 'glpiacessivel');
        }
        return false;
    }

    return true;
}

function plugin_glpiacessivel_install(): bool
{
    return Bootstrap::install();
}

function plugin_glpiacessivel_uninstall(): bool
{
    return Bootstrap::uninstall();
}

function plugin_glpiacessivel_is_glpi11(): bool
{
    return defined('GLPI_VERSION') && version_compare(GLPI_VERSION, '11.0.0', '>=');
}

function plugin_glpiacessivel_supports_anonymous_page_css(): bool
{
    if (!defined('GLPI_VERSION')) {
        return false;
    }

    // No GLPI 10, mantemos o caminho mais conservador e deixamos as paginas
    // publicas carregarem CSS diretamente pelos templates do plugin.
    return plugin_glpiacessivel_is_glpi11();
}

function plugin_glpiacessivel_hook_asset_path(string $assetPath): string
{
    $assetPath = ltrim($assetPath, '/');
    if (!plugin_glpiacessivel_is_glpi11()) {
    // GLPI 10 pode validar assets de hook como caminho fisico; query string pode impedir o carregamento.
        return $assetPath;
    }

    return $assetPath . '?v=' . rawurlencode(plugin_glpiacessivel_asset_version($assetPath));
}

function plugin_glpiacessivel_is_chatbot_enabled(): bool
{
    $states = plugin_glpiacessivel_get_portal_module_states();
    return ($states['chatbot'] ?? 'available') !== 'disabled';
}

/** @return array<string, string> */
function plugin_glpiacessivel_get_portal_module_states(): array
{
    $configs = plugin_glpiacessivel_get_cached_config_map();
    $modules = ['ticket_create', 'forms', 'tickets', 'cockpit', 'knowledge', 'chatbot', 'playbooks'];
    $states = [];
    foreach ($modules as $module) {
        $configured = (string) ($configs['module_' . $module . '_state'] ?? '');
        if (!in_array($configured, ['available', 'hidden', 'disabled'], true)) {
            if ($module === 'forms' && ($configs['forms_enabled'] ?? '1') === '0') {
                $configured = 'disabled';
            } elseif ($module === 'chatbot' && ($configs['chatbot_enabled'] ?? '1') === '0') {
                $configured = 'disabled';
            } else {
                $configured = 'available';
            }
        }
        $states[$module] = $configured;
    }

    if (($states['tickets'] ?? 'available') === 'disabled') {
        $states['cockpit'] = 'disabled';
    } elseif (
        ($states['tickets'] ?? 'available') === 'hidden'
        && ($states['cockpit'] ?? 'available') === 'available'
    ) {
        $states['cockpit'] = 'hidden';
    }

    return $states;
}

function plugin_glpiacessivel_get_accessibility_mode(): string
{
    $configs = plugin_glpiacessivel_get_cached_config_map();
    $mode = (string) ($configs['accessibility_mode'] ?? 'hybrid');
    if ($mode === 'global') {
        return 'embedded';
    }

    return in_array($mode, ['portal', 'embedded', 'hybrid'], true) ? $mode : 'hybrid';
}

function plugin_glpiacessivel_get_authentication_entry_mode(): string
{
    $configs = plugin_glpiacessivel_get_cached_config_map();
    $mode = (string) (
        $configs['authentication_entry_mode']
        ?? ConfigService::AUTHENTICATION_ENTRY_NATIVE_ONLY
    );

    return in_array($mode, ConfigService::AUTHENTICATION_ENTRY_SUPPORTED_MODES, true)
        ? $mode
        : ConfigService::AUTHENTICATION_ENTRY_NATIVE_ONLY;
}

function plugin_glpiacessivel_is_accessible_login_bridge_enabled(): bool
{
    return plugin_glpiacessivel_get_authentication_entry_mode() === 'accessible_bridge';
}

function plugin_glpiacessivel_is_login_accessibility_notice_enabled(): bool
{
    $configs = plugin_glpiacessivel_get_cached_config_map();
    return ($configs['show_login_accessibility_notice'] ?? '0') === '1';
}

function plugin_glpiacessivel_should_display_login_accessibility_notice(): bool
{
    return plugin_glpiacessivel_get_authentication_entry_mode() === 'native_only'
        && plugin_glpiacessivel_is_login_accessibility_notice_enabled();
}

function plugin_glpiacessivel_should_register_login_hook(): bool
{
    return plugin_glpiacessivel_is_accessible_login_bridge_enabled()
        || plugin_glpiacessivel_should_display_login_accessibility_notice();
}

function plugin_glpiacessivel_is_chatbot_floating_button_enabled(): bool
{
    return plugin_glpiacessivel_is_chatbot_enabled()
        && plugin_glpiacessivel_get_chatbot_floating_scope() !== 'disabled';
}

function plugin_glpiacessivel_get_vlibras_scope(): string
{
    $configs = plugin_glpiacessivel_get_cached_config_map();
    $scope = (string) ($configs['vlibras_scope'] ?? 'plugin_pages');
    return in_array($scope, ['disabled', 'public_only', 'plugin_pages', 'all_pages'], true) ? $scope : 'plugin_pages';
}

function plugin_glpiacessivel_is_vlibras_enabled_for_context(bool $isPluginPage = false, bool $isPublicPage = false): bool
{
    $scope = plugin_glpiacessivel_get_vlibras_scope();
    return match ($scope) {
        'all_pages' => true,
        'plugin_pages' => $isPluginPage,
        'public_only' => $isPublicPage,
        default => false,
    };
}

function plugin_glpiacessivel_get_chatbot_floating_scope(): string
{
    $configs = plugin_glpiacessivel_get_cached_config_map();
    $scope = (string) ($configs['chatbot_floating_scope'] ?? '');
    if (in_array($scope, ['plugin_only', 'all_logged_pages', 'disabled'], true)) {
        return $scope;
    }

    if (($configs['chatbot_floating_button_enabled'] ?? '1') === '0') {
        return 'disabled';
    }

    return 'all_logged_pages';
}

function plugin_glpiacessivel_get_cached_config_map(): array
{
    static $cache = null;
    if (is_array($cache)) {
        return $cache;
    }

    global $DB;
    $defaults = [
        'accessibility_mode' => 'hybrid',
        'authentication_entry_mode' => ConfigService::AUTHENTICATION_ENTRY_NATIVE_ONLY,
        'show_login_accessibility_notice' => '0',
        'plugin_fallback_locale' => 'pt_BR',
        'vlibras_scope' => 'plugin_pages',
        'forms_enabled' => '1',
        'forms_native_flow_mode' => 'native_embedded',
        'chatbot_enabled' => '1',
        'chatbot_floating_scope' => 'all_logged_pages',
        'chatbot_floating_button_enabled' => '1',
    ];
    if (!isset($DB) || !method_exists($DB, 'request')) {
        $cache = $defaults;
        return $cache;
    }

    $cache = $defaults;
    try {
        $rows = $DB->request([
            'SELECT' => ['key_name', 'value_text'],
            'FROM' => 'glpi_plugin_glpiacessivel_configs',
            'WHERE' => [
                'key_name' => array_keys($defaults),
            ],
        ]);
        foreach ($rows as $row) {
            $key = (string) ($row['key_name'] ?? '');
            if ($key === '' || !array_key_exists($key, $cache)) {
                continue;
            }

            $cache[$key] = (string) ($row['value_text'] ?? $cache[$key]);
        }
    } catch (\Throwable $e) {
        $cache = $defaults;
    }

    return $cache;
}
