<?php

$glpiacessivelStandaloneLayout = (bool) ($glpiacessivelStandaloneLayout ?? false);
$glpiacessivelHtmlLang = function_exists('glpiacessivel_html_lang') ? glpiacessivel_html_lang() : 'pt-BR';
$assetVersionFor = static function (string $assetPath): string {
    if (function_exists('plugin_glpiacessivel_asset_version')) {
        return plugin_glpiacessivel_asset_version($assetPath);
    }

    $version = defined('PLUGIN_GLPIACESSIVEL_VERSION') ? (string) PLUGIN_GLPIACESSIVEL_VERSION : 'dev';
    $fullPath = __DIR__ . '/../../' . ltrim($assetPath, '/');
    $mtime = is_file($fullPath) ? @filemtime($fullPath) : false;

    return $mtime !== false ? $version . '-' . (string) $mtime : $version;
};
$axeSourceAsset = 'public/assets/js/axe.min.js';
$axeSourceUrl = \GlpiPlugin\Glpiacessivel\Support\Url::asset(
    $axeSourceAsset . '?v=' . rawurlencode($assetVersionFor($axeSourceAsset))
);

if (!$glpiacessivelStandaloneLayout && !class_exists('Html')) {
    throw new RuntimeException('GLPI nao carregado.');
}

if ($glpiacessivelStandaloneLayout) {
    $standaloneCss = \GlpiPlugin\Glpiacessivel\Support\Url::asset('public/assets/css/glpiacessivel.css?v=' . rawurlencode($assetVersionFor('public/assets/css/glpiacessivel.css')));
    $standalonePortalCss = \GlpiPlugin\Glpiacessivel\Support\Url::asset('public/assets/css/portal.css?v=' . rawurlencode($assetVersionFor('public/assets/css/portal.css')));
    $standaloneAuditCss = \GlpiPlugin\Glpiacessivel\Support\Url::asset('public/assets/css/a11y-audit.css?v=' . rawurlencode($assetVersionFor('public/assets/css/a11y-audit.css')));
    $standaloneAuditJs = \GlpiPlugin\Glpiacessivel\Support\Url::asset('public/assets/js/a11y-audit.js?v=' . rawurlencode($assetVersionFor('public/assets/js/a11y-audit.js')));
    $standaloneJs = \GlpiPlugin\Glpiacessivel\Support\Url::asset('public/assets/js/glpiacessivel.js?v=' . rawurlencode($assetVersionFor('public/assets/js/glpiacessivel.js')));
    ?>
<!doctype html>
<html lang="<?= htmlspecialchars($glpiacessivelHtmlLang, ENT_QUOTES, 'UTF-8') ?>">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?= htmlspecialchars((string) ($title ?? 'GLPI Acessivel'), ENT_QUOTES, 'UTF-8') ?></title>
  <link rel="stylesheet" href="<?= htmlspecialchars($standaloneCss, ENT_QUOTES, 'UTF-8') ?>" />
  <link rel="stylesheet" href="<?= htmlspecialchars($standalonePortalCss, ENT_QUOTES, 'UTF-8') ?>" />
  <link rel="stylesheet" href="<?= htmlspecialchars($standaloneAuditCss, ENT_QUOTES, 'UTF-8') ?>" />
</head>
<body class="glpiacessivel-login-page glpiacessivel-portal-shell-page">
<?php
} else {
    Html::header($title ?? 'GLPI Acessivel', '', 'helpdesk', 'ticket');
}

if (!function_exists('glpiacessivel_e')) {
    function glpiacessivel_e($value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('glpiacessivel_url')) {
    function glpiacessivel_url(string $path): string
    {
        return \GlpiPlugin\Glpiacessivel\Support\Url::plugin($path);
    }
}

if (!function_exists('glpiacessivel_ticket_status')) {
    function glpiacessivel_ticket_status($status): string
    {
        return \GlpiPlugin\Glpiacessivel\Support\TicketStatusLabels::label((int) $status);
    }
}

if (!function_exists('glpiacessivel_ticket_priority')) {
    function glpiacessivel_ticket_priority($priority): string
    {
        $labels = [
            1 => 'Muito baixa',
            2 => 'Baixa',
            3 => 'Media',
            4 => 'Alta',
            5 => 'Muito alta',
            6 => 'Critica',
        ];

        return $labels[(int) $priority] ?? ('Prioridade ' . (int) $priority);
    }
}

if (!function_exists('glpiacessivel_status_class')) {
    function glpiacessivel_status_class($status): string
    {
        $classes = [
            1 => 'new',
            2 => 'assigned',
            3 => 'planned',
            4 => 'pending',
            5 => 'solved',
            6 => 'closed',
        ];

        return $classes[(int) $status] ?? 'neutral';
    }
}

if (!function_exists('glpiacessivel_priority_class')) {
    function glpiacessivel_priority_class($priority): string
    {
        $priority = (int) $priority;
        if ($priority >= 5) {
            return 'critical';
        }
        if ($priority === 4) {
            return 'high';
        }
        if ($priority === 3) {
            return 'medium';
        }

        return 'low';
    }
}

if (!function_exists('glpiacessivel_timeline_label')) {
    function glpiacessivel_timeline_label($type): string
    {
        $labels = [
            'followup' => 'Acompanhamento',
            'task' => 'Tarefa',
            'solution' => 'Solucao',
        ];

        return $labels[(string) $type] ?? ucfirst((string) $type);
    }
}

if (!function_exists('glpiacessivel_aria_current')) {
    function glpiacessivel_aria_current(string $path): string
    {
        $request = (string) ($_SERVER['REQUEST_URI'] ?? '');
        return str_contains($request, $path) ? ' aria-current="page"' : '';
    }
}

if (!function_exists('glpiacessivel_mode_label')) {
    function glpiacessivel_mode_label(string $mode): string
    {
        return match ($mode) {
            'portal' => glpiacessivel_t('Modo portal acessivel'),
            'embedded' => 'Modo embutido no GLPI',
            default => glpiacessivel_t('Modo hibrido'),
        };
    }
}

if (!function_exists('glpiacessivel_mode_description')) {
    function glpiacessivel_mode_description(string $mode): string
    {
        return match ($mode) {
            'portal' => glpiacessivel_t('Jornada principal em telas acessiveis do plugin, com maior independencia da interface nativa do GLPI.'),
            'embedded' => glpiacessivel_t('Experiencia priorizada dentro do GLPI, com ponte acessivel e apoio contextual, mas com menor controle de acessibilidade completa nas telas nativas.'),
            default => glpiacessivel_t('Portal acessivel como jornada principal, com integracao embutida no GLPI para continuidade operacional.'),
        };
    }
}

if (!function_exists('glpiacessivel_mode_glpi_action_label')) {
    function glpiacessivel_mode_glpi_action_label(string $mode): string
    {
        return match ($mode) {
            'portal' => glpiacessivel_t('Usar GLPI padrao quando necessario'),
            'embedded' => 'Voltar ao GLPI padrao',
            default => glpiacessivel_t('Abrir no GLPI padrao'),
        };
    }
}

if (!function_exists('glpiacessivel_standard_glpi_url')) {
    function glpiacessivel_standard_glpi_url(): string
    {
        $requestPath = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);

        if (str_contains($requestPath, '/plugins/glpiacessivel/front/ticket.create.php')) {
            return \GlpiPlugin\Glpiacessivel\Support\Url::core('front/ticket.form.php');
        }

        if (str_contains($requestPath, '/plugins/glpiacessivel/front/ticket.php')) {
            $ticketId = (int) ($_GET['id'] ?? 0);
            if ($ticketId > 0) {
                return \GlpiPlugin\Glpiacessivel\Support\Url::core('front/ticket.form.php?id=' . $ticketId);
            }

            return \GlpiPlugin\Glpiacessivel\Support\Url::core('front/ticket.php');
        }

        if (str_contains($requestPath, '/plugins/glpiacessivel/front/knowledge.php')) {
            $articleId = (int) ($_GET['article_id'] ?? $_GET['article'] ?? 0);
            if ($articleId > 0) {
                return \GlpiPlugin\Glpiacessivel\Support\Url::core('front/knowbaseitem.form.php?id=' . $articleId);
            }

            return \GlpiPlugin\Glpiacessivel\Support\Url::core('front/knowbaseitem.php');
        }

        if (str_contains($requestPath, '/plugins/glpiacessivel/front/forms.php')) {
            if (class_exists('\\Glpi\\Form\\Form') || class_exists('\\Glpi\\Form\\ServiceCatalog\\ServiceCatalog')) {
                return \GlpiPlugin\Glpiacessivel\Support\Url::core('ServiceCatalog');
            }

            return \GlpiPlugin\Glpiacessivel\Support\Url::core('plugins/formcreator/front/formlist.php');
        }

        $activeInterface = (string) ($_SESSION['glpiactiveprofile']['interface'] ?? '');
        if ($activeInterface !== '' && $activeInterface !== 'central') {
            return \GlpiPlugin\Glpiacessivel\Support\Url::core('front/helpdesk.public.php');
        }

        return \GlpiPlugin\Glpiacessivel\Support\Url::core('front/central.php');
    }
}

$flash = $_SESSION['glpiacessivel_flash'] ?? null;
unset($_SESSION['glpiacessivel_flash']);

$chatbotEnabled = true;
$chatbotFloatingEnabled = true;
$chatbotFloatingScope = 'all_logged_pages';
$canViewTickets = false;
$canViewKnowledgeBase = false;
$canViewCockpit = false;
$canUseChatbot = false;
$canUseForms = false;
$canManageGlpiacessivel = false;
$canManagePlaybooks = false;
$accessibilityMode = 'hybrid';
$glpiacessivelContext = null;
$portalModules = [];
try {
    $container = \GlpiPlugin\Glpiacessivel\Support\Container::get();
    $modulePolicy = $container->portalModulePolicy();
    $portalModules = $modulePolicy->getEffectiveStates();
    $chatbotEnabled = $modulePolicy->isVisible(\GlpiPlugin\Glpiacessivel\Application\ConfigService::MODULE_CHATBOT);
    $chatbotFloatingEnabled = $chatbotEnabled && $container->configService()->isChatbotFloatingButtonEnabled();
    $chatbotFloatingScope = $container->configService()->getChatbotFloatingScope();
    $canViewTickets = $modulePolicy->isVisible(\GlpiPlugin\Glpiacessivel\Application\ConfigService::MODULE_TICKETS)
        && $container->authorization()->canViewTickets();
    $canViewKnowledgeBase = $modulePolicy->isVisible(\GlpiPlugin\Glpiacessivel\Application\ConfigService::MODULE_KNOWLEDGE)
        && $container->authorization()->canViewKnowledgeBase();
    $canViewCockpit = $modulePolicy->isVisible(\GlpiPlugin\Glpiacessivel\Application\ConfigService::MODULE_COCKPIT)
        && $container->authorization()->canViewCockpit();
    $canUseChatbot = $chatbotEnabled && $container->authorization()->canUseChatbot();
    $canUseForms = $modulePolicy->isVisible(\GlpiPlugin\Glpiacessivel\Application\ConfigService::MODULE_FORMS)
        && $container->authorization()->canUseForms();
    $canCreateTicket = $modulePolicy->isVisible(\GlpiPlugin\Glpiacessivel\Application\ConfigService::MODULE_TICKET_CREATE)
        && $container->authorization()->canCreateTickets();
    $rightUpdate = defined('UPDATE') ? (int) constant('UPDATE') : 2;
    $canManageGlpiacessivel = class_exists('Session')
        && \Session::haveRight('config', $rightUpdate);
    $canManagePlaybooks = $canManageGlpiacessivel
        && $modulePolicy->isVisible(\GlpiPlugin\Glpiacessivel\Application\ConfigService::MODULE_PLAYBOOKS);
    $accessibilityMode = $container->configService()->getAccessibilityMode();
    $glpiacessivelContext = $container->contextService()->getContext();
} catch (\Throwable $e) {
    $chatbotEnabled = true;
    $chatbotFloatingEnabled = true;
    $chatbotFloatingScope = 'all_logged_pages';
    $canViewTickets = false;
    $canViewKnowledgeBase = false;
    $canViewCockpit = false;
    $canUseChatbot = false;
    $canUseForms = false;
    $canManageGlpiacessivel = false;
    $canManagePlaybooks = false;
    $accessibilityMode = 'hybrid';
    $glpiacessivelContext = null;
}

$canCreateTicket = $canCreateTicket ?? false;
$createTicketUrl = $createTicketUrl ?? \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/ticket.create.php');

if (!isset($createTicketUrl) || $createTicketUrl === '') {
    $createTicketUrl = \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/ticket.create.php');
}

$standardGlpiUrl = glpiacessivel_standard_glpi_url();
$modeLabel = glpiacessivel_mode_label($accessibilityMode);
$modeDescription = glpiacessivel_mode_description($accessibilityMode);
$modeGlpiActionLabel = glpiacessivel_mode_glpi_action_label($accessibilityMode);
$contextCsrfToken = (new \GlpiPlugin\Glpiacessivel\Security\CsrfGuard())->token();
$contextReturnTo = (string) ($_SERVER['REQUEST_URI'] ?? \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/acessivel.php'));
$isPublicPluginPage = !isset($_SESSION['glpiID']) || (int) $_SESSION['glpiID'] <= 0;
$vlibrasScope = function_exists('plugin_glpiacessivel_get_vlibras_scope') ? plugin_glpiacessivel_get_vlibras_scope() : 'plugin_pages';
$vlibrasEnabled = function_exists('plugin_glpiacessivel_is_vlibras_enabled_for_context')
    ? plugin_glpiacessivel_is_vlibras_enabled_for_context(true, $isPublicPluginPage)
    : false;
$sessionStatus = (new \GlpiPlugin\Glpiacessivel\Security\SessionContextGuard())->status();
?>
<script>
  document.documentElement.setAttribute('data-glpiacessivel-chatbot-floating', '<?= $chatbotFloatingEnabled ? '1' : '0' ?>');
  document.documentElement.setAttribute('data-glpiacessivel-vlibras', '<?= $vlibrasEnabled ? '1' : '0' ?>');
  window.__glpiacessivelChatbotFloatingEnabled = <?= $chatbotFloatingEnabled ? 'true' : 'false' ?>;
  window.__glpiacessivelRuntimeConfig = <?= glpiacessivel_json_for_script([
      'accessibilityMode' => $accessibilityMode,
      'chatbotEnabled' => $chatbotEnabled,
      'chatbotFloatingScope' => $chatbotFloatingScope,
      'isLogged' => !empty($sessionStatus['is_authenticated']),
      'sessionReady' => !empty($sessionStatus['session_ready']),
      'contextValid' => !empty($sessionStatus['context_valid']),
      'sessionIssueCode' => (string) ($sessionStatus['issue_code'] ?? 'unknown'),
      'activeProfileId' => (int) ($sessionStatus['profile_id'] ?? 0),
      'activeEntityId' => (int) ($sessionStatus['entity_id'] ?? 0),
      'locale' => \GlpiPlugin\Glpiacessivel\Support\I18n::locale(),
      'htmlLang' => \GlpiPlugin\Glpiacessivel\Support\I18n::htmlLang(),
      'fallbackLocale' => \GlpiPlugin\Glpiacessivel\Support\I18n::fallbackLocale(),
      'vlibrasScope' => $vlibrasScope,
      'vlibrasEnabled' => $vlibrasEnabled,
      'portalModules' => $portalModules,
  ]) ?>;
  window.__glpiacessivelRuntimeConfigLoaded = true;
  window.__glpiacessivelI18n = <?= glpiacessivel_json_for_script(glpiacessivel_i18n_catalog()) ?>;
  window.__glpiacessivelI18nLoaded = true;
</script>
<a class="glpiacessivel-skip-link" href="#conteudo-principal" aria-keyshortcuts="Alt+1"><?= glpiacessivel_e(glpiacessivel_t('Ir para conteudo principal')) ?></a>
<a class="glpiacessivel-skip-link" href="#glpiacessivel-menu" aria-keyshortcuts="Alt+2"><?= glpiacessivel_e(glpiacessivel_t('Ir para menu')) ?></a>
<a class="glpiacessivel-skip-link" href="#glpiacessivel-search-anchor" aria-keyshortcuts="Alt+3"><?= glpiacessivel_e(glpiacessivel_t('Ir para busca')) ?></a>
<div id="glpiacessivel-live" class="glpiacessivel-sr-only" aria-live="polite" aria-atomic="true"></div>
<?php if ($glpiacessivelStandaloneLayout): ?>
<header class="glpiacessivel-login-topbar" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Ferramentas de acessibilidade')) ?>">
  <nav class="glpiacessivel-login-shortcuts" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Atalhos da pagina')) ?>">
    <a href="#conteudo-principal" aria-keyshortcuts="Alt+1"><?= glpiacessivel_e(glpiacessivel_t('Ir para o conteudo [1]')) ?></a>
    <a href="#glpiacessivel-menu" aria-keyshortcuts="Alt+2"><?= glpiacessivel_e(glpiacessivel_t('Ir para o menu [2]')) ?></a>
    <a href="#glpiacessivel-search-anchor" aria-keyshortcuts="Alt+3"><?= glpiacessivel_e(glpiacessivel_t('Ir para a busca [3]')) ?></a>
  </nav>
  <div class="glpiacessivel-login-tools" role="toolbar" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Controles de acessibilidade')) ?>">
    <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-theme aria-pressed="false" aria-keyshortcuts="Alt+T Control+Alt+Shift+T" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Alternar tema claro e noturno')) ?>"><?= glpiacessivel_e(glpiacessivel_t('Tema')) ?></button>
    <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-contrast aria-pressed="false" aria-keyshortcuts="Alt+C Control+Alt+Shift+K" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Ativar ou desativar alto contraste')) ?>"><?= glpiacessivel_e(glpiacessivel_t('Alto Contraste')) ?></button>
    <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-font="decrease" aria-keyshortcuts="Alt+-" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Diminuir tamanho da fonte')) ?>">A-</button>
    <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-font="reset" aria-keyshortcuts="Alt+0" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Restaurar tamanho da fonte')) ?>">A</button>
    <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-font="increase" aria-keyshortcuts="Alt++" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Aumentar tamanho da fonte')) ?>">A+</button>
    <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-help aria-expanded="false" aria-controls="glpiacessivel-help-panel" aria-keyshortcuts="Alt+H Control+Alt+Shift+H"><?= glpiacessivel_e(glpiacessivel_t('Ajuda')) ?></button>
  </div>
</header>
<header class="glpiacessivel-login-hero" aria-labelledby="glpiacessivel-shell-title">
  <div class="glpiacessivel-login-brand">
    <div class="glpiacessivel-login-brand-icon" aria-hidden="true">
      <?php if (function_exists('plugin_glpiacessivel_portal_icon_markup')): ?>
        <?= plugin_glpiacessivel_portal_icon_markup() ?>
      <?php endif; ?>
    </div>
    <div>
      <h1 id="glpiacessivel-shell-title"><?= glpiacessivel_e(glpiacessivel_t('Portal de Chamados Acessivel')) ?></h1>
      <p class="glpiacessivel-login-brand-copy"><?= glpiacessivel_e(glpiacessivel_t('Atendimento institucional acessivel')) ?></p>
      <p class="glpiacessivel-login-brand-copy">
        <?= glpiacessivel_e(glpiacessivel_t('Modo atual')) ?>: <?= glpiacessivel_e($accessibilityMode) ?>.
        <?= glpiacessivel_e(glpiacessivel_t('A jornada do plugin usa shell proprio e mantem autenticacao, perfil, entidade e regras do GLPI.')) ?>
      </p>
    </div>
  </div>
  <?php if (is_array($glpiacessivelContext)): ?>
    <div class="glpiacessivel-context-form" role="group" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Alterar contexto de entidade e perfil')) ?>">
      <form class="glpiacessivel-context-switch-form" method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/context.php')) ?>" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Alterar perfil ativo')) ?>">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($contextCsrfToken) ?>" />
        <input type="hidden" name="return_to" value="<?= glpiacessivel_e($contextReturnTo) ?>" />
        <input type="hidden" name="entity_id" value="current" />
        <div class="glpiacessivel-context-control glpiacessivel-context-control-profile">
          <label for="glpiacessivel-context-profile"><?= glpiacessivel_e(glpiacessivel_t('Perfil ativo')) ?></label>
          <select id="glpiacessivel-context-profile" name="profile_id" aria-describedby="glpiacessivel-context-profile-help">
            <?php foreach ((array) ($glpiacessivelContext['profiles'] ?? []) as $profile): ?>
              <?php $profileId = (int) ($profile['id'] ?? 0); ?>
              <option value="<?= $profileId ?>"<?= ((int) ($glpiacessivelContext['current_profile_id'] ?? 0) === $profileId) ? ' selected' : '' ?>>
                <?= glpiacessivel_e((string) ($profile['name'] ?? ('Perfil ' . $profileId))) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <span id="glpiacessivel-context-profile-help" class="glpiacessivel-sr-only"><?= glpiacessivel_e(glpiacessivel_t('Ao aplicar outro perfil, o GLPI seleciona uma entidade permitida e recarrega a lista de entidades.')) ?></span>
        </div>
        <button type="submit" class="glpiacessivel-context-apply"><?= glpiacessivel_e(glpiacessivel_t('Aplicar perfil')) ?></button>
      </form>
      <form class="glpiacessivel-context-switch-form" method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/context.php')) ?>" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Alterar entidade ativa')) ?>">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($contextCsrfToken) ?>" />
        <input type="hidden" name="return_to" value="<?= glpiacessivel_e($contextReturnTo) ?>" />
        <input type="hidden" name="profile_id" value="<?= (int) ($glpiacessivelContext['current_profile_id'] ?? 0) ?>" />
        <div class="glpiacessivel-context-control glpiacessivel-context-control-entity">
          <label for="glpiacessivel-context-entity"><?= glpiacessivel_e(glpiacessivel_t('Entidade ativa')) ?></label>
          <select id="glpiacessivel-context-entity" name="entity_id">
            <?php foreach ((array) ($glpiacessivelContext['entities'] ?? []) as $entity): ?>
              <?php $entityId = (string) ($entity['id'] ?? ''); ?>
              <option value="<?= glpiacessivel_e($entityId) ?>"<?= ((string) ($glpiacessivelContext['current_entity_value'] ?? $glpiacessivelContext['current_entity_id'] ?? '') === $entityId) ? ' selected' : '' ?>>
                <?= glpiacessivel_e((string) ($entity['name'] ?? $entityId)) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <button type="submit" class="glpiacessivel-context-apply"><?= glpiacessivel_e(glpiacessivel_t('Aplicar entidade')) ?></button>
      </form>
      <p class="glpiacessivel-context-user">
        <strong><?= glpiacessivel_e(glpiacessivel_t('Usuario')) ?>:</strong> <?= glpiacessivel_e((string) ($glpiacessivelContext['user_label'] ?? glpiacessivel_t('Usuario atual'))) ?>
      </p>
      <a class="glpiacessivel-context-logout" href="<?= glpiacessivel_e(\GlpiPlugin\Glpiacessivel\Support\Url::core('front/logout.php')) ?>"><?= glpiacessivel_e(glpiacessivel_t('Sair')) ?></a>
    </div>
  <?php endif; ?>
</header>
<?php else: ?>
<header class="glpiacessivel-toolbar" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Ferramentas de acessibilidade')) ?>">
  <nav class="glpiacessivel-toolbar-shortcuts" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Atalhos da pagina')) ?>">
    <a href="#conteudo-principal" aria-keyshortcuts="Alt+1"><?= glpiacessivel_e(glpiacessivel_t('Ir para o conteudo [1]')) ?></a>
    <a href="#glpiacessivel-menu" aria-keyshortcuts="Alt+2"><?= glpiacessivel_e(glpiacessivel_t('Ir para o menu [2]')) ?></a>
    <a href="#glpiacessivel-search-anchor" aria-keyshortcuts="Alt+3"><?= glpiacessivel_e(glpiacessivel_t('Ir para a busca [3]')) ?></a>
  </nav>
  <div class="glpiacessivel-toolbar-tools" role="toolbar" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Controles de acessibilidade')) ?>">
    <button type="button" class="glpiacessivel-toolbar-btn" data-glpiacessivel-theme aria-pressed="false" aria-keyshortcuts="Alt+T Control+Alt+Shift+T" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Alternar tema claro e noturno')) ?>"><?= glpiacessivel_e(glpiacessivel_t('Tema')) ?></button>
    <button type="button" class="glpiacessivel-toolbar-btn" data-glpiacessivel-contrast aria-pressed="false" aria-keyshortcuts="Alt+C Control+Alt+Shift+K" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Ativar ou desativar alto contraste')) ?>"><?= glpiacessivel_e(glpiacessivel_t('Alto Contraste')) ?></button>
    <button type="button" class="glpiacessivel-toolbar-btn" data-glpiacessivel-font="decrease" aria-keyshortcuts="Alt+-" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Diminuir tamanho da fonte')) ?>">A-</button>
    <button type="button" class="glpiacessivel-toolbar-btn" data-glpiacessivel-font="reset" aria-keyshortcuts="Alt+0" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Restaurar tamanho da fonte')) ?>">A</button>
    <button type="button" class="glpiacessivel-toolbar-btn" data-glpiacessivel-font="increase" aria-keyshortcuts="Alt++" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Aumentar tamanho da fonte')) ?>">A+</button>
    <button type="button" class="glpiacessivel-toolbar-btn" data-glpiacessivel-help aria-expanded="false" aria-controls="glpiacessivel-help-panel" aria-keyshortcuts="Alt+H Control+Alt+Shift+H"><?= glpiacessivel_e(glpiacessivel_t('Ajuda')) ?></button>
  </div>
</header>
<?php endif; ?>
<main id="conteudo-principal" class="glpiacessivel-wrap<?= $glpiacessivelStandaloneLayout ? ' glpiacessivel-portal-shell-wrap' : '' ?>" tabindex="-1">
  <section class="glpiacessivel-mode-banner" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Contexto da jornada acessivel')) ?>">
    <div class="glpiacessivel-mode-banner-copy">
      <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Jornada acessivel ativa')) ?></p>
      <h2><?= glpiacessivel_e($modeLabel) ?></h2>
      <p><?= glpiacessivel_e($modeDescription) ?> <?= glpiacessivel_e(glpiacessivel_t('Mesma sessao, mesmo perfil e mesma entidade do GLPI.')) ?></p>
    </div>
    <div class="glpiacessivel-mode-banner-actions">
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($standardGlpiUrl) ?>">
        <?= glpiacessivel_e($modeGlpiActionLabel) ?>
      </a>
      <?php if ($canManageGlpiacessivel): ?>
        <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-a11y-audit aria-controls="glpiacessivel-a11y-audit-panel" aria-expanded="false"
          data-axe-source-url="<?= glpiacessivel_e($axeSourceUrl) ?>"
          data-running-label="<?= glpiacessivel_e(glpiacessivel_t('Auditoria local em execucao.')) ?>"
          data-failed-label="<?= glpiacessivel_e(glpiacessivel_t('Nao foi possivel executar a auditoria local.')) ?>"
          data-complete-label="<?= glpiacessivel_e(glpiacessivel_t('Foram encontradas {count} regra(s) com violacao.')) ?>"
          data-none-label="<?= glpiacessivel_e(glpiacessivel_t('Nenhuma violacao automatizada foi encontrada nesta pagina.')) ?>"
          data-incomplete-label="<?= glpiacessivel_e(glpiacessivel_t('A auditoria encontrou {count} regra(s) que exigem revisao manual.')) ?>"
          data-limit-label="<?= glpiacessivel_e(glpiacessivel_t('Resultado local e automatizado. Ele nao substitui avaliacao manual, teclado e leitores de tela.')) ?>"
          data-affected-label="<?= glpiacessivel_e(glpiacessivel_t('Elementos afetados: {count}.')) ?>"
          data-rule-label="<?= glpiacessivel_e(glpiacessivel_t('Ver regra {rule}.')) ?>"
          data-review-label="<?= glpiacessivel_e(glpiacessivel_t('Revisar regra {rule}.')) ?>"
          data-impact-unknown-label="<?= glpiacessivel_e(glpiacessivel_t('Impacto nao classificado')) ?>">
          <?= glpiacessivel_e(glpiacessivel_t('Auditar esta pagina')) ?>
        </button>
      <?php endif; ?>
    </div>
  </section>
  <?php if ($canManageGlpiacessivel): ?>
    <section id="glpiacessivel-a11y-audit-panel" class="glpiacessivel-a11y-audit-panel" hidden role="region" aria-labelledby="glpiacessivel-a11y-audit-title" aria-describedby="glpiacessivel-a11y-audit-scope">
      <div class="glpiacessivel-a11y-audit-heading">
        <h2 id="glpiacessivel-a11y-audit-title" tabindex="-1"><?= glpiacessivel_e(glpiacessivel_t('Diagnostico local de acessibilidade')) ?></h2>
        <button type="button" class="glpiacessivel-help-close" data-glpiacessivel-a11y-audit-close aria-label="<?= glpiacessivel_e(glpiacessivel_t('Fechar diagnostico de acessibilidade')) ?>">X</button>
      </div>
      <p id="glpiacessivel-a11y-audit-scope"><?= glpiacessivel_e(glpiacessivel_t('A auditoria usa Axe local no conteudo principal do plugin e mantem o resultado apenas nesta aba.')) ?></p>
      <div id="glpiacessivel-a11y-audit-results" role="status" aria-live="polite" aria-atomic="true"></div>
      <div class="glpiacessivel-help-footer">
        <button type="button" class="glpiacessivel-button glpiacessivel-button-primary" data-glpiacessivel-a11y-audit-close><?= glpiacessivel_e(glpiacessivel_t('Fechar')) ?></button>
      </div>
    </section>
  <?php endif; ?>
  <section id="glpiacessivel-help-panel" class="glpiacessivel-help-panel" hidden tabindex="-1" role="dialog" aria-modal="true" aria-labelledby="glpiacessivel-help-title">
    <div class="glpiacessivel-help-heading">
      <h2 id="glpiacessivel-help-title"><?= glpiacessivel_e(glpiacessivel_t('Ajuda de Acessibilidade')) ?></h2>
      <button type="button" class="glpiacessivel-help-close" data-glpiacessivel-help-close aria-label="<?= glpiacessivel_e(glpiacessivel_t('Fechar ajuda')) ?>">X</button>
    </div>
    <p><?= glpiacessivel_e(glpiacessivel_t('Atalhos disponiveis para facilitar a navegacao e o uso do portal.')) ?></p>
    <div class="glpiacessivel-shortcut-table-wrap" tabindex="0">
      <table class="glpiacessivel-shortcut-table">
        <thead><tr><th><?= glpiacessivel_e(glpiacessivel_t('Atalho')) ?></th><th><?= glpiacessivel_e(glpiacessivel_t('Acao')) ?></th></tr></thead>
        <tbody>
          <tr><td><kbd>Alt</kbd> + <kbd>1</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Ir para conteudo principal')) ?></td></tr>
          <tr><td><kbd>Alt</kbd> + <kbd>2</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Ir para menu de navegacao')) ?></td></tr>
          <tr><td><kbd>Alt</kbd> + <kbd>3</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Ir para campo de busca ou formulario principal')) ?></td></tr>
          <tr><td><kbd>Alt</kbd> + <kbd>C</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Alternar alto contraste')) ?></td></tr>
          <tr><td><kbd>Alt</kbd> + <kbd>T</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Alternar tema claro/noturno')) ?></td></tr>
          <tr><td><kbd>Alt</kbd> + <kbd>-</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Diminuir tamanho da fonte')) ?></td></tr>
          <tr><td><kbd>Alt</kbd> + <kbd>0</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Restaurar tamanho da fonte')) ?></td></tr>
          <tr><td><kbd>Alt</kbd> + <kbd>+</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Aumentar tamanho da fonte')) ?></td></tr>
          <tr><td><kbd>Alt</kbd> + <kbd>H</kbd><br><kbd>Ctrl</kbd> + <kbd>Alt</kbd> + <kbd>Shift</kbd> + <kbd>H</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Abrir ou fechar ajuda de acessibilidade')) ?></td></tr>
          <tr><td><kbd>Alt</kbd> + <kbd>A</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Abrir a entrada do portal acessivel')) ?></td></tr>
          <?php if ($chatbotEnabled && $canUseChatbot): ?>
          <tr><td><kbd>Alt</kbd> + <kbd>V</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Abrir chatbot operacional')) ?></td></tr>
          <?php endif; ?>
          <?php if ($canViewTickets): ?>
          <tr><td><kbd>Alt</kbd> + <kbd>P</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Ver meus chamados')) ?></td></tr>
          <?php endif; ?>
          <?php if ($canViewTickets): ?>
          <tr><td><kbd>Alt</kbd> + <kbd>G</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Ver todos os chamados permitidos')) ?></td></tr>
          <?php endif; ?>
          <?php if ($canCreateTicket): ?>
          <tr><td><kbd>Alt</kbd> + <kbd>N</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Ir para tela Abrir Chamado')) ?></td></tr>
          <?php endif; ?>
          <?php if ($canUseForms): ?>
          <tr><td><kbd>Alt</kbd> + <kbd>M</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Ir para tela Formularios')) ?></td></tr>
          <?php endif; ?>
          <?php if ($canViewKnowledgeBase): ?>
          <tr><td><kbd>Alt</kbd> + <kbd>B</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Ir para tela Base de Conhecimento')) ?></td></tr>
          <?php endif; ?>
          <?php if ($canViewCockpit): ?>
          <tr><td><kbd>Alt</kbd> + <kbd>O</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Ir para Cockpit operacional')) ?></td></tr>
          <?php endif; ?>
          <tr><td><kbd>Alt</kbd> + <kbd>F</kbd></td><td><?= glpiacessivel_e(glpiacessivel_t('Ir para FAQ publica acessivel')) ?></td></tr>
        </tbody>
      </table>
    </div>
    <div class="glpiacessivel-help-notes" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Orientacoes complementares de acessibilidade')) ?>">
      <section>
        <h3><?= glpiacessivel_e(glpiacessivel_t('Leitores de Tela')) ?></h3>
        <p><?= glpiacessivel_e(glpiacessivel_t('Este portal e otimizado para leitores de tela como NVDA, JAWS e VoiceOver.')) ?></p>
        <ul>
          <li><?= glpiacessivel_e(glpiacessivel_t('Landmarks: use teclas de navegacao rapida do leitor de tela, como R no NVDA, para pular entre secoes.')) ?></li>
          <li><?= glpiacessivel_e(glpiacessivel_t('Headings: use a tecla H do leitor de tela para navegar por titulos.')) ?></li>
          <li><?= glpiacessivel_e(glpiacessivel_t('Tabelas: navegue pelas celulas com os comandos de tabela do leitor de tela, como Ctrl+Alt+Setas quando suportado.')) ?></li>
          <li><?= glpiacessivel_e(glpiacessivel_t('Formularios: campos obrigatorios sao marcados e anunciados como obrigatorios.')) ?></li>
        </ul>
      </section>
      <section>
        <h3><?= glpiacessivel_e(glpiacessivel_t('Recursos Visuais')) ?></h3>
        <ul>
          <li><?= glpiacessivel_e(glpiacessivel_t('Modo escuro: ative via botao Tema, Alt+T ou Ctrl+Alt+Shift+T.')) ?></li>
          <li><?= glpiacessivel_e(glpiacessivel_t('Alto contraste: ative pela barra de acessibilidade, Alt+C ou Ctrl+Alt+Shift+K.')) ?></li>
          <li><?= glpiacessivel_e(glpiacessivel_t('Foco visivel: bordas destacadas indicam o elemento ativo.')) ?></li>
          <li><?= glpiacessivel_e(glpiacessivel_t('VLibras: traducao automatica para Lingua Brasileira de Sinais quando habilitada.')) ?></li>
        </ul>
      </section>
    </div>
    <div class="glpiacessivel-help-footer">
      <button type="button" class="glpiacessivel-button glpiacessivel-button-primary" data-glpiacessivel-help-close><?= glpiacessivel_e(glpiacessivel_t('Fechar')) ?></button>
    </div>
  </section>
  <span id="glpiacessivel-search-anchor" class="glpiacessivel-sr-only"><?= glpiacessivel_e(glpiacessivel_t('Busca')) ?></span>
  <h1 class="glpiacessivel-title"><?= glpiacessivel_e($title ?? glpiacessivel_t('Portal Acessivel')) ?></h1>
  <nav id="glpiacessivel-menu" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Navegacao do portal acessivel')) ?>" class="glpiacessivel-nav">
    <a href="<?= glpiacessivel_e(glpiacessivel_url('front/acessivel.php')) ?>" aria-keyshortcuts="Alt+A"<?= glpiacessivel_aria_current('front/acessivel.php') ?>><?= glpiacessivel_e(glpiacessivel_t('Entrada acessivel')) ?></a>
    <?php if ($canCreateTicket): ?>
      <a href="<?= glpiacessivel_e($createTicketUrl) ?>" aria-keyshortcuts="Alt+N"<?= glpiacessivel_aria_current('front/ticket.create.php') ?>><?= glpiacessivel_e(glpiacessivel_t('Novo chamado')) ?></a>
    <?php endif; ?>
    <?php if ($canUseForms): ?>
      <a href="<?= glpiacessivel_e(glpiacessivel_url('front/forms.php')) ?>" aria-keyshortcuts="Alt+M"<?= glpiacessivel_aria_current('front/forms.php') ?>><?= glpiacessivel_e(glpiacessivel_t('Formularios')) ?></a>
    <?php endif; ?>
    <?php if ($canViewTickets): ?>
      <a href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php')) ?>" aria-keyshortcuts="Alt+G"<?= glpiacessivel_aria_current('front/ticket.php') ?>><?= glpiacessivel_e(glpiacessivel_t('Chamados')) ?></a>
    <?php endif; ?>
    <?php if ($canViewCockpit): ?>
      <a href="<?= glpiacessivel_e(glpiacessivel_url('front/cockpit.php')) ?>" aria-keyshortcuts="Alt+O"<?= glpiacessivel_aria_current('front/cockpit.php') ?>><?= glpiacessivel_e(glpiacessivel_t('Cockpit')) ?></a>
    <?php endif; ?>
    <?php if ($canViewKnowledgeBase): ?>
      <a href="<?= glpiacessivel_e(glpiacessivel_url('front/knowledge.php')) ?>" aria-keyshortcuts="Alt+B"<?= glpiacessivel_aria_current('front/knowledge.php') ?>><?= glpiacessivel_e(glpiacessivel_t('Base de conhecimento')) ?></a>
    <?php endif; ?>
    <?php if ($chatbotEnabled && $canUseChatbot): ?>
      <a href="<?= glpiacessivel_e(glpiacessivel_url('front/chatbot.php')) ?>" aria-keyshortcuts="Alt+V Control+Alt+Shift+V"<?= glpiacessivel_aria_current('front/chatbot.php') ?>><?= glpiacessivel_e(glpiacessivel_t('Chatbot')) ?></a>
    <?php endif; ?>
    <?php if ($canManagePlaybooks): ?>
      <a href="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>"<?= glpiacessivel_aria_current('front/playbooks.php') ?>><?= glpiacessivel_e(glpiacessivel_t('Roteiros')) ?></a>
    <?php endif; ?>
  </nav>
  <?php if (is_array($flash)): ?>
    <?php $flashIsError = (($flash['type'] ?? '') === 'error'); ?>
    <div
      class="glpiacessivel-alert glpiacessivel-alert-<?= glpiacessivel_e($flash['type']) ?>"
      role="<?= $flashIsError ? 'alert' : 'status' ?>"
      aria-live="<?= $flashIsError ? 'assertive' : 'polite' ?>"
      <?= $flashIsError ? 'tabindex="-1" data-glpiacessivel-focus-alert' : '' ?>
    >
      <?= glpiacessivel_e($flash['message']) ?>
    </div>
  <?php endif; ?>
  <script>
    (function () {
      var body = document.body;
      var live = document.getElementById('glpiacessivel-live');
      var storageKey = 'glpiacessivel-login-preferences-v2';
      var themeButton = document.querySelector('button[data-glpiacessivel-theme], [role="button"][data-glpiacessivel-theme]');
      var contrastButton = document.querySelector('button[data-glpiacessivel-contrast], [role="button"][data-glpiacessivel-contrast]');
        var helpButton = document.querySelector('button[data-glpiacessivel-help], [role="button"][data-glpiacessivel-help]');
        var helpPanel = document.getElementById('glpiacessivel-help-panel');
        var helpCloseButtons = document.querySelectorAll('[data-glpiacessivel-help-close]');
        var prefs = { theme: 'light', contrast: false, fontScale: 1 };
        var shellI18n = <?= glpiacessivel_json_for_script([
          'theme_night_enabled' => glpiacessivel_t('Tema noturno ativado.'),
          'theme_light_enabled' => glpiacessivel_t('Tema claro ativado.'),
          'contrast_disabled_suffix' => glpiacessivel_t(' Alto contraste desativado.'),
          'contrast_enabled' => glpiacessivel_t('Alto contraste ativado.'),
          'contrast_disabled' => glpiacessivel_t('Alto contraste desativado.'),
          'help_opened' => glpiacessivel_t('Painel de ajuda aberto.'),
          'help_closed' => glpiacessivel_t('Painel de ajuda fechado.'),
          'font_adjusted' => glpiacessivel_t('Tamanho da fonte ajustado para {percent} por cento.'),
        ]) ?>;

      function shellText(key, params) {
        var template = shellI18n && shellI18n[key] ? String(shellI18n[key]) : key;
        var values = params || {};
        return template.replace(/\{([a-zA-Z0-9_]+)\}/g, function (match, name) {
          return Object.prototype.hasOwnProperty.call(values, name) ? String(values[name]) : match;
        });
      }

      function announce(message) {
        if (live) {
          live.textContent = message;
        }
      }

      function focusPageAlert() {
        var focusAlert = document.querySelector('[data-glpiacessivel-focus-alert]');
        if (focusAlert && typeof focusAlert.focus === 'function') {
          focusAlert.focus();
        }
      }

      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', focusPageAlert, { once: true });
      } else {
        focusPageAlert();
      }

      function readPrefs() {
        try {
          var raw = window.localStorage.getItem(storageKey);
          if (!raw) {
            return prefs;
          }
          var parsed = JSON.parse(raw);
          return {
            theme: parsed.theme === 'night' ? 'night' : 'light',
            contrast: parsed.contrast === true,
            fontScale: parsed.fontScale === 0.9 || parsed.fontScale === 1.1 || parsed.fontScale === 1.2 ? parsed.fontScale : 1
          };
        } catch (error) {
          return prefs;
        }
      }

      function writePrefs(next) {
        try {
          window.localStorage.setItem(storageKey, JSON.stringify(next));
        } catch (error) {
          // ignore storage restrictions
        }
      }

      function applyPrefs(next) {
        prefs = next;
        body.dataset.glpiacessivelTheme = prefs.theme;
        body.dataset.glpiacessivelContrast = prefs.contrast ? 'high' : 'default';
        body.style.fontSize = prefs.fontScale + 'rem';
        if (themeButton) {
          themeButton.setAttribute('aria-pressed', prefs.theme === 'night' ? 'true' : 'false');
        }
        if (contrastButton) {
          contrastButton.setAttribute('aria-pressed', prefs.contrast ? 'true' : 'false');
        }
      }

      var helpLastFocus = null;
      var helpHiddenBackground = [];

      function getHelpFocusableElements() {
        if (!helpPanel) {
          return [];
        }
        return Array.prototype.slice.call(helpPanel.querySelectorAll('a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'))
          .filter(function (element) {
            return element instanceof HTMLElement && !element.hidden && element.offsetParent !== null;
          });
      }

      function setHelpBackgroundHidden(hidden) {
        helpHiddenBackground.forEach(function (item) {
          if (item.hadAriaHidden) {
            item.element.setAttribute('aria-hidden', item.ariaHidden);
          } else {
            item.element.removeAttribute('aria-hidden');
          }
          if ('inert' in item.element) {
            item.element.inert = item.wasInert;
          }
        });
        helpHiddenBackground = [];

        if (!hidden || !helpPanel) {
          return;
        }

        Array.prototype.slice.call(document.body.children).forEach(function (child) {
          if (!(child instanceof HTMLElement) || child === helpPanel || child.contains(helpPanel)) {
            return;
          }
          helpHiddenBackground.push({
            element: child,
            hadAriaHidden: child.hasAttribute('aria-hidden'),
            ariaHidden: child.getAttribute('aria-hidden') || '',
            wasInert: 'inert' in child ? child.inert : false
          });
          child.setAttribute('aria-hidden', 'true');
          if ('inert' in child) {
            child.inert = true;
          }
        });

        var parent = helpPanel.parentElement;
        if (parent) {
          Array.prototype.slice.call(parent.children).forEach(function (sibling) {
            if (!(sibling instanceof HTMLElement) || sibling === helpPanel) {
              return;
            }
            helpHiddenBackground.push({
              element: sibling,
              hadAriaHidden: sibling.hasAttribute('aria-hidden'),
              ariaHidden: sibling.getAttribute('aria-hidden') || '',
              wasInert: 'inert' in sibling ? sibling.inert : false
            });
            sibling.setAttribute('aria-hidden', 'true');
            if ('inert' in sibling) {
              sibling.inert = true;
            }
          });
        }
      }

      function setHelpOpen(open) {
        if (!helpButton || !helpPanel) {
          return;
        }
        if (open) {
          helpLastFocus = document.activeElement instanceof HTMLElement ? document.activeElement : helpButton;
        }
        helpButton.setAttribute('aria-expanded', open ? 'true' : 'false');
        helpPanel.hidden = !open;
        setHelpBackgroundHidden(open);
        if (open) {
          var closeButton = helpPanel.querySelector('[data-glpiacessivel-help-close]');
          if (closeButton) {
            closeButton.focus();
          } else {
            helpPanel.focus();
          }
        } else if (helpLastFocus && typeof helpLastFocus.focus === 'function') {
          helpLastFocus.focus();
        }
      }

      function announceExternal(externalLiveRegion, message) {
        announce(message);
        if (externalLiveRegion && externalLiveRegion !== live && 'textContent' in externalLiveRegion) {
          externalLiveRegion.textContent = message;
        }
      }

      window.glpiacessivelToggleTheme = function (externalLiveRegion) {
        if (!themeButton) {
          return false;
        }
        var contrastWasActive = prefs.contrast;
        if (contrastWasActive) {
          prefs.contrast = false;
        }
        prefs.theme = prefs.theme === 'light' ? 'night' : 'light';
        applyPrefs(prefs);
        writePrefs(prefs);
        var message = (prefs.theme === 'night' ? shellText('theme_night_enabled') : shellText('theme_light_enabled')) + (contrastWasActive ? shellText('contrast_disabled_suffix') : '');
        announceExternal(externalLiveRegion, message);
        themeButton.focus();
        return true;
      };

      window.glpiacessivelToggleContrast = function (externalLiveRegion) {
        if (!contrastButton) {
          return false;
        }
        prefs.contrast = !prefs.contrast;
        applyPrefs(prefs);
        writePrefs(prefs);
        var message = prefs.contrast ? shellText('contrast_enabled') : shellText('contrast_disabled');
        announceExternal(externalLiveRegion, message);
        contrastButton.focus();
        return true;
      };

      window.glpiacessivelToggleHelp = function (externalLiveRegion) {
        if (!helpButton || !helpPanel) {
          return false;
        }
        var isOpen = helpButton.getAttribute('aria-expanded') === 'true';
        setHelpOpen(!isOpen);
        var message = !isOpen ? shellText('help_opened') : shellText('help_closed');
        announce(message);
        if (externalLiveRegion && externalLiveRegion !== live && 'textContent' in externalLiveRegion) {
          externalLiveRegion.textContent = message;
        }
        return true;
      };
      applyPrefs(readPrefs());

      if (themeButton) {
        themeButton.addEventListener('click', function () {
          window.glpiacessivelToggleTheme();
        });
      }

      if (contrastButton) {
        contrastButton.addEventListener('click', function () {
          window.glpiacessivelToggleContrast();
        });
      }

      Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-font]')).forEach(function (button) {
        button.addEventListener('click', function () {
          var action = button.getAttribute('data-glpiacessivel-font');
          if (action === 'increase') {
            prefs.fontScale = Math.min(1.2, prefs.fontScale + 0.1);
          } else if (action === 'decrease') {
            prefs.fontScale = Math.max(0.9, prefs.fontScale - 0.1);
          } else {
            prefs.fontScale = 1;
          }
          applyPrefs(prefs);
          writePrefs(prefs);
          announce(shellText('font_adjusted', { percent: Math.round(prefs.fontScale * 100) }));
        });
      });

      function normalizeShortcutKey(event) {
        var key = String(event.key || '').toLowerCase();
        var code = String(event.code || '').toLowerCase();
        if (key === '=' || key === 'add') {
          return '+';
        }
        if (key === '_' || key === 'subtract') {
          return '-';
        }
        if (key.length === 1) {
          return key;
        }
        if (code.indexOf('key') === 0 && code.length === 4) {
          return code.charAt(3);
        }
        if (code.indexOf('digit') === 0 && code.length === 6) {
          return code.charAt(5);
        }
        if (code === 'equal' || code === 'numpadadd') {
          return '+';
        }
        if (code === 'minus' || code === 'numpadsubtract') {
          return '-';
        }
        return key;
      }

      if (helpButton && helpPanel) {
        helpButton.addEventListener('click', function () {
          var isOpen = helpButton.getAttribute('aria-expanded') === 'true';
          setHelpOpen(!isOpen);
          announce(!isOpen ? shellText('help_opened') : shellText('help_closed'));
        });

        helpPanel.addEventListener('keydown', function (event) {
          if (event.key === 'Escape') {
            event.preventDefault();
            setHelpOpen(false);
            announce(shellText('help_closed'));
            return;
          }

          if (event.key !== 'Tab') {
            return;
          }

          var focusable = getHelpFocusableElements();
          if (focusable.length === 0) {
            event.preventDefault();
            helpPanel.focus();
            return;
          }

          var first = focusable[0];
          var last = focusable[focusable.length - 1];
          if (event.shiftKey && document.activeElement === first) {
            event.preventDefault();
            last.focus();
          } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault();
            first.focus();
          }
        });

        Array.prototype.slice.call(helpCloseButtons).forEach(function (button) {
          button.addEventListener('click', function () {
            setHelpOpen(false);
            announce(shellText('help_closed'));
          });
        });
      }
    })();
  </script>

