<?php
$routing = is_array($ticket['routing_context'] ?? null) ? $ticket['routing_context'] : [];
$itilActions = is_array($ticket['itil_actions'] ?? null) ? $ticket['itil_actions'] : [];
$satisfaction = is_array($ticket['satisfaction_state'] ?? null) ? $ticket['satisfaction_state'] : [];
$historyContext = is_array($ticket['history_context'] ?? null) ? $ticket['history_context'] : [];
$historyItems = array_values((array) ($historyContext['items'] ?? []));
$criticalConfirmations = is_array($critical_confirmations ?? null) ? $critical_confirmations : [];
$assignedUserIds = array_values(array_map('intval', (array) ($routing['assigned_user_ids'] ?? [])));
$observerUserIds = array_values(array_map('intval', (array) ($routing['observer_user_ids'] ?? [])));
$assignedGroupIds = array_values(array_map('intval', (array) ($routing['assigned_group_ids'] ?? [])));
$observerGroupIds = array_values(array_map('intval', (array) ($routing['observer_group_ids'] ?? [])));
$followupTemplates = array_values((array) ($ticket['followup_templates'] ?? []));
$taskCategories = array_values((array) ($routing['task_categories'] ?? []));
$taskStateOptions = array_values((array) ($routing['task_state_options'] ?? []));
$taskDurationOptions = array_values((array) ($routing['task_duration_options'] ?? []));
$assignableUsers = array_values((array) ($routing['assignable_users'] ?? []));
$assignableGroups = array_values((array) ($routing['assignable_groups'] ?? []));
$observerGroups = array_values((array) ($routing['observer_groups'] ?? []));
$ticketStatus = (int) ($ticket['status'] ?? 0);
$solvedStatus = defined('\CommonITILObject::SOLVED') ? (int) \CommonITILObject::SOLVED : 5;
$closedStatus = defined('\CommonITILObject::CLOSED') ? (int) \CommonITILObject::CLOSED : 6;
$isSolved = $ticketStatus === $solvedStatus;
$isClosed = $ticketStatus === $closedStatus;
$isTerminal = $isSolved || $isClosed;
$currentUserId = (int) ($_SESSION['glpiID'] ?? 0);
$requesterId = (int) ($ticket['requester_id'] ?? 0);
$canAddFollowup = !$isTerminal && !empty($itilActions['can_add_followup']);
$canAddTask = !$isTerminal && !empty($itilActions['can_add_task']);
$canAddPrivateFollowup = $canAddFollowup && !empty($itilActions['can_add_private_followup']);
$canAddPrivateTask = $canAddTask && !empty($itilActions['can_add_private_task']);
$canAddSolution = !$isTerminal && !empty($itilActions['can_add_solution']);
$canChangeStatus = !$isTerminal && !empty($itilActions['can_change_status']);
$canRoute = !$isTerminal && !empty($itilActions['can_route']);
$canDecideSolution = $isSolved && $requesterId > 0
    && ($requesterId === $currentUserId || !empty($routing['can_update']));
$itilTabs = [];
if ($canAddFollowup) {
    $itilTabs[] = ['key' => 'followup', 'label' => 'Responder', 'hint' => 'Acompanhamento'];
}
if ($canAddTask) {
    $itilTabs[] = ['key' => 'task', 'label' => 'Criar tarefa', 'hint' => 'Atividade tecnica'];
}
if ($canAddSolution) {
    $itilTabs[] = ['key' => 'solution', 'label' => 'Adicionar solucao', 'hint' => 'Encaminhar encerramento'];
}
$activeItilTab = (string) ($itilTabs[0]['key'] ?? '');
$defaultTaskState = (int) ($taskStateOptions[0]['id'] ?? 2);
foreach ($taskStateOptions as $taskStateOption) {
    $taskStateLabel = (string) ($taskStateOption['label'] ?? '');
    $taskStateId = (int) ($taskStateOption['id'] ?? 0);
    if ($taskStateId === 2 || stripos($taskStateLabel, 'fazer') !== false) {
        $defaultTaskState = $taskStateId;
        break;
    }
}
$followupTemplatePayload = [];
foreach ($followupTemplates as $template) {
    $templateId = (int) ($template['id'] ?? 0);
    if ($templateId > 0) {
        $followupTemplatePayload[(string) $templateId] = [
            'content' => (string) ($template['content'] ?? ''),
            'is_private' => !empty($template['is_private']) ? 1 : 0,
        ];
    }
}
$defaultFollowupIsPrivate = $canAddPrivateFollowup && !empty($itilActions['default_followup_is_private']);
$defaultTaskIsPrivate = $canAddPrivateTask && !empty($itilActions['default_task_is_private']);
$requesterName = trim((string) (($ticket['requester_firstname'] ?? '') . ' ' . ($ticket['requester_realname'] ?? '')));
if ($requesterName === '') {
    $requesterName = 'Nao informado';
}
$piiMaskingEnabled = !empty($ticket['pii_masking_enabled']);
$revealedPiiFields = array_fill_keys((array) ($ticket['revealed_pii_fields'] ?? []), true);
$canRevealPii = $piiMaskingEnabled && !empty($ticket['can_reveal_pii']);
$attachmentHelp = __('Opcional. O GLPI validara extensao, tamanho e permissao conforme a configuracao do servidor.', 'glpiacessivel');
$fileSelectionMessages = [
    'empty' => __('Nenhum anexo selecionado.', 'glpiacessivel'),
    'cleared' => __('Selecao de anexos limpa.', 'glpiacessivel'),
    'selected' => __('%d anexo(s) selecionado(s).', 'glpiacessivel'),
];
$formatDocumentSize = static function (int $bytes): string {
    if ($bytes <= 0) {
        return __('Tamanho nao informado', 'glpiacessivel');
    }
    if ($bytes >= 1024 * 1024) {
        return number_format($bytes / (1024 * 1024), 1, ',', '.') . ' MB';
    }
    if ($bytes >= 1024) {
        return number_format($bytes / 1024, 1, ',', '.') . ' KB';
    }

    return $bytes . ' B';
};
$documentTypeLabel = static function (array $document): string {
    $displayName = (string) ($document['display_name'] ?? $document['filename'] ?? '');
    $extension = strtoupper((string) pathinfo($displayName, PATHINFO_EXTENSION));
    if ($extension !== '') {
        return $extension;
    }
    $mime = trim((string) ($document['mime'] ?? ''));

    return $mime !== '' ? $mime : __('Tipo nao informado', 'glpiacessivel');
};
$renderDocuments = static function (
    array $documents,
    string $originLabel
) use ($formatDocumentSize, $documentTypeLabel): void {
    if ($documents === []) {
        return;
    }
    ?>
    <ul class="glpiacessivel-list glpiacessivel-document-list">
      <?php foreach ($documents as $document): ?>
        <?php
          $displayName = trim((string) ($document['display_name'] ?? $document['filename'] ?? $document['name'] ?? ''));
          $documentType = $documentTypeLabel($document);
          $documentSize = $formatDocumentSize((int) ($document['size'] ?? 0));
          $downloadLabel = sprintf(
              __('Baixar %1$s, documento %2$s, %3$s', 'glpiacessivel'),
              $displayName,
              $documentType,
              $documentSize
          );
        ?>
        <li>
          <a
            class="glpiacessivel-document-link"
            href="<?= glpiacessivel_e((string) ($document['download_url'] ?? '')) ?>"
            aria-label="<?= glpiacessivel_e($downloadLabel) ?>"
          ><?= glpiacessivel_e($displayName) ?></a>
          <dl class="glpiacessivel-document-meta">
            <div><dt><?= glpiacessivel_e(__('Formato', 'glpiacessivel')) ?></dt><dd><?= glpiacessivel_e($documentType) ?></dd></div>
            <div><dt><?= glpiacessivel_e(__('Tamanho', 'glpiacessivel')) ?></dt><dd><?= glpiacessivel_e($documentSize) ?></dd></div>
            <div><dt><?= glpiacessivel_e(__('Origem', 'glpiacessivel')) ?></dt><dd><?= glpiacessivel_e($originLabel) ?></dd></div>
            <?php if (!empty($document['date_mod'])): ?>
              <div><dt><?= glpiacessivel_e(__('Atualizado em', 'glpiacessivel')) ?></dt><dd><?= glpiacessivel_e((string) $document['date_mod']) ?></dd></div>
            <?php endif; ?>
            <?php if (array_key_exists('is_private', $document)): ?>
              <div><dt><?= glpiacessivel_e(__('Visibilidade', 'glpiacessivel')) ?></dt><dd><?= glpiacessivel_e(!empty($document['is_private']) ? __('Privado', 'glpiacessivel') : __('Publico', 'glpiacessivel')) ?></dd></div>
            <?php endif; ?>
          </dl>
        </li>
      <?php endforeach; ?>
    </ul>
    <?php
};
?>
<section class="glpiacessivel-card" aria-labelledby="detalhe-ticket">
  <h2 id="detalhe-ticket">Chamado #<?= (int) $ticket['id'] ?> - <?= glpiacessivel_e($ticket['name']) ?></h2>
  <div class="glpiacessivel-ticket-summary">
    <p>
      <strong>Status</strong>
      <span class="glpiacessivel-badge glpiacessivel-badge-status-<?= glpiacessivel_e(glpiacessivel_status_class($ticket['status'])) ?>">
        <?= glpiacessivel_e(glpiacessivel_ticket_status($ticket['status'])) ?>
      </span>
    </p>
    <p>
      <strong>Prioridade</strong>
      <span class="glpiacessivel-badge glpiacessivel-badge-priority-<?= glpiacessivel_e(glpiacessivel_priority_class($ticket['priority'])) ?>">
        <?= glpiacessivel_e(glpiacessivel_ticket_priority($ticket['priority'])) ?>
      </span>
    </p>
    <p><strong>Entidade</strong><span><?= glpiacessivel_e((string) ($ticket['entity_name'] ?? $ticket['entities_id'])) ?></span></p>
    <p><strong>Categoria</strong><span><?= glpiacessivel_e((string) ($ticket['category_name'] ?? 'Nao informado')) ?></span></p>
    <p><strong>Localizacao</strong><span><?= glpiacessivel_e((string) ($ticket['location_name'] ?? 'Nao informado')) ?></span></p>
    <p><strong>Ultima atualizacao</strong><span><?= glpiacessivel_e($ticket['date_mod']) ?></span></p>
  </div>

  <section aria-labelledby="bloco-atores">
    <h3 id="bloco-atores">Atores do chamado</h3>
    <div class="glpiacessivel-grid-3">
      <article class="glpiacessivel-note">
        <h4>Requerentes</h4>
        <ul class="glpiacessivel-list">
          <?php foreach (($ticket['actors']['requesters'] ?? []) as $actor): ?>
            <li><?= glpiacessivel_e((string) ($actor['name'] ?? '')) ?></li>
          <?php endforeach; ?>
          <?php if (empty($ticket['actors']['requesters'])): ?><li>Nao informado</li><?php endif; ?>
        </ul>
      </article>
      <article class="glpiacessivel-note">
        <h4>Atribuidos</h4>
        <ul class="glpiacessivel-list">
          <?php foreach (($ticket['actors']['assignees'] ?? []) as $actor): ?>
            <li><?= glpiacessivel_e((string) ($actor['name'] ?? '')) ?></li>
          <?php endforeach; ?>
          <?php if (empty($ticket['actors']['assignees'])): ?><li>Nao informado</li><?php endif; ?>
        </ul>
      </article>
      <article class="glpiacessivel-note">
        <h4>Observadores</h4>
        <ul class="glpiacessivel-list">
          <?php foreach (($ticket['actors']['watchers'] ?? []) as $actor): ?>
            <li><?= glpiacessivel_e((string) ($actor['name'] ?? '')) ?></li>
          <?php endforeach; ?>
          <?php if (empty($ticket['actors']['watchers'])): ?><li>Nao informado</li><?php endif; ?>
        </ul>
      </article>
    </div>
  </section>

  <section aria-labelledby="bloco-requisitante">
    <h3 id="bloco-requisitante">Requisitante</h3>
    <?php if ($piiMaskingEnabled): ?>
      <p class="glpiacessivel-muted">Os contatos pessoais estao mascarados conforme a configuracao do plugin.</p>
    <?php else: ?>
      <p class="glpiacessivel-muted">Os contatos pessoais sao exibidos conforme as permissoes nativas do GLPI.</p>
    <?php endif; ?>
    <div class="glpiacessivel-definition-grid">
      <p><strong>Nome</strong><span><?= glpiacessivel_e($requesterName) ?></span></p>
      <?php foreach ([
        'requester_email' => 'E-mail',
        'requester_phone' => 'Telefone',
        'requester_mobile' => 'Celular',
      ] as $piiField => $piiLabel): ?>
        <?php
          $piiValue = trim((string) ($ticket[$piiField] ?? ''));
          $piiRevealed = isset($revealedPiiFields[$piiField]);
        ?>
        <p>
          <strong><?= glpiacessivel_e($piiLabel) ?></strong>
          <span>
            <?= glpiacessivel_e($piiValue !== '' ? $piiValue : 'Nao informado') ?>
            <?php if ($piiMaskingEnabled && $piiValue !== ''): ?>
              <small>(<?= $piiRevealed ? 'revelado temporariamente' : 'mascarado' ?>)</small>
            <?php endif; ?>
          </span>
        </p>
      <?php endforeach; ?>
    </div>

    <?php if ($canRevealPii): ?>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-form glpiacessivel-pii-reveal-form">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['pii_reveal'] ?? $csrf_token) ?>" />
        <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="pii_reveal" />
        <fieldset>
          <legend>Revelar contato por 5 minutos</legend>
          <p id="pii-reveal-help" class="glpiacessivel-help-text">A revelacao exige permissao de atualizacao no chamado e fica registrada na auditoria.</p>
          <label for="pii_field">Dado</label>
          <select id="pii_field" name="pii_field" required aria-describedby="pii-reveal-help">
            <option value="">Selecione</option>
            <option value="requester_email">E-mail</option>
            <option value="requester_phone">Telefone</option>
            <option value="requester_mobile">Celular</option>
          </select>
          <label for="pii_reason">Motivo da consulta</label>
          <input id="pii_reason" name="pii_reason" type="text" maxlength="255" required aria-describedby="pii-reveal-help" />
          <button type="submit">Revelar dado selecionado</button>
        </fieldset>
      </form>
    <?php endif; ?>
  </section>

  <?php if ($canRoute): ?>
    <section aria-labelledby="roteamento-ticket" class="glpiacessivel-routing-panel">
      <h3 id="roteamento-ticket">Atribuicao e escalonamento</h3>
      <p class="glpiacessivel-muted">Atualize o grupo técnico, os técnicos atribuídos e os observadores, sejam pessoas ou grupos, usando os mesmos atores do GLPI.</p>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-routing-form">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['routing'] ?? $csrf_token) ?>" />
        <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="routing" />
        <div class="glpiacessivel-routing-grid">
          <div class="glpiacessivel-field-block">
            <label for="routing_groups">Grupos técnicos responsáveis</label>
            <select id="routing_groups" name="_groups_id_assign[]" multiple size="6" aria-describedby="routing_groups_help">
              <?php foreach ((array) ($routing['assignable_groups'] ?? []) as $group): ?>
                <?php $id = (int) ($group['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $assignedGroupIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($group['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_groups_help" class="glpiacessivel-help-text">Selecione um ou mais grupos responsáveis. Em listas múltiplas, use Ctrl (ou Command no macOS) para manter mais de uma seleção.</small>
          </div>
          <div class="glpiacessivel-field-block">
            <label for="routing_users">Técnicos atribuídos</label>
            <select id="routing_users" name="_users_id_assign[]" multiple size="6" aria-describedby="routing_users_help">
              <?php foreach ((array) ($routing['assignable_users'] ?? []) as $user): ?>
                <?php $id = (int) ($user['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $assignedUserIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($user['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_users_help" class="glpiacessivel-help-text">Selecione uma ou mais pessoas responsáveis pelo atendimento.</small>
          </div>
          <div class="glpiacessivel-field-block">
            <label for="routing_watchers">Pessoas observadoras</label>
            <select id="routing_watchers" name="_users_id_observer[]" multiple size="6" aria-describedby="routing_watchers_help">
              <?php foreach ((array) ($routing['assignable_users'] ?? []) as $user): ?>
                <?php $id = (int) ($user['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $observerUserIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($user['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_watchers_help" class="glpiacessivel-help-text">Selecione as pessoas que devem acompanhar o chamado sem assumir o atendimento.</small>
          </div>
          <div class="glpiacessivel-field-block">
            <label for="routing_observer_groups">Grupos observadores</label>
            <select id="routing_observer_groups" name="_groups_id_observer[]" multiple size="6" aria-describedby="routing_observer_groups_help">
              <?php foreach ($observerGroups as $group): ?>
                <?php $id = (int) ($group['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $observerGroupIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($group['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_observer_groups_help" class="glpiacessivel-help-text">Selecione os grupos cujos integrantes devem acompanhar o chamado sem assumir o atendimento. É possível escolher mais de um grupo.</small>
          </div>
        </div>
        <label for="routing_reason">Motivo do escalonamento</label>
        <input id="routing_reason" type="text" name="routing_reason" maxlength="255" placeholder="Ex.: direcionado para equipe responsavel" />
        <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary">Atualizar atribuição e observadores</button>
      </form>
    </section>
  <?php endif; ?>

  <section aria-labelledby="descricao-ticket">
    <h3 id="descricao-ticket">Descricao</h3>
    <article class="glpiacessivel-content"><?= \GlpiPlugin\Glpiacessivel\Support\RichTextFormatter::toHtml((string) $ticket['content']) ?></article>
  </section>

  <section aria-labelledby="documentos-ticket">
    <h3 id="documentos-ticket">Documentos e anexos</h3>
    <?php if (empty($ticket['documents'])): ?>
      <p class="glpiacessivel-empty">Nenhum documento vinculado.</p>
    <?php else: ?>
      <?php $renderDocuments((array) $ticket['documents'], __('Chamado', 'glpiacessivel')); ?>
    <?php endif; ?>
  </section>
</section>

<section class="glpiacessivel-card glpiacessivel-itil-actions" aria-labelledby="acoes-ticket">
  <div class="glpiacessivel-itil-actions-head">
    <div>
      <p class="glpiacessivel-eyebrow">Processamento do chamado</p>
      <h2 id="acoes-ticket">Interacoes e acoes ITIL</h2>
      <p class="glpiacessivel-muted">Use as mesmas etapas conceituais do GLPI: acompanhamento, tarefa, solucao e status. As permissoes e transicoes continuam validadas pelo core.</p>
    </div>
    <span class="glpiacessivel-meta-chip">Ticket #<?= (int) $ticket['id'] ?></span>
  </div>

  <?php if ($isSolved): ?>
    <article class="glpiacessivel-itil-secondary-form" aria-labelledby="aprovacao-solucao">
      <div>
        <h3 id="aprovacao-solucao">Aprovacao da solucao</h3>
        <p class="glpiacessivel-help-text">Este chamado esta solucionado. Como no GLPI, as acoes operacionais foram encerradas e resta aprovar ou recusar a solucao.</p>
      </div>
      <?php if ($canDecideSolution): ?>
        <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" enctype="multipart/form-data" class="glpiacessivel-itil-action-form" data-glpiacessivel-critical-form data-critical-title="Confirmar decisao sobre a solucao" data-critical-message="Revise antes de aprovar ou recusar a solucao do chamado #<?= (int) $ticket['id'] ?>." data-critical-consequence="Esta acao altera o ciclo de vida do chamado no GLPI.">
          <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['solution_decision'] ?? $csrf_token) ?>" />
          <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
          <input type="hidden" name="critical_confirmed" value="0" />
          <input type="hidden" name="critical_confirmation_token" value="" />
          <label for="solution_decision_comment">Comentarios</label>
          <textarea id="solution_decision_comment" name="content" aria-describedby="solution-decision-help"></textarea>
          <small id="solution-decision-help" class="glpiacessivel-help-text">Ao recusar, informe o motivo para reabrir o atendimento. Ao aprovar, o chamado sera encaminhado ao fechamento.</small>
          <label for="solution_decision_filename">Documento</label>
          <input id="solution_decision_filename" type="file" name="solution_decision_filename[]" multiple />
          <div class="glpiacessivel-itil-form-footer">
            <button type="submit" name="action" value="solution_refuse" class="glpiacessivel-button glpiacessivel-button-secondary" data-critical-confirmation-token="<?= glpiacessivel_e((string) ($criticalConfirmations['solution_refuse'] ?? '')) ?>" data-critical-message="Recusar a solucao reabre o atendimento e registra o motivo informado.">Recusar solucao</button>
            <button type="submit" name="action" value="solution_approve" class="glpiacessivel-button glpiacessivel-button-primary" data-critical-confirmation-token="<?= glpiacessivel_e((string) ($criticalConfirmations['solution_approve'] ?? '')) ?>" data-critical-message="Aprovar a solucao encaminha o chamado para fechamento.">Aprovar solucao</button>
          </div>
        </form>
      <?php else: ?>
        <p class="glpiacessivel-empty">A aprovacao da solucao esta disponivel apenas para o requisitante autorizado ou perfil tecnico permitido.</p>
      <?php endif; ?>
    </article>
  <?php elseif ($isClosed): ?>
    <article class="glpiacessivel-itil-secondary-form" aria-labelledby="chamado-fechado">
      <h3 id="chamado-fechado">Chamado fechado</h3>
      <p class="glpiacessivel-help-text">O chamado esta fechado. O fluxo operacional do GLPI nao permite novas acoes ITIL nesta etapa.</p>
    </article>
  <?php else: ?>
  <?php if ($itilTabs !== []): ?>
  <div class="glpiacessivel-itil-action-switcher" role="tablist" aria-label="Escolha a acao ITIL do chamado">
    <?php foreach ($itilTabs as $index => $tab): ?>
      <?php
        $tabKey = (string) ($tab['key'] ?? '');
        $isActiveTab = $index === 0;
      ?>
      <button
        type="button"
        id="itil-tab-<?= glpiacessivel_e($tabKey) ?>"
        class="glpiacessivel-itil-action-tab <?= $isActiveTab ? 'is-active' : '' ?>"
        role="tab"
        aria-selected="<?= $isActiveTab ? 'true' : 'false' ?>"
        aria-controls="itil-panel-<?= glpiacessivel_e($tabKey) ?>"
        tabindex="<?= $isActiveTab ? '0' : '-1' ?>"
        data-glpiacessivel-itil-tab="<?= glpiacessivel_e($tabKey) ?>"
      >
        <span aria-hidden="true"><?= $tabKey === 'followup' ? '+' : ($tabKey === 'task' ? 'OK' : '!') ?></span>
        <strong><?= glpiacessivel_e((string) ($tab['label'] ?? '')) ?></strong>
        <small><?= glpiacessivel_e((string) ($tab['hint'] ?? '')) ?></small>
      </button>
    <?php endforeach; ?>
  </div>

  <div class="glpiacessivel-itil-panel-stack">
    <?php if ($canAddFollowup): ?>
    <section id="itil-panel-followup" class="glpiacessivel-itil-panel" role="tabpanel" tabindex="0" aria-labelledby="itil-tab-followup" <?= $activeItilTab === 'followup' ? '' : 'hidden' ?>>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" enctype="multipart/form-data" class="glpiacessivel-itil-action-form">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['followup'] ?? $csrf_token) ?>" />
        <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="followup" />
        <div class="glpiacessivel-itil-panel-head">
          <div>
            <h3>Acompanhamento</h3>
            <p>Registre uma resposta ou atualizacao na timeline do chamado, como no botao Responder do GLPI.</p>
          </div>
        </div>
        <div class="glpiacessivel-followup-template-box">
          <div class="glpiacessivel-followup-template-grid">
            <div>
              <label for="itilfollowuptemplates_id">Modelo de acompanhamento</label>
              <select id="itilfollowuptemplates_id" name="itilfollowuptemplates_id" aria-describedby="followup-template-help">
                <option value="0">Sem modelo</option>
                <?php foreach ($followupTemplates as $template): ?>
                  <option value="<?= (int) ($template['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($template['name'] ?? '')) ?></option>
                <?php endforeach; ?>
                <?php if (empty($followupTemplates)): ?>
                  <option value="0" disabled>Nenhum modelo disponivel para este perfil e entidade</option>
                <?php endif; ?>
              </select>
            </div>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-apply-followup-template <?= empty($followupTemplates) ? 'disabled' : '' ?>>Aplicar modelo</button>
          </div>
          <small id="followup-template-help" class="glpiacessivel-help-text">Opcional. O conteudo do modelo e renderizado pelo GLPI conforme o chamado atual, como na timeline nativa.</small>
        </div>
        <script type="application/json" id="glpiacessivel-followup-template-data"><?= json_encode($followupTemplatePayload, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?></script>
        <?php if ($canAddPrivateFollowup): ?>
        <fieldset
          class="glpiacessivel-visibility-fieldset"
          data-glpiacessivel-visibility
          data-public-label="<?= glpiacessivel_e(__('Adicionar resposta publica', 'glpiacessivel')) ?>"
          data-private-label="<?= glpiacessivel_e(__('Adicionar nota interna', 'glpiacessivel')) ?>"
          aria-describedby="followup-visibility-help"
        >
          <legend><?= glpiacessivel_e(__('Visibilidade do acompanhamento', 'glpiacessivel')) ?></legend>
          <div class="glpiacessivel-visibility-options">
            <label class="glpiacessivel-visibility-option" for="followup-visibility-public">
              <input id="followup-visibility-public" type="radio" name="followup_is_private" value="0" required <?= !$defaultFollowupIsPrivate ? 'checked' : '' ?> aria-describedby="followup-visibility-public-help" />
              <span>
                <strong><?= glpiacessivel_e(__('Resposta publica', 'glpiacessivel')) ?></strong>
                <small id="followup-visibility-public-help"><?= glpiacessivel_e(__('Visivel ao solicitante e aos participantes autorizados no chamado.', 'glpiacessivel')) ?></small>
              </span>
            </label>
            <label class="glpiacessivel-visibility-option" for="followup-visibility-private">
              <input id="followup-visibility-private" type="radio" name="followup_is_private" value="1" required <?= $defaultFollowupIsPrivate ? 'checked' : '' ?> aria-describedby="followup-visibility-private-help" />
              <span>
                <strong><?= glpiacessivel_e(__('Nota interna privada', 'glpiacessivel')) ?></strong>
                <small id="followup-visibility-private-help"><?= glpiacessivel_e(__('Visivel somente aos usuarios autorizados a consultar itens privados.', 'glpiacessivel')) ?></small>
              </span>
            </label>
          </div>
          <small id="followup-visibility-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(__('A opcao inicial acompanha sua preferencia atual no GLPI. Os documentos anexados terao a mesma visibilidade.', 'glpiacessivel')) ?></small>
        </fieldset>
        <?php else: ?>
          <input type="hidden" name="followup_is_private" value="0" />
          <p class="glpiacessivel-help-text"><?= glpiacessivel_e(__('Este acompanhamento sera publico para os participantes autorizados no chamado.', 'glpiacessivel')) ?></p>
        <?php endif; ?>
        <label for="followup">Descricao do acompanhamento *</label>
        <textarea id="followup" name="content" required aria-describedby="followup-help"></textarea>
        <small id="followup-help" class="glpiacessivel-help-text">Exemplo: contato realizado, retorno do usuario, diagnostico parcial ou nova informacao.</small>
        <div class="glpiacessivel-field glpiacessivel-file-picker" data-glpiacessivel-file-picker>
          <label for="followup_filename"><?= glpiacessivel_e(__('Documentos', 'glpiacessivel')) ?></label>
          <input
            id="followup_filename"
            type="file"
            name="followup_filename[]"
            multiple
            aria-describedby="followup-filename-help followup-filename-status"
            data-glpiacessivel-file-input
          />
          <small id="followup-filename-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($attachmentHelp) ?></small>
          <div class="glpiacessivel-file-actions">
            <button
              type="button"
              class="glpiacessivel-button glpiacessivel-button-secondary"
              aria-controls="followup-filename-list"
              data-glpiacessivel-file-clear
              hidden
            ><?= glpiacessivel_e(__('Limpar anexos', 'glpiacessivel')) ?></button>
          </div>
          <p id="followup-filename-status" class="glpiacessivel-sr-only" aria-live="polite" aria-atomic="true"></p>
          <ul id="followup-filename-list" class="glpiacessivel-file-list" data-glpiacessivel-file-list></ul>
        </div>
        <div class="glpiacessivel-itil-form-footer">
          <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary" data-glpiacessivel-visibility-submit><?= glpiacessivel_e(__('Adicionar resposta publica', 'glpiacessivel')) ?></button>
        </div>
      </form>
    </section>
    <?php endif; ?>

    <?php if ($canAddTask): ?>
    <section id="itil-panel-task" class="glpiacessivel-itil-panel" role="tabpanel" tabindex="0" aria-labelledby="itil-tab-task" <?= $activeItilTab === 'task' ? '' : 'hidden' ?>>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" enctype="multipart/form-data" class="glpiacessivel-itil-action-form">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['task'] ?? $csrf_token) ?>" />
        <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="task" />
        <div class="glpiacessivel-itil-panel-head">
          <div>
            <h3>Criar tarefa</h3>
            <p>Registre uma atividade tecnica executada ou planejada. Campos opcionais seguem a gravacao nativa do GLPI quando disponiveis.</p>
          </div>
        </div>
        <div class="glpiacessivel-itil-editor-layout">
          <div class="glpiacessivel-itil-editor-main">
            <?php if ($canAddPrivateTask): ?>
            <fieldset
              class="glpiacessivel-visibility-fieldset"
              data-glpiacessivel-visibility
              data-public-label="<?= glpiacessivel_e(__('Adicionar tarefa publica', 'glpiacessivel')) ?>"
              data-private-label="<?= glpiacessivel_e(__('Adicionar tarefa interna', 'glpiacessivel')) ?>"
              aria-describedby="task-visibility-help"
            >
              <legend><?= glpiacessivel_e(__('Visibilidade da tarefa', 'glpiacessivel')) ?></legend>
              <div class="glpiacessivel-visibility-options">
                <label class="glpiacessivel-visibility-option" for="task-visibility-public">
                  <input id="task-visibility-public" type="radio" name="task_is_private" value="0" required <?= !$defaultTaskIsPrivate ? 'checked' : '' ?> aria-describedby="task-visibility-public-help" />
                  <span>
                    <strong><?= glpiacessivel_e(__('Tarefa publica', 'glpiacessivel')) ?></strong>
                    <small id="task-visibility-public-help"><?= glpiacessivel_e(__('Visivel na timeline para os participantes autorizados pelo GLPI.', 'glpiacessivel')) ?></small>
                  </span>
                </label>
                <label class="glpiacessivel-visibility-option" for="task-visibility-private">
                  <input id="task-visibility-private" type="radio" name="task_is_private" value="1" required <?= $defaultTaskIsPrivate ? 'checked' : '' ?> aria-describedby="task-visibility-private-help" />
                  <span>
                    <strong><?= glpiacessivel_e(__('Tarefa interna privada', 'glpiacessivel')) ?></strong>
                    <small id="task-visibility-private-help"><?= glpiacessivel_e(__('Visivel somente aos usuarios autorizados a consultar tarefas privadas.', 'glpiacessivel')) ?></small>
                  </span>
                </label>
              </div>
              <small id="task-visibility-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(__('A opcao inicial acompanha sua preferencia atual no GLPI. Os documentos anexados terao a mesma visibilidade.', 'glpiacessivel')) ?></small>
            </fieldset>
            <?php else: ?>
              <input type="hidden" name="task_is_private" value="0" />
              <p class="glpiacessivel-help-text"><?= glpiacessivel_e(__('Esta tarefa sera publica para os participantes autorizados no chamado.', 'glpiacessivel')) ?></p>
            <?php endif; ?>
            <label for="task">Descricao da tarefa *</label>
            <textarea id="task" name="content" required aria-describedby="task-help"></textarea>
            <small id="task-help" class="glpiacessivel-help-text">Use para registrar atividade operacional, execucao tecnica ou acao futura.</small>
            <div class="glpiacessivel-field glpiacessivel-file-picker" data-glpiacessivel-file-picker>
              <label for="task_filename"><?= glpiacessivel_e(__('Documentos', 'glpiacessivel')) ?></label>
              <input
                id="task_filename"
                type="file"
                name="task_filename[]"
                multiple
                aria-describedby="task-filename-help task-filename-status"
                data-glpiacessivel-file-input
              />
              <small id="task-filename-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($attachmentHelp) ?></small>
              <div class="glpiacessivel-file-actions">
                <button
                  type="button"
                  class="glpiacessivel-button glpiacessivel-button-secondary"
                  aria-controls="task-filename-list"
                  data-glpiacessivel-file-clear
                  hidden
                ><?= glpiacessivel_e(__('Limpar anexos', 'glpiacessivel')) ?></button>
              </div>
              <p id="task-filename-status" class="glpiacessivel-sr-only" aria-live="polite" aria-atomic="true"></p>
              <ul id="task-filename-list" class="glpiacessivel-file-list" data-glpiacessivel-file-list></ul>
            </div>
          </div>
          <aside class="glpiacessivel-itil-editor-side" aria-label="Campos complementares da tarefa">
            <label for="taskcategories_id">Categoria da tarefa</label>
            <select id="taskcategories_id" name="taskcategories_id">
              <option value="0">Nao informar</option>
              <?php foreach ($taskCategories as $category): ?>
                <option value="<?= (int) ($category['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($category['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>

            <div class="glpiacessivel-itil-mini-grid">
              <div>
                <label for="task_begin">Inicio planejado</label>
                <input id="task_begin" type="datetime-local" name="task_begin" />
              </div>
              <div>
                <label for="task_end">Fim planejado</label>
                <input id="task_end" type="datetime-local" name="task_end" />
              </div>
            </div>

            <label for="task_state">Estado</label>
            <select id="task_state" name="task_state">
              <?php foreach ($taskStateOptions as $state): ?>
                <?php $stateId = (int) ($state['id'] ?? 0); ?>
                <option value="<?= $stateId ?>" <?= $stateId === $defaultTaskState ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($state['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>


            <label for="task_actiontime">Duracao</label>
            <select id="task_actiontime" name="task_actiontime">
              <?php foreach ($taskDurationOptions as $duration): ?>
                <option value="<?= (int) ($duration['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($duration['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>

            <label for="task_users_id_tech">Tecnico responsavel</label>
            <select id="task_users_id_tech" name="task_users_id_tech">
              <option value="0">Usuario atual / nao alterar</option>
              <?php foreach ($assignableUsers as $user): ?>
                <option value="<?= (int) ($user['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($user['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>

            <label for="task_groups_id_tech">Grupo tecnico</label>
            <select id="task_groups_id_tech" name="task_groups_id_tech">
              <option value="0">Nao informar</option>
              <?php foreach ($assignableGroups as $group): ?>
                <option value="<?= (int) ($group['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($group['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
          </aside>
        </div>
        <div class="glpiacessivel-itil-form-footer">
          <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary" data-glpiacessivel-visibility-submit><?= glpiacessivel_e(__('Adicionar tarefa publica', 'glpiacessivel')) ?></button>
        </div>
      </form>
    </section>
    <?php endif; ?>

    <?php if ($canAddSolution): ?>
    <section id="itil-panel-solution" class="glpiacessivel-itil-panel" role="tabpanel" tabindex="0" aria-labelledby="itil-tab-solution" <?= $activeItilTab === 'solution' ? '' : 'hidden' ?>>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-itil-action-form" data-glpiacessivel-critical-form data-critical-title="Confirmar adicao de solucao" data-critical-message="Revise a solucao antes de marcar o chamado #<?= (int) $ticket['id'] ?> como solucionado." data-critical-consequence="Ao salvar, o fluxo atual marca o chamado como solucionado.">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['solution'] ?? $csrf_token) ?>" />
        <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="solution" />
        <input type="hidden" name="critical_confirmed" value="0" />
        <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['solution'] ?? '')) ?>" />
        <div class="glpiacessivel-itil-panel-head">
          <div>
            <h3>Adicionar solucao</h3>
            <p>Informe a solucao aplicada para encaminhar o chamado ao encerramento.</p>
          </div>
        </div>
        <label for="solution">Descricao da solucao *</label>
        <textarea id="solution" name="content" required aria-describedby="solution-help"></textarea>
        <small id="solution-help" class="glpiacessivel-help-text">Descreva causa, acao executada e validacao. Ao salvar, o fluxo atual marca o chamado como solucionado.</small>
        <div class="glpiacessivel-itil-form-footer">
          <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary">Adicionar solucao</button>
        </div>
      </form>
    </section>
    <?php endif; ?>
  </div>
  <?php else: ?>
    <p class="glpiacessivel-empty" role="status">Nenhuma acao ITIL esta disponivel para este chamado com seu perfil e entidade atuais.</p>
  <?php endif; ?>

  <script>
    (function () {
      var select = document.getElementById('itilfollowuptemplates_id');
      var textarea = document.getElementById('followup');
      var applyButton = document.querySelector('[data-glpiacessivel-apply-followup-template]');
      var dataElement = document.getElementById('glpiacessivel-followup-template-data');
      if (select && textarea && applyButton && dataElement) {
        var templates = {};
        try {
          templates = JSON.parse(dataElement.textContent || '{}');
        } catch (error) {
          templates = {};
        }

        function applyTemplate() {
          var id = String(select.value || '0');
          var template = templates[id] || {};
          var content = typeof template === 'string' ? template : (template.content || '');
          if (id === '0' || content.trim() === '') {
            return;
          }

          if (textarea.value.trim() !== '' && !window.confirm('Substituir o texto atual pelo modelo selecionado?')) {
            return;
          }

          textarea.value = content;
          if (typeof template === 'object') {
            var privacy = String(Number(template.is_private) === 1 ? 1 : 0);
            var privacyOption = document.querySelector('input[name="followup_is_private"][value="' + privacy + '"]');
            if (privacyOption) {
              privacyOption.checked = true;
              privacyOption.dispatchEvent(new Event('change', { bubbles: true }));
            }
          }
          textarea.focus();
          var live = document.getElementById('glpiacessivel-live') || document.getElementById('glpiacessivel-live-region');
          if (live) {
            live.textContent = 'Modelo de acompanhamento aplicado.';
          }
        }

        applyButton.addEventListener('click', applyTemplate);
      }

      Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-visibility]')).forEach(function (fieldset) {
        var form = fieldset.closest('form');
        var submit = form ? form.querySelector('[data-glpiacessivel-visibility-submit]') : null;
        var radios = Array.prototype.slice.call(fieldset.querySelectorAll('input[type="radio"]'));
        if (!submit || radios.length === 0) {
          return;
        }

        function updateSubmitLabel() {
          var selected = radios.find(function (radio) { return radio.checked; });
          var isPrivate = selected && selected.value === '1';
          submit.textContent = isPrivate
            ? fieldset.getAttribute('data-private-label')
            : fieldset.getAttribute('data-public-label');
        }

        radios.forEach(function (radio) {
          radio.addEventListener('change', updateSubmitLabel);
        });
        updateSubmitLabel();
      });

      var fileSelectionMessages = <?= json_encode($fileSelectionMessages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '{}' ?>;
      Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-file-picker]')).forEach(function (picker) {
        var input = picker.querySelector('[data-glpiacessivel-file-input]');
        var list = picker.querySelector('[data-glpiacessivel-file-list]');
        var clearButton = picker.querySelector('[data-glpiacessivel-file-clear]');
        var statusId = input ? (input.getAttribute('aria-describedby') || '').split(/\s+/).filter(function (id) {
          return id.indexOf('-status') !== -1;
        })[0] : '';
        var status = statusId ? document.getElementById(statusId) : null;
        if (!input || !list || !clearButton || !status) {
          return;
        }

        function renderSelectedFiles(announcement) {
          list.innerHTML = '';
          var files = Array.prototype.slice.call(input.files || []);
          files.forEach(function (file) {
            var item = document.createElement('li');
            var sizeKb = Math.max(1, Math.ceil((file.size || 0) / 1024));
            item.textContent = file.name + ' (' + sizeKb + ' KB)';
            list.appendChild(item);
          });
          clearButton.hidden = files.length === 0;
          if (announcement) {
            status.textContent = files.length === 0
              ? fileSelectionMessages.empty
              : String(fileSelectionMessages.selected || '').replace('%d', String(files.length));
          }
        }

        input.addEventListener('change', function () {
          renderSelectedFiles(true);
        });
        clearButton.addEventListener('click', function () {
          input.value = '';
          renderSelectedFiles(false);
          status.textContent = fileSelectionMessages.cleared;
          input.focus();
        });
        renderSelectedFiles(false);
      });

      var tabs = Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-itil-tab]'));
      if (tabs.length === 0) {
        return;
      }

      function activateTab(tab) {
        tabs.forEach(function (item) {
          var panel = document.getElementById(item.getAttribute('aria-controls') || '');
          var active = item === tab;
          item.classList.toggle('is-active', active);
          item.setAttribute('aria-selected', active ? 'true' : 'false');
          item.setAttribute('tabindex', active ? '0' : '-1');
          if (panel) {
            panel.hidden = !active;
          }
        });
        tab.focus();
      }

      tabs.forEach(function (tab, index) {
        tab.setAttribute('tabindex', index === 0 ? '0' : '-1');
        tab.addEventListener('click', function () {
          activateTab(tab);
        });
        tab.addEventListener('keydown', function (event) {
          var next = index;
          if (event.key === 'ArrowRight') {
            next = (index + 1) % tabs.length;
          } else if (event.key === 'ArrowLeft') {
            next = (index - 1 + tabs.length) % tabs.length;
          } else if (event.key === 'Home') {
            next = 0;
          } else if (event.key === 'End') {
            next = tabs.length - 1;
          } else {
            return;
          }
          event.preventDefault();
          activateTab(tabs[next]);
        });
      });
    })();
  </script>

  <div class="glpiacessivel-itil-secondary-grid">
    <?php if ($canChangeStatus): ?>
    <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-itil-secondary-form" data-glpiacessivel-critical-form data-critical-title="Confirmar alteracao de status" data-critical-message="Revise a transicao de status do chamado #<?= (int) $ticket['id'] ?>." data-critical-consequence="A alteracao fica registrada no historico do GLPI.">
      <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['status'] ?? $csrf_token) ?>" />
      <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
      <input type="hidden" name="action" value="status" />
      <input type="hidden" name="critical_confirmed" value="0" />
      <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['status'] ?? '')) ?>" />
      <div>
        <h3>Status do chamado</h3>
        <p class="glpiacessivel-help-text">Selecione uma transicao permitida pelo perfil e pelo estado atual.</p>
      </div>
      <label for="status">Novo status</label>
      <select id="status" name="status">
        <?php foreach (($ticket['allowed_transitions'] ?? []) as $allowed): ?>
          <option value="<?= (int) $allowed ?>"><?= glpiacessivel_e(glpiacessivel_ticket_status($allowed)) ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary">Atualizar status</button>
    </form>
    <?php endif; ?>

    <?php if (!empty($satisfaction['available'])): ?>
      <article class="glpiacessivel-itil-secondary-form" aria-labelledby="satisfacao-ticket">
        <div>
          <h3 id="satisfacao-ticket">Satisfacao do requisitante</h3>
          <p class="glpiacessivel-help-text">Disponivel porque o GLPI gerou uma pesquisa de satisfacao para este chamado fechado.</p>
        </div>
        <?php if (!empty($satisfaction['can_answer'])): ?>
          <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-itil-action-form" data-glpiacessivel-critical-form data-critical-title="Confirmar resposta da satisfacao" data-critical-message="Revise a nota de satisfacao do chamado #<?= (int) $ticket['id'] ?> antes de enviar." data-critical-consequence="A resposta fica registrada na pesquisa de satisfacao do GLPI.">
            <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['requester_decision'] ?? $csrf_token) ?>" />
            <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
            <input type="hidden" name="action" value="requester_decision" />
            <input type="hidden" name="critical_confirmed" value="0" />
            <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['requester_decision'] ?? '')) ?>" />
            <label for="decision">Nota de satisfacao</label>
            <select id="decision" name="decision">
              <option value="5" <?= (int) ($satisfaction['score'] ?? 0) === 5 ? 'selected' : '' ?>>Muito satisfeito</option>
              <option value="4" <?= (int) ($satisfaction['score'] ?? 0) === 4 ? 'selected' : '' ?>>Satisfeito</option>
              <option value="3" <?= (int) ($satisfaction['score'] ?? 0) === 3 ? 'selected' : '' ?>>Neutro</option>
              <option value="2" <?= (int) ($satisfaction['score'] ?? 0) === 2 ? 'selected' : '' ?>>Insatisfeito</option>
              <option value="1" <?= (int) ($satisfaction['score'] ?? 0) === 1 ? 'selected' : '' ?>>Muito insatisfeito</option>
            </select>
            <label for="decision_comment">Comentario</label>
            <input id="decision_comment" type="text" name="content" maxlength="255" value="<?= glpiacessivel_e((string) ($satisfaction['comment'] ?? '')) ?>" />
            <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary">Responder pesquisa</button>
          </form>
        <?php else: ?>
          <p class="glpiacessivel-empty">Pesquisa disponivel apenas para o requisitante autorizado ou ja bloqueada pelo GLPI.</p>
        <?php endif; ?>
      </article>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="timeline-ticket">
  <h2 id="timeline-ticket">Timeline operacional</h2>
  <p class="glpiacessivel-muted"><?= glpiacessivel_e(__('A linha do tempo mostra as interacoes ITIL que seu perfil pode consultar. Itens privados sao identificados em texto.', 'glpiacessivel')) ?></p>
  <?php if (count($ticket['timeline']) === 0): ?>
    <p class="glpiacessivel-empty" role="status"><?= glpiacessivel_e(__('Nenhum evento disponivel para este chamado com as permissoes atuais.', 'glpiacessivel')) ?></p>
  <?php else: ?>
    <ol class="glpiacessivel-timeline">
      <?php foreach ($ticket['timeline'] as $event): ?>
        <li>
          <div class="glpiacessivel-timeline-marker" aria-hidden="true"></div>
          <article class="glpiacessivel-timeline-body">
            <header>
              <span class="glpiacessivel-meta-chip"><?= glpiacessivel_e(glpiacessivel_timeline_label($event['type'])) ?></span>
              <?php if (array_key_exists('is_private', $event)): ?>
                <span class="glpiacessivel-meta-chip"><?= glpiacessivel_e(!empty($event['is_private']) ? __('Privado', 'glpiacessivel') : __('Publico', 'glpiacessivel')) ?></span>
              <?php endif; ?>
              <time datetime="<?= glpiacessivel_e((string) $event['date']) ?>"><?= glpiacessivel_e((string) $event['date']) ?></time>
            </header>
            <?php if (!empty($event['author_name'])): ?>
              <p class="glpiacessivel-muted"><?= glpiacessivel_e(sprintf(__('Autor: %s', 'glpiacessivel'), (string) $event['author_name'])) ?></p>
            <?php endif; ?>
            <div class="glpiacessivel-content"><?= \GlpiPlugin\Glpiacessivel\Support\RichTextFormatter::toHtml((string) $event['content']) ?></div>
            <?php if (!empty($event['documents'])): ?>
              <?php
                $eventDocumentTitleId = 'documentos-' . (string) $event['type'] . '-' . (int) $event['id'];
                $eventDocumentOrigin = $event['type'] === 'task'
                    ? __('Tarefa do chamado', 'glpiacessivel')
                    : __('Acompanhamento do chamado', 'glpiacessivel');
              ?>
              <section class="glpiacessivel-timeline-documents" aria-labelledby="<?= glpiacessivel_e($eventDocumentTitleId) ?>">
                <h3 id="<?= glpiacessivel_e($eventDocumentTitleId) ?>"><?= glpiacessivel_e(__('Anexos deste evento', 'glpiacessivel')) ?></h3>
                <?php $renderDocuments((array) $event['documents'], $eventDocumentOrigin); ?>
              </section>
            <?php endif; ?>
          </article>
        </li>
      <?php endforeach; ?>
    </ol>
  <?php endif; ?>
</section>


<?php if (!empty($historyContext['can_view'])): ?>
<section class="glpiacessivel-card" aria-labelledby="historico-ticket" aria-describedby="historico-ticket-desc">
  <h2 id="historico-ticket">Historico detalhado do chamado</h2>
  <p id="historico-ticket-desc" class="glpiacessivel-muted">Alteracoes registradas no historico nativo do GLPI, limitadas ao que seu perfil pode consultar.</p>
  <?php if (empty($historyContext['available'])): ?>
    <p class="glpiacessivel-empty" role="status">Historico indisponivel no momento. Tente novamente mais tarde.</p>
  <?php elseif (count($historyItems) === 0): ?>
    <p class="glpiacessivel-empty" role="status">Nenhuma alteracao detalhada disponivel para este chamado.</p>
  <?php else: ?>
    <ol class="glpiacessivel-timeline">
      <?php foreach ($historyItems as $index => $event): ?>
        <?php
          $eventId = 'historico-evento-' . (int) ($event['id'] ?? ($index + 1));
          $eventDate = (string) ($event['date'] ?? '');
          $eventField = (string) ($event['field'] ?? '');
          $eventUser = (string) ($event['user'] ?? '');
          $eventAction = (string) ($event['action'] ?? '');
          $eventSummary = (string) ($event['summary'] ?? '');
        ?>
        <li>
          <div class="glpiacessivel-timeline-marker" aria-hidden="true"></div>
          <article class="glpiacessivel-timeline-body" aria-labelledby="<?= glpiacessivel_e($eventId) ?>">
            <header>
              <h3 id="<?= glpiacessivel_e($eventId) ?>" class="glpiacessivel-sr-only">
                <?= glpiacessivel_e('Alteracao do chamado em ' . ($eventDate !== '' ? $eventDate : 'data nao informada')) ?>
              </h3>
              <span class="glpiacessivel-meta-chip"><?= glpiacessivel_e($eventField !== '' ? $eventField : 'Historico') ?></span>
              <?php if ($eventDate !== ''): ?><time datetime="<?= glpiacessivel_e($eventDate) ?>"><?= glpiacessivel_e($eventDate) ?></time><?php endif; ?>
            </header>
            <p><?= glpiacessivel_e($eventSummary) ?></p>
            <?php if ($eventUser !== '' || $eventAction !== ''): ?>
              <p class="glpiacessivel-muted">
                <?php if ($eventUser !== ''): ?>Usuario: <?= glpiacessivel_e($eventUser) ?><?php endif; ?>
                <?php if ($eventAction !== ''): ?><?= $eventUser !== '' ? ' | ' : '' ?>Acao: <?= glpiacessivel_e($eventAction) ?><?php endif; ?>
              </p>
            <?php endif; ?>
          </article>
        </li>
      <?php endforeach; ?>
    </ol>
    <p class="glpiacessivel-help-text">Exibindo ate <?= (int) ($historyContext['limit'] ?? 50) ?> registro(s) recentes do historico nativo.</p>
  <?php endif; ?>
</section>
<?php endif; ?>
<?php if (!empty($satisfaction['exists'])): ?>
  <section class="glpiacessivel-card" aria-labelledby="decisao-requisitante">
    <h2 id="decisao-requisitante">Satisfacao registrada</h2>
    <div class="glpiacessivel-definition-grid">
      <p><strong>Nota</strong><span><?= glpiacessivel_e((string) ($satisfaction['score'] ?? 'N/D')) ?></span></p>
      <p><strong>Respondida em</strong><span><?= glpiacessivel_e((string) ($satisfaction['date_answered'] ?? '')) ?></span></p>
      <p><strong>Comentario</strong><span><?= glpiacessivel_e((string) ($satisfaction['comment'] ?? '')) ?></span></p>
    </div>
  </section>
<?php endif; ?>
