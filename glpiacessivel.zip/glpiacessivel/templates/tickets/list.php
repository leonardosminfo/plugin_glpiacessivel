<?php
global $CFG_GLPI;

$items = (array) ($result['items'] ?? []);
$page = max(1, (int) ($result['page'] ?? 1));
$pages = max(1, (int) ($result['pages'] ?? 1));
$total = max(0, (int) ($result['total'] ?? 0));
$pageSize = max(1, (int) ($filters['page_size'] ?? 20));
$backend = (string) ($result['backend'] ?? 'native_saved_search_blocked');
$showOperationalDiagnostics = !empty($showOperationalDiagnostics);
$backendReason = (string) ($result['backend_reason'] ?? '');
$backendLabel = $backend === 'search_api'
  ? 'Listagem carregada pelo modo nativo do GLPI.'
  : 'A listagem nao foi ampliada: a Search API do GLPI esta indisponivel para esta consulta.';
$firstItem = $total > 0 ? (($page - 1) * $pageSize) + 1 : 0;
$lastItem = $total > 0 ? min($total, $firstItem + count($items) - 1) : 0;
$nativeTicketUrl = (string) (($CFG_GLPI['root_doc'] ?? '') . '/front/ticket.php');
$savedSearchCatalog = is_array($saved_search_catalog ?? null) ? $saved_search_catalog : [];
$nativeSavedSearches = array_values(array_filter(
  (array) ($savedSearchCatalog['native'] ?? []),
  'is_array'
));

/**
 * Contrato progressivo da interface nativa:
 * - saved_search_catalog.native (ou native_catalog.items): itens do GLPI;
 * - query, previous_cursor/prev_cursor, next_cursor, total e page_size: catalogo;
 * - capabilities.can_create_private e editor: formulario de criacao/edicao;
 * - capabilities.can_edit/can_set_default/can_delete, edit_url e
 *   expected_fingerprint: operacoes permitidas por item.
 *
 * Sem capacidades explicitas, a interface permanece somente leitura. Nenhuma
 * pesquisa e copiada, importada ou persistida pelo plugin.
 */
$nativeCatalog = is_array($savedSearchCatalog['native_catalog'] ?? null)
  ? $savedSearchCatalog['native_catalog']
  : $savedSearchCatalog;
$nativeCatalogPagination = is_array($nativeCatalog['pagination'] ?? null)
  ? $nativeCatalog['pagination']
  : [];
$nativeCatalogCapabilities = is_array($nativeCatalog['capabilities'] ?? null)
  ? $nativeCatalog['capabilities']
  : [];
$nativeCatalogEditor = is_array($nativeCatalog['editor'] ?? null)
  ? $nativeCatalog['editor']
  : [];
$nativeCatalogUsesBackendPagination = array_key_exists('items', $nativeCatalog)
  || array_key_exists('next_cursor', $nativeCatalog)
  || array_key_exists('next_cursor', $nativeCatalogPagination);
$nativeCatalogItems = array_key_exists('items', $nativeCatalog)
  ? array_values(array_filter((array) $nativeCatalog['items'], 'is_array'))
  : $nativeSavedSearches;
$nativeCatalogPageSize = 25;
$nativeCatalogQuery = trim((string) ($_GET['saved_search_q'] ?? ($nativeCatalog['query'] ?? '')));
$nativeCatalogQuery = substr($nativeCatalogQuery, 0, 120);
$nativeCatalogCursor = (string) ($_GET['saved_search_cursor'] ?? '');
$nativeCatalogOffset = ctype_digit($nativeCatalogCursor) ? (int) $nativeCatalogCursor : 0;

if (!$nativeCatalogUsesBackendPagination && $nativeCatalogQuery !== '') {
  $nativeCatalogItems = array_values(array_filter(
    $nativeCatalogItems,
    static function (array $saved) use ($nativeCatalogQuery): bool {
      $searchableText = implode(' ', [
        (string) ($saved['name'] ?? ''),
        (string) ($saved['visibility'] ?? ''),
        (string) ($saved['entity_name'] ?? ''),
        (string) ($saved['criteria_summary'] ?? ''),
      ]);

      return stripos($searchableText, $nativeCatalogQuery) !== false;
    }
  ));
}

if ($nativeCatalogUsesBackendPagination) {
  $nativeCatalogTotal = max(0, (int) (
    $nativeCatalog['total'] ?? $nativeCatalogPagination['total'] ?? count($nativeCatalogItems)
  ));
  $nativeCatalogPreviousCursor = (string) (
    $nativeCatalog['previous_cursor']
    ?? $nativeCatalog['prev_cursor']
    ?? $nativeCatalogPagination['previous_cursor']
    ?? $nativeCatalogPagination['prev_cursor']
    ?? ''
  );
  $nativeCatalogHasPrevious = $nativeCatalogPreviousCursor !== '';
  $nativeCatalogCanReturnToFirst = !$nativeCatalogHasPrevious && $nativeCatalogCursor !== '';
  $nativeCatalogNextCursor = (string) (
    $nativeCatalog['next_cursor'] ?? $nativeCatalogPagination['next_cursor'] ?? ''
  );
} else {
  $nativeCatalogTotal = count($nativeCatalogItems);
  $nativeCatalogOffset = min(
    $nativeCatalogOffset,
    max(0, ((int) ceil(max(1, $nativeCatalogTotal) / $nativeCatalogPageSize) - 1) * $nativeCatalogPageSize)
  );
  $nativeCatalogItems = array_slice($nativeCatalogItems, $nativeCatalogOffset, $nativeCatalogPageSize);
  $nativeCatalogPreviousCursor = $nativeCatalogOffset > 0
    ? (string) max(0, $nativeCatalogOffset - $nativeCatalogPageSize)
    : '';
  $nativeCatalogHasPrevious = $nativeCatalogPreviousCursor !== '';
  $nativeCatalogCanReturnToFirst = false;
  $nativeCatalogNextCursor = ($nativeCatalogOffset + count($nativeCatalogItems)) < $nativeCatalogTotal
    ? (string) ($nativeCatalogOffset + $nativeCatalogPageSize)
    : '';
}

$nativeCatalogDefaultItem = is_array($nativeCatalog['default_item'] ?? null)
  ? $nativeCatalog['default_item']
  : null;
if ($nativeCatalogDefaultItem === null) {
  foreach ($nativeCatalogItems as $nativeCatalogCandidate) {
    if (!empty($nativeCatalogCandidate['is_default'])) {
      $nativeCatalogDefaultItem = $nativeCatalogCandidate;
      break;
    }
  }
}
$canCreateNativeSearch = !empty($nativeCatalogCapabilities['can_create_private']);
$canEditNativeSearch = !empty($nativeCatalogEditor['can_edit'])
  || count(array_filter(
    $nativeCatalogItems,
    static fn(array $saved): bool => !empty($saved['can_edit'])
      || !empty($saved['capabilities']['can_edit'])
  )) > 0;
$nativeCatalogFocusResults = array_key_exists('saved_search_q', $_GET)
  || array_key_exists('saved_search_cursor', $_GET);
$selectedSavedSearch = (string) ($selected_saved_search ?? '');
$activeSavedSearch = is_array($active_saved_search ?? null) ? $active_saved_search : null;
$advancedSearchCatalog = is_array($advanced_search_catalog ?? null) ? $advanced_search_catalog : [];
$advancedSearchState = is_array($advanced_search_state ?? null) ? $advanced_search_state : [];
$advancedSearchToken = trim((string) ($advanced_search_token ?? ''));
$advancedSearchCriteria = array_values(array_filter(
  (array) ($advancedSearchState['criteria'] ?? []),
  'is_array'
));
$advancedSearchMetaCriteria = array_values(array_filter(
  (array) ($advancedSearchState['metacriteria'] ?? []),
  'is_array'
));
$advancedSearchSort = array_values((array) ($advancedSearchState['sort'] ?? []));
$advancedSearchOrder = array_values((array) ($advancedSearchState['order'] ?? []));
$advancedSearchErrors = array_values(array_filter(
  (array) ($advancedSearchState['errors'] ?? []),
  'is_string'
));
$advancedSearchFocusResults = !empty($advancedSearchState['focus_results'])
  || (string) ($_GET['focus'] ?? '') === 'results';
$advancedSearchEditable = !array_key_exists('editable', $advancedSearchState)
  || !empty($advancedSearchState['editable']);
$savedSearchDefinitionActive = $activeSavedSearch !== null
  && in_array(
    (string) ($activeSavedSearch['capability'] ?? $activeSavedSearch['compatibility'] ?? ''),
    ['editable', 'executable_read_only'],
    true
  );
$advancedSearchActive = $advancedSearchToken !== ''
  || $advancedSearchErrors !== []
  || $advancedSearchCriteria !== []
  || $advancedSearchMetaCriteria !== []
  || $savedSearchDefinitionActive;
$advancedVisibleCriteriaCount = max(
  0,
  (int) ($advancedSearchState['criteria_count']
    ?? (count($advancedSearchCriteria) + count($advancedSearchMetaCriteria)))
);
$advancedSearchConfig = [
  'catalog' => $advancedSearchCatalog,
  'criteria' => $advancedSearchCriteria,
  'metacriteria' => $advancedSearchMetaCriteria,
  'sort' => $advancedSearchSort,
  'order' => $advancedSearchOrder,
  'default_columns' => ['id', 'name', 'status', 'priority', 'group', 'date_mod'],
  'is_deleted' => (int) ($advancedSearchState['is_deleted'] ?? 0),
  'editable' => $advancedSearchEditable,
  'native_search_url' => $nativeTicketUrl,
  'remote_value_url' => glpiacessivel_url('front/ticket.search-values.php'),
  'csrf_token' => (string) ($csrf_token ?? ''),
  'limits' => [
    'criteria' => 25,
    'metacriteria' => 25,
    'sorts' => 5,
    'depth' => 3,
  ],
];
$advancedSearchConfigJson = json_encode(
  $advancedSearchConfig,
  JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
);
if (!is_string($advancedSearchConfigJson)) {
  $advancedSearchConfigJson = '{"catalog":{},"criteria":[],"metacriteria":[],"sort":[],"order":[]}';
}
$ticketColumnOptions = [
  'id' => 'ID',
  'name' => 'Titulo',
  'status' => 'Status',
  'priority' => 'Prioridade',
  'group' => 'Grupo responsavel',
  'requester' => 'Requisitante',
  'assignee' => 'Tecnico',
  'category' => 'Categoria',
  'entity' => 'Entidade',
  'location' => 'Localizacao',
  'date' => 'Data de abertura',
  'date_mod' => 'Ultima atualizacao',
  'time_to_resolve' => 'Prazo para solucao',
];
$ticketColumnCatalog = array_values(array_filter(
  (array) ($advancedSearchCatalog['columns'] ?? []),
  'is_array'
));
$requiredTicketColumns = ['id', 'name'];
foreach ($ticketColumnCatalog as $columnDefinition) {
  $columnIdentifier = trim((string) (
    $columnDefinition['identifier']
    ?? $columnDefinition['key']
    ?? $columnDefinition['option_id']
    ?? ''
  ));
  if ($columnIdentifier === '' || !array_key_exists($columnIdentifier, $ticketColumnOptions)) {
    continue;
  }
  $columnLabel = trim((string) ($columnDefinition['label'] ?? ''));
  if ($columnLabel !== '') {
    $ticketColumnOptions[$columnIdentifier] = $columnLabel;
  }
  if (!empty($columnDefinition['required'])) {
    $requiredTicketColumns[] = $columnIdentifier;
  }
}
$requiredTicketColumns = array_values(array_unique($requiredTicketColumns));
$columns = array_values((array) ($filters['columns'] ?? ['id', 'name', 'status', 'priority', 'group', 'date_mod']));

$savedSearchActionUrl = glpiacessivel_url('front/ticket.saved-search.php');
$savedSearchIdempotencyKey = static fn(): string => bin2hex(random_bytes(24));

$statusLabels = ['' => glpiacessivel_t('Todos')];
foreach (\GlpiPlugin\Glpiacessivel\Support\TicketStatusLabels::all() as $statusId => $statusLabel) {
  $statusLabels[(string) $statusId] = $statusLabel;
}

$scopeLabels = [
  'all' => 'Todos os chamados permitidos',
  'mine' => 'Meus chamados',
  'group' => 'Chamados do grupo',
];

$groupByLabels = [
  'none' => 'Lista unica',
  'group' => 'Agrupar por grupo',
];

$queryUrl = static function (array $changes = []) use ($filters, $columns, $advancedSearchToken): string {
  $params = array_merge((array) $filters, $changes);
  if ($advancedSearchToken !== '') {
    $params['advanced_search_token'] = $advancedSearchToken;
  }
  foreach (['native_criteria', 'native_metacriteria', 'native_sort', 'native_order', 'native_is_deleted', 'native_saved_search_id', 'native_parameters', 'columns'] as $internalKey) {
    unset($params[$internalKey]);
  }
  foreach ($columns as $column) {
    $params['columns'][] = $column;
  }
  foreach ($params as $key => $value) {
    if ($value === '' || $value === null) {
      unset($params[$key]);
    }
  }

  return '?' . http_build_query($params);
};

$sortUrl = static function (string $column) use ($filters, $queryUrl): string {
  $currentSort = (string) ($filters['sort'] ?? 'date_mod');
  $currentDirection = strtoupper((string) ($filters['direction'] ?? 'DESC'));
  $nextDirection = ($currentSort === $column && $currentDirection === 'ASC') ? 'DESC' : 'ASC';

  return $queryUrl([
    'sort' => $column,
    'direction' => $nextDirection,
    'page' => 1,
  ]);
};

$ariaSort = static function (string $column) use ($filters): string {
  if ((string) ($filters['sort'] ?? 'date_mod') !== $column) {
    return 'none';
  }

  return strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? 'ascending' : 'descending';
};

$sortMarker = static function (string $column) use ($filters): string {
  if ((string) ($filters['sort'] ?? 'date_mod') !== $column) {
    return '';
  }

  return strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? ' crescente' : ' decrescente';
};

$groupLabel = 'Todos os grupos';
foreach ((array) ($group_options ?? []) as $groupOption) {
  if ((int) ($groupOption['id'] ?? 0) === (int) ($filters['group_id'] ?? 0)) {
    $groupLabel = (string) ($groupOption['label'] ?? $groupLabel);
    break;
  }
}

$activeFilters = [];
$activeFilters['Escopo'] = $scopeLabels[(string) ($filters['scope'] ?? 'all')]
  ?? 'Todos os chamados permitidos';
if (trim((string) ($filters['q'] ?? '')) !== '') {
  $activeFilters['Busca'] = (string) $filters['q'];
}
if ((string) ($filters['status'] ?? '') !== '') {
  $activeFilters['Status'] = $statusLabels[(string) $filters['status']] ?? (string) $filters['status'];
}
if ((int) ($filters['group_id'] ?? 0) > 0) {
  $activeFilters['Grupo responsavel'] = $groupLabel;
}
if ((string) ($filters['group_by'] ?? 'none') !== 'none') {
  $activeFilters['Classificacao'] = $groupByLabels[(string) $filters['group_by']] ?? 'Agrupar por grupo';
}

$appliedSearchSummary = is_array($applied_search_summary ?? null)
  ? $applied_search_summary
  : [];
$appliedSummarySections = [];
foreach ((array) ($appliedSearchSummary['sections'] ?? []) as $section) {
  if (!is_array($section)) {
    continue;
  }
  $sectionLabel = trim((string) ($section['label'] ?? ''));
  $sectionItems = array_values(array_filter(array_map(
    static fn($item): string => trim((string) $item),
    (array) ($section['items'] ?? [])
  ), static fn(string $item): bool => $item !== ''));
  if ($sectionLabel !== '' && $sectionItems !== []) {
    $appliedSummarySections[] = [
      'key' => trim((string) ($section['key'] ?? '')),
      'label' => $sectionLabel,
      'items' => $sectionItems,
    ];
  }
}
$appliedSummaryWarnings = array_values(array_filter(array_map(
  static fn($warning): string => trim((string) $warning),
  (array) ($appliedSearchSummary['warnings'] ?? [])
), static fn(string $warning): bool => $warning !== ''));
$appliedSummaryHeading = trim((string) ($appliedSearchSummary['heading'] ?? ''));
$appliedSummarySavedSearchName = trim((string) (
  $appliedSearchSummary['saved_search_name'] ?? ''
));
$appliedSummaryPlainText = trim((string) ($appliedSearchSummary['plain_text'] ?? ''));
$appliedSummaryActive = !empty($appliedSearchSummary['active']);

if ($appliedSearchSummary === []) {
  $fallbackItems = [];
  if ($advancedSearchActive) {
    $advancedSummary = trim((string) ($advancedSearchState['summary'] ?? ''));
    $fallbackItems[] = $advancedSummary !== ''
      ? $advancedSummary
      : $advancedVisibleCriteriaCount . ' criterio(s) avancado(s) aplicado(s)';
  } else {
    foreach ($activeFilters as $filterName => $filterValue) {
      $fallbackItems[] = (string) $filterName . ': ' . (string) $filterValue;
    }
  }
  if ($fallbackItems !== []) {
    $appliedSummarySections[] = [
      'key' => 'fallback',
      'label' => $advancedSearchActive ? 'Pesquisa avancada' : 'Filtros',
      'items' => $fallbackItems,
    ];
  }
  $appliedSummaryHeading = 'Resumo dos filtros aplicados';
  $appliedSummarySavedSearchName = trim((string) ($activeSavedSearch['name'] ?? ''));
  $appliedSummaryPlainText = implode('. ', $fallbackItems);
  $appliedSummaryActive = $fallbackItems !== [];
}

if ($appliedSummaryHeading === '') {
  $appliedSummaryHeading = 'Resumo dos filtros aplicados';
}
$renderSortHeader = static function (
  string $column,
  string $label
) use ($sortUrl, $ariaSort, $sortMarker, $advancedSearchActive): void {
  if ($advancedSearchActive) {
    ?>
    <th scope="col" aria-sort="none">
      <?= glpiacessivel_e($label) ?>
      <span class="glpiacessivel-sr-only">Use a seção Ordenação da busca avançada para alterar a ordem.</span>
    </th>
    <?php
    return;
  }
  ?>
  <th scope="col" aria-sort="<?= glpiacessivel_e($ariaSort($column)) ?>">
    <a class="glpiacessivel-sort-link" href="<?= glpiacessivel_e($sortUrl($column)) ?>">
      <?= glpiacessivel_e($label) ?><span class="glpiacessivel-sr-only"><?= glpiacessivel_e($sortMarker($column)) ?></span>
    </a>
  </th>
  <?php
};

$renderTicketHeaders = static function (bool $showGroup = true) use (
  $columns,
  $ticketColumnOptions,
  $renderSortHeader
): void {
  $sortableColumns = ['id', 'name', 'status', 'date', 'priority', 'date_mod'];
  foreach ($columns as $column) {
    if (!$showGroup && $column === 'group') {
      continue;
    }

    $label = (string) ($ticketColumnOptions[$column] ?? $column);
    if (in_array($column, $sortableColumns, true)) {
      $renderSortHeader($column, $label);
      continue;
    }
    ?>
    <th scope="col"><?= glpiacessivel_e($label) ?></th>
    <?php
  }
};

$renderTicketRow = static function (array $item, bool $showGroup = true) use ($columns): void {
  $ticketId = (int) ($item['id'] ?? 0);
  $ticketName = (string) ($item['name'] ?? '');
  $ticketUrl = glpiacessivel_url('front/ticket.php?id=' . $ticketId);
  ?>
  <tr>
    <td>
      <input
        type="checkbox"
        class="glpiacessivel-ticket-select"
        value="<?= $ticketId ?>"
        aria-label="Selecionar chamado <?= $ticketId ?>"
      />
    </td>
    <?php foreach ($columns as $column): ?>
      <?php if (!$showGroup && $column === 'group') {
        continue;
      } ?>
      <?php switch ($column):
        case 'id': ?>
          <td><?= $ticketId ?></td>
          <?php break;
        case 'name': ?>
          <td>
            <a href="<?= glpiacessivel_e($ticketUrl) ?>" class="glpiacessivel-ticket-title-link">
              <?= glpiacessivel_e($ticketName) ?>
            </a>
          </td>
          <?php break;
        case 'status': ?>
          <td>
            <span class="glpiacessivel-badge glpiacessivel-badge-status-<?= glpiacessivel_e(glpiacessivel_status_class((int) ($item['status'] ?? 0))) ?>">
              <?= glpiacessivel_e(glpiacessivel_ticket_status((int) ($item['status'] ?? 0))) ?>
            </span>
          </td>
          <?php break;
        case 'priority': ?>
          <td>
            <span class="glpiacessivel-badge glpiacessivel-badge-priority-<?= glpiacessivel_e(glpiacessivel_priority_class((int) ($item['priority'] ?? 0))) ?>">
              <?= glpiacessivel_e(glpiacessivel_ticket_priority((int) ($item['priority'] ?? 0))) ?>
            </span>
          </td>
          <?php break;
        case 'group': ?>
          <td><?= glpiacessivel_e((string) ($item['primary_group_name'] ?? 'Sem grupo')) ?></td>
          <?php break;
        case 'requester': ?>
          <td><?= glpiacessivel_e(trim((string) ($item['requester_name'] ?? ''))) ?></td>
          <?php break;
        case 'assignee': ?>
          <td><?= glpiacessivel_e(trim((string) ($item['assignee_name'] ?? ''))) ?></td>
          <?php break;
        case 'category': ?>
          <td><?= glpiacessivel_e((string) ($item['category_name'] ?? '')) ?></td>
          <?php break;
        case 'entity': ?>
          <td><?= glpiacessivel_e((string) ($item['entity_name'] ?? '')) ?></td>
          <?php break;
        case 'location': ?>
          <td><?= glpiacessivel_e((string) ($item['location_name'] ?? '')) ?></td>
          <?php break;
        case 'date': ?>
          <td><?= glpiacessivel_e((string) ($item['date'] ?? '')) ?></td>
          <?php break;
        case 'date_mod': ?>
          <td><?= glpiacessivel_e((string) ($item['date_mod'] ?? '')) ?></td>
          <?php break;
        case 'time_to_resolve': ?>
          <td><?= glpiacessivel_e((string) ($item['time_to_resolve'] ?? '')) ?></td>
          <?php break;
      endswitch; ?>
    <?php endforeach; ?>
    <td>
      <a
        class="glpiacessivel-button glpiacessivel-button-secondary"
        href="<?= glpiacessivel_e($ticketUrl) ?>"
        aria-label="Abrir chamado <?= $ticketId ?>: <?= glpiacessivel_e($ticketName) ?>"
      >Abrir</a>
    </td>
  </tr>
  <?php
};?>

<section class="glpiacessivel-section-head" aria-labelledby="tickets-intro">
  <p class="glpiacessivel-eyebrow">Gestao de chamados</p>
  <h2 id="tickets-intro">Chamados</h2>
  <p>Pesquise usando os mesmos campos autorizados para seu perfil e entidade no GLPI.</p>
</section>

<nav class="glpiacessivel-ticket-toolbar" aria-label="Acoes da listagem de chamados">
  <a class="glpiacessivel-button" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.create.php')) ?>">Novo chamado</a>
  <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($queryUrl()) ?>">Atualizar lista</a>
  <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeTicketUrl) ?>">Abrir listagem nativa do GLPI</a>
</nav>

<nav class="glpiacessivel-ticket-page-nav" aria-label="Nesta pagina">
  <strong>Nesta p&aacute;gina</strong>
  <a href="#tickets-filtros">Busca e filtros</a>
  <a href="#tickets-filter-summary">Resumo dos filtros aplicados</a>
  <a href="#tickets-lista">Resultados dos chamados</a>
  <a href="#tickets-pesquisas-salvas">Pesquisas salvas</a>
</nav>

<section aria-labelledby="tickets-filtros" class="glpiacessivel-card glpiacessivel-ticket-search-workspace">
  <div class="glpiacessivel-card-heading">
    <div>
      <p class="glpiacessivel-eyebrow">Pesquisa de chamados</p>
      <h2 id="tickets-filtros">Busca e filtros</h2>
    </div>
    <p class="glpiacessivel-card-note">A consulta respeita os campos, operadores, permissoes e entidades autorizados pelo GLPI.</p>
  </div>

  <noscript>
    <div class="glpiacessivel-alert glpiacessivel-alert-info" role="status">
      O construtor acessivel requer JavaScript.
      <a href="<?= glpiacessivel_e($nativeTicketUrl) ?>">Pesquisar na interface nativa do GLPI</a>.
    </div>
  </noscript>

  <form
    id="ticket-advanced-search-form"
    method="post"
    action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php')) ?>"
    class="glpiacessivel-advanced-search-form glpiacessivel-ticket-unified-search"
    role="search"
    aria-label="Pesquisar chamados"
    data-glpiacessivel-advanced-search-form
    data-editable="<?= $advancedSearchEditable ? '1' : '0' ?>"
    novalidate
  >
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
    <input type="hidden" name="search_mode" value="advanced" />
    <input type="hidden" name="advanced[action]" value="search" />
    <input type="hidden" name="advanced[focus]" value="results" />
    <input
      type="hidden"
      name="advanced[context_revision]"
      value="<?= glpiacessivel_e((string) ($advancedSearchCatalog['context_revision'] ?? '')) ?>"
    />

    <div class="glpiacessivel-ticket-search-basics">
      <div class="glpiacessivel-field glpiacessivel-ticket-search-text">
        <label for="q">ID, título ou descrição</label>
        <input
          id="q"
          type="search"
          name="q"
          maxlength="120"
          value="<?= glpiacessivel_e((string) ($filters['q'] ?? '')) ?>"
          autocomplete="off"
          aria-describedby="ticket-search-text-help"
        />
        <p id="ticket-search-text-help" class="glpiacessivel-help-text">A pesquisa textual é combinada com os filtros avançados ativos.</p>
      </div>
      <div class="glpiacessivel-field glpiacessivel-ticket-search-scope">
        <label for="scope">Escopo</label>
        <select id="scope" name="scope">
          <option value="all" <?= ($filters['scope'] ?? 'all') === 'all' ? 'selected' : '' ?>>Todos os chamados permitidos</option>
          <option value="mine" <?= ($filters['scope'] ?? 'all') === 'mine' ? 'selected' : '' ?>>Meus chamados</option>
          <option value="group" <?= ($filters['scope'] ?? 'all') === 'group' ? 'selected' : '' ?>>Chamados do grupo</option>
        </select>
      </div>
    </div>

    <?php if ($advancedSearchErrors !== []): ?>
      <div
        class="glpiacessivel-alert glpiacessivel-alert-error"
        id="ticket-advanced-search-errors"
        role="alert"
        tabindex="-1"
        data-glpiacessivel-advanced-errors
      >
        <h3>Revise a busca avancada</h3>
        <ul>
          <?php foreach ($advancedSearchErrors as $advancedSearchError): ?>
            <li><?= glpiacessivel_e($advancedSearchError) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php else: ?>
      <div
        class="glpiacessivel-alert glpiacessivel-alert-error"
        id="ticket-advanced-search-errors"
        role="alert"
        tabindex="-1"
        data-glpiacessivel-advanced-errors
        hidden
      >
        <h3>Revise a busca avancada</h3>
        <ul></ul>
      </div>
    <?php endif; ?>

    <?php if (!$advancedSearchEditable): ?>
      <div class="glpiacessivel-alert glpiacessivel-alert-info" role="status">
        Esta pesquisa pode ser aplicada, mas contem recursos que nao podem ser editados fielmente neste portal. Nenhum criterio foi simplificado.
      </div>
    <?php endif; ?>

    <details class="glpiacessivel-ticket-advanced-filters" <?= $advancedSearchActive ? 'open' : '' ?>>
      <summary>
        <span>Filtros avancados</span>
        <span class="glpiacessivel-filter-count"><?= $advancedVisibleCriteriaCount ?> ativo(s)</span>
      </summary>
      <div class="glpiacessivel-ticket-advanced-filters-content">
        <section class="glpiacessivel-advanced-search-section" aria-labelledby="advanced-criteria-heading">
          <div class="glpiacessivel-advanced-section-heading">
            <div>
              <h3 id="advanced-criteria-heading">Regras da pesquisa</h3>
              <p class="glpiacessivel-help-text">Combine campo, condição e valor. A primeira regra não exibe conector; a partir da segunda, escolha E, OU, E NÃO ou OU NÃO.</p>
            </div>
          </div>
          <ol
            class="glpiacessivel-advanced-search-list"
            data-glpiacessivel-criteria-list
            aria-label="Criterios da busca avancada"
          ></ol>
          <div class="glpiacessivel-advanced-search-add-actions" role="group" aria-label="Adicionar regras a pesquisa">
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-add-criterion>
              Adicionar regra
            </button>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-add-global-rule>
              Adicionar regra global
            </button>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-add-group>
              Adicionar grupo
            </button>
          </div>
        </section>

        <section class="glpiacessivel-advanced-search-section glpiacessivel-advanced-global-section" aria-labelledby="advanced-global-rules-heading">
          <h3 id="advanced-global-rules-heading">Regras globais adicionadas</h3>
          <p class="glpiacessivel-help-text">As regras globais consultam campos relacionados autorizados pelo GLPI.</p>
          <ol
            class="glpiacessivel-advanced-search-list"
            data-glpiacessivel-global-rules-list
            aria-label="Regras globais da busca avancada"
          ></ol>
        </section>

      </div>
    </details>

    <div
      class="glpiacessivel-ticket-search-actions glpiacessivel-ticket-search-tools"
      role="group"
      aria-label="Ações da pesquisa de chamados"
      data-glpiacessivel-search-tools
    >
      <button type="submit" class="glpiacessivel-search-tool-primary" <?= !$advancedSearchEditable ? 'disabled' : '' ?>>
        <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m21 21-4.35-4.35m2.35-5.15A7.5 7.5 0 1 1 4 11.5a7.5 7.5 0 0 1 15 0Z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" /></svg>
        <span>Pesquisar</span>
      </button>
      <button
        type="button"
        class="glpiacessivel-button glpiacessivel-button-secondary"
        aria-expanded="true"
        aria-controls="ticket-search-tool-saved-searches"
        data-glpiacessivel-search-tool-trigger="saved-searches"
      >
        <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="2" /><path d="m15.5 15.5 5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" /></svg>
        <span>Pesquisas salvas</span>
      </button>
      <?php if ($canCreateNativeSearch): ?>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($queryUrl(['manage_saved_search' => 1])) ?>#create-native-saved-search">
          <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m12 3 2.7 5.47 6.03.88-4.37 4.25 1.03 6-5.39-2.83L6.61 19.6l1.03-6-4.37-4.25 6.03-.88L12 3Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" /></svg>
          <span>Salvar pesquisa</span>
        </a>
      <?php endif; ?>
      <button
        type="button"
        class="glpiacessivel-button glpiacessivel-button-secondary"
        aria-expanded="true"
        aria-controls="ticket-search-tool-result-options"
        data-glpiacessivel-search-tool-trigger="result-options"
      >
        <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" stroke-width="2" /><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.12 2.12-.06-.06a1.7 1.7 0 0 0-1.88-.34 1.7 1.7 0 0 0-1.03 1.56V20.3h-3v-.08a1.7 1.7 0 0 0-1.03-1.56A1.7 1.7 0 0 0 8.8 19l-.06.06-2.12-2.12.06-.06A1.7 1.7 0 0 0 7.02 15a1.7 1.7 0 0 0-1.56-1.03h-.08v-3h.08A1.7 1.7 0 0 0 7.02 9.9a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.12-2.12.06.06a1.7 1.7 0 0 0 1.88.34A1.7 1.7 0 0 0 11.71 4.7v-.08h3v.08a1.7 1.7 0 0 0 1.03 1.56 1.7 1.7 0 0 0 1.88-.34l.06-.06 2.12 2.12-.06.06a1.7 1.7 0 0 0-.34 1.88 1.7 1.7 0 0 0 1.56 1.03h.08v3h-.08A1.7 1.7 0 0 0 19.4 15Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" /></svg>
        <span>Opções dos resultados</span>
      </button>
      <?php if (!empty($advancedSearchCatalog['capabilities']['allow_deleted'])): ?>
        <button
          type="button"
          class="glpiacessivel-button glpiacessivel-button-secondary"
          aria-expanded="true"
          aria-controls="ticket-search-tool-record-scope"
          data-glpiacessivel-search-tool-trigger="record-scope"
          aria-label="Registros: <?= (int) ($advancedSearchState['is_deleted'] ?? 0) === 1 ? 'excluídos' : 'ativos' ?>"
        >
          <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 7h16v13H4V7Zm-1-4h18v4H3V3Zm6 8h6" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" /></svg>
          <span>Registros:</span>
          <span data-glpiacessivel-record-scope-state><?= (int) ($advancedSearchState['is_deleted'] ?? 0) === 1 ? 'excluídos' : 'ativos' ?></span>
        </button>
      <?php endif; ?>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php?saved_search=')) ?>">
        <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m6 6 12 12M18 6 6 18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" /></svg>
        <span>Limpar filtros</span>
      </a>
    </div>

    <section
      id="ticket-search-tool-result-options"
      class="glpiacessivel-advanced-result-options"
      aria-labelledby="ticket-search-tool-result-options-heading"
      tabindex="-1"
      data-glpiacessivel-search-tool-panel="result-options"
    >
      <div class="glpiacessivel-search-tool-panel-heading">
        <div>
          <p class="glpiacessivel-eyebrow">Resultados dos chamados</p>
          <h3 id="ticket-search-tool-result-options-heading">Opções dos resultados</h3>
          <p class="glpiacessivel-help-text" data-glpiacessivel-result-options-summary>Ordenação e exibição (<?= count($advancedSearchSort) ?> ordenação(ões); <?= (int) ($filters['page_size'] ?? 20) ?> por página; <?= count($columns) ?> colunas)</p>
        </div>
        <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-search-tool-close="result-options">
          <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m6 6 12 12M18 6 6 18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" /></svg>
          <span>Fechar</span>
        </button>
      </div>
      <div class="glpiacessivel-advanced-result-options-content">
        <section class="glpiacessivel-advanced-search-section" aria-labelledby="advanced-sorts-heading">
          <h3 id="advanced-sorts-heading">Ordenação</h3>
          <p class="glpiacessivel-help-text">Defina até cinco campos. A primeira ordenação tem maior prioridade.</p>
          <ol
            class="glpiacessivel-advanced-sort-list"
            data-glpiacessivel-sorts-list
            aria-label="Ordenações da busca avançada"
          ></ol>
          <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-add-sort>
            Adicionar ordenação
          </button>
        </section>

        <div class="glpiacessivel-ticket-result-settings">
          <div class="glpiacessivel-field glpiacessivel-ticket-filter-pagesize">
            <label for="advanced_page_size">Itens por página</label>
            <select id="advanced_page_size" name="advanced[page_size]">
              <?php foreach ([10, 20, 50, 100] as $option): ?>
                <option value="<?= $option ?>" <?= (int) ($filters['page_size'] ?? 20) === $option ? 'selected' : '' ?>><?= $option ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="glpiacessivel-field glpiacessivel-ticket-column-summary">
            <span class="glpiacessivel-field-label">Colunas dos resultados</span>
            <button
              type="button"
              class="glpiacessivel-button glpiacessivel-button-secondary"
              data-glpiacessivel-open-columns
              aria-haspopup="dialog"
              aria-controls="ticket-column-dialog"
            >Escolher colunas (<?= count($columns) ?> selecionadas)</button>
            <p class="glpiacessivel-help-text">ID e título permanecem disponíveis para identificar e abrir o chamado.</p>
          </div>
        </div>

        <dialog
          id="ticket-column-dialog"
          class="glpiacessivel-column-dialog"
          aria-labelledby="ticket-column-dialog-heading"
          data-glpiacessivel-column-dialog
        >
          <div class="glpiacessivel-column-dialog-head">
            <div>
              <p class="glpiacessivel-eyebrow">Resultados dos chamados</p>
              <h3 id="ticket-column-dialog-heading">Escolher e ordenar colunas</h3>
            </div>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-close-columns>Fechar</button>
          </div>
          <p class="glpiacessivel-help-text">Adicione, remova ou reordene as informações. A ordem desta lista será a ordem da tabela.</p>
          <div class="glpiacessivel-column-dialog-add">
            <div class="glpiacessivel-field">
              <label for="ticket-column-add">Coluna disponível</label>
              <select id="ticket-column-add" data-glpiacessivel-column-add>
                <option value="">Selecione uma coluna</option>
                <?php foreach ($ticketColumnOptions as $columnIdentifier => $columnLabel): ?>
                  <option value="<?= glpiacessivel_e($columnIdentifier) ?>"><?= glpiacessivel_e($columnLabel) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-add-column>Adicionar coluna</button>
          </div>
          <ol class="glpiacessivel-column-list" data-glpiacessivel-column-list aria-label="Colunas selecionadas, na ordem de exibição">
            <?php foreach (array_values(array_unique($columns)) as $selectedColumn): ?>
              <?php
                if (!array_key_exists($selectedColumn, $ticketColumnOptions)) {
                  continue;
                }
                $selectedColumnLocked = in_array($selectedColumn, $requiredTicketColumns, true);
              ?>
              <li
                data-column-id="<?= glpiacessivel_e($selectedColumn) ?>"
                data-column-label="<?= glpiacessivel_e($ticketColumnOptions[$selectedColumn]) ?>"
                data-column-locked="<?= $selectedColumnLocked ? '1' : '0' ?>"
              >
                <span><?= glpiacessivel_e($ticketColumnOptions[$selectedColumn]) ?></span>
                <?php if ($selectedColumnLocked): ?>
                  <span class="glpiacessivel-badge">Obrigatória</span>
                <?php else: ?>
                  <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-column-remove>
                    Remover <?= glpiacessivel_e($ticketColumnOptions[$selectedColumn]) ?>
                  </button>
                <?php endif; ?>
              </li>
            <?php endforeach; ?>
          </ol>
          <div class="glpiacessivel-column-dialog-actions glpiacessivel-column-dialog-footer">
            <button type="button" data-glpiacessivel-apply-columns>Aplicar colunas</button>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-reset-columns>Restaurar colunas padrão</button>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-close-columns>Cancelar</button>
          </div>
        </dialog>
      </div>
    </section>

    <?php if (!empty($advancedSearchCatalog['capabilities']['allow_deleted'])): ?>
      <section
        id="ticket-search-tool-record-scope"
        class="glpiacessivel-search-tool-panel glpiacessivel-record-scope-panel"
        aria-labelledby="ticket-search-tool-record-scope-heading"
        tabindex="-1"
        data-glpiacessivel-search-tool-panel="record-scope"
      >
        <div class="glpiacessivel-search-tool-panel-heading">
          <div>
            <p class="glpiacessivel-eyebrow">Escopo da lista</p>
            <h3 id="ticket-search-tool-record-scope-heading">Registros exibidos</h3>
          </div>

        </div>
        <fieldset class="glpiacessivel-advanced-deleted-scope">
          <legend>Escolha quais registros incluir na próxima pesquisa</legend>
          <label>
            <input type="radio" name="advanced[deleted_scope]" value="active" <?= (int) ($advancedSearchState['is_deleted'] ?? 0) !== 1 ? 'checked' : '' ?> />
            Somente chamados ativos
          </label>
          <label>
            <input type="radio" name="advanced[deleted_scope]" value="deleted" <?= (int) ($advancedSearchState['is_deleted'] ?? 0) === 1 ? 'checked' : '' ?> />
            Somente chamados excluídos
          </label>
        </fieldset>
        <p class="glpiacessivel-help-text">A alteracao sera aplicada somente quando voce ativar Pesquisar.</p>
      </section>
    <?php endif; ?>

    <input type="hidden" name="advanced_schema_version" value="3" />
    <input type="hidden" name="advanced_request_complete" value="1" />

    <section class="glpiacessivel-query-draft-summary" aria-labelledby="ticket-query-draft-heading">
      <h3 id="ticket-query-draft-heading">Consulta em edição</h3>
      <p data-glpiacessivel-advanced-summary>Nenhum critério avançado configurado.</p>
    </section>
  </form>

  <section
    id="tickets-filter-summary"
    class="glpiacessivel-applied-search-summary"
    role="region"
    aria-labelledby="tickets-filter-summary-heading"
    data-glpiacessivel-applied-search-summary
  >
    <div class="glpiacessivel-active-filters" role="group" aria-label="Filtros ativos">
    <h3 id="tickets-filter-summary-heading"><?= glpiacessivel_e($appliedSummaryHeading) ?></h3>
    <?php if ($appliedSummarySavedSearchName !== ''): ?>
      <p><strong>Pesquisa salva:</strong> <?= glpiacessivel_e($appliedSummarySavedSearchName) ?></p>
    <?php endif; ?>
    <?php if (!$appliedSummaryActive): ?>
      <p>Nenhum filtro adicional foi aplicado aos resultados.</p>
    <?php endif; ?>
    <?php foreach ($appliedSummarySections as $appliedSection): ?>
      <section class="glpiacessivel-applied-search-summary-section">
        <h4><?= glpiacessivel_e((string) $appliedSection['label']) ?></h4>
        <ul>
          <?php foreach ($appliedSection['items'] as $appliedItem): ?>
            <li><?= glpiacessivel_e((string) $appliedItem) ?></li>
          <?php endforeach; ?>
        </ul>
      </section>
    <?php endforeach; ?>
    <?php if ($appliedSummaryWarnings !== []): ?>
      <div class="glpiacessivel-alert glpiacessivel-alert-info" role="status">
        <strong>Informacoes sobre esta consulta</strong>
        <ul>
          <?php foreach ($appliedSummaryWarnings as $appliedWarning): ?>
            <li><?= glpiacessivel_e($appliedWarning) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>
    <?php if ($appliedSummarySections === [] && $appliedSummaryPlainText !== ''): ?>
      <p><?= glpiacessivel_e($appliedSummaryPlainText) ?></p>
    <?php endif; ?>
    </div>
  </section>

  <script type="application/json" id="ticket-advanced-search-config"><?= $advancedSearchConfigJson ?></script>
</section>
<?php if ($showOperationalDiagnostics && $backend !== 'search_api'): ?>
  <?php
    $backendReasonLabels = [
      'native_saved_search_unavailable' => 'A pesquisa salva não pôde ser executada pela Search API do GLPI.',
      'search_api_unavailable' => 'A Search API nativa não está disponível para esta consulta.',
      'saved_search_unavailable' => 'A pesquisa salva deixou de estar disponível para o perfil e a entidade atuais.',
    ];
    $backendReasonText = $backendReasonLabels[$backendReason]
      ?? 'A consulta não pôde ser executada fielmente pela Search API do GLPI.';
  ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning" role="status" aria-live="polite" id="tickets-native-search-warning">
    <strong>Lista de chamados não carregada.</strong>
    <p><?= glpiacessivel_e($backendReasonText) ?></p>
    <p>Para evitar resultados diferentes ou mais amplos que a pesquisa solicitada, o portal exibiu uma lista vazia.</p>
    <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeTicketUrl) ?>">Abrir a listagem nativa do GLPI</a>
  </div>
<?php endif; ?>
<section aria-labelledby="tickets-lista" class="glpiacessivel-card">
  <div class="glpiacessivel-list-header">
    <div>
      <p class="glpiacessivel-eyebrow">Resultado operacional</p>
      <h2
        id="tickets-lista"
        tabindex="-1"
        <?= $advancedSearchFocusResults ? 'data-glpiacessivel-advanced-results-focus' : '' ?>
      >Lista de chamados</h2>
      <p>
        <?php if ($total > 0): ?>
          Exibindo <strong><?= $firstItem ?></strong>-<strong><?= $lastItem ?></strong> de <?= !empty($result['backend_limited']) ? 'pelo menos ' : '' ?><strong><?= $total ?></strong> chamado(s).
        <?php else: ?>
          Nenhum chamado visivel para a consulta atual.
        <?php endif; ?>
      </p>
      <?php if ($showOperationalDiagnostics): ?>
        <p class="glpiacessivel-card-note">
          <?= glpiacessivel_e($backendLabel) ?>
        </p>
      <?php endif; ?>
    </div>
    <div class="glpiacessivel-selection-summary" role="status" aria-live="polite">
      Selecionados: <strong data-glpiacessivel-selected-count>0</strong>
      <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-copy-selected disabled>Copiar IDs</button>
    </div>
  </div>

  <?php if (count($items) === 0): ?>
    <div class="glpiacessivel-empty" role="status">
      <p>Nenhum chamado encontrado para os filtros informados.</p>
      <p>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php?saved_search=')) ?>">Limpar filtros</a>
        <a class="glpiacessivel-button" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.create.php')) ?>">Abrir novo chamado</a>
      </p>
    </div>
  <?php else: ?>
    <?php if (in_array(($filters['scope'] ?? 'all'), ['mine', 'group'], true) && ($filters['group_by'] ?? 'none') === 'group' && !empty($grouped_items)): ?>
      <div class="glpiacessivel-ticket-grouped">
        <?php foreach ((array) ($grouped_items ?? []) as $groupIndex => $groupTickets): ?>
          <?php $groupHeadingId = 'tickets-grupo-' . md5((string) $groupIndex); ?>
          <section class="glpiacessivel-ticket-group" aria-labelledby="<?= glpiacessivel_e($groupHeadingId) ?>">
            <h3 id="<?= glpiacessivel_e($groupHeadingId) ?>"><?= glpiacessivel_e((string) $groupIndex) ?> (<?= count((array) $groupTickets) ?>)</h3>
            <div class="glpiacessivel-table-wrap" role="region" aria-labelledby="<?= glpiacessivel_e($groupHeadingId) ?>" tabindex="0">
              <table class="tab_cadre_fixehov glpiacessivel-ticket-table">
                <caption class="glpiacessivel-sr-only">Chamados do grupo <?= glpiacessivel_e((string) $groupIndex) ?> para os filtros atuais</caption>
                <thead>
                  <tr>
                    <th scope="col"><span class="glpiacessivel-sr-only">Selecionar</span></th>
                    <?php $renderTicketHeaders(false); ?>

                    <th scope="col">Acao</th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach ((array) $groupTickets as $item): ?>
                  <?php $renderTicketRow((array) $item, false); ?>
                <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </section>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="glpiacessivel-table-wrap" role="region" aria-label="Tabela de chamados" tabindex="0">
        <table class="tab_cadre_fixehov glpiacessivel-ticket-table" aria-describedby="tickets-lista">
          <caption class="glpiacessivel-sr-only">Chamados encontrados para os filtros atuais</caption>
          <thead>
            <tr>
              <th scope="col"><span class="glpiacessivel-sr-only">Selecionar</span></th>
              <?php $renderTicketHeaders(true); ?>

              <th scope="col">Acao</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($items as $item): ?>
            <?php $renderTicketRow((array) $item, true); ?>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</section>

<nav class="glpiacessivel-pagination glpiacessivel-ticket-pagination" aria-label="Paginacao">
  <span>Pagina <?= $page ?> de <?= $pages ?></span>
  <?php if ($page > 1): ?>
    <a href="<?= glpiacessivel_e($queryUrl(['page' => 1])) ?>">Primeira</a>
    <a href="<?= glpiacessivel_e($queryUrl(['page' => $page - 1])) ?>">Anterior</a>
  <?php else: ?>
    <span aria-disabled="true">Primeira</span>
    <span aria-disabled="true">Anterior</span>
  <?php endif; ?>
  <span aria-current="page">Atual: <?= $page ?></span>
  <?php if ($page < $pages): ?>
    <a href="<?= glpiacessivel_e($queryUrl(['page' => $page + 1])) ?>">Proxima</a>
    <a href="<?= glpiacessivel_e($queryUrl(['page' => $pages])) ?>">Ultima</a>
  <?php else: ?>
    <span aria-disabled="true">Proxima</span>
    <span aria-disabled="true">Ultima</span>
  <?php endif; ?>
</nav>

<section
  id="ticket-search-tool-saved-searches"
  class="glpiacessivel-card glpiacessivel-saved-searches glpiacessivel-search-tool-panel glpiacessivel-saved-search-tool-panel"
  aria-labelledby="tickets-pesquisas-salvas"
  tabindex="-1"
  data-glpiacessivel-search-tool-panel="saved-searches"
  data-glpiacessivel-search-tool-initial-open="<?= (isset($_GET['manage_saved_search']) || !empty($saved_search_invalid) || $nativeCatalogFocusResults) ? '1' : '0' ?>"
>
  <div class="glpiacessivel-card-heading glpiacessivel-search-tool-panel-heading">
    <div>
      <p class="glpiacessivel-eyebrow"><?= __('Acesso recorrente', 'glpiacessivel') ?></p>
      <h2 id="tickets-pesquisas-salvas"><?= __('Pesquisas salvas do GLPI', 'glpiacessivel') ?></h2>
      <p class="glpiacessivel-card-note">
        <?= __('Consulte e gerencie as pesquisas mantidas no próprio GLPI. Nenhuma cópia é criada pelo plugin.', 'glpiacessivel') ?>
      </p>
    </div>
    <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-search-tool-close="saved-searches">
      <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m6 6 12 12M18 6 6 18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" /></svg>
      <span>Fechar</span>
    </button>
  </div>

  <div class="glpiacessivel-saved-search-manager-content">
  <?php if (!empty($saved_search_invalid)): ?>
    <div class="glpiacessivel-alert glpiacessivel-alert-error" role="alert" tabindex="-1" id="saved-search-unavailable">
      <strong><?= __('Pesquisa salva indisponível.', 'glpiacessivel') ?></strong>
      <p><?= __('Ela pode ter sido excluída ou deixado de estar disponível para seu perfil e entidade. Nenhum chamado foi exibido para evitar uma lista diferente da esperada.', 'glpiacessivel') ?></p>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php?saved_search=')) ?>">
        <?= __('Limpar pesquisa indisponível', 'glpiacessivel') ?>
      </a>
    </div>
  <?php endif; ?>

  <?php if ($activeSavedSearch !== null && ($activeSavedSearch['origin'] ?? '') === 'glpi'): ?>
    <div class="glpiacessivel-active-saved-search" role="status" aria-live="polite">
      <strong><?= __('Pesquisa aplicada:', 'glpiacessivel') ?></strong>
      <?= glpiacessivel_e((string) ($activeSavedSearch['name'] ?? '')) ?>.
      <?php if (($activeSavedSearch['capability'] ?? $activeSavedSearch['compatibility'] ?? '') === 'native_only'): ?>
        <span><?= __('Os critérios completos desta pesquisa só estão disponíveis na interface nativa.', 'glpiacessivel') ?></span>
        <a href="<?= glpiacessivel_e((string) ($activeSavedSearch['native_url'] ?? $nativeTicketUrl)) ?>">
          <?= __('Abrir pesquisa completa no GLPI', 'glpiacessivel') ?>
        </a>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <?php if ($nativeCatalogDefaultItem !== null): ?>
    <aside class="glpiacessivel-native-search-default" aria-labelledby="native-search-default-heading">
      <h3 id="native-search-default-heading"><?= __('Pesquisa padrão atual', 'glpiacessivel') ?></h3>
      <p><?= glpiacessivel_e((string) ($nativeCatalogDefaultItem['name'] ?? __('Sem nome', 'glpiacessivel'))) ?></p>
    </aside>
  <?php endif; ?>

  <form
    method="get"
    action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php')) ?>"
    class="glpiacessivel-native-search-catalog-form"
    role="search"
    aria-label="<?= glpiacessivel_e(__('Pesquisar no catálogo de pesquisas salvas do GLPI', 'glpiacessivel')) ?>"
  >
    <?php foreach (['scope', 'status', 'q', 'group_id', 'group_by', 'page', 'page_size', 'sort', 'direction', 'saved_search'] as $filterKey): ?>
      <?php if ((string) ($filters[$filterKey] ?? '') !== ''): ?>
        <input type="hidden" name="<?= glpiacessivel_e($filterKey) ?>" value="<?= glpiacessivel_e((string) $filters[$filterKey]) ?>" />
      <?php endif; ?>
    <?php endforeach; ?>
    <?php foreach ($columns as $column): ?>
      <input type="hidden" name="columns[]" value="<?= glpiacessivel_e((string) $column) ?>" />
    <?php endforeach; ?>
    <div class="glpiacessivel-field">
      <label for="saved_search_q"><?= __('Buscar pesquisa salva por nome', 'glpiacessivel') ?></label>
      <input
        id="saved_search_q"
        type="search"
        name="saved_search_q"
        maxlength="120"
        value="<?= glpiacessivel_e($nativeCatalogQuery) ?>"
        autocomplete="off"
        aria-describedby="saved-search-catalog-help"
      />
      <p id="saved-search-catalog-help" class="glpiacessivel-help-text">
        <?= __('A busca só será executada depois que você ativar o botão Buscar pesquisas.', 'glpiacessivel') ?>
      </p>
    </div>
    <button type="submit"><?= __('Buscar pesquisas', 'glpiacessivel') ?></button>
    <?php if ($nativeCatalogQuery !== ''): ?>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($queryUrl([
        'saved_search_q' => null,
        'saved_search_cursor' => null,
      ])) ?>">
        <?= __('Limpar busca de pesquisas', 'glpiacessivel') ?>
      </a>
    <?php endif; ?>
  </form>

  <div class="glpiacessivel-native-search-results-head">
    <h3
      id="saved-search-catalog-results"
      tabindex="-1"
      <?= $nativeCatalogFocusResults ? 'data-glpiacessivel-catalog-results-focus' : '' ?>
    >
      <?= glpiacessivel_e(sprintf(
        _n('%d pesquisa nesta página', '%d pesquisas nesta página', count($nativeCatalogItems), 'glpiacessivel'),
        count($nativeCatalogItems)
      )) ?>
    </h3>
    <p><?= glpiacessivel_e(sprintf(__('São exibidas no máximo %d pesquisas por página.', 'glpiacessivel'), $nativeCatalogPageSize)) ?></p>
  </div>

  <?php if (!$canCreateNativeSearch && !$canEditNativeSearch): ?>
    <div class="glpiacessivel-alert glpiacessivel-alert-info" role="status">
      <p><?= __('As pesquisas são lidas diretamente do GLPI. As opções de alteração aparecem somente quando o GLPI autoriza a operação para seu perfil e para aquela pesquisa.', 'glpiacessivel') ?></p>
    </div>
  <?php endif; ?>

  <?php if ($canCreateNativeSearch): ?>
    <details id="create-native-saved-search" class="glpiacessivel-native-search-editor" <?= isset($_GET['manage_saved_search']) ? 'open' : '' ?>>
      <summary><?= __('Criar pesquisa salva no GLPI com os filtros atuais', 'glpiacessivel') ?></summary>
      <form method="post" action="<?= glpiacessivel_e($savedSearchActionUrl) ?>">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
        <input type="hidden" name="idempotency_key" value="<?= glpiacessivel_e($savedSearchIdempotencyKey()) ?>" />
        <input type="hidden" name="saved_search_action" value="create" />
        <?php if ($advancedSearchToken !== ''): ?>
          <input type="hidden" name="search_mode" value="advanced" />
          <input type="hidden" name="advanced_search_token" value="<?= glpiacessivel_e($advancedSearchToken) ?>" />
          <p class="glpiacessivel-help-text"><?= __('A pesquisa avancada aplicada sera salva diretamente no GLPI.', 'glpiacessivel') ?></p>
        <?php endif; ?>
        <?php foreach (['scope', 'status', 'q', 'group_id', 'group_by', 'page_size', 'sort', 'direction'] as $filterKey): ?>
          <input type="hidden" name="<?= glpiacessivel_e($filterKey) ?>" value="<?= glpiacessivel_e((string) ($filters[$filterKey] ?? '')) ?>" />
        <?php endforeach; ?>
        <?php foreach ($columns as $column): ?>
          <input type="hidden" name="columns[]" value="<?= glpiacessivel_e((string) $column) ?>" />
        <?php endforeach; ?>
        <div class="glpiacessivel-field">
          <label for="native_saved_search_name_create"><?= __('Nome da nova pesquisa no GLPI', 'glpiacessivel') ?></label>
          <input id="native_saved_search_name_create" name="saved_search_name" maxlength="180" required />
        </div>
        <label class="glpiacessivel-checkbox-row">
          <input type="checkbox" name="saved_search_default" value="1" />
          <?= __('Definir como minha pesquisa padrão', 'glpiacessivel') ?>
        </label>
        <button type="submit"><?= __('Criar pesquisa no GLPI', 'glpiacessivel') ?></button>
      </form>
    </details>
  <?php endif; ?>

  <?php if ($nativeCatalogItems === []): ?>
    <p class="glpiacessivel-empty-state" role="status">
      <?= $nativeCatalogQuery === ''
        ? __('Nenhuma pesquisa salva do GLPI está disponível para seu perfil e entidade.', 'glpiacessivel')
        : __('Nenhuma pesquisa salva corresponde à busca informada.', 'glpiacessivel') ?>
    </p>
  <?php else: ?>
    <ol class="glpiacessivel-native-search-catalog" aria-labelledby="saved-search-catalog-results">
      <?php foreach ($nativeCatalogItems as $savedIndex => $saved): ?>
        <?php
          $savedId = max(0, (int) ($saved['id'] ?? 0));
          $savedName = trim((string) ($saved['name'] ?? ''));
          $savedName = $savedName !== '' ? $savedName : __('Pesquisa sem nome', 'glpiacessivel');
          $savedKey = 'native:' . $savedId;
          $savedHeadingId = 'native-saved-search-' . $savedId . '-' . (int) $savedIndex;
          $savedCapabilities = is_array($saved['capabilities'] ?? null) ? $saved['capabilities'] : [];
          $savedCanEdit = !empty($savedCapabilities['can_edit']) || !empty($saved['can_edit']);
          $savedCanSetDefault = !empty($savedCapabilities['can_set_default']) || !empty($saved['can_set_default']);
          $savedCanUnsetDefault = !empty($savedCapabilities['can_unset_default']) || !empty($saved['can_unset_default']);
          $savedCanDelete = !empty($savedCapabilities['can_delete']) || !empty($saved['can_delete']);
          $savedIsDefault = !empty($saved['is_default']);
          $savedFingerprint = (string) ($saved['expected_fingerprint'] ?? $saved['fingerprint'] ?? '');
          $savedNativeUrl = (string) ($saved['native_url'] ?? $nativeTicketUrl);
          $savedCapability = (string) ($saved['capability'] ?? $saved['compatibility'] ?? 'native_only');
          $savedVisibilityLabel = (string) ($saved['visibility'] ?? 'private') === 'private'
            ? __('Privada', 'glpiacessivel')
            : __('Compartilhada', 'glpiacessivel');
          $savedCriteriaCount = max(0, (int) ($saved['criteria_count'] ?? 0));
          $savedDeletePanelId = 'native-saved-search-delete-' . $savedId . '-' . (int) $savedIndex;
        ?>
        <li>
          <article class="glpiacessivel-native-search-card" aria-labelledby="<?= glpiacessivel_e($savedHeadingId) ?>">
            <div class="glpiacessivel-native-search-card-head">
              <h4 id="<?= glpiacessivel_e($savedHeadingId) ?>"><?= glpiacessivel_e($savedName) ?></h4>
              <?php if ($savedIsDefault): ?>
                <span class="glpiacessivel-badge"><?= __('Pesquisa padrão', 'glpiacessivel') ?></span>
              <?php endif; ?>
            </div>
            <dl class="glpiacessivel-native-search-meta">
              <div><dt><?= __('Visibilidade', 'glpiacessivel') ?></dt><dd><?= glpiacessivel_e($savedVisibilityLabel) ?></dd></div>
              <div><dt><?= __('Critérios', 'glpiacessivel') ?></dt><dd><?= $savedCriteriaCount ?></dd></div>
              <div>
                <dt><?= __('Disponibilidade', 'glpiacessivel') ?></dt>
                <dd><?= $savedCapability === 'native_only'
                  ? __('Somente na interface nativa do GLPI', 'glpiacessivel')
                  : __('Aplicável nesta lista acessível', 'glpiacessivel') ?></dd>
              </div>
            </dl>

            <div class="glpiacessivel-native-search-actions" role="group" aria-label="<?= glpiacessivel_e(sprintf(__('Ações para a pesquisa %s', 'glpiacessivel'), $savedName)) ?>">
              <?php if ($savedId > 0 && $savedCapability !== 'native_only'): ?>
                <a class="glpiacessivel-button" href="<?= glpiacessivel_e(glpiacessivel_url(
                  'front/ticket.php?saved_search=' . rawurlencode($savedKey)
                )) ?>"><?= glpiacessivel_e(sprintf(__('Aplicar: %s', 'glpiacessivel'), $savedName)) ?></a>
              <?php endif; ?>
              <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($savedNativeUrl) ?>">
                <?= glpiacessivel_e(sprintf(__('Abrir no GLPI: %s', 'glpiacessivel'), $savedName)) ?>
              </a>

              <?php if (!$savedIsDefault && $savedCanSetDefault && $savedId > 0): ?>
                <form method="post" action="<?= glpiacessivel_e($savedSearchActionUrl) ?>">
                  <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
                  <input type="hidden" name="idempotency_key" value="<?= glpiacessivel_e($savedSearchIdempotencyKey()) ?>" />
                  <input type="hidden" name="saved_search_action" value="default" />
                  <input type="hidden" name="native_saved_search_id" value="<?= $savedId ?>" />
                  <input type="hidden" name="expected_fingerprint" value="<?= glpiacessivel_e($savedFingerprint) ?>" />
                  <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary">
                    <?= glpiacessivel_e(sprintf(__('Definir como padrão: %s', 'glpiacessivel'), $savedName)) ?>
                  </button>
                </form>
              <?php elseif ($savedIsDefault && $savedCanUnsetDefault && $savedId > 0): ?>
                <form method="post" action="<?= glpiacessivel_e($savedSearchActionUrl) ?>">
                  <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
                  <input type="hidden" name="idempotency_key" value="<?= glpiacessivel_e($savedSearchIdempotencyKey()) ?>" />
                  <input type="hidden" name="saved_search_action" value="unset_default" />
                  <input type="hidden" name="native_saved_search_id" value="<?= $savedId ?>" />
                  <input type="hidden" name="expected_fingerprint" value="<?= glpiacessivel_e($savedFingerprint) ?>" />
                  <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary">
                    <?= glpiacessivel_e(sprintf(__('Remover como padrão: %s', 'glpiacessivel'), $savedName)) ?>
                  </button>
                </form>
              <?php endif; ?>

              <?php if ($savedCanDelete && $savedId > 0): ?>
                <button
                  type="button"
                  class="glpiacessivel-button glpiacessivel-button-secondary"
                  aria-expanded="false"
                  aria-controls="<?= glpiacessivel_e($savedDeletePanelId) ?>"
                  data-glpiacessivel-native-delete-open
                  data-open-announcement="<?= glpiacessivel_e(sprintf(__('Confirmação de exclusão aberta para %s.', 'glpiacessivel'), $savedName)) ?>"
                ><?= glpiacessivel_e(sprintf(__('Excluir: %s', 'glpiacessivel'), $savedName)) ?></button>
              <?php endif; ?>
            </div>

            <?php if ($savedCanEdit && $savedId > 0): ?>
              <details class="glpiacessivel-native-search-editor">
                <summary><?= glpiacessivel_e(sprintf(__('Renomear e ajustar padrão: %s', 'glpiacessivel'), $savedName)) ?></summary>
                <form method="post" action="<?= glpiacessivel_e($savedSearchActionUrl) ?>">
                  <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
                  <input type="hidden" name="idempotency_key" value="<?= glpiacessivel_e($savedSearchIdempotencyKey()) ?>" />
                  <input type="hidden" name="saved_search_action" value="update" />
                  <input type="hidden" name="native_saved_search_id" value="<?= $savedId ?>" />
                  <input type="hidden" name="expected_fingerprint" value="<?= glpiacessivel_e($savedFingerprint) ?>" />
                  <p class="glpiacessivel-help-text"><?= __('Os critérios da pesquisa serão preservados exatamente como estão no GLPI.', 'glpiacessivel') ?></p>
                  <div class="glpiacessivel-field">
                    <label for="native_saved_search_name_<?= $savedId ?>_<?= (int) $savedIndex ?>">
                      <?= glpiacessivel_e(sprintf(__('Nome da pesquisa %s', 'glpiacessivel'), $savedName)) ?>
                    </label>
                    <input
                      id="native_saved_search_name_<?= $savedId ?>_<?= (int) $savedIndex ?>"
                      name="saved_search_name"
                      maxlength="180"
                      value="<?= glpiacessivel_e($savedName) ?>"
                      required
                    />
                  </div>
                  <label class="glpiacessivel-checkbox-row">
                    <input type="checkbox" name="saved_search_default" value="1" <?= $savedIsDefault ? 'checked' : '' ?> />
                    <?= __('Definir como minha pesquisa padrão', 'glpiacessivel') ?>
                  </label>
                  <button type="submit"><?= glpiacessivel_e(sprintf(__('Salvar nome e padrão no GLPI: %s', 'glpiacessivel'), $savedName)) ?></button>
                </form>
              </details>
            <?php endif; ?>

            <?php if ($savedCanDelete && $savedId > 0): ?>
              <section
                id="<?= glpiacessivel_e($savedDeletePanelId) ?>"
                class="glpiacessivel-native-search-delete-confirmation"
                role="region"
                aria-labelledby="<?= glpiacessivel_e($savedDeletePanelId) ?>-heading"
                aria-describedby="<?= glpiacessivel_e($savedDeletePanelId) ?>-description"
                data-glpiacessivel-native-delete-panel
                data-cancel-announcement="<?= glpiacessivel_e(sprintf(__('Exclusão cancelada para %s.', 'glpiacessivel'), $savedName)) ?>"
                hidden
              >
                <h5 id="<?= glpiacessivel_e($savedDeletePanelId) ?>-heading" tabindex="-1">
                  <?= glpiacessivel_e(sprintf(__('Confirmar exclusão de %s', 'glpiacessivel'), $savedName)) ?>
                </h5>
                <p id="<?= glpiacessivel_e($savedDeletePanelId) ?>-description">
                  <?= glpiacessivel_e(sprintf(
                    __('Esta ação exclui definitivamente a pesquisa %s no GLPI%s. Os chamados não serão excluídos.', 'glpiacessivel'),
                    $savedName,
                    $savedIsDefault ? __(', que atualmente é sua pesquisa padrão', 'glpiacessivel') : ''
                  )) ?>
                </p>
                <form method="post" action="<?= glpiacessivel_e($savedSearchActionUrl) ?>">
                  <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
                  <input type="hidden" name="idempotency_key" value="<?= glpiacessivel_e($savedSearchIdempotencyKey()) ?>" />
                  <input type="hidden" name="saved_search_action" value="delete" />
                  <input type="hidden" name="native_saved_search_id" value="<?= $savedId ?>" />
                  <input type="hidden" name="expected_fingerprint" value="<?= glpiacessivel_e($savedFingerprint) ?>" />
                  <label class="glpiacessivel-checkbox-row">
                    <input type="checkbox" name="confirm_delete" value="1" required />
                    <?= glpiacessivel_e(sprintf(__('Confirmo a exclusão definitiva da pesquisa %s no GLPI', 'glpiacessivel'), $savedName)) ?>
                  </label>
                  <div class="glpiacessivel-native-search-confirmation-actions">
                    <button type="submit"><?= glpiacessivel_e(sprintf(__('Excluir definitivamente: %s', 'glpiacessivel'), $savedName)) ?></button>
                    <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-native-delete-cancel>
                      <?= __('Cancelar', 'glpiacessivel') ?>
                    </button>
                  </div>
                </form>
              </section>
            <?php endif; ?>
          </article>
        </li>
      <?php endforeach; ?>
    </ol>
  <?php endif; ?>

  <?php if ($nativeCatalogHasPrevious || $nativeCatalogCanReturnToFirst || $nativeCatalogNextCursor !== ''): ?>
    <nav class="glpiacessivel-native-search-pagination" aria-label="<?= glpiacessivel_e(__('Paginação das pesquisas salvas do GLPI', 'glpiacessivel')) ?>">
      <?php if ($nativeCatalogHasPrevious): ?>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($queryUrl([
          'saved_search_q' => $nativeCatalogQuery,
          'saved_search_cursor' => $nativeCatalogPreviousCursor,
        ])) ?>"><?= __('Página anterior de pesquisas', 'glpiacessivel') ?></a>
      <?php elseif ($nativeCatalogCanReturnToFirst): ?>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($queryUrl([
          'saved_search_q' => $nativeCatalogQuery,
          'saved_search_cursor' => null,
        ])) ?>"><?= __('Voltar à primeira página de pesquisas', 'glpiacessivel') ?></a>
      <?php endif; ?>
      <?php if ($nativeCatalogNextCursor !== ''): ?>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($queryUrl([
          'saved_search_q' => $nativeCatalogQuery,
          'saved_search_cursor' => $nativeCatalogNextCursor,
        ])) ?>"><?= __('Próxima página de pesquisas', 'glpiacessivel') ?></a>
      <?php endif; ?>
    </nav>
  <?php endif; ?>
  </div>
</section>
