<?php
$values = is_array($values ?? null) ? $values : [];
$context = is_array($context ?? null) ? $context : [];
$errors = is_array($errors ?? null) ? $errors : [];
$submissionMetadata = is_array($submission_metadata ?? null) ? $submission_metadata : [];
$partialCreatedTicketId = (int) ($submissionMetadata['created_ticket_id'] ?? 0);
$categories = is_array($context['categories'] ?? null) ? $context['categories'] : [];
$locations = is_array($context['locations'] ?? null) ? $context['locations'] : [];
$users = is_array($context['assignable_users'] ?? null) ? $context['assignable_users'] : [];
$groups = is_array($context['assignable_groups'] ?? null) ? $context['assignable_groups'] : [];
$observerGroups = is_array($context['observer_groups'] ?? null) ? $context['observer_groups'] : [];
$typeOptions = is_array($context['type_options'] ?? null) ? $context['type_options'] : [];
$urgencyOptions = is_array($context['urgency_options'] ?? null) ? $context['urgency_options'] : [];
$impactOptions = is_array($context['impact_options'] ?? null) ? $context['impact_options'] : [];
$requestSourceOptions = is_array($context['request_source_options'] ?? null) ? $context['request_source_options'] : [];
$defaultRequestSourceId = (int) ($context['default_request_source_id'] ?? 1);
$requestSourceSupported = !empty($context['request_source_supported']);
$externalIdSupported = !empty($context['external_id_supported']);
$groupAssignmentSupported = !empty($context['group_assignment_supported']);
$fieldRequirements = is_array($context['field_requirements'] ?? null) ? $context['field_requirements'] : [];
$ticketTemplates = is_array($context['ticket_templates'] ?? null) ? $context['ticket_templates'] : [];
$serviceCatalog = is_array($context['service_catalog'] ?? null) ? $context['service_catalog'] : [];
$portalLimitations = is_array($context['portal_limitations'] ?? null) ? $context['portal_limitations'] : [];
$dynamicFormSchema = is_array($context['dynamic_form_schema'] ?? null) ? $context['dynamic_form_schema'] : [];
$schemaFieldsByName = [];
foreach ((array) ($dynamicFormSchema['fields'] ?? []) as $schemaField) {
    if (!is_array($schemaField)) {
        continue;
    }
    foreach ([(string) ($schemaField['name'] ?? ''), (string) ($schemaField['native_field'] ?? ''), (string) ($schemaField['id'] ?? '')] as $schemaFieldKey) {
        if ($schemaFieldKey !== '') {
            $schemaFieldsByName[$schemaFieldKey] = $schemaField;
        }
    }
}
$fieldSchema = static fn(string $field): array => is_array($schemaFieldsByName[$field] ?? null) ? $schemaFieldsByName[$field] : [];
$fieldRequired = static function (string $field, bool $default = false) use ($fieldSchema): bool {
    $schemaField = $fieldSchema($field);
    return $schemaField === [] ? $default : !empty($schemaField['required']);
};
$fieldVisible = static function (string $field, bool $default = true) use ($fieldSchema): bool {
    $schemaField = $fieldSchema($field);
    return $schemaField === [] || !array_key_exists('visible', $schemaField) ? $default : !empty($schemaField['visible']);
};
$fieldReadonly = static function (string $field, bool $default = false) use ($fieldSchema): bool {
    $schemaField = $fieldSchema($field);
    return $schemaField === [] ? $default : !empty($schemaField['readonly']);
};
$fieldDisabled = static function (string $field, bool $default = false) use ($fieldSchema): bool {
    $schemaField = $fieldSchema($field);
    return $schemaField === [] ? $default : !empty($schemaField['disabled']);
};
$fieldLabel = static function (string $field, string $default) use ($fieldSchema): string {
    $schemaField = $fieldSchema($field);
    return (string) (($schemaField['label'] ?? '') !== '' ? $schemaField['label'] : $default);
};
$requiredAttrs = static function (string $field, bool $default = false) use ($fieldRequired): string {
    return $fieldRequired($field, $default) ? ' required aria-required="true"' : '';
};
$stateAttrs = static function (string $field, bool $disabledDefault = false) use ($fieldReadonly, $fieldDisabled): string {
    $attrs = [];
    if ($fieldReadonly($field)) {
        $attrs[] = 'readonly';
    }
    if ($fieldDisabled($field, $disabledDefault)) {
        $attrs[] = 'disabled';
    }
    return $attrs === [] ? '' : ' ' . implode(' ', $attrs);
};
$requiredMark = static function (string $field, bool $default = false) use ($fieldRequired): string {
    return $fieldRequired($field, $default) ? ' *' : '';
};
$selectedTemplateId = (int) ($values['tickettemplates_id'] ?? 0);
$nativeCreateTicketUrl = (string) ($native_create_ticket_url ?? glpiacessivel_url('front/ticket.php'));
$templateById = [];
$templateMetadataPayload = [];
$selectedTemplate = null;
foreach ($ticketTemplates as $template) {
    $templateId = (int) ($template['id'] ?? 0);
    if ($templateId <= 0) {
        continue;
    }
    $templateById[$templateId] = $template;
    if ($templateId === $selectedTemplateId) {
        $selectedTemplate = $template;
    }
    $requiredLabels = [];
    foreach ((array) ($template['mandatory_fields'] ?? []) as $requiredField) {
        $requiredLabels[] = (string) (($fieldRequirements[$requiredField]['label'] ?? null) ?: ($template['field_requirements'][$requiredField]['label'] ?? $requiredField));
    }
    $unsupportedLabels = [];
    foreach ((array) ($template['unsupported_required'] ?? []) as $requiredField) {
        $unsupportedLabels[] = (string) (($template['field_requirements'][$requiredField]['label'] ?? null) ?: $requiredField);
    }
    $templateMetadataPayload[(string) $templateId] = [
        'label' => (string) ($template['label'] ?? ('Modelo #' . $templateId)),
        'required' => $requiredLabels,
        'requiredFields' => array_values(array_map('strval', (array) ($template['mandatory_fields'] ?? []))),
        'unsupported' => $unsupportedLabels,
        'requiresNativeFallback' => !empty($template['requires_native_fallback']),
    ];
}

$computePriorityPreview = static function (int $urgency, int $impact): string {
    $score = max(1, min(5, $urgency)) + max(1, min(5, $impact));
    return match (true) {
        $score <= 3 => 'Muito baixa',
        $score <= 5 => 'Baixa',
        $score <= 7 => 'Media',
        $score <= 9 => 'Alta',
        default => 'Muito alta',
    };
};

$fieldIdMap = [
    'name' => 'name',
    'content' => 'content',
    'type' => 'type',
    'itilcategories_id' => 'itilcategories_id',
    'locations_id' => 'locations_id',
    'requesttypes_id' => 'requesttypes_id',
    'externalid' => 'externalid',
    '_groups_id_assign' => 'groups_assign',
    '_users_id_assign' => 'users_assign',
    '_users_id_observer' => 'users_observer',
    '_groups_id_observer' => 'groups_observer',
    '_filename' => 'filename',
    'filename' => 'filename',
    'tickettemplates_id' => 'tickettemplates_id',
    'urgency' => 'urgency',
    'impact' => 'impact',
];

$errorFieldMap = [
    'titulo' => 'name',
    'descricao' => 'content',
    'tipo' => 'type',
    'categoria' => 'itilcategories_id',
    'localizacao' => 'locations_id',
    'origem' => 'requesttypes_id',
    'externo' => 'externalid',
    'grupo' => 'groups_assign',
    'tecnico' => 'users_assign',
    'observador' => 'users_observer',
    'grupo observador' => 'groups_observer',
    'ator' => 'users_assign',
    'anexo' => 'filename',
    'upload' => 'filename',
    'arquivo' => 'filename',
    'modelo' => 'tickettemplates_id',
    'urgencia' => 'urgency',
    'impacto' => 'impact',
];

$errorMap = array_fill_keys(array_keys($fieldIdMap), false);
$errorMap['filename'] = false;
$errorMap['tickettemplates_id'] = false;
$normalizedErrors = [];
foreach ($errors as $error) {
    if (is_array($error)) {
        $message = (string) ($error['message'] ?? 'Revise este campo.');
        $field = (string) ($error['field'] ?? '');
        $code = (string) ($error['code'] ?? 'invalid');
    } else {
        $message = (string) $error;
        $field = '';
        $code = 'legacy';
        $normalized = mb_strtolower($message, 'UTF-8');
        foreach ($errorFieldMap as $needle => $fieldId) {
            if (str_contains($normalized, $needle)) {
                $field = (string) array_search($fieldId, $fieldIdMap, true);
                if ($field === '') {
                    $field = $fieldId;
                }
                break;
            }
        }
    }

    $target = $fieldIdMap[$field] ?? $field;
    if ($target !== '' && isset($errorMap[$field])) {
        $errorMap[$field] = true;
    }
    if ($target !== '' && isset($errorMap[$target])) {
        $errorMap[$target] = true;
    }
    $normalizedErrors[] = [
        'field' => $field,
        'target' => $target,
        'code' => $code,
        'message' => $message,
    ];
}

$selectedUrgency = (int) ($values['urgency'] ?? 3);
$selectedImpact = (int) ($values['impact'] ?? 3);
$priorityPreview = $computePriorityPreview($selectedUrgency, $selectedImpact);
$selectedRequestSourceId = (int) ($values['requesttypes_id'] ?? $defaultRequestSourceId);

$errorFieldMap = [
    'titulo' => 'name',
    'descricao' => 'content',
    'tipo' => 'type',
    'categoria' => 'itilcategories_id',
    'localizacao' => 'locations_id',
    'origem' => 'requesttypes_id',
    'externo' => 'externalid',
    'grupo' => 'groups_assign',
    'anexo' => 'filename',
    'upload' => 'filename',
    'arquivo' => 'filename',
    'modelo' => 'tickettemplates_id',
];
?>
<section class="glpiacessivel-section-head" aria-labelledby="novo-chamado-titulo">
  <p class="glpiacessivel-eyebrow">Abertura assistida</p>
  <h2 id="novo-chamado-titulo">Abrir chamado</h2>
  <p>Formulario acessivel organizado como o fluxo nativo do GLPI: dados principais do chamado, propriedades operacionais, atores e encaminhamento tecnico.</p>
</section>

<?php if (!empty($submissionMetadata['partial_success']) && $partialCreatedTicketId > 0): ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning" role="alert" aria-labelledby="partial-create-title">
    <strong id="partial-create-title">Chamado criado; anexo pendente de confirmacao</strong>
    <p>O chamado foi criado, mas o vinculo final do anexo ainda nao foi confirmado pelo GLPI. Nao envie novamente o formulario.</p>
    <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php?id=' . $partialCreatedTicketId)) ?>">Abrir chamado criado</a>
  </div>
<?php endif; ?>

<?php if (!empty($serviceCatalog['available'])): ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning glpiacessivel-ticket-create-fallback" role="status" aria-labelledby="service-catalog-fallback-title">
    <strong id="service-catalog-fallback-title">Catalogo de Servicos GLPI 11</strong>
    <p><?= glpiacessivel_e((string) ($serviceCatalog['message'] ?? 'Use o fluxo nativo quando a solicitacao exigir formulario dinamico.')) ?></p>
    <?php if (!empty($serviceCatalog['enabled']) && !empty($serviceCatalog['url'])): ?>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e((string) $serviceCatalog['url']) ?>">Abrir Catalogo de Servicos nativo</a>
    <?php endif; ?>
  </div>
<?php endif; ?>

<?php if ($portalLimitations !== []): ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning glpiacessivel-ticket-create-fallback" role="status" aria-labelledby="portal-limitations-title">
    <strong id="portal-limitations-title">Limites beta do formulario acessivel</strong>
    <ul>
      <?php foreach ($portalLimitations as $limitation): ?>
        <li><?= glpiacessivel_e((string) $limitation) ?></li>
      <?php endforeach; ?>
    </ul>
    <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeCreateTicketUrl) ?>">Abrir formulario nativo do GLPI</a>
  </div>
<?php endif; ?>

<?php if ($errors !== []): ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-error" role="alert" aria-live="assertive" id="form-errors" tabindex="-1">
    <strong>Revise os dados informados.</strong>
    <ul class="glpiacessivel-error-list">
      <?php foreach ($normalizedErrors as $error): ?>
        <?php $target = (string) ($error['target'] ?? ''); ?>
        <li>
          <?php if ($target !== ''): ?>
            <a href="#<?= glpiacessivel_e($target) ?>"><?= glpiacessivel_e((string) ($error['message'] ?? 'Revise este campo.')) ?></a>
          <?php else: ?>
            <?= glpiacessivel_e((string) ($error['message'] ?? 'Revise este campo.')) ?>
          <?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<section class="glpiacessivel-card glpiacessivel-open-ticket-card" aria-labelledby="novo-chamado-formulario">
  <div class="glpiacessivel-open-ticket-header">
    <div>
      <p class="glpiacessivel-eyebrow">Novo chamado</p>
      <h3 id="novo-chamado-formulario">Registro inicial do chamado</h3>
      <p class="glpiacessivel-help-text">A criacao continua sendo executada pelo core do GLPI com seu perfil, entidade ativa e ACL nativa. A tela abaixo aproxima a ordem funcional do formulario original, mantendo leitura simplificada e navegacao por teclado.</p>
    </div>
    <section class="glpiacessivel-ticket-create-meta" aria-labelledby="ticket-create-context-title" role="region">
      <h3 id="ticket-create-context-title" class="glpiacessivel-sr-only">Contexto do chamado</h3>
      <div class="glpiacessivel-ticket-create-chip">
        <span>Entidade ativa</span>
        <strong><?= glpiacessivel_e($context['entity_name'] ?? 'Entidade atual') ?></strong>
      </div>
      <div class="glpiacessivel-ticket-create-chip">
        <span>Requerente</span>
        <strong><?= glpiacessivel_e($context['requester_name'] ?? '') ?></strong>
      </div>
    </section>
  </div>

  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.create.php')) ?>" class="glpiacessivel-open-ticket-form" id="glpiacessivel-open-ticket-form" enctype="multipart/form-data" novalidate>
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
    <?php if ($dynamicFormSchema !== []): ?>
      <input type="hidden" name="dynamic_form_schema_id" value="<?= glpiacessivel_e((string) ($dynamicFormSchema['id'] ?? '')) ?>" />
      <input type="hidden" name="dynamic_form_source" value="<?= glpiacessivel_e((string) ($dynamicFormSchema['source'] ?? 'native_ticket')) ?>" />
    <?php endif; ?>
    <div id="create-live-region" class="glpiacessivel-sr-only" aria-live="polite" aria-atomic="true"></div>

    <div class="glpiacessivel-ticket-create-shell">
      <main class="glpiacessivel-ticket-create-main" id="conteudo-principal-chamado">
        <div class="glpiacessivel-ticket-create-entity" role="status" aria-live="polite">
          <span class="glpiacessivel-ticket-create-avatar" aria-hidden="true"><?= glpiacessivel_e(mb_strtoupper(mb_substr((string) ($context['requester_name'] ?? 'GL'), 0, 2, 'UTF-8'), 'UTF-8')) ?></span>
          <div>
            <strong>Chamado sera adicionado na entidade</strong>
            <span><?= glpiacessivel_e($context['entity_name'] ?? 'Entidade atual') ?></span>
          </div>
        </div>

        <fieldset class="glpiacessivel-form-fieldset glpiacessivel-ticket-create-panel glpiacessivel-ticket-create-panel-primary">
          <legend>Chamado</legend>
          <div class="glpiacessivel-open-ticket-grid">
            <div class="glpiacessivel-field glpiacessivel-open-ticket-title">
              <label for="name"><?= glpiacessivel_e($fieldLabel('name', 'Titulo')) ?><?= $requiredMark('name', true) ?></label>
              <input
                id="name"
                type="text"
                name="name"
                maxlength="255"<?= $requiredAttrs('name', true) ?><?= $stateAttrs('name') ?>
                aria-describedby="name-help<?= $errorMap['name'] ? ' form-errors' : '' ?>"
                aria-invalid="<?= $errorMap['name'] ? 'true' : 'false' ?>"
                value="<?= glpiacessivel_e($values['name'] ?? '') ?>"
              />
              <small id="name-help" class="glpiacessivel-help-text">Informe o assunto do chamado de forma objetiva, como aparece para a central de servicos.</small>
            </div>

            <div class="glpiacessivel-field glpiacessivel-open-ticket-description">
              <label for="content"><?= glpiacessivel_e($fieldLabel('content', 'Descricao')) ?><?= $requiredMark('content', true) ?></label>
              <textarea
                id="content"
                name="content"<?= $requiredAttrs('content', true) ?><?= $stateAttrs('content') ?>
                aria-describedby="content-help<?= $errorMap['content'] ? ' form-errors' : '' ?>"
                aria-invalid="<?= $errorMap['content'] ? 'true' : 'false' ?>"
              ><?= glpiacessivel_e($values['content'] ?? '') ?></textarea>
              <small id="content-help" class="glpiacessivel-help-text">Explique o problema, informe contexto, evidencias e impacto. Se houver urgencia operacional, descreva o efeito no servico.</small>
            </div>
          </div>

          <div class="glpiacessivel-field glpiacessivel-ticket-create-upload-note">
            <label for="filename"><?= glpiacessivel_e($fieldLabel('_filename', 'Anexos')) ?><?= $requiredMark('_filename') ?></label>
            <input
              id="filename"
              type="file"
              name="filename[]"
              multiple<?= $requiredAttrs('_filename') ?>
              aria-describedby="filename-help<?= $errorMap['filename'] ? ' form-errors' : '' ?>"
              aria-invalid="<?= $errorMap['filename'] ? 'true' : 'false' ?>"
              data-glpiacessivel-file-input
            />
            <small id="filename-help" class="glpiacessivel-help-text">Opcional. Os arquivos sao anexados pelo fluxo nativo de documentos do GLPI, respeitando tipos e limites configurados na instalacao.</small>
            <div class="glpiacessivel-file-actions">
              <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-file-clear>Limpar anexos</button>
            </div>
            <ul class="glpiacessivel-file-list" data-glpiacessivel-file-list aria-live="polite"></ul>
          </div>
        </fieldset>
      </main>

      <aside class="glpiacessivel-ticket-create-aside" aria-label="Propriedades e atores do chamado">
        <fieldset class="glpiacessivel-form-fieldset glpiacessivel-ticket-create-panel glpiacessivel-ticket-create-panel-side">
          <legend>Propriedades do chamado</legend>
          <div class="glpiacessivel-ticket-create-side-grid">
            <div class="glpiacessivel-field glpiacessivel-ticket-create-readonly">
              <span class="glpiacessivel-label-like">Data de abertura</span>
              <output><?= glpiacessivel_e($context['opening_date_preview'] ?? date('d/m/Y H:i')) ?></output>
            </div>

            <div class="glpiacessivel-field">
              <label for="type"><?= glpiacessivel_e($fieldLabel('type', 'Tipo')) ?><?= $requiredMark('type', true) ?></label>
              <select id="type" name="type"<?= $requiredAttrs('type', true) ?><?= $stateAttrs('type') ?> aria-describedby="<?= $errorMap['type'] ? 'form-errors' : 'type-help' ?>" aria-invalid="<?= $errorMap['type'] ? 'true' : 'false' ?>">
                <?php foreach ($typeOptions as $option): ?>
                  <option value="<?= (int) $option['id'] ?>"<?= ((int) ($values['type'] ?? 0) === (int) $option['id']) ? ' selected' : '' ?>>
                    <?= glpiacessivel_e($option['label']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <small id="type-help" class="glpiacessivel-help-text">A categoria se ajusta automaticamente ao tipo.</small>
            </div>

            <div class="glpiacessivel-field">
              <label for="itilcategories_id"><?= glpiacessivel_e($fieldLabel('itilcategories_id', 'Categoria')) ?><?= $requiredMark('itilcategories_id') ?></label>
              <select id="itilcategories_id" name="itilcategories_id"<?= $requiredAttrs('itilcategories_id') ?><?= $stateAttrs('itilcategories_id') ?> aria-describedby="category-help<?= $errorMap['itilcategories_id'] ? ' form-errors' : '' ?>" aria-invalid="<?= $errorMap['itilcategories_id'] ? 'true' : 'false' ?>">
                <option value="0">Selecione se souber</option>
                <?php foreach ($categories as $category): ?>
                  <option
                    value="<?= (int) $category['id'] ?>"
                    data-incident="<?= !empty($category['is_incident']) ? '1' : '0' ?>"
                    data-request="<?= !empty($category['is_request']) ? '1' : '0' ?>"
                    <?= ((int) ($values['itilcategories_id'] ?? 0) === (int) $category['id']) ? ' selected' : '' ?>
                  >
                    <?= glpiacessivel_e($category['label']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <small id="category-help" class="glpiacessivel-help-text">Carregada do GLPI conforme entidade, perfil e tipo do chamado.</small>
            </div>

            <?php if ($ticketTemplates !== []): ?>
              <div class="glpiacessivel-field glpiacessivel-ticket-template-field">
                <label for="tickettemplates_id"><?= glpiacessivel_e($fieldLabel('tickettemplates_id', 'Modelo ITIL')) ?><?= $requiredMark('tickettemplates_id') ?></label>
                <select
                  id="tickettemplates_id"
                  name="tickettemplates_id"
                  data-glpiacessivel-ticket-template
                  aria-describedby="tickettemplates-help tickettemplates-status<?= $errorMap['tickettemplates_id'] ? ' form-errors' : '' ?>"
                  aria-invalid="<?= $errorMap['tickettemplates_id'] ? 'true' : 'false' ?>"
                >
                  <option value="0">Sem modelo</option>
                  <?php foreach ($ticketTemplates as $template): ?>
                    <?php $templateId = (int) ($template['id'] ?? 0); ?>
                    <option
                      value="<?= $templateId ?>"
                      data-requires-native-fallback="<?= !empty($template['requires_native_fallback']) ? '1' : '0' ?>"
                      <?= $selectedTemplateId === $templateId ? ' selected' : '' ?>
                    >
                      <?= glpiacessivel_e((string) ($template['label'] ?? ('Modelo #' . $templateId))) ?><?= !empty($template['requires_native_fallback']) ? ' - requer GLPI nativo' : '' ?>
                    </option>
                  <?php endforeach; ?>
                </select>
                <small id="tickettemplates-help" class="glpiacessivel-help-text">Aplica valores padrao e campos obrigatorios do modelo quando o subconjunto e suportado pelo portal.</small>
                <p id="tickettemplates-status" class="glpiacessivel-template-status" role="status" aria-live="polite">
                  <?php if ($selectedTemplate !== null && !empty($selectedTemplate['requires_native_fallback'])): ?>
                    Modelo selecionado exige campos ainda nao suportados aqui. Use o formulario nativo do GLPI.
                  <?php elseif ($selectedTemplate !== null): ?>
                    Modelo selecionado sera validado antes da criacao. Campos de titulo e descricao nao sao sobrescritos.
                  <?php else: ?>
                    Nenhum modelo ITIL selecionado.
                  <?php endif; ?>
                </p>
              </div>
            <?php endif; ?>

            <div class="glpiacessivel-field glpiacessivel-ticket-create-readonly">
              <span class="glpiacessivel-label-like">Status</span>
              <output><span class="glpiacessivel-status-dot" aria-hidden="true"></span>Novo</output>
            </div>

            <div class="glpiacessivel-field">
              <label for="requesttypes_id"><?= glpiacessivel_e($fieldLabel('requesttypes_id', 'Origem da requisicao')) ?><?= $requiredMark('requesttypes_id') ?></label>
              <select id="requesttypes_id" name="requesttypes_id"<?= $requestSourceSupported ? '' : ' disabled' ?> aria-describedby="<?= $errorMap['requesttypes_id'] ? 'form-errors' : 'requesttypes-help' ?>" aria-invalid="<?= $errorMap['requesttypes_id'] ? 'true' : 'false' ?>">
                <?php foreach ($requestSourceOptions as $option): ?>
                  <option value="<?= (int) $option['id'] ?>"<?= $selectedRequestSourceId === (int) $option['id'] ? ' selected' : '' ?>>
                    <?= glpiacessivel_e((string) $option['label']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <?php if (!$requestSourceSupported): ?>
                <input type="hidden" name="requesttypes_id" value="<?= $selectedRequestSourceId ?>" />
              <?php endif; ?>
              <small id="requesttypes-help" class="glpiacessivel-help-text"><?= $requestSourceSupported ? 'Mantida no ticket criado conforme configuracao do GLPI.' : 'Esta instalacao nao permite alterar a origem; o ticket sera criado com a origem padrao.' ?></small>
            </div>

            <div class="glpiacessivel-field">
              <label for="urgency"><?= glpiacessivel_e($fieldLabel('urgency', 'Urgencia')) ?><?= $requiredMark('urgency', true) ?></label>
              <select id="urgency" name="urgency"<?= $requiredAttrs('urgency', true) ?><?= $stateAttrs('urgency') ?> aria-describedby="<?= $errorMap['urgency'] ? 'form-errors' : 'urgency-help' ?>" aria-invalid="<?= $errorMap['urgency'] ? 'true' : 'false' ?>">
                <?php foreach ($urgencyOptions as $option): ?>
                  <option value="<?= (int) $option['id'] ?>"<?= $selectedUrgency === (int) $option['id'] ? ' selected' : '' ?>>
                    <?= glpiacessivel_e($option['label']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <small id="urgency-help" class="glpiacessivel-help-text">Informe a urgencia percebida para apoiar o calculo de prioridade.</small>
            </div>

            <div class="glpiacessivel-field">
              <label for="impact"><?= glpiacessivel_e($fieldLabel('impact', 'Impacto')) ?><?= $requiredMark('impact', true) ?></label>
              <select id="impact" name="impact"<?= $requiredAttrs('impact', true) ?><?= $stateAttrs('impact') ?> aria-describedby="<?= $errorMap['impact'] ? 'form-errors' : 'impact-help' ?>" aria-invalid="<?= $errorMap['impact'] ? 'true' : 'false' ?>">
                <?php foreach ($impactOptions as $option): ?>
                  <option value="<?= (int) $option['id'] ?>"<?= $selectedImpact === (int) $option['id'] ? ' selected' : '' ?>>
                    <?= glpiacessivel_e($option['label']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <small id="impact-help" class="glpiacessivel-help-text">Informe o impacto no servico ou atividade afetada.</small>
            </div>

            <div class="glpiacessivel-field glpiacessivel-ticket-create-readonly">
              <span class="glpiacessivel-label-like">Prioridade</span>
              <output id="priority-preview" class="glpiacessivel-badge glpiacessivel-badge-priority-medium"><?= glpiacessivel_e($priorityPreview) ?></output>
            </div>

            <div class="glpiacessivel-field">
              <label for="locations_id"><?= glpiacessivel_e($fieldLabel('locations_id', 'Localizacao')) ?><?= $requiredMark('locations_id') ?></label>
              <select id="locations_id" name="locations_id"<?= $requiredAttrs('locations_id') ?><?= $stateAttrs('locations_id') ?> aria-describedby="<?= $errorMap['locations_id'] ? 'form-errors' : 'locations-help' ?>" aria-invalid="<?= $errorMap['locations_id'] ? 'true' : 'false' ?>">
                <option value="0">Nao informar agora</option>
                <?php foreach ($locations as $location): ?>
                  <option value="<?= (int) $location['id'] ?>"<?= ((int) ($values['locations_id'] ?? 0) === (int) $location['id']) ? ' selected' : '' ?>>
                    <?= glpiacessivel_e((string) $location['label']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <small id="locations-help" class="glpiacessivel-help-text">Carregada do GLPI conforme a entidade ativa.</small>
            </div>

            <div class="glpiacessivel-field glpiacessivel-ticket-create-readonly">
              <span class="glpiacessivel-label-like">Duracao total</span>
              <output><?= glpiacessivel_e($context['duration_total_help'] ?? 'Acompanhada apos a abertura.') ?></output>
            </div>

            <div class="glpiacessivel-field">
              <label for="externalid"><?= glpiacessivel_e($fieldLabel('externalid', 'ID externo')) ?><?= $requiredMark('externalid') ?></label>
              <input
                id="externalid"
                type="text"
                name="externalid"
                maxlength="255"
                value="<?= glpiacessivel_e((string) ($values['externalid'] ?? '')) ?>"
                <?= $externalIdSupported ? '' : 'disabled' ?>
                aria-describedby="<?= $errorMap['externalid'] ? 'form-errors' : 'externalid-help' ?>"
                aria-invalid="<?= $errorMap['externalid'] ? 'true' : 'false' ?>"
              />
              <?php if (!$externalIdSupported): ?>
                <input type="hidden" name="externalid" value="" />
              <?php endif; ?>
              <small id="externalid-help" class="glpiacessivel-help-text"><?= $externalIdSupported ? 'Use quando o chamado estiver vinculado a outro sistema.' : 'Campo nao suportado nesta instalacao do GLPI.' ?></small>
            </div>
          </div>
        </fieldset>

        <fieldset class="glpiacessivel-form-fieldset glpiacessivel-ticket-create-panel glpiacessivel-ticket-create-panel-side glpiacessivel-ticket-create-actors">
          <legend>Atores</legend>
          <div class="glpiacessivel-field glpiacessivel-ticket-create-readonly">
            <span class="glpiacessivel-label-like">Requerente</span>
            <output><?= glpiacessivel_e($context['requester_name'] ?? '') ?></output>
          </div>

          <details class="glpiacessivel-open-ticket-advanced">
            <summary>
              <span>Encaminhamento tecnico</span>
              <small>Opcional. Direcione grupo, tecnico ou observadores quando necessario.</small>
            </summary>
            <p class="glpiacessivel-help-text glpiacessivel-ticket-create-routing-intro">
              Marque ou adicione atores do chamado como no GLPI. Com JavaScript ativo, use busca, adicionar e remover; sem JavaScript, os campos abaixo continuam como listas de selecao multipla.
            </p>
            <div class="glpiacessivel-ticket-create-routing-grid">
              <?php if ($groupAssignmentSupported): ?>
                <div class="glpiacessivel-field glpiacessivel-actor-field">
                  <label for="groups_assign"><?= glpiacessivel_e($fieldLabel('_groups_id_assign', 'Grupo tecnico')) ?><?= $requiredMark('_groups_id_assign') ?></label>
                  <select
                    id="groups_assign"
                    class="glpiacessivel-actor-native-select"
                    name="_groups_id_assign[]"
                    multiple
                    size="4"
                    data-glpiacessivel-actor-select
                    data-actor-kind="grupo tecnico"
                    data-actor-add-label="Adicionar grupo tecnico"
                    data-actor-search-label="Filtrar grupos tecnicos"
                    data-actor-empty-label="Nenhum grupo tecnico selecionado."
                    <?= $requiredAttrs('_groups_id_assign') ?><?= $stateAttrs('_groups_id_assign') ?> aria-describedby="<?= $errorMap['_groups_id_assign'] ? 'form-errors' : 'groups-help' ?>"
                    aria-invalid="<?= $errorMap['_groups_id_assign'] ? 'true' : 'false' ?>"
                  >
                    <?php foreach ($groups as $group): ?>
                      <?php $selected = in_array((int) $group['id'], array_map('intval', (array) ($values['_groups_id_assign'] ?? [])), true); ?>
                      <option value="<?= (int) $group['id'] ?>"<?= $selected ? ' selected' : '' ?>>
                        <?= glpiacessivel_e((string) $group['label']) ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                  <small id="groups-help" class="glpiacessivel-help-text">Selecao opcional para direcionar o atendimento ao grupo tecnico correspondente. Para selecionar varios itens no fallback nativo, use Ctrl no desktop.</small>
                </div>
              <?php endif; ?>

              <div class="glpiacessivel-field glpiacessivel-actor-field">
                <label for="users_assign"><?= glpiacessivel_e($fieldLabel('_users_id_assign', 'Atribuir para')) ?><?= $requiredMark('_users_id_assign') ?></label>
                <select
                  id="users_assign"
                  class="glpiacessivel-actor-native-select"
                  name="_users_id_assign[]"
                  multiple
                  size="4"
                  data-glpiacessivel-actor-select
                  data-actor-kind="tecnico atribuido"
                  data-actor-add-label="Adicionar tecnico"
                  data-actor-search-label="Filtrar tecnicos"
                  data-actor-empty-label="Nenhum tecnico selecionado."
                  <?= $requiredAttrs('_users_id_assign') ?><?= $stateAttrs('_users_id_assign') ?> aria-describedby="users-assign-help"
                >
                  <?php foreach ($users as $user): ?>
                    <?php $selected = in_array((int) $user['id'], array_map('intval', (array) ($values['_users_id_assign'] ?? [])), true); ?>
                    <option value="<?= (int) $user['id'] ?>"<?= $selected ? ' selected' : '' ?>>
                      <?= glpiacessivel_e((string) $user['label']) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
                <small id="users-assign-help" class="glpiacessivel-help-text">Opcional. Use quando quiser atribuir o chamado a um tecnico especifico. Para selecionar varios itens no fallback nativo, use Ctrl no desktop.</small>
              </div>

              <div class="glpiacessivel-field glpiacessivel-actor-field">
                <label for="users_observer"><?= glpiacessivel_e($fieldLabel('_users_id_observer', 'Adicionar observador')) ?><?= $requiredMark('_users_id_observer') ?></label>
                <select
                  id="users_observer"
                  class="glpiacessivel-actor-native-select"
                  name="_users_id_observer[]"
                  multiple
                  size="4"
                  data-glpiacessivel-actor-select
                  data-actor-kind="observador"
                  data-actor-add-label="Adicionar observador"
                  data-actor-search-label="Filtrar observadores"
                  data-actor-empty-label="Nenhum observador selecionado."
                  <?= $requiredAttrs('_users_id_observer') ?><?= $stateAttrs('_users_id_observer') ?> aria-describedby="users-observer-help"
                >
                  <?php foreach ($users as $user): ?>
                    <?php $selected = in_array((int) $user['id'], array_map('intval', (array) ($values['_users_id_observer'] ?? [])), true); ?>
                    <option value="<?= (int) $user['id'] ?>"<?= $selected ? ' selected' : '' ?>>
                      <?= glpiacessivel_e((string) $user['label']) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
                <small id="users-observer-help" class="glpiacessivel-help-text">Inclui pessoas que devem acompanhar o andamento do chamado.</small>
              </div>
              <div class="glpiacessivel-field glpiacessivel-actor-field">
                <label for="groups_observer"><?= glpiacessivel_e($fieldLabel('_groups_id_observer', 'Adicionar grupos observadores')) ?><?= $requiredMark('_groups_id_observer') ?></label>
                <select
                  id="groups_observer"
                  class="glpiacessivel-actor-native-select"
                  name="_groups_id_observer[]"
                  multiple
                  size="4"
                  data-glpiacessivel-actor-select
                  data-actor-kind="grupo observador"
                  data-actor-add-label="Adicionar grupo observador"
                  data-actor-search-label="Filtrar grupos observadores"
                  data-actor-empty-label="Nenhum grupo observador selecionado."
                  <?= $requiredAttrs('_groups_id_observer') ?><?= $stateAttrs('_groups_id_observer') ?> aria-describedby="groups-observer-help"
                >
                  <?php foreach ($observerGroups as $group): ?>
                    <?php $selected = in_array((int) $group['id'], array_map('intval', (array) ($values['_groups_id_observer'] ?? [])), true); ?>
                    <option value="<?= (int) $group['id'] ?>"<?= $selected ? ' selected' : '' ?>>
                      <?= glpiacessivel_e((string) $group['label']) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
                <small id="groups-observer-help" class="glpiacessivel-help-text">Inclui grupos cujos integrantes devem acompanhar o chamado sem assumir o atendimento.</small>
              </div>
            </div>
          </details>
        </fieldset>
      </aside>
    </div>

    <div class="glpiacessivel-ticket-create-actions">
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary">Registrar chamado</button>
      <button type="reset" class="glpiacessivel-button glpiacessivel-button-secondary">Limpar formulario</button>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeCreateTicketUrl) ?>">
        Abrir formulario nativo do GLPI
      </a>
    </div>
  </form>
</section>

<script>
  (function () {
    var typeField = document.getElementById('type');
    var categoryField = document.getElementById('itilcategories_id');
    var urgencyField = document.getElementById('urgency');
    var impactField = document.getElementById('impact');
    var requestSourceField = document.getElementById('requesttypes_id');
    var requestSourcePreview = document.getElementById('request-source-preview');
    var priorityPreview = document.getElementById('priority-preview');
    var form = document.getElementById('glpiacessivel-open-ticket-form');
    var liveRegion = document.getElementById('create-live-region');
    var errorSummary = document.getElementById('form-errors');

    if (!typeField || !categoryField || !urgencyField || !impactField || !priorityPreview) {
      return;
    }

    function announce(message) {
      if (liveRegion) {
        liveRegion.textContent = message;
      }
    }

    var actorPickers = [];

    function enhanceFileInputs() {
      Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-file-input]')).forEach(function (input) {
        var list = input.parentNode ? input.parentNode.querySelector('[data-glpiacessivel-file-list]') : null;
        if (!list) {
          return;
        }

        var clearButton = input.parentNode ? input.parentNode.querySelector('[data-glpiacessivel-file-clear]') : null;
        function clearFiles() {
          input.value = '';
          list.innerHTML = '';
          announce('Selecao de anexos limpa.');
        }
        if (clearButton) {
          clearButton.addEventListener('click', clearFiles);
        }

        input.addEventListener('change', function () {
          list.innerHTML = '';
          var files = Array.prototype.slice.call(input.files || []);
          if (files.length === 0) {
            announce('Nenhum anexo selecionado.');
            return;
          }

          files.forEach(function (file) {
            var item = document.createElement('li');
            item.textContent = file.name + ' (' + Math.ceil((file.size || 0) / 1024) + ' KB)';
            list.appendChild(item);
          });
          announce(files.length + ' anexo(s) selecionado(s).');
        });
      });
    }

    var templateField = document.querySelector('[data-glpiacessivel-ticket-template]');
    var templateStatus = document.getElementById('tickettemplates-status');
    var templateMetadata = <?= json_encode($templateMetadataPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '{}' ?>;
    var templateFieldTargets = {
      name: 'name',
      content: 'content',
      type: 'type',
      itilcategories_id: 'itilcategories_id',
      locations_id: 'locations_id',
      requesttypes_id: 'requesttypes_id',
      externalid: 'externalid',
      urgency: 'urgency',
      impact: 'impact',
      _groups_id_assign: 'groups_assign',
      _users_id_assign: 'users_assign',
      _users_id_observer: 'users_observer',
      _groups_id_observer: 'groups_observer',
      _filename: 'filename',
      filename: 'filename'
    };
    var dynamicRequiredFields = [];

    function setFieldRequired(field, required) {
      var id = templateFieldTargets[field] || field;
      var control = document.getElementById(id);
      var label = control ? document.querySelector('label[for="' + id + '"]') : null;
      if (!control || control.disabled || control.getAttribute('aria-hidden') === 'true') {
        return;
      }
      if (required) {
        control.setAttribute('required', 'required');
        control.setAttribute('aria-required', 'true');
        if (label && label.textContent.indexOf('*') === -1) {
          label.setAttribute('data-template-required-added', '1');
          label.textContent = label.textContent + ' *';
        }
      } else {
        var nativeRequired = ['name', 'content', 'type', 'urgency', 'impact'].indexOf(field) !== -1;
        if (!nativeRequired) {
          control.removeAttribute('required');
          control.removeAttribute('aria-required');
        }
        if (label && label.getAttribute('data-template-required-added') === '1') {
          label.textContent = label.textContent.replace(/\s\*$/, '');
          label.removeAttribute('data-template-required-added');
        }
      }
    }

    function resetDynamicRequiredFields() {
      dynamicRequiredFields.forEach(function (field) {
        setFieldRequired(field, false);
      });
      dynamicRequiredFields = [];
    }

    function updateTicketTemplateStatus() {
      if (!templateField || !templateStatus) {
        return;
      }
      var selected = templateField.options[templateField.selectedIndex];
      var metadata = templateMetadata[String(templateField.value)] || null;
      resetDynamicRequiredFields();
      if (!metadata || templateField.value === '0') {
        templateStatus.textContent = 'Nenhum modelo ITIL selecionado.';
        return;
      }
      if (selected && selected.getAttribute('data-requires-native-fallback') === '1') {
        var unsupported = metadata.unsupported && metadata.unsupported.length ? metadata.unsupported.join(', ') : 'campos obrigatorios nao suportados';
        templateStatus.textContent = 'Modelo ' + metadata.label + ' exige ' + unsupported + '. Use o formulario nativo do GLPI para concluir.';
        announce(templateStatus.textContent);
        return;
      }
      dynamicRequiredFields = Array.isArray(metadata.requiredFields) ? metadata.requiredFields.slice(0) : [];
      dynamicRequiredFields.forEach(function (field) {
        setFieldRequired(field, true);
      });
      var required = metadata.required && metadata.required.length ? ' Campos obrigatorios: ' + metadata.required.join(', ') + '.' : '';
      templateStatus.textContent = 'Modelo ' + metadata.label + ' selecionado.' + required + ' Titulo e descricao nao serao sobrescritos.';
      announce(templateStatus.textContent);
    }

    if (templateField) {
      templateField.addEventListener('change', updateTicketTemplateStatus);
      updateTicketTemplateStatus();
    }

    function actorText(value) {
      return String(value || '').replace(/\s+/g, ' ').trim();
    }

    function selectedActorOptions(select) {
      return Array.prototype.slice.call(select.options).filter(function (option) {
        return option.selected && option.value !== '';
      });
    }

    function enhanceActorSelect(select) {
      if (!select || select.dataset.glpiacessivelActorEnhanced === '1') {
        return;
      }

      var field = select.closest('.glpiacessivel-actor-field');
      var label = field ? field.querySelector('label') : null;
      var labelText = actorText(label ? label.textContent : select.getAttribute('data-actor-kind'));
      var kind = actorText(select.getAttribute('data-actor-kind') || labelText || 'ator');
      var addLabel = actorText(select.getAttribute('data-actor-add-label') || ('Adicionar ' + kind));
      var searchLabel = actorText(select.getAttribute('data-actor-search-label') || ('Filtrar ' + kind));
      var emptyLabel = actorText(select.getAttribute('data-actor-empty-label') || ('Nenhum ' + kind + ' selecionado.'));
      var baseId = select.id || ('actor-' + actorPickers.length);
      var options = Array.prototype.slice.call(select.options).map(function (option) {
        return {
          option: option,
          value: option.value,
          label: actorText(option.textContent)
        };
      }).filter(function (item) {
        return item.value !== '';
      });

      var picker = document.createElement('div');
      picker.className = 'glpiacessivel-actor-picker';
      picker.setAttribute('data-actor-kind', kind);

      var controls = document.createElement('div');
      controls.className = 'glpiacessivel-actor-picker-controls';

      var searchWrap = document.createElement('div');
      searchWrap.className = 'glpiacessivel-field glpiacessivel-actor-search-field';

      var searchId = baseId + '_search';
      var searchLabelNode = document.createElement('label');
      searchLabelNode.setAttribute('for', searchId);
      searchLabelNode.textContent = searchLabel;

      var searchInput = document.createElement('input');
      searchInput.id = searchId;
      searchInput.type = 'search';
      searchInput.className = 'glpiacessivel-actor-search';
      searchInput.setAttribute('autocomplete', 'off');
      searchInput.setAttribute('aria-controls', baseId + '_candidate');

      searchWrap.appendChild(searchLabelNode);
      searchWrap.appendChild(searchInput);

      var candidateWrap = document.createElement('div');
      candidateWrap.className = 'glpiacessivel-field glpiacessivel-actor-candidate-field';

      var candidateId = baseId + '_candidate';
      var candidateLabel = document.createElement('label');
      candidateLabel.setAttribute('for', candidateId);
      candidateLabel.className = 'glpiacessivel-sr-only';
      candidateLabel.textContent = 'Opcao para adicionar em ' + kind;

      var candidateSelect = document.createElement('select');
      candidateSelect.id = candidateId;
      candidateSelect.className = 'glpiacessivel-actor-candidate';

      candidateWrap.appendChild(candidateLabel);
      candidateWrap.appendChild(candidateSelect);

      var buttonWrap = document.createElement('div');
      buttonWrap.className = 'glpiacessivel-actor-add-wrap';

      var addButton = document.createElement('button');
      addButton.type = 'button';
      addButton.className = 'glpiacessivel-button glpiacessivel-button-secondary glpiacessivel-actor-add';
      addButton.textContent = '+';
      addButton.setAttribute('aria-label', addLabel + ' selecionado');

      buttonWrap.appendChild(addButton);
      controls.appendChild(searchWrap);
      controls.appendChild(candidateWrap);
      controls.appendChild(buttonWrap);

      var summary = document.createElement('p');
      summary.id = baseId + '_summary';
      summary.className = 'glpiacessivel-actor-summary';
      summary.setAttribute('aria-live', 'polite');

      var selectedList = document.createElement('ul');
      selectedList.id = baseId + '_selected';
      selectedList.className = 'glpiacessivel-actor-selected-list';
      selectedList.setAttribute('aria-describedby', summary.id);

      var clearButton = document.createElement('button');
      clearButton.type = 'button';
      clearButton.className = 'glpiacessivel-button glpiacessivel-button-secondary glpiacessivel-actor-clear';
      clearButton.textContent = 'Limpar';
      clearButton.setAttribute('aria-label', 'Limpar selecao de ' + kind);

      picker.appendChild(controls);
      picker.appendChild(summary);
      picker.appendChild(selectedList);
      picker.appendChild(clearButton);

      if (field) {
        field.insertBefore(picker, select);
        field.setAttribute('data-actor-enhanced', 'true');
      } else {
        select.parentNode.insertBefore(picker, select);
      }

      select.dataset.glpiacessivelActorEnhanced = '1';
      select.setAttribute('aria-hidden', 'true');
      select.tabIndex = -1;

      function filteredCandidates() {
        var term = actorText(searchInput.value).toLocaleLowerCase();
        return options.filter(function (item) {
          return !item.option.selected && (term === '' || item.label.toLocaleLowerCase().indexOf(term) !== -1);
        });
      }

      function renderCandidates() {
        var previous = candidateSelect.value;
        var candidates = filteredCandidates();
        candidateSelect.innerHTML = '';

        if (candidates.length === 0) {
          var emptyOption = document.createElement('option');
          emptyOption.value = '';
          emptyOption.textContent = options.length === 0 ? 'Nenhuma opcao disponivel' : 'Nenhum resultado disponivel';
          candidateSelect.appendChild(emptyOption);
          candidateSelect.disabled = true;
          addButton.disabled = true;
          return;
        }

        candidates.forEach(function (item) {
          var option = document.createElement('option');
          option.value = item.value;
          option.textContent = item.label;
          candidateSelect.appendChild(option);
        });

        candidateSelect.disabled = false;
        addButton.disabled = false;
        if (previous && candidates.some(function (item) { return item.value === previous; })) {
          candidateSelect.value = previous;
        }
      }

      function renderSelected() {
        var selected = selectedActorOptions(select);
        selectedList.innerHTML = '';

        if (selected.length === 0) {
          summary.textContent = emptyLabel;
          selectedList.classList.add('glpiacessivel-actor-selected-list-empty');
          clearButton.disabled = true;
          renderCandidates();
          return;
        }

        summary.textContent = selected.length + ' ' + kind + '(s) selecionado(s).';
        selectedList.classList.remove('glpiacessivel-actor-selected-list-empty');
        clearButton.disabled = false;

        selected.forEach(function (option) {
          var item = document.createElement('li');
          item.className = 'glpiacessivel-actor-chip';

          var text = document.createElement('span');
          text.textContent = actorText(option.textContent);

          var remove = document.createElement('button');
          remove.type = 'button';
          remove.className = 'glpiacessivel-actor-remove';
          remove.textContent = 'Remover';
          remove.setAttribute('aria-label', 'Remover ' + actorText(option.textContent) + ' de ' + kind);
          remove.addEventListener('click', function () {
            option.selected = false;
            renderSelected();
            announce(actorText(option.textContent) + ' removido de ' + kind + '.');
          });

          item.appendChild(text);
          item.appendChild(remove);
          selectedList.appendChild(item);
        });

        renderCandidates();
      }

      function addSelectedCandidate() {
        var value = candidateSelect.value;
        if (!value) {
          announce('Nenhuma opcao disponivel para adicionar em ' + kind + '.');
          return;
        }

        var selectedItem = options.find(function (item) {
          return item.value === value;
        });
        if (!selectedItem) {
          return;
        }

        selectedItem.option.selected = true;
        searchInput.value = '';
        renderSelected();
        announce(selectedItem.label + ' adicionado em ' + kind + '.');
      }

      searchInput.addEventListener('input', renderCandidates);
      searchInput.addEventListener('keydown', function (event) {
        if (event.key === 'Enter') {
          event.preventDefault();
          addSelectedCandidate();
        }
      });
      candidateSelect.addEventListener('keydown', function (event) {
        if (event.key === 'Enter') {
          event.preventDefault();
          addSelectedCandidate();
        }
      });
      addButton.addEventListener('click', addSelectedCandidate);
      clearButton.addEventListener('click', function () {
        var selected = selectedActorOptions(select);
        selected.forEach(function (option) {
          option.selected = false;
        });
        renderSelected();
        announce('Selecao de ' + kind + ' limpa.');
      });
      select.addEventListener('change', renderSelected);

      renderSelected();
      actorPickers.push({
        render: renderSelected
      });
    }

    function enhanceActorPickers() {
      Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-actor-select]')).forEach(enhanceActorSelect);
    }

    function computePriorityLabel(urgency, impact) {
      var score = Number(urgency) + Number(impact);
      if (score <= 3) {
        return 'Muito baixa';
      }
      if (score <= 5) {
        return 'Baixa';
      }
      if (score <= 7) {
        return 'Media';
      }
      if (score <= 9) {
        return 'Alta';
      }

      return 'Muito alta';
    }

    function updatePriorityPreview() {
      var label = computePriorityLabel(urgencyField.value || 3, impactField.value || 3);
      priorityPreview.textContent = label;
      priorityPreview.className = 'glpiacessivel-badge ' + (
        label === 'Muito alta' || label === 'Alta'
          ? 'glpiacessivel-badge-priority-high'
          : (label === 'Media' ? 'glpiacessivel-badge-priority-medium' : 'glpiacessivel-badge-priority-low')
      );
      announce('Prioridade prevista atualizada para ' + label + '.');
    }

    function updateRequestSourcePreview() {
      if (!requestSourceField || !requestSourcePreview) {
        return;
      }

      var selected = requestSourceField.options[requestSourceField.selectedIndex];
      requestSourcePreview.textContent = selected ? selected.textContent : 'Helpdesk / Interface GLPI';
    }

    function syncCategories() {
      var selectedType = String(typeField.value);
      var hasVisibleSelected = false;
      var visibleCount = 0;

      Array.prototype.slice.call(categoryField.options).forEach(function (option, index) {
        if (index === 0) {
          option.hidden = false;
          option.disabled = false;
          return;
        }

        var allowed = selectedType === '2'
          ? option.getAttribute('data-request') === '1'
          : option.getAttribute('data-incident') === '1';

        option.hidden = !allowed;
        option.disabled = !allowed;
        if (allowed) {
          visibleCount += 1;
        }
        if (allowed && option.selected) {
          hasVisibleSelected = true;
        }
      });

      if (!hasVisibleSelected) {
        categoryField.value = '0';
      }

      announce('Categorias atualizadas para o tipo selecionado. ' + visibleCount + ' opcao(oes) disponiveis.');
    }

    typeField.addEventListener('change', syncCategories);
    urgencyField.addEventListener('change', updatePriorityPreview);
    impactField.addEventListener('change', updatePriorityPreview);
    if (requestSourceField) {
      requestSourceField.addEventListener('change', function () {
        updateRequestSourcePreview();
        announce('Origem da requisicao atualizada.');
      });
    }

    syncCategories();
    updatePriorityPreview();
    updateRequestSourcePreview();
    enhanceActorPickers();
    enhanceFileInputs();

    if (form) {
      form.addEventListener('reset', function () {
        window.setTimeout(function () {
          syncCategories();
          updatePriorityPreview();
          updateRequestSourcePreview();
          actorPickers.forEach(function (picker) {
            picker.render();
          });
          announce('Formulario limpo.');
        }, 0);
      });
    }

    if (errorSummary && typeof errorSummary.focus === 'function') {
      errorSummary.focus();
    } else {
      var firstInvalid = form ? form.querySelector('[aria-invalid="true"]') : null;
      if (firstInvalid && typeof firstInvalid.focus === 'function') {
        firstInvalid.focus();
      }
    }
  })();
</script>

