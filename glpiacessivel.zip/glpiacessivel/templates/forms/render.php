<?php
$formView = is_array($formView ?? null) ? $formView : [];
$form = is_array($formView['form'] ?? null) ? $formView['form'] : [];
$schema = is_array($formView['schema'] ?? null) ? $formView['schema'] : [];
$adminDiagnostics = is_array($formView['admin_diagnostics'] ?? null)
    ? $formView['admin_diagnostics']
    : [];
$nativeUrl = (string) ($form['native_url'] ?? glpiacessivel_url('front/forms.php'));
$showOperationalDiagnostics = !empty($showOperationalDiagnostics);
$formsNativeFlowMode = (string) ($formsNativeFlowMode ?? 'native_embedded');
$formcreatorMinimalEmbedEnabled = !empty($formcreatorMinimalEmbedEnabled);
$glpiVersion = (string) ($glpiVersion ?? '');
$formcreatorVersion = (string) ($formcreatorVersion ?? '');
$title = (string) ($schema['title'] ?? $form['name'] ?? glpiacessivel_t('Formulário'));
$sections = is_array($schema['sections'] ?? null) ? $schema['sections'] : [];
$fields = is_array($schema['fields'] ?? null) ? $schema['fields'] : [];
$capabilities = is_array($schema['capabilities'] ?? null) ? $schema['capabilities'] : [];
$metadata = is_array($schema['metadata'] ?? null) ? $schema['metadata'] : [];
$conditions = is_array($schema['conditions'] ?? null) ? $schema['conditions'] : [];
$matrix = is_array($adminDiagnostics['compatibility_matrix'] ?? null)
    ? $adminDiagnostics['compatibility_matrix']
    : [];
$submissionReadiness = is_array($capabilities['own_submission_readiness'] ?? null) ? $capabilities['own_submission_readiness'] : [];
$nativeSubmitContract = is_array($capabilities['native_submit_contract'] ?? null) ? $capabilities['native_submit_contract'] : [];
$nativeHiddenFields = is_array($nativeSubmitContract['hidden_fields'] ?? null) ? $nativeSubmitContract['hidden_fields'] : [];
$requiresNativeCsrf = !empty($nativeSubmitContract['requires_csrf']);
$nativeCsrfToken = (string) ($csrf_token ?? '');
$unsupported = is_array($adminDiagnostics['unsupported_questions'] ?? null)
    ? $adminDiagnostics['unsupported_questions']
    : [];
global $CFG_GLPI;
$glpiRoot = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/');
$canSubmitViaNativeContract = !empty($nativeSubmitContract['enabled']) && !empty($submissionReadiness['ready']);
$source = (string) ($form['source'] ?? '');
$wantsConvertedPortalForm = $formsNativeFlowMode === 'plugin_converted_with_native_callback';
$wantsMinimalEmbeddedForm = $formsNativeFlowMode === 'native_embedded_minimal'
    || (
        $formsNativeFlowMode === 'native_embedded'
        && $formcreatorMinimalEmbedEnabled
    );
$canUseConvertedPortalForm = $wantsConvertedPortalForm && $canSubmitViaNativeContract;
$nativeSubmitUrl = trim((string) ($nativeSubmitContract['submit_url'] ?? ''));
if ($nativeSubmitUrl === '') {
    $nativeSubmitUrl = $glpiRoot . (string) ($nativeSubmitContract['submit_endpoint'] ?? ($source === 'glpi11_service_catalog' ? '/Form/SubmitAnswers' : ''));
}
$nativeValidateUrl = $nativeSubmitContract !== [] && isset($nativeSubmitContract['validate_endpoint'])
    ? $glpiRoot . (string) $nativeSubmitContract['validate_endpoint']
    : ($source === 'glpi11_service_catalog' ? $glpiRoot . '/Form/ValidateAnswers' : '');
$nativeConditionUrl = $nativeSubmitContract !== [] && isset($nativeSubmitContract['condition_endpoint'])
    ? $glpiRoot . (string) $nativeSubmitContract['condition_endpoint']
    : ($source === 'glpi11_service_catalog' ? $glpiRoot . '/Form/Condition/Engine' : '');
$formId = (int) ($metadata['form_id'] ?? $nativeSubmitContract['form_id'] ?? $form['id'] ?? 0);
$canEmbedNativeFlow = !$canUseConvertedPortalForm
    && $formsNativeFlowMode !== 'native_link'
    && in_array($source, ['glpi11_service_catalog', 'formcreator_glpi10'], true)
    && $formId > 0
    && $nativeUrl !== '';
$nativeEmbedUrl = $nativeUrl;
if ($canEmbedNativeFlow) {
    $nativeEmbedUrl .= (str_contains($nativeEmbedUrl, '?') ? '&' : '?') . 'glpiacessivel_native_embed=1';
}
$nativeUrlParts = parse_url($nativeUrl);
$nativeUrlHost = is_array($nativeUrlParts) && is_string($nativeUrlParts['host'] ?? null)
    ? strtolower((string) $nativeUrlParts['host'])
    : '';
$requestHost = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
if (str_contains($requestHost, ':')) {
    $requestHost = (string) strstr($requestHost, ':', true);
}
$nativeUrlQuery = [];
if (is_array($nativeUrlParts) && is_string($nativeUrlParts['query'] ?? null)) {
    parse_str((string) $nativeUrlParts['query'], $nativeUrlQuery);
}
$nativePath = is_array($nativeUrlParts) && is_string($nativeUrlParts['path'] ?? null)
    ? (string) $nativeUrlParts['path']
    : '';
$nativeSubmitUrlParts = parse_url($nativeSubmitUrl);
$nativeSubmitPath = is_array($nativeSubmitUrlParts) && is_string($nativeSubmitUrlParts['path'] ?? null)
    ? (string) $nativeSubmitUrlParts['path']
    : '';
$nativeUrlFormId = is_numeric($nativeUrlQuery['id'] ?? null)
    ? (int) $nativeUrlQuery['id']
    : 0;
$minimalPresentationProfile = 'formcreator-glpi10-2.13-vertical-dom-v2';
$minimalEmbedGateEnabled = $canEmbedNativeFlow
    && $wantsMinimalEmbeddedForm
    && $source === 'formcreator_glpi10'
    && version_compare($glpiVersion, '10.0.0', '>=')
    && version_compare($glpiVersion, '11.0.0', '<')
    && version_compare($formcreatorVersion, '2.13.0', '>=')
    && version_compare($formcreatorVersion, '2.14.0', '<')
    && preg_match('#/(?:plugins|marketplace)/formcreator/front/formdisplay\.php$#i', $nativePath) === 1
    && $nativeUrlFormId === $formId
    && ($nativeUrlHost === '' || ($requestHost !== '' && hash_equals($requestHost, $nativeUrlHost)));
$nativeParentPath = (string) (parse_url(glpiacessivel_url('front/form.render.php'), PHP_URL_PATH) ?: '');
$sectionMap = [];
foreach ($sections as $section) {
    if (!is_array($section)) {
        continue;
    }
    $id = (string) ($section['id'] ?? '');
    if ($id === '') {
        continue;
    }
    $sectionMap[$id] = $section;
}
$fieldsBySection = [];
foreach ($fields as $field) {
    if (!is_array($field) || empty($field['visible'])) {
        continue;
    }
    $sectionId = (string) ($field['section_id'] ?? 'metadata');
    $fieldsBySection[$sectionId][] = $field;
}
$sectionIds = array_values(array_unique(array_merge(array_keys($sectionMap), array_keys($fieldsBySection))));
$projectedFieldCount = 0;
foreach ($fieldsBySection as $sectionFields) {
    $projectedFieldCount += is_array($sectionFields) ? count($sectionFields) : 0;
}
$canRenderPortalForm = $canUseConvertedPortalForm;
$rendererDecision = $canRenderPortalForm
    ? 'plugin_converted'
    : ($canEmbedNativeFlow
        ? ($minimalEmbedGateEnabled ? 'native_embedded_minimal_candidate' : 'native_embedded_callback')
        : 'native_link');
$nativeDescribedBy = 'form-render-help';
?>

<nav class="glpiacessivel-context-actions" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Navegação dos formulários')) ?>">
  <a href="<?= glpiacessivel_e(glpiacessivel_url('front/forms.php')) ?>"><?= glpiacessivel_e(glpiacessivel_t('Voltar para formulários')) ?></a>
</nav>

<section class="glpiacessivel-section-head" aria-labelledby="form-render-title">
  <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Preencha o formulário')) ?></p>
  <h2 id="form-render-title"><?= glpiacessivel_e($title) ?></h2>
  <p id="form-render-help"><?= glpiacessivel_e(glpiacessivel_t('Preencha os campos abaixo e selecione Enviar.')) ?></p>
</section>

<?php if ($canEmbedNativeFlow) :
    ?>
  <section class="glpiacessivel-card glpiacessivel-native-embed" aria-labelledby="form-render-embedded-title" aria-busy="true" data-glpiacessivel-native-embed>
    <div>
      <h3 id="form-render-embedded-title"><?= glpiacessivel_e(glpiacessivel_t('Área de preenchimento')) ?></h3>
      <p id="form-render-embedded-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Você pode preencher e enviar o formulário nesta página. Se preferir, abra-o em uma página completa.')) ?></p>
    </div>
    <div id="form-render-native-frame-status" class="glpiacessivel-help-text" role="status" aria-live="polite" aria-atomic="true" data-glpiacessivel-native-frame-status>
      <?= glpiacessivel_e(glpiacessivel_t('Carregando o formulário…')) ?>
    </div>
    <div class="glpiacessivel-form-actions">
      <a class="glpiacessivel-button glpiacessivel-button-primary" href="#form-render-native-frame" aria-describedby="form-render-embedded-help" data-glpiacessivel-focus-native-frame>
        <?= glpiacessivel_e(glpiacessivel_t('Começar preenchimento')) ?>
      </a>
      <button class="glpiacessivel-button glpiacessivel-button-secondary" type="button" hidden data-glpiacessivel-native-retry>
        <?= glpiacessivel_e(glpiacessivel_t('Tentar novamente')) ?>
      </button>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeUrl) ?>" aria-describedby="form-render-embedded-help" data-glpiacessivel-native-full-link>
        <?= glpiacessivel_e(glpiacessivel_t('Abrir este formulário em página completa')) ?>
      </a>
    </div>
    <iframe
      id="form-render-native-frame"
      class="glpiacessivel-native-embed-frame"
      src="<?= glpiacessivel_e($nativeEmbedUrl) ?>"
      title="<?= glpiacessivel_e(sprintf(glpiacessivel_t('Formulário: %s'), $title)) ?>"
      aria-describedby="form-render-embedded-help"
      loading="eager"
      referrerpolicy="same-origin"
      data-glpiacessivel-native-source="<?= glpiacessivel_e($source) ?>"
      data-glpiacessivel-minimal-requested="<?= $wantsMinimalEmbeddedForm ? '1' : '0' ?>"
      data-glpiacessivel-minimal-gate-enabled="<?= $minimalEmbedGateEnabled ? '1' : '0' ?>"
      data-glpiacessivel-minimal-profile="<?= $minimalEmbedGateEnabled ? glpiacessivel_e($minimalPresentationProfile) : '' ?>"
      data-glpiacessivel-glpi-version="<?= glpiacessivel_e($glpiVersion) ?>"
      data-glpiacessivel-formcreator-version="<?= glpiacessivel_e($formcreatorVersion) ?>"
      data-glpiacessivel-expected-parent-path="<?= glpiacessivel_e($nativeParentPath) ?>"
      data-glpiacessivel-expected-child-path="<?= glpiacessivel_e($nativePath) ?>"
      data-glpiacessivel-expected-submit-path="<?= glpiacessivel_e($source === 'glpi11_service_catalog' ? $nativeSubmitPath : '') ?>"
      data-glpiacessivel-expected-form-id="<?= (int) $formId ?>"
      data-glpiacessivel-native-frame>
    </iframe>
  </section>
<?php endif; ?>

<?php if ($canRenderPortalForm) : ?>
<form class="glpiacessivel-form-grid glpiacessivel-dynamic-renderer" method="post" action="<?= glpiacessivel_e($nativeSubmitUrl) ?>" enctype="multipart/form-data" aria-labelledby="form-render-fields-title" novalidate data-glpiacessivel-dynamic-form-renderer data-glpiacessivel-native-submit="<?= $canSubmitViaNativeContract ? '1' : '0' ?>" data-glpiacessivel-form-id="<?= (int) $formId ?>" data-glpiacessivel-validate-url="<?= glpiacessivel_e($nativeValidateUrl) ?>" data-glpiacessivel-condition-url="<?= glpiacessivel_e($nativeConditionUrl) ?>">
    <?php if ($canSubmitViaNativeContract) :
        ?>
        <?php if ($nativeHiddenFields === []) :
            ?>
      <input type="hidden" name="forms_id" value="<?= (int) $formId ?>">
            <?php
        else :
            ?>
            <?php foreach ($nativeHiddenFields as $hiddenName => $hiddenValue) :
                ?>
        <input type="hidden" name="<?= glpiacessivel_e((string) $hiddenName) ?>" value="<?= glpiacessivel_e((string) $hiddenValue) ?>">
                <?php
            endforeach; ?>
            <?php
        endif; ?>
        <?php if ($requiresNativeCsrf && $nativeCsrfToken !== '') :
            ?>
      <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($nativeCsrfToken) ?>">
            <?php
        endif; ?>
        <?php
    endif; ?>
  <div id="form-render-error-summary" class="glpiacessivel-alert glpiacessivel-alert-danger" role="alert" tabindex="-1" hidden></div>
  <div id="form-render-submit-status" class="glpiacessivel-alert glpiacessivel-alert-success" role="status" tabindex="-1" hidden></div>
  <h3 id="form-render-fields-title"><?= glpiacessivel_e(glpiacessivel_t('Campos do formulário')) ?></h3>
  <div id="form-render-condition-status" class="glpiacessivel-sr-only" role="status" aria-live="polite" aria-atomic="true"></div>

    <?php if ($fieldsBySection === []) : ?>
    <p class="glpiacessivel-empty-state"><?= glpiacessivel_e(glpiacessivel_t('Não foi possível exibir estes campos nesta página. Abra o formulário em página completa para continuar.')) ?></p>
    <?php endif; ?>

    <?php foreach ($sectionIds as $sectionId) : ?>
        <?php
        $section = $sectionMap[$sectionId] ?? ['title' => glpiacessivel_t('Seção'), 'description' => ''];
        $sectionFields = $fieldsBySection[$sectionId] ?? [];
        if ($sectionFields === []) {
            continue;
        }
        $legendId = 'form-render-section-' . preg_replace('/[^a-z0-9_-]/i', '-', (string) $sectionId);
        $nativeSectionId = preg_replace('/^section_/', '', (string) $sectionId);
        ?>
    <fieldset class="glpiacessivel-form-fieldset glpiacessivel-dynamic-renderer-section" aria-labelledby="<?= glpiacessivel_e($legendId) ?>" data-glpiacessivel-section-wrapper data-section-id="<?= glpiacessivel_e((string) $sectionId) ?>" data-native-section-id="<?= glpiacessivel_e((string) $nativeSectionId) ?>">
      <legend id="<?= glpiacessivel_e($legendId) ?>"><?= glpiacessivel_e((string) ($section['title'] ?? glpiacessivel_t('Seção'))) ?></legend>
        <?php if (trim((string) ($section['description'] ?? '')) !== '') : ?>
        <p class="glpiacessivel-help-text"><?= glpiacessivel_e((string) $section['description']) ?></p>
        <?php endif; ?>

        <?php foreach ($sectionFields as $field) : ?>
            <?php
            $fieldId = 'field-' . preg_replace('/[^a-z0-9_-]/i', '-', (string) ($field['id'] ?? $field['name'] ?? uniqid('field_', false)));
            $fieldName = (string) ($field['name'] ?? $field['id'] ?? $fieldId);
            $fieldType = (string) ($field['type'] ?? 'text');
            $fieldMetadata = is_array($field['metadata'] ?? null) ? $field['metadata'] : [];
            $nativeQuestionId = (int) ($fieldMetadata['native_question_id'] ?? 0);
            $nativeInputName = (string) ($fieldMetadata['native_input_name'] ?? ($nativeQuestionId > 0 ? 'answers_' . $nativeQuestionId : $fieldName));
            $inputName = $canSubmitViaNativeContract && $nativeQuestionId > 0 ? $nativeInputName : $fieldName;
            $isProjectionOnly = !empty($fieldMetadata['projection_only']);
            $label = (string) ($field['label'] ?? $fieldName);
            $description = trim((string) ($field['description'] ?? ''));
            $required = !empty($field['required']);
            $readonly = !empty($field['readonly']) || $isProjectionOnly;
            $disabled = !empty($field['disabled']) || $isProjectionOnly;
            $multiple = !empty($field['multiple']);
            $default = $field['default'] ?? '';
            $value = is_scalar($default) ? (string) $default : '';
            $options = is_array($field['options'] ?? null) ? $field['options'] : [];
            $helpId = $description !== '' ? $fieldId . '-help' : '';
            $describedBy = trim($helpId . ($fieldType === 'file' ? ' ' . $fieldId . '-file-note' : ''));
            $commonAttributes = ($required ? ' required aria-required="true"' : '')
            . ($readonly ? ' readonly' : '')
            . ($disabled ? ' disabled' : '')
            . ($describedBy !== '' ? ' aria-describedby="' . glpiacessivel_e($describedBy) . '"' : '');
            ?>
        <div class="glpiacessivel-dynamic-renderer-field glpiacessivel-dynamic-renderer-field-<?= glpiacessivel_e(preg_replace('/[^a-z0-9_-]/i', '-', $fieldType)) ?>" data-glpiacessivel-field-wrapper data-field-name="<?= glpiacessivel_e($fieldName) ?>" data-field-id="<?= glpiacessivel_e((string) ($field['id'] ?? $fieldName)) ?>" data-native-question-id="<?= (int) $nativeQuestionId ?>" data-native-input-name="<?= glpiacessivel_e($nativeInputName) ?>" data-original-required="<?= $required ? '1' : '0' ?>" data-original-disabled="<?= $disabled ? '1' : '0' ?>">
            <?php if (in_array($fieldType, ['radio', 'checkbox'], true) && $options !== []) : ?>
            <fieldset class="glpiacessivel-dynamic-renderer-choice"<?= $required ? ' aria-required="true"' : '' ?><?= $describedBy !== '' ? ' aria-describedby="' . glpiacessivel_e($describedBy) . '"' : '' ?>>
              <legend><?= glpiacessivel_e($label) ?><?= $required ? ' *' : '' ?></legend>
                <?php if ($description !== '') : ?>
                <p id="<?= glpiacessivel_e($helpId) ?>" class="glpiacessivel-help-text"><?= glpiacessivel_e($description) ?></p>
                <?php endif; ?>
              <div class="glpiacessivel-dynamic-renderer-options">
                <?php foreach ($options as $optionIndex => $option) : ?>
                    <?php
                    $optionValue = (string) (is_array($option) ? ($option['id'] ?? $option['value'] ?? $optionIndex) : $optionIndex);
                    $optionLabel = (string) (is_array($option) ? ($option['label'] ?? $option['name'] ?? $optionValue) : $option);
                    $optionId = $fieldId . '-' . preg_replace('/[^a-z0-9_-]/i', '-', $optionValue);
                    ?>
                  <label for="<?= glpiacessivel_e($optionId) ?>" class="glpiacessivel-dynamic-renderer-option">
                    <input type="<?= glpiacessivel_e($fieldType) ?>" id="<?= glpiacessivel_e($optionId) ?>" name="<?= glpiacessivel_e($inputName . ($fieldType === 'checkbox' && $multiple ? '[]' : '')) ?>" value="<?= glpiacessivel_e($optionValue) ?>"<?= $disabled ? ' disabled' : '' ?>>
                    <span><?= glpiacessivel_e($optionLabel) ?></span>
                  </label>
                <?php endforeach; ?>
              </div>
            </fieldset>
            <?php else : ?>
            <label for="<?= glpiacessivel_e($fieldId) ?>"><?= glpiacessivel_e($label) ?><?= $required ? ' *' : '' ?></label>
                <?php if ($description !== '') : ?>
              <p id="<?= glpiacessivel_e($helpId) ?>" class="glpiacessivel-help-text"><?= glpiacessivel_e($description) ?></p>
                <?php endif; ?>

                <?php if ($fieldType === 'native_reference') : ?>
              <div id="<?= glpiacessivel_e($fieldId) ?>" class="glpiacessivel-native-reference" role="note"<?= $describedBy !== '' ? ' aria-describedby="' . glpiacessivel_e($describedBy) . '"' : '' ?>>
                <strong><?= glpiacessivel_e(glpiacessivel_t('Campo preenchido pelo sistema')) ?></strong>
                <p><?= glpiacessivel_e(glpiacessivel_t('Este valor é definido automaticamente e não pode ser alterado aqui. Abra o formulário em página completa para revisá-lo.')) ?></p>
              </div>
                <?php elseif ($fieldType === 'hidden') : ?>
              <div id="<?= glpiacessivel_e($fieldId) ?>" class="glpiacessivel-native-reference" role="note"<?= $describedBy !== '' ? ' aria-describedby="' . glpiacessivel_e($describedBy) . '"' : '' ?>>
                <strong><?= glpiacessivel_e(glpiacessivel_t('Campo preenchido pelo sistema')) ?></strong>
                <p><?= glpiacessivel_e(glpiacessivel_t('Este valor é definido automaticamente e não pode ser alterado aqui.')) ?></p>
              </div>
                <?php elseif ($fieldType === 'textarea') : ?>
              <textarea id="<?= glpiacessivel_e($fieldId) ?>" name="<?= glpiacessivel_e($inputName) ?>" rows="5"<?= $commonAttributes ?>><?= glpiacessivel_e($value) ?></textarea>
                <?php elseif ($fieldType === 'select' || $fieldType === 'multiselect') : ?>
              <select id="<?= glpiacessivel_e($fieldId) ?>" name="<?= glpiacessivel_e($inputName . ($multiple ? '[]' : '')) ?>"<?= $multiple ? ' multiple' : '' ?><?= $commonAttributes ?>>
                    <?php if (!$required && !$multiple) : ?>
                  <option value=""><?= glpiacessivel_e(glpiacessivel_t('Selecione')) ?></option>
                    <?php endif; ?>
                    <?php foreach ($options as $optionIndex => $option) : ?>
                        <?php
                        $optionValue = (string) (is_array($option) ? ($option['id'] ?? $option['value'] ?? $optionIndex) : $optionIndex);
                        $optionLabel = (string) (is_array($option) ? ($option['label'] ?? $option['name'] ?? $optionValue) : $option);
                        ?>
                  <option value="<?= glpiacessivel_e($optionValue) ?>"<?= $optionValue === $value ? ' selected' : '' ?>><?= glpiacessivel_e($optionLabel) ?></option>
                    <?php endforeach; ?>
              </select>
                <?php elseif ($fieldType === 'file') : ?>
              <input type="file" id="<?= glpiacessivel_e($fieldId) ?>" name="<?= glpiacessivel_e($inputName) ?>"<?= $multiple ? ' multiple' : '' ?> disabled aria-describedby="<?= glpiacessivel_e(trim($describedBy . ' ' . $fieldId . '-file-note')) ?>">
              <p id="<?= glpiacessivel_e($fieldId) ?>-file-note" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Para enviar anexos, abra o formulário em página completa.')) ?></p>
                <?php else : ?>
                    <?php
                    $htmlType = in_array($fieldType, ['email', 'number', 'date'], true) ? $fieldType : ($fieldType === 'datetime' ? 'datetime-local' : 'text');
                    ?>
              <input type="<?= glpiacessivel_e($htmlType) ?>" id="<?= glpiacessivel_e($fieldId) ?>" name="<?= glpiacessivel_e($inputName) ?>" value="<?= glpiacessivel_e($value) ?>"<?= $commonAttributes ?>>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </fieldset>
    <?php endforeach; ?>

  <div class="glpiacessivel-form-actions">
    <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/forms.php')) ?>">
      <?= glpiacessivel_e(glpiacessivel_t('Voltar para formulários')) ?>
    </a>
    <?php if ($canSubmitViaNativeContract) : ?>
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary" data-glpiacessivel-native-submit-button>
        <?= glpiacessivel_e(glpiacessivel_t('Enviar solicitação')) ?>
      </button>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeUrl) ?>" aria-describedby="<?= glpiacessivel_e($nativeDescribedBy) ?>">
        <?= glpiacessivel_e(glpiacessivel_t('Abrir este formulário em página completa')) ?>
      </a>
    <?php elseif ($canEmbedNativeFlow) : ?>
      <a class="glpiacessivel-button glpiacessivel-button-primary" href="#form-render-native-frame" aria-describedby="<?= glpiacessivel_e($nativeDescribedBy) ?>">
        <?= glpiacessivel_e(glpiacessivel_t('Começar preenchimento')) ?>
      </a>
    <?php else : ?>
      <a class="glpiacessivel-button glpiacessivel-button-primary" href="<?= glpiacessivel_e($nativeUrl) ?>" aria-describedby="<?= glpiacessivel_e($nativeDescribedBy) ?>">
        <?= glpiacessivel_e(glpiacessivel_t('Abrir formulário')) ?>
      </a>
    <?php endif; ?>
  </div>
  <script type="application/json" id="form-render-conditions-json"><?= json_encode($conditions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?: '[]' ?></script>
</form>
<?php elseif (!$canEmbedNativeFlow) :
    ?>
  <section class="glpiacessivel-card" aria-labelledby="form-render-new-page-title">
    <h3 id="form-render-new-page-title"><?= glpiacessivel_e(glpiacessivel_t('Continue em uma nova página')) ?></h3>
    <p><?= glpiacessivel_e(glpiacessivel_t('Este formulário será aberto em uma página completa.')) ?></p>
    <a class="glpiacessivel-button glpiacessivel-button-primary" href="<?= glpiacessivel_e($nativeUrl) ?>" aria-describedby="<?= glpiacessivel_e($nativeDescribedBy) ?>">
      <?= glpiacessivel_e(glpiacessivel_t('Abrir formulário')) ?>
    </a>
  </section>
    <?php
endif; ?>

<?php if ($showOperationalDiagnostics) :
    ?>
  <details class="glpiacessivel-card glpiacessivel-form-compatibility">
    <summary id="form-render-diagnostics-title"><?= glpiacessivel_e(glpiacessivel_t('Diagnóstico técnico do formulário')) ?></summary>
    <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Decisão de abertura')) ?>: <?= glpiacessivel_e($rendererDecision) ?></p>
    <dl class="glpiacessivel-form-compatibility-matrix">
      <?php foreach ($matrix as $item) : ?>
            <?php if (!is_array($item)) {
                continue;
            } ?>
        <div>
          <dt><?= glpiacessivel_e((string) ($item['area'] ?? '')) ?> <span><?= glpiacessivel_e((string) ($item['status'] ?? '')) ?></span></dt>
          <dd><?= glpiacessivel_e((string) ($item['message'] ?? '')) ?></dd>
        </div>
      <?php endforeach; ?>
    </dl>
    <?php if ($submissionReadiness !== []) : ?>
      <details class="glpiacessivel-form-compatibility">
        <summary><?= glpiacessivel_e(glpiacessivel_t('Verificação de envio pelo portal')) ?></summary>
        <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Decisão')) ?>: <?= glpiacessivel_e((string) ($submissionReadiness['decision'] ?? 'native_fallback_required')) ?></p>
        <?php $blockers = is_array($submissionReadiness['blockers'] ?? null) ? $submissionReadiness['blockers'] : []; ?>
        <?php if ($blockers !== []) : ?>
          <ul>
            <?php foreach ($blockers as $area => $message) : ?>
              <li><strong><?= glpiacessivel_e((string) $area) ?></strong>: <?= glpiacessivel_e((string) $message) ?></li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </details>
    <?php endif; ?>

    <?php if ($unsupported !== []) :
        ?>
      <details class="glpiacessivel-form-compatibility">
        <summary><?= glpiacessivel_e(glpiacessivel_t('Itens ainda não suportados')) ?></summary>
        <ul>
          <?php foreach ($unsupported as $question) :
                ?>
            <li><?= glpiacessivel_e((string) $question) ?></li>
                <?php
          endforeach; ?>
        </ul>
      </details>
        <?php
    endif; ?>
  </details>
    <?php
endif; ?>
