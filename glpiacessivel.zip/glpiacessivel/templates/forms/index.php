<?php
$catalogView = is_array($catalogView ?? null) ? $catalogView : [];
$items = is_array($catalogView['items'] ?? null) ? $catalogView['items'] : [];
$catalogState = (string) ($catalogView['state'] ?? 'unavailable');
$catalogQuery = (string) ($catalogView['query'] ?? '');
$catalogPageNumber = max(1, (int) ($catalogView['page'] ?? 1));
$catalogHasMore = !empty($catalogView['has_more']);
$catalogNextCursor = (string) ($catalogView['next_cursor'] ?? '');
$catalogPreviousCursor = (string) ($catalogView['previous_cursor'] ?? '');
$catalogItemCount = max(0, (int) ($catalogView['item_count'] ?? count($items)));
$catalogFullListUrl = (string) ($catalogView['full_list_url'] ?? '');
$adminDiagnostics = is_array($catalogView['admin_diagnostics'] ?? null)
  ? $catalogView['admin_diagnostics']
  : [];
$formsNativeFlowMode = (string) ($formsNativeFlowMode ?? 'native_embedded');
$showOperationalDiagnostics = !empty($showOperationalDiagnostics) && $adminDiagnostics !== [];
$focusFormResults = !empty($focusFormResults);
$formListBaseUrl = glpiacessivel_url('front/forms.php');
$formListQueryUrl = static function (string $query, string $cursor = '') use ($formListBaseUrl): string {
  $params = [];
  if ($query !== '') {
    $params['q'] = $query;
  }
  if ($cursor !== '') {
    $params['form_cursor'] = $cursor;
  }
  return $params === []
    ? $formListBaseUrl
    : $formListBaseUrl . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
};
$catalogMessage = match ($catalogState) {
  'empty' => glpiacessivel_t('Nenhum formulário está disponível para o perfil e a entidade atuais.'),
  'degraded' => glpiacessivel_t('Alguns formulários podem não aparecer. Tente novamente.'),
  'unavailable' => glpiacessivel_t('Não foi possível carregar os formulários agora.'),
  default => '',
};
?>

<section class="glpiacessivel-section-head" aria-labelledby="forms-title">
  <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Serviços disponíveis')) ?></p>
  <h2 id="forms-title"><?= glpiacessivel_e(glpiacessivel_t('Formulários')) ?></h2>
  <p><?= glpiacessivel_e(glpiacessivel_t('Escolha o serviço que deseja solicitar.')) ?></p>
</section>

<section class="glpiacessivel-card" aria-labelledby="forms-list-title">
  <div class="glpiacessivel-open-ticket-header">
    <div>
      <h3 id="forms-list-title" tabindex="-1"><?= glpiacessivel_e(glpiacessivel_t('Formulários disponíveis')) ?></h3>
    </div>
  </div>

  <form method="get" action="<?= glpiacessivel_e($formListBaseUrl) ?>" class="glpiacessivel-form" role="search">
    <div class="glpiacessivel-field">
      <label for="form-catalog-query"><?= glpiacessivel_e(glpiacessivel_t('Buscar formulário')) ?></label>
      <input
        id="form-catalog-query"
        name="q"
        type="search"
        value="<?= glpiacessivel_e($catalogQuery) ?>"
        maxlength="120"
        autocomplete="off"
        aria-describedby="form-catalog-query-help"
      >
      <p id="form-catalog-query-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Pesquise pelo nome ou pela descrição.')) ?></p>
    </div>
    <div class="glpiacessivel-form-actions">
      <button class="glpiacessivel-button glpiacessivel-button-primary" type="submit"><?= glpiacessivel_e(glpiacessivel_t('Buscar')) ?></button>
      <?php if ($catalogQuery !== ''): ?>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($formListBaseUrl) ?>"><?= glpiacessivel_e(glpiacessivel_t('Limpar busca')) ?></a>
      <?php endif; ?>
    </div>
  </form>

  <?php if ($catalogMessage !== ''): ?>
    <div class="glpiacessivel-alert <?= in_array($catalogState, ['degraded', 'unavailable'], true) ? 'glpiacessivel-alert-warning' : 'glpiacessivel-alert-info' ?>" <?= $catalogState === 'unavailable' ? 'role="alert"' : 'role="status"' ?>>
      <p><?= glpiacessivel_e($catalogMessage) ?></p>
      <?php if (in_array($catalogState, ['degraded', 'unavailable'], true)): ?>
        <div class="glpiacessivel-form-actions">
          <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($formListQueryUrl($catalogQuery)) ?>"><?= glpiacessivel_e(glpiacessivel_t('Tentar novamente')) ?></a>
          <?php if ($catalogFullListUrl !== ''): ?>
            <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($catalogFullListUrl) ?>"><?= glpiacessivel_e(glpiacessivel_t('Abrir lista completa')) ?></a>
          <?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <?php if (in_array($catalogState, ['ready', 'degraded'], true)): ?>
    <p class="glpiacessivel-help-text" role="status" aria-live="polite">
      <?= glpiacessivel_e(sprintf(
        $catalogItemCount === 1
          ? glpiacessivel_t('%d formulário encontrado. Página %d.')
          : glpiacessivel_t('%d formulários encontrados. Página %d.'),
        $catalogItemCount,
        $catalogPageNumber
      )) ?>
    </p>
  <?php endif; ?>

  <?php if ($items === []): ?>
    <?php if (!in_array($catalogState, ['unavailable', 'degraded'], true)): ?>
      <p class="glpiacessivel-empty-state"><?= glpiacessivel_e(
        $catalogQuery !== ''
          ? glpiacessivel_t('Nenhum formulário corresponde à sua busca.')
          : glpiacessivel_t('Nenhum formulário está disponível para você neste contexto.')
      ) ?></p>
    <?php endif; ?>
  <?php else: ?>
    <div class="glpiacessivel-form-catalog-grid" role="list" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Formulários disponíveis')) ?>">
      <?php foreach ($items as $item): ?>
        <?php
          if (!is_array($item)) {
              continue;
          }
          $itemId = max(0, (int) ($item['id'] ?? 0));
          $source = (string) ($item['source'] ?? '');
          $title = (string) ($item['name'] ?? glpiacessivel_t('Formulário'));
          $description = trim((string) ($item['description'] ?? ''));
          $illustration = trim((string) ($item['illustration'] ?? ''));
          $visualKind = preg_replace('/[^a-z0-9_-]/i', '', (string) ($item['visual_kind'] ?? 'form')) ?: 'form';
          $canRenderImage = $illustration !== '' && (bool) preg_match('#^(?:https?:)?/|^data:image/#', $illustration);
          $titleId = 'form-title-' . preg_replace('/[^a-z0-9_-]/i', '-', $source . '-' . (string) $itemId);
          $descriptionId = $description !== '' ? $titleId . '-description' : '';
          // Preserve the accessible portal shell for every configured flow.
          // Link-only mode is presented inside the wrapper as a safe native action.
          $openUrl = glpiacessivel_url(
              'front/form.render.php?source=' . rawurlencode($source) . '&id=' . $itemId
          );
          $diagnostics = is_array($item['diagnostics'] ?? null) ? $item['diagnostics'] : [];
        ?>
        <article class="glpiacessivel-form-catalog-card glpiacessivel-form-catalog-card-<?= glpiacessivel_e($visualKind) ?>" role="listitem" aria-labelledby="<?= glpiacessivel_e($titleId) ?>">
          <div class="glpiacessivel-form-catalog-visual" aria-hidden="true">
            <?php if ($canRenderImage): ?>
              <img src="<?= glpiacessivel_e($illustration) ?>" alt="" loading="lazy">
            <?php else: ?>
              <span class="glpiacessivel-form-catalog-fallback" aria-hidden="true"></span>
            <?php endif; ?>
          </div>
          <div class="glpiacessivel-form-catalog-body">
            <h3 id="<?= glpiacessivel_e($titleId) ?>"><?= glpiacessivel_e($title) ?></h3>
            <?php if ($description !== ''): ?>
              <p id="<?= glpiacessivel_e($descriptionId) ?>" class="glpiacessivel-form-catalog-description"><?= glpiacessivel_e($description) ?></p>
            <?php endif; ?>
          </div>
          <div class="glpiacessivel-form-catalog-actions">
            <a class="glpiacessivel-button glpiacessivel-button-primary" href="<?= glpiacessivel_e($openUrl) ?>" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Abrir formulário') . ': ' . $title) ?>"<?= $descriptionId !== '' ? ' aria-describedby="' . glpiacessivel_e($descriptionId) . '"' : '' ?>>
              <?= glpiacessivel_e(glpiacessivel_t('Abrir formulário')) ?>
            </a>
          </div>
          <?php if ($showOperationalDiagnostics && $diagnostics !== []): ?>
            <details class="glpiacessivel-form-compatibility">
              <summary><?= glpiacessivel_e(glpiacessivel_t('Diagnóstico deste formulário')) ?></summary>
              <dl>
                <dt><?= glpiacessivel_e(glpiacessivel_t('Fonte')) ?></dt>
                <dd><?= glpiacessivel_e((string) ($diagnostics['source_label'] ?? '')) ?></dd>
                <dt><?= glpiacessivel_e(glpiacessivel_t('Estado de compatibilidade')) ?></dt>
                <dd><?= glpiacessivel_e((string) ($diagnostics['compatibility_status'] ?? '')) ?></dd>
              </dl>
              <?php if (trim((string) ($diagnostics['compatibility_summary'] ?? '')) !== ''): ?>
                <p><?= glpiacessivel_e((string) $diagnostics['compatibility_summary']) ?></p>
              <?php endif; ?>
            </details>
          <?php endif; ?>
        </article>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <?php if ($catalogPreviousCursor !== '' || $catalogHasMore): ?>
    <nav class="glpiacessivel-pagination" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Paginação dos formulários')) ?>">
      <?php if ($catalogPreviousCursor !== ''): ?>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" rel="prev" href="<?= glpiacessivel_e($formListQueryUrl($catalogQuery, $catalogPreviousCursor)) ?>"><?= glpiacessivel_e(glpiacessivel_t('Página anterior')) ?></a>
      <?php endif; ?>
      <span aria-current="page"><?= glpiacessivel_e(sprintf(glpiacessivel_t('Página %d'), $catalogPageNumber)) ?></span>
      <?php if ($catalogHasMore && $catalogNextCursor !== ''): ?>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" rel="next" href="<?= glpiacessivel_e($formListQueryUrl($catalogQuery, $catalogNextCursor)) ?>"><?= glpiacessivel_e(glpiacessivel_t('Próxima página')) ?></a>
      <?php endif; ?>
    </nav>
  <?php endif; ?>
</section>

<?php if ($showOperationalDiagnostics): ?>
  <details class="glpiacessivel-card glpiacessivel-form-compatibility">
    <summary><?= glpiacessivel_e(glpiacessivel_t('Diagnóstico técnico dos formulários')) ?></summary>
    <?php if (trim((string) ($adminDiagnostics['fallback_policy'] ?? '')) !== ''): ?>
      <p><?= glpiacessivel_e((string) $adminDiagnostics['fallback_policy']) ?></p>
    <?php endif; ?>
    <p><strong><?= glpiacessivel_e(glpiacessivel_t('Estado interno')) ?>:</strong> <?= glpiacessivel_e((string) ($adminDiagnostics['raw_state'] ?? '')) ?></p>
    <ul>
      <?php foreach ((array) ($adminDiagnostics['sources'] ?? []) as $source): ?>
        <?php if (is_array($source)): ?>
          <li>
            <strong><?= glpiacessivel_e((string) ($source['label'] ?? $source['key'] ?? '')) ?></strong>:
            <?= glpiacessivel_e((string) ($source['message'] ?? '')) ?>
            <?php if ((string) ($source['diagnostic_code'] ?? '') !== ''): ?>
              <code><?= glpiacessivel_e((string) $source['diagnostic_code']) ?></code>
            <?php endif; ?>
          </li>
        <?php endif; ?>
      <?php endforeach; ?>
    </ul>
  </details>
<?php endif; ?>

<?php if ($focusFormResults): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
  var resultsTitle = document.getElementById('forms-list-title');
  if (resultsTitle) {
    resultsTitle.focus();
  }
});
</script>
<?php endif; ?>
