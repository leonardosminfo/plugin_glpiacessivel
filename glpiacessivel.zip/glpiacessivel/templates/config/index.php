<section class="glpiacessivel-card" aria-labelledby="config-title">
  <h2 id="config-title">Parametros</h2>

  <?php if (!empty($saved)): ?>
    <p role="status" aria-live="polite">Configuracao salva com sucesso.</p>
  <?php endif; ?>

  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/config.php')) ?>" class="glpiacessivel-form-grid">
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
    <?php
      $moduleStates = is_array($portal_module_states ?? null) ? $portal_module_states : [];
      $moduleEffectiveStates = is_array($portal_module_effective_states ?? null) ? $portal_module_effective_states : $moduleStates;
      $modulePresetsJson = json_encode(
          $portal_module_presets ?? [],
          JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
      ) ?: '{}';
    ?>
    <section class="glpiacessivel-module-settings" aria-labelledby="portal-modules-title">
      <h3 id="portal-modules-title"><?= glpiacessivel_e(glpiacessivel_t('Funcionalidades disponiveis no portal')) ?></h3>
      <p id="portal-modules-help" class="glpiacessivel-help-text">
        <?= glpiacessivel_e(glpiacessivel_t('A disponibilidade nunca amplia permissoes: perfil, entidade e ACL nativa do GLPI continuam sendo validados.')) ?>
      </p>

      <div class="glpiacessivel-module-preset">
        <div class="glpiacessivel-field">
          <label for="portal_module_preset"><?= glpiacessivel_e(glpiacessivel_t('Configuracao predefinida')) ?></label>
          <select
            id="portal_module_preset"
            data-glpiacessivel-module-preset
            data-presets="<?= glpiacessivel_e($modulePresetsJson) ?>"
            aria-describedby="portal-module-preset-help"
          >
            <?php foreach (($portal_module_presets ?? []) as $presetKey => $presetStates): ?>
              <option value="<?= glpiacessivel_e((string) $presetKey) ?>">
                <?= glpiacessivel_e((string) (($portal_module_preset_labels[$presetKey] ?? $presetKey))) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <p id="portal-module-preset-help" class="glpiacessivel-help-text">
            <?= glpiacessivel_e(glpiacessivel_t('O preset apenas prepara os controles. Revise as opcoes e use Salvar para confirmar.')) ?>
          </p>
        </div>
        <button
          type="button"
          class="glpiacessivel-button glpiacessivel-button-secondary"
          data-glpiacessivel-module-preset-apply
          data-announcement="<?= glpiacessivel_e(glpiacessivel_t('Preset preparado. Revise as funcionalidades e salve a configuracao.')) ?>"
        >
          <?= glpiacessivel_e(glpiacessivel_t('Aplicar preset ao formulario')) ?>
        </button>
      </div>

      <p
        id="portal-module-preset-status"
        class="glpiacessivel-help-text"
        role="status"
        aria-live="polite"
        data-glpiacessivel-module-status
      ></p>
      <p
        id="portal-module-dependency-status"
        class="glpiacessivel-alert glpiacessivel-alert-warning"
        role="status"
        aria-live="polite"
        data-glpiacessivel-module-dependency
        data-disabled-message="<?= glpiacessivel_e(glpiacessivel_t('Cockpit tambem ficara indisponivel porque depende do modulo Chamados.')) ?>"
        data-hidden-message="<?= glpiacessivel_e(glpiacessivel_t('Cockpit tambem ficara oculto porque depende do modulo Chamados.')) ?>"
        hidden
      ></p>

      <div class="glpiacessivel-module-grid" aria-describedby="portal-modules-help">
        <?php foreach (($portal_modules ?? []) as $module): ?>
          <?php
            $moduleKey = (string) $module;
            $moduleState = (string) ($moduleStates[$moduleKey] ?? 'available');
            $effectiveState = (string) ($moduleEffectiveStates[$moduleKey] ?? $moduleState);
            $moduleId = 'portal-module-' . preg_replace('/[^a-z0-9_-]/i', '-', $moduleKey);
          ?>
          <fieldset
            class="glpiacessivel-module-card"
            data-glpiacessivel-module="<?= glpiacessivel_e($moduleKey) ?>"
            aria-describedby="<?= glpiacessivel_e($moduleId) ?>-description"
          >
            <legend><?= glpiacessivel_e((string) ($portal_module_labels[$moduleKey] ?? $moduleKey)) ?></legend>
            <p id="<?= glpiacessivel_e($moduleId) ?>-description" class="glpiacessivel-help-text">
              <?= glpiacessivel_e((string) ($portal_module_descriptions[$moduleKey] ?? '')) ?>
            </p>
            <div class="glpiacessivel-module-state-options">
              <?php foreach (($portal_module_state_labels ?? []) as $stateKey => $stateLabel): ?>
                <?php $stateId = $moduleId . '-' . preg_replace('/[^a-z0-9_-]/i', '-', (string) $stateKey); ?>
                <label for="<?= glpiacessivel_e($stateId) ?>" class="glpiacessivel-module-state-option">
                  <input
                    id="<?= glpiacessivel_e($stateId) ?>"
                    type="radio"
                    name="module_states[<?= glpiacessivel_e($moduleKey) ?>]"
                    value="<?= glpiacessivel_e((string) $stateKey) ?>"
                    <?= $moduleState === $stateKey ? 'checked' : '' ?>
                  />
                  <span>
                    <strong><?= glpiacessivel_e((string) $stateLabel) ?></strong>
                    <small><?= glpiacessivel_e((string) ($portal_module_state_descriptions[$stateKey] ?? '')) ?></small>
                  </span>
                </label>
              <?php endforeach; ?>
            </div>
            <?php if ($effectiveState !== $moduleState): ?>
              <p class="glpiacessivel-help-text">
                <?= glpiacessivel_e(glpiacessivel_t('Estado efetivo ajustado por dependencia:')) ?>
                <strong><?= glpiacessivel_e((string) ($portal_module_state_labels[$effectiveState] ?? $effectiveState)) ?></strong>
              </p>
            <?php endif; ?>
          </fieldset>
        <?php endforeach; ?>
      </div>
    </section>

    <label for="accessibility_mode">Modo de acessibilidade</label>
    <select id="accessibility_mode" name="accessibility_mode">
      <option value="portal" <?= ($accessibility_mode ?? 'hybrid') === 'portal' ? 'selected' : '' ?>>
        Portal acessivel
      </option>
      <option value="embedded" <?= ($accessibility_mode ?? 'hybrid') === 'embedded' ? 'selected' : '' ?>>
        Embutido no GLPI
      </option>
      <option value="hybrid" <?= ($accessibility_mode ?? 'hybrid') === 'hybrid' ? 'selected' : '' ?>>
        Hibrido
      </option>
    </select>

    <div class="glpiacessivel-field" style="grid-column: 1 / -1;">
      <p class="glpiacessivel-help-text">
        Escolha como a experiencia acessivel deve conviver com o GLPI padrao.
      </p>
      <div class="glpiacessivel-config-path-list" aria-label="Resumo dos modos de acessibilidade">
        <p><strong>Portal acessivel:</strong> usa telas proprias do plugin como jornada principal, com maior independencia da interface nativa do GLPI e maior controle de WCAG/eMAG.</p>
        <p><strong>Embutido no GLPI:</strong> usa o plugin como apoio dentro do GLPI, inclusive com ponte de login acessivel, mas depende mais da interface nativa e por isso oferece menor controle de acessibilidade ponta a ponta.</p>
        <p><strong>Hibrido:</strong> combina portal + embutido. E o modo recomendado para producao porque controla a jornada acessivel sem perder continuidade operacional no GLPI.</p>
      </div>
    </div>

    <label for="authentication_entry_mode"><?= glpiacessivel_e(glpiacessivel_t('Entrada antes da autenticacao')) ?></label>
    <select
      id="authentication_entry_mode"
      name="authentication_entry_mode"
      aria-describedby="authentication-entry-mode-help"
    >
      <?php
        $authenticationEntryLabels = [
          'native_only' => glpiacessivel_t('Usar somente o login unificado do GLPI (recomendado)'),
          'accessible_bridge' => glpiacessivel_t('Permitir formulario acessivel alternativo (compatibilidade)'),
        ];
      ?>
      <?php foreach (($authentication_entry_supported_modes ?? ['native_only', 'accessible_bridge']) as $entryMode): ?>
        <option
          value="<?= glpiacessivel_e((string) $entryMode) ?>"
          <?= (($authentication_entry_mode ?? 'native_only') === $entryMode) ? 'selected' : '' ?>
        >
          <?= glpiacessivel_e((string) ($authenticationEntryLabels[$entryMode] ?? $entryMode)) ?>
        </option>
      <?php endforeach; ?>
    </select>
    <div id="authentication-entry-mode-help" class="glpiacessivel-help-text" style="grid-column: 1 / -1;">
      <p><?= glpiacessivel_e(glpiacessivel_t('Somente login unificado: o plugin nao exibe campos de senha e envia acessos anonimos ao login oficial do GLPI, preservando SSO e MFA.')) ?></p>
      <p><?= glpiacessivel_e(glpiacessivel_t('Formulario alternativo: mantem a ponte acessivel anterior somente para compatibilidade e rollback.')) ?></p>
    </div>

    <label for="show_login_accessibility_notice"><?= glpiacessivel_e(glpiacessivel_t('Aviso de acessibilidade na tela de login')) ?></label>
    <select
      id="show_login_accessibility_notice"
      name="show_login_accessibility_notice"
      aria-describedby="login-accessibility-notice-help"
    >
      <option value="0" <?= ($show_login_accessibility_notice ?? '0') === '0' ? 'selected' : '' ?>>
        <?= glpiacessivel_e(glpiacessivel_t('Nao exibir (padrao seguro)')) ?>
      </option>
      <option value="1" <?= ($show_login_accessibility_notice ?? '0') === '1' ? 'selected' : '' ?>>
        <?= glpiacessivel_e(glpiacessivel_t('Exibir aviso informativo')) ?>
      </option>
    </select>
    <div id="login-accessibility-notice-help" class="glpiacessivel-help-text" style="grid-column: 1 / -1;">
      <p><?= glpiacessivel_e(glpiacessivel_t('No modo de login unificado, mostra uma nota estatica na area nativa de login: Portal Acessivel disponivel apos o login.')) ?></p>
      <p><?= glpiacessivel_e(glpiacessivel_t('O aviso nao e link, nao recebe credenciais e nao cria rota alternativa. No modo de compatibilidade, a ponte acessivel substitui o aviso para evitar duplicidade.')) ?></p>
    </div>

    <label for="plugin_fallback_locale">Idioma fallback do plugin</label>
    <select id="plugin_fallback_locale" name="plugin_fallback_locale" aria-describedby="plugin-fallback-locale-help">
      <?php foreach (($supported_locales ?? ['pt_BR']) as $locale): ?>
        <option value="<?= glpiacessivel_e((string) $locale) ?>" <?= (($plugin_fallback_locale ?? 'pt_BR') === $locale) ? 'selected' : '' ?>>
          <?= glpiacessivel_e((string) $locale) ?>
        </option>
      <?php endforeach; ?>
    </select>
    <p id="plugin-fallback-locale-help" class="glpiacessivel-help-text">O idioma principal continua herdado do GLPI. Este fallback vale apenas para traducoes ausentes do plugin.</p>

    <label for="vlibras_scope">VLibras</label>
    <select id="vlibras_scope" name="vlibras_scope" aria-describedby="vlibras-scope-help">
      <?php
        $vlibrasLabels = [
          'disabled' => 'Desativado',
          'public_only' => 'Somente paginas publicas',
          'plugin_pages' => 'Paginas do plugin',
          'all_pages' => 'Todas as paginas com runtime do plugin',
        ];
      ?>
      <?php foreach (($vlibras_scopes ?? ['plugin_pages']) as $scope): ?>
        <option value="<?= glpiacessivel_e((string) $scope) ?>" <?= (($vlibras_scope ?? 'plugin_pages') === $scope) ? 'selected' : '' ?>>
          <?= glpiacessivel_e((string) ($vlibrasLabels[$scope] ?? $scope)) ?>
        </option>
      <?php endforeach; ?>
    </select>
    <p id="vlibras-scope-help" class="glpiacessivel-help-text">VLibras e integracao externa opcional. Pode exigir CSP para vlibras.gov.br e nao substitui WCAG/eMAG, teclado, foco, contraste e semantica.</p>

    <label for="pii_masking_enabled"><?= glpiacessivel_e(glpiacessivel_t('Mascarar contatos pessoais')) ?></label>
    <select id="pii_masking_enabled" name="pii_masking_enabled" aria-describedby="pii-masking-help">
      <option value="0" <?= ($pii_masking_enabled ?? '0') === '0' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Desativado')) ?></option>
      <option value="1" <?= ($pii_masking_enabled ?? '0') === '1' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Habilitado')) ?></option>
    </select>
    <p id="pii-masking-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Quando ativado, e-mail e telefones do requisitante ficam mascarados e a revelacao temporaria exige permissao, justificativa e auditoria. O padrao e desativado.')) ?></p>
    <label for="forms_native_flow_mode"><?= glpiacessivel_e(glpiacessivel_t('Modo de abertura dos formularios')) ?></label>
    <select id="forms_native_flow_mode" name="forms_native_flow_mode" aria-describedby="forms-native-flow-help">
      <?php
        $formsNativeFlowLabels = [
          'native_embedded' => glpiacessivel_t('Incorporar formulario nativo no portal'),
          'native_link' => glpiacessivel_t('Abrir no GLPI/Formcreator nativo'),
          'plugin_converted_with_native_callback' => glpiacessivel_t('Usar formulario acessivel convertido quando seguro'),
        ];
      ?>
      <?php foreach (($forms_native_flow_modes ?? ['native_embedded', 'native_link', 'plugin_converted_with_native_callback']) as $mode): ?>
        <option value="<?= glpiacessivel_e((string) $mode) ?>" <?= (($forms_native_flow_mode ?? 'native_embedded') === $mode) ? 'selected' : '' ?>>
          <?= glpiacessivel_e((string) ($formsNativeFlowLabels[$mode] ?? $mode)) ?>
        </option>
      <?php endforeach; ?>
    </select>
    <div id="forms-native-flow-help" class="glpiacessivel-help-text">
      <p><?= glpiacessivel_e(glpiacessivel_t('Incorporar formulario nativo: exibe o formulario oficial dentro do portal, quando permitido.')) ?></p>
      <p><?= glpiacessivel_e(glpiacessivel_t('Abrir no GLPI/Formcreator nativo: redireciona para a tela oficial completa.')) ?></p>
      <p><?= glpiacessivel_e(glpiacessivel_t('Usar formulario acessivel convertido quando seguro: usa o renderer do plugin apenas quando a compatibilidade estiver validada; caso contrario, retorna ao fluxo nativo incorporado.')) ?></p>
    </div>

    <label for="chatbot_display_name"><?= glpiacessivel_e(glpiacessivel_t('Nome exibido do chatbot')) ?></label>
    <div class="glpiacessivel-field">
      <input
        id="chatbot_display_name"
        type="text"
        name="chatbot_display_name"
        value="<?= glpiacessivel_e((string) ($chatbot_display_name ?? 'Assistente')) ?>"
        maxlength="60"
        required
        autocomplete="off"
        aria-describedby="chatbot-display-name-help"
      />
      <p id="chatbot-display-name-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Este nome aparece na interface, nas respostas, na voz e nos rotulos acessiveis. O valor padrao e Assistente.')) ?></p>
    </div>

    <label for="chatbot_floating_scope">Escopo do botao flutuante do chatbot</label>
    <select id="chatbot_floating_scope" name="chatbot_floating_scope">
      <option value="plugin_only" <?= ($chatbot_floating_scope ?? 'all_logged_pages') === 'plugin_only' ? 'selected' : '' ?>>Somente portal e paginas do plugin</option>
      <option value="all_logged_pages" <?= ($chatbot_floating_scope ?? 'all_logged_pages') === 'all_logged_pages' ? 'selected' : '' ?>>Todas as paginas com usuario autenticado</option>
      <option value="disabled" <?= ($chatbot_floating_scope ?? 'all_logged_pages') === 'disabled' ? 'selected' : '' ?>>Desativado</option>
    </select>

    <label for="chatbot_voice_enabled">Chatbot por voz (pt-BR)</label>
    <select id="chatbot_voice_enabled" name="chatbot_voice_enabled">
      <option value="1" <?= ($chatbot_voice_enabled ?? '1') === '1' ? 'selected' : '' ?>>Sim</option>
      <option value="0" <?= ($chatbot_voice_enabled ?? '1') === '0' ? 'selected' : '' ?>>Nao</option>
    </select>

    <div class="glpiacessivel-field" style="grid-column: 1 / -1;">
      <span id="chatbot-intents-label"><strong>Intencoes liberadas para o chatbot</strong></span>
      <p class="glpiacessivel-help-text">Desmarque as intencoes que nao devem ser executadas automaticamente no ambiente.</p>
      <?php
        $rightUpdate = defined('UPDATE') ? (int) constant('UPDATE') : 2;
        $canManagePlaybooks = ($moduleEffectiveStates['playbooks'] ?? 'available') === 'available'
            && class_exists('Session')
            && \Session::haveRight('config', $rightUpdate);
      ?>
      <?php if ($canManagePlaybooks): ?>
        <p class="glpiacessivel-help-text">
          Os roteiros do chatbot ficam no painel administrativo do portal.
          <a class="glpiacessivel-link" href="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>">
            Abrir roteiros do chatbot
          </a>
        </p>
      <?php endif; ?>
      <fieldset aria-labelledby="chatbot-intents-label" class="glpiacessivel-grid-2" style="border:1px solid #c8d3e3;border-radius:8px;padding:0.75rem;">
        <?php foreach (($chatbot_intents ?? []) as $intent): ?>
          <?php
            $intentKey = (string) $intent;
            $intentId = 'intent_' . preg_replace('/[^a-z0-9_]/', '_', $intentKey);
            $isEnabled = in_array($intentKey, (array) ($chatbot_enabled_intents ?? []), true);
            $label = (string) (($chatbot_intent_labels[$intentKey] ?? $intentKey));
            $isMandatory = $intentKey === 'handoff_humano';
          ?>
          <label for="<?= glpiacessivel_e($intentId) ?>" style="font-weight:600;">
            <input
              id="<?= glpiacessivel_e($intentId) ?>"
              type="checkbox"
              name="chatbot_enabled_intents[]"
              value="<?= glpiacessivel_e($intentKey) ?>"
              <?= $isEnabled ? 'checked' : '' ?>
              <?= $isMandatory ? 'disabled' : '' ?>
            />
            <?= glpiacessivel_e($label) ?>
            <?php if ($isMandatory): ?><small>(sempre ativo)</small><?php endif; ?>
          </label>
          <?php if ($isMandatory): ?>
            <input type="hidden" name="chatbot_enabled_intents[]" value="<?= glpiacessivel_e($intentKey) ?>" />
          <?php endif; ?>
        <?php endforeach; ?>
      </fieldset>
    </div>

    <div class="glpiacessivel-field" style="grid-column: 1 / -1;">
      <span id="chatbot-voice-label"><strong>Motores de voz no navegador</strong></span>
      <p class="glpiacessivel-help-text">Padrao atual do plugin: reconhecimento de voz pelo Vosklet ou navegador e fala pelo sintetizador nativo do navegador. Piper WASM fica disponivel apenas como motor experimental.</p>
      <fieldset aria-labelledby="chatbot-voice-label" class="glpiacessivel-form-fieldset">
        <div class="glpiacessivel-config-block">
          <h3>Comportamento geral</h3>
          <p class="glpiacessivel-help-text">Use <strong>Priorizar arquivos locais do servidor</strong> em homologacao e producao. Os caminhos locais sao sempre relativos ao diretorio do plugin.</p>
          <div class="glpiacessivel-form-grid">
            <div class="glpiacessivel-field">
              <label for="chatbot_voice_locale">Localidade da voz</label>
              <input id="chatbot_voice_locale" type="text" name="chatbot_voice_locale" value="<?= glpiacessivel_e((string) ($chatbot_voice_locale ?? 'pt-BR')) ?>" placeholder="pt-BR" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_voice_asset_mode">Origem dos arquivos de voz</label>
              <select id="chatbot_voice_asset_mode" name="chatbot_voice_asset_mode">
                <option value="local_preferred" <?= (($chatbot_voice_asset_mode ?? 'local_preferred') === 'local_preferred') ? 'selected' : '' ?>>Priorizar arquivos locais do servidor</option>
                <option value="local_only" <?= (($chatbot_voice_asset_mode ?? 'local_preferred') === 'local_only') ? 'selected' : '' ?>>Somente arquivos locais</option>
                <option value="external_only" <?= (($chatbot_voice_asset_mode ?? 'local_preferred') === 'external_only') ? 'selected' : '' ?>>Somente URLs externas</option>
              </select>
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_stt_engine">Motor STT (ouvir usuario)</label>
              <select id="chatbot_stt_engine" name="chatbot_stt_engine">
                <?php foreach (($chatbot_stt_engines ?? []) as $engine): ?>
                  <option value="<?= glpiacessivel_e((string) $engine) ?>" <?= (($chatbot_stt_engine ?? 'vosklet') === $engine) ? 'selected' : '' ?>>
                    <?= glpiacessivel_e((string) $engine) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_engine">Motor TTS (falar resposta)</label>
              <select id="chatbot_tts_engine" name="chatbot_tts_engine">
                <?php
                  $ttsEngineLabels = [
                    'browser_native' => 'Nativo do navegador (recomendado)',
                    'piper_wasm' => 'Piper WASM (experimental)',
                    'none' => 'Desativado',
                  ];
                ?>
                <?php foreach (($chatbot_tts_engines ?? []) as $engine): ?>
                  <option value="<?= glpiacessivel_e((string) $engine) ?>" <?= (($chatbot_tts_engine ?? 'browser_native') === $engine) ? 'selected' : '' ?>>
                    <?= glpiacessivel_e((string) ($ttsEngineLabels[$engine] ?? $engine)) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>

        <div class="glpiacessivel-config-block">
          <h3>Arquivos locais recomendados</h3>
          <p class="glpiacessivel-help-text">Estes sao os caminhos atuais do pacote `0.40+`. Se o plugin estava configurado com `.mjs` antigo ou com prefixo `plugins/glpiacessivel/`, ele sera corrigido automaticamente.</p>
          <div class="glpiacessivel-config-path-list" aria-label="Caminhos locais recomendados">
            <p><strong>Script STT:</strong> <code>public/assets/vendor/vosklet/Vosklet.js</code></p>
            <p><strong>Modelo STT pt-BR:</strong> <code>public/assets/voice/vosk/pt-BR/vosk-model-small-pt-0.3.zip</code></p>
            <p><strong>Modulo TTS:</strong> <code>public/assets/vendor/piper/piper-tts-web.js</code></p>
            <p><strong>ONNX Runtime:</strong> <code>public/assets/vendor/onnxruntime-web/1.18.0/ort.esm.js</code></p>
            <p><strong>WASM ONNX:</strong> <code>public/assets/vendor/onnxruntime-web/1.18.0</code></p>
            <p><strong>WASM Piper:</strong> <code>public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.wasm</code></p>
            <p><strong>Dados Piper:</strong> <code>public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.data</code></p>
            <p><strong>Voz pt-BR:</strong> <code>public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx</code></p>
            <p><strong>Config da voz:</strong> <code>public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx.json</code></p>
          </div>
          <div class="glpiacessivel-form-grid">
            <div class="glpiacessivel-field">
              <label for="chatbot_stt_script_local_path">Caminho local do script STT</label>
              <input id="chatbot_stt_script_local_path" type="text" name="chatbot_stt_script_local_path" value="<?= glpiacessivel_e((string) ($chatbot_stt_script_local_path ?? '')) ?>" placeholder="public/assets/vendor/vosklet/Vosklet.js" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_stt_model_local_path">Caminho local do modelo STT pt-BR</label>
              <input id="chatbot_stt_model_local_path" type="text" name="chatbot_stt_model_local_path" value="<?= glpiacessivel_e((string) ($chatbot_stt_model_local_path ?? '')) ?>" placeholder="public/assets/voice/vosk/pt-BR/vosk-model-small-pt-0.3.zip" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_script_local_path">Caminho local do modulo TTS</label>
              <input id="chatbot_tts_script_local_path" type="text" name="chatbot_tts_script_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_script_local_path ?? '')) ?>" placeholder="public/assets/vendor/piper/piper-tts-web.js" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_onnx_runtime_local_path">Caminho local do ONNX Runtime</label>
              <input id="chatbot_tts_onnx_runtime_local_path" type="text" name="chatbot_tts_onnx_runtime_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_onnx_runtime_local_path ?? '')) ?>" placeholder="public/assets/vendor/onnxruntime-web/1.18.0/ort.esm.js" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_onnx_wasm_local_path">Diretorio local dos WASM ONNX</label>
              <input id="chatbot_tts_onnx_wasm_local_path" type="text" name="chatbot_tts_onnx_wasm_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_onnx_wasm_local_path ?? '')) ?>" placeholder="public/assets/vendor/onnxruntime-web/1.18.0" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_piper_wasm_local_path">Caminho local do WASM Piper</label>
              <input id="chatbot_tts_piper_wasm_local_path" type="text" name="chatbot_tts_piper_wasm_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_piper_wasm_local_path ?? '')) ?>" placeholder="public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.wasm" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_piper_data_local_path">Caminho local dos dados Piper</label>
              <input id="chatbot_tts_piper_data_local_path" type="text" name="chatbot_tts_piper_data_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_piper_data_local_path ?? '')) ?>" placeholder="public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.data" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_voice_model_local_path">Caminho local do modelo de voz pt-BR</label>
              <input id="chatbot_tts_voice_model_local_path" type="text" name="chatbot_tts_voice_model_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_voice_model_local_path ?? '')) ?>" placeholder="public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_voice_config_local_path">Caminho local da configuracao da voz pt-BR</label>
              <input id="chatbot_tts_voice_config_local_path" type="text" name="chatbot_tts_voice_config_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_voice_config_local_path ?? '')) ?>" placeholder="public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx.json" />
            </div>
          </div>
        </div>

        <div class="glpiacessivel-config-block">
          <h3>Fallback externo</h3>
          <p class="glpiacessivel-help-text">Preencha apenas se quiser manter fallback quando os arquivos locais nao estiverem publicados no servidor.</p>
          <div class="glpiacessivel-form-grid">
            <div class="glpiacessivel-field">
              <label for="chatbot_stt_script_url">URL script STT (Vosklet)</label>
              <input id="chatbot_stt_script_url" type="text" name="chatbot_stt_script_url" value="<?= glpiacessivel_e((string) ($chatbot_stt_script_url ?? '')) ?>" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_stt_model_url">URL modelo STT pt-BR (Vosklet)</label>
              <input id="chatbot_stt_model_url" type="text" name="chatbot_stt_model_url" value="<?= glpiacessivel_e((string) ($chatbot_stt_model_url ?? '')) ?>" placeholder="https://.../vosk-model-small-pt-0.3.zip" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_script_url">URL modulo TTS (Piper WASM)</label>
              <input id="chatbot_tts_script_url" type="text" name="chatbot_tts_script_url" value="<?= glpiacessivel_e((string) ($chatbot_tts_script_url ?? '')) ?>" />
            </div>
          </div>
        </div>

        <div class="glpiacessivel-config-block">
          <h3>Identificacao do modelo e voz</h3>
          <div class="glpiacessivel-form-grid">
            <div class="glpiacessivel-field">
              <label for="chatbot_stt_model_label">Descricao do modelo STT</label>
              <input id="chatbot_stt_model_label" type="text" name="chatbot_stt_model_label" value="<?= glpiacessivel_e((string) ($chatbot_stt_model_label ?? 'Portugues (Brasil)')) ?>" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_stt_model_cache_id">Cache ID do modelo STT</label>
              <input id="chatbot_stt_model_cache_id" type="text" name="chatbot_stt_model_cache_id" value="<?= glpiacessivel_e((string) ($chatbot_stt_model_cache_id ?? 'glpi-vosk-ptbr')) ?>" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_voice_id">Voice ID TTS (Piper)</label>
              <input id="chatbot_tts_voice_id" type="text" name="chatbot_tts_voice_id" value="<?= glpiacessivel_e((string) ($chatbot_tts_voice_id ?? 'pt_BR-faber-medium')) ?>" />
            </div>
          </div>
        </div>
      </fieldset>
    </div>

    <label for="audit_retention_days">Retencao de auditoria (dias)</label>
    <input
      id="audit_retention_days"
      name="audit_retention_days"
      type="number"
      min="30"
      max="3650"
      value="<?= (int) ($audit_retention_days ?? 365) ?>"
      required
    />

    <button type="submit">Salvar</button>
  </form>
</section>

<section class="glpiacessivel-card" aria-labelledby="config-diagnostics-title">
  <h2 id="config-diagnostics-title">Diagnostico operacional</h2>
  <p class="glpiacessivel-help-text">Informacoes somente leitura para homologacao, suporte e auditoria. Nao substituem os testes reais GLPI 10/11.</p>

  <?php $i18nDiagnostics = is_array($i18n_diagnostics ?? null) ? $i18n_diagnostics : []; ?>
  <h3>Idioma e internacionalizacao</h3>
  <dl class="glpiacessivel-definition-list">
    <dt>Politica de idioma</dt>
    <dd>Herdar do GLPI</dd>
    <dt>Locale GLPI/sessao</dt>
    <dd><?= glpiacessivel_e((string) ($i18nDiagnostics['glpi_session_locale'] ?? '')) ?: 'Nao informado' ?></dd>
    <dt>Locale efetivo do plugin</dt>
    <dd><?= glpiacessivel_e((string) ($i18nDiagnostics['effective_locale'] ?? '')) ?></dd>
    <dt>HTML lang</dt>
    <dd><?= glpiacessivel_e((string) ($i18nDiagnostics['html_lang'] ?? '')) ?></dd>
    <dt>Fallback configurado</dt>
    <dd><?= glpiacessivel_e((string) ($i18nDiagnostics['fallback_locale'] ?? '')) ?></dd>
    <dt>Dominio gettext</dt>
    <dd><code><?= glpiacessivel_e((string) ($i18nDiagnostics['domain'] ?? 'glpiacessivel')) ?></code></dd>
    <dt>Mensagens JS</dt>
    <dd><?= (int) ($i18nDiagnostics['javascript_catalog_messages'] ?? 0) ?></dd>
  </dl>

  <?php $catalogStatus = is_array($i18nDiagnostics['catalog_status'] ?? null) ? $i18nDiagnostics['catalog_status'] : []; ?>
  <div class="glpiacessivel-table-wrapper">
    <table class="glpiacessivel-table">
      <caption>Status dos catalogos de traducao</caption>
      <thead>
        <tr>
          <th scope="col">Locale</th>
          <th scope="col">PO</th>
          <th scope="col">MO</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($catalogStatus as $locale => $status): ?>
          <tr>
            <th scope="row"><?= glpiacessivel_e((string) $locale) ?></th>
            <td><?= !empty($status['po']) ? 'Encontrado' : 'Ausente' ?></td>
            <td><?= !empty($status['mo']) ? 'Encontrado' : 'Ausente' ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <?php $operationalDiagnostics = is_array($operational_diagnostics ?? null) ? $operational_diagnostics : []; ?>
  <h3>Runtime</h3>
  <dl class="glpiacessivel-definition-list">
    <dt>Versao do plugin</dt>
    <dd><?= glpiacessivel_e((string) ($operationalDiagnostics['plugin_version'] ?? 'unknown')) ?></dd>
    <dt>GLPI</dt>
    <dd><?= glpiacessivel_e((string) ($operationalDiagnostics['glpi_version'] ?? 'unknown')) ?></dd>
    <dt>PHP</dt>
    <dd><?= glpiacessivel_e((string) ($operationalDiagnostics['php_version'] ?? PHP_VERSION)) ?></dd>
    <dt>Modo de acessibilidade</dt>
    <dd><?= glpiacessivel_e((string) ($operationalDiagnostics['accessibility_mode'] ?? '')) ?></dd>
    <dt>Entrada antes da autenticacao</dt>
    <dd><?= glpiacessivel_e((string) ($operationalDiagnostics['authentication_entry_mode'] ?? 'native_only')) ?></dd>
    <dt>Aviso de acessibilidade no login</dt>
    <dd><?= (($operationalDiagnostics['show_login_accessibility_notice'] ?? '0') === '1') ? 'Ativo' : 'Desativado' ?></dd>
    <dt>Escopo VLibras</dt>
    <dd><?= glpiacessivel_e((string) ($operationalDiagnostics['vlibras_scope'] ?? '')) ?></dd>
    <dt>Formularios no portal</dt>
    <dd><?= glpiacessivel_e(((string) ($operationalDiagnostics['forms_enabled'] ?? '1')) === '1' ? glpiacessivel_t('Habilitado') : glpiacessivel_t('Desativado')) ?></dd>
    <dt>Modo de abertura dos formularios</dt>
    <dd><?= glpiacessivel_e((string) ($operationalDiagnostics['forms_native_flow_mode'] ?? 'native_embedded')) ?></dd>
    <dt>Origem de voz</dt>
    <dd><?= glpiacessivel_e((string) ($operationalDiagnostics['voice_asset_mode'] ?? '')) ?></dd>
    <dt>Retencao de auditoria</dt>
    <dd><?= (int) ($operationalDiagnostics['audit_retention_days'] ?? 0) ?> dias</dd>
  </dl>

  <?php $voiceSources = is_array($operationalDiagnostics['voice_sources'] ?? null) ? $operationalDiagnostics['voice_sources'] : []; ?>
  <?php if ($voiceSources !== []): ?>
    <div class="glpiacessivel-table-wrapper">
      <table class="glpiacessivel-table">
        <caption>Resolucao dos assets de voz</caption>
        <thead>
          <tr>
            <th scope="col">Asset</th>
            <th scope="col">Fonte</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($voiceSources as $asset => $source): ?>
            <tr>
              <th scope="row"><code><?= glpiacessivel_e((string) $asset) ?></code></th>
              <td><?= glpiacessivel_e((string) $source) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="config-mode-help">
  <h2 id="config-mode-help">Como os modos funcionam</h2>
  <p><strong>Portal acessivel:</strong> ideal quando a central quer priorizar acessibilidade, previsibilidade visual e controle fino da jornada do usuario final.</p>
  <p><strong>Embutido no GLPI:</strong> ideal quando a prioridade e operar majoritariamente na interface nativa do GLPI, aceitando menor controle de acessibilidade completa nas telas do core.</p>
  <p><strong>Hibrido:</strong> ideal para o estado atual do projeto. Mantem o portal como rota acessivel principal e usa o GLPI embutido como continuidade, ponte e apoio operacional.</p>
</section>
