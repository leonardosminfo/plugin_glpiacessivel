<?php
try {
  $canUseForms = !empty($canUseForms) && \GlpiPlugin\Glpiacessivel\Support\Container::get()->configService()->isFormsEnabled();
} catch (\Throwable $e) {
  $canUseForms = !empty($canUseForms);
}
?>
<?php
$sessionStatus = is_array($session_status ?? null) ? $session_status : ['session_ready' => true, 'issue_code' => 'ready'];
$sessionReady = !empty($sessionStatus['session_ready']);
$sessionIssueCode = (string) ($sessionStatus['issue_code'] ?? 'unknown');
$sessionIssueMessages = [
  'not_logged' => 'Sua sessao nao esta autenticada. Acesse novamente para continuar.',
  'password_expired_partial' => 'A autenticacao foi iniciada, mas o GLPI exige atualizar a senha antes de liberar as funcoes.',
  'missing_profiles' => 'A sessao foi iniciada, mas o GLPI ainda nao carregou os perfis permitidos.',
  'missing_active_profile' => 'A sessao foi iniciada, mas o GLPI ainda nao definiu o perfil ativo.',
  'missing_active_entities' => 'A sessao foi iniciada, mas o GLPI ainda nao definiu a entidade ativa.',
  'no_current_interface' => 'A sessao foi iniciada, mas o GLPI ainda nao definiu a interface operacional.',
];
$sessionIssueMessage = $sessionIssueMessages[$sessionIssueCode] ?? 'A sessao foi iniciada, mas o contexto operacional do GLPI ainda nao esta pronto.';
?>

<?php if (!$sessionReady): ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning" role="alert" tabindex="-1" aria-labelledby="portal-session-alert-title">
    <strong id="portal-session-alert-title">Sessao GLPI incompleta</strong>
    <p><?= glpiacessivel_e($sessionIssueMessage) ?></p>
    <p>As funcoes que dependem de perfil, entidade e permissoes foram pausadas para evitar erro silencioso. Recarregue esta pagina ou use o login padrao do GLPI e retorne ao portal acessivel.</p>
    <p>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e((string) ($nativeLoginUrl ?? glpiacessivel_url('front/acessivel.php'))) ?>">Abrir login padrao do GLPI</a>
    </p>
  </div>
<?php endif; ?>

<section class="glpiacessivel-portal-hero" aria-labelledby="portal-title">
  <div>
    <p class="glpiacessivel-eyebrow">Central de servicos acessivel</p>
    <h2 id="portal-title">Atendimento GLPI com leitura clara, teclado completo e permissoes nativas</h2>
    <p class="glpiacessivel-hero-copy">
      Esta entrada concentra os fluxos habilitados da central de servicos em uma jornada acessivel e integrada ao GLPI.
    </p>
    <h2 id="portal-principles-title" class="glpiacessivel-sr-only">Principios do portal</h2>
    <ul class="glpiacessivel-hero-points" aria-labelledby="portal-principles-title">
      <li>Entrada oficial da experiencia adaptada</li>
      <li>Navegacao completa por teclado</li>
      <li>Fluxos criticos preservados no GLPI</li>
    </ul>
    <?php if (!empty($canCreateTicket)): ?>
      <div class="glpiacessivel-hero-actions">
        <a class="glpiacessivel-button glpiacessivel-button-primary" href="<?= glpiacessivel_e($createTicketUrl) ?>">
          Abrir novo chamado
        </a>
        <p class="glpiacessivel-hero-note">
          A abertura usa a tela acessivel do plugin e continua registrando o chamado pelo core do GLPI, preservando perfil, entidade e regras do sistema.
        </p>
      </div>
    <?php endif; ?>
  </div>

  <aside class="glpiacessivel-hero-panel" aria-labelledby="portal-experience-title" role="region">
    <h2 id="portal-experience-title" class="glpiacessivel-sr-only">Resumo da experiencia acessivel</h2>
    <article>
      <strong>Diretriz WCAG 2.2 AA</strong>
      <small>Alvo de foco, teclado, contraste e reflow.</small>
    </article>
    <article>
      <strong>Diretriz eMAG</strong>
      <small>Padrao conservador para servico publico.</small>
    </article>
    <article>
      <strong>ITIL</strong>
      <small>Chamados, transicoes e timeline operacional.</small>
    </article>
    <article>
      <strong>Permissoes GLPI</strong>
      <small>Perfil, entidade e acesso ao chamado respeitados pelo core.</small>
    </article>
  </aside>
</section>

<section class="glpiacessivel-section-head" aria-labelledby="portal-start">
  <p class="glpiacessivel-eyebrow">Inicio rapido</p>
  <h2 id="portal-start">Escolha o fluxo que deseja iniciar</h2>
  <p>Os atalhos abaixo mantem a experiencia adaptada sem perder o contexto de perfil, entidade e autorizacao do GLPI.</p>
</section>

<section class="glpiacessivel-action-band" aria-labelledby="portal-actions"<?= !$sessionReady ? ' aria-describedby="portal-session-alert-title"' : '' ?>>
  <h2 id="portal-actions">O que voce quer fazer agora?</h2>
  <div class="glpiacessivel-action-grid">
    <?php if (!$sessionReady): ?>
      <div class="glpiacessivel-action-card" aria-disabled="true">
        <strong>Funcoes pausadas</strong>
        <span>Aguardando o GLPI concluir perfil, entidade e permissoes da sessao.</span>
      </div>
    <?php elseif (empty($hasPortalActions)): ?>
      <div class="glpiacessivel-action-card" role="status">
        <strong><?= glpiacessivel_e(glpiacessivel_t('Nenhuma funcionalidade disponivel neste contexto.')) ?></strong>
        <span><?= glpiacessivel_e(glpiacessivel_t('Use o seletor Perfil ativo para escolher outro perfil permitido. Se nenhuma opcao atender, solicite ao administrador a revisao das permissoes e das funcionalidades liberadas.')) ?></span>
      </div>
    <?php else: ?>
      <?php if (!empty($canCreateTicket)): ?>
        <a class="glpiacessivel-action-card glpiacessivel-action-card-primary" href="<?= glpiacessivel_e($createTicketUrl) ?>">
          <strong><?= glpiacessivel_e(glpiacessivel_t('Abrir novo chamado')) ?></strong>
          <span><?= glpiacessivel_e(glpiacessivel_t('Registre uma solicitacao em uma tela adaptada, com gravacao pelo fluxo oficial do GLPI.')) ?></span>
        </a>
      <?php endif; ?>
      <?php if (!empty($canUseForms)): ?>
        <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/forms.php')) ?>">
          <strong><?= glpiacessivel_e(glpiacessivel_t('Formularios')) ?></strong>
          <span><?= glpiacessivel_e(glpiacessivel_t('Acesse formularios cadastrados no Service Catalog GLPI 11 ou Formcreator GLPI 10 com fallback nativo seguro.')) ?></span>
        </a>
      <?php endif; ?>
      <?php if (!empty($canViewTickets)): ?>
      <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php?scope=mine')) ?>">
        <strong>Meus chamados</strong>
        <span>Acompanhe solicitacoes em que voce participa.</span>
      </a>
      <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.php')) ?>">
        <strong>Todos os chamados</strong>
        <span>Pesquise, filtre e acesse detalhes conforme seu perfil.</span>
      </a>
      <?php endif; ?>
      <?php if (!empty($canViewCockpit)): ?>
      <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/cockpit.php')) ?>">
        <strong>Cockpit</strong>
        <span>Veja indicadores operacionais respeitando seu escopo.</span>
      </a>
      <?php endif; ?>
      <?php if (!empty($canViewKnowledgeBase)): ?>
      <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/knowledge.php')) ?>">
        <strong>Base de conhecimento</strong>
        <span>Consulte orientacoes e respostas frequentes.</span>
      </a>
      <?php endif; ?>
      <?php if (!empty($chatbot_enabled)): ?>
        <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/chatbot.php')) ?>">
          <strong>Chatbot operacional</strong>
          <span>Receba orientacao e consulte dados permitidos.</span>
        </a>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</section>
