<?php
try {
  $canUseForms = !empty($canUseForms) && \GlpiPlugin\Glpiacessivel\Support\Container::get()->configService()->isFormsEnabled();
} catch (\Throwable $e) {
  $canUseForms = !empty($canUseForms);
}
?>
<?php
$t = static fn(string $text): string => glpiacessivel_t($text);
$sessionStatus = is_array($session_status ?? null) ? $session_status : ['session_ready' => true, 'issue_code' => 'ready'];
$sessionReady = !empty($sessionStatus['session_ready']);
$sessionIssueCode = (string) ($sessionStatus['issue_code'] ?? 'unknown');
$sessionIssueMessages = [
  'not_logged' => $t('Sua sessão não está autenticada. Acesse novamente para continuar.'),
  'password_expired_partial' => $t('A autenticação foi iniciada, mas o GLPI exige atualizar a senha antes de liberar as funções.'),
  'missing_profiles' => $t('A sessão foi iniciada, mas o GLPI ainda não carregou os perfis permitidos.'),
  'missing_active_profile' => $t('A sessão foi iniciada, mas o GLPI ainda não definiu o perfil ativo.'),
  'missing_active_entities' => $t('A sessão foi iniciada, mas o GLPI ainda não definiu a entidade ativa.'),
  'no_current_interface' => $t('A sessão foi iniciada, mas o GLPI ainda não definiu a interface operacional.'),
];
$sessionIssueMessage = $sessionIssueMessages[$sessionIssueCode]
  ?? $t('A sessão foi iniciada, mas o contexto operacional do GLPI ainda não está pronto.');
?>

<?php if (!$sessionReady): ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning" role="alert" tabindex="-1" aria-labelledby="portal-session-alert-title">
    <strong id="portal-session-alert-title"><?= glpiacessivel_e($t('Sessão GLPI incompleta')) ?></strong>
    <p><?= glpiacessivel_e($sessionIssueMessage) ?></p>
    <p><?= glpiacessivel_e($t('As funções que dependem de perfil, entidade e permissões foram pausadas para evitar erro silencioso. Recarregue esta página ou use o login padrão do GLPI e retorne ao portal acessível.')) ?></p>
    <p>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e((string) ($nativeLoginUrl ?? glpiacessivel_url('front/acessivel.php'))) ?>"><?= glpiacessivel_e($t('Abrir login padrão do GLPI')) ?></a>
    </p>
  </div>
<?php endif; ?>

<section class="glpiacessivel-portal-hero" aria-labelledby="portal-title">
  <div>
    <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e($t('Central de serviços acessível')) ?></p>
    <h2 id="portal-title"><?= glpiacessivel_e($t('Atendimento acessível com leitura clara e teclado completo')) ?></h2>
    <p class="glpiacessivel-hero-copy">
      <?= glpiacessivel_e($t('Esta entrada concentra os fluxos habilitados da central de serviços em uma jornada acessível e integrada ao GLPI.')) ?>
    </p>
    <h2 id="portal-principles-title" class="glpiacessivel-sr-only"><?= glpiacessivel_e($t('Princípios do portal')) ?></h2>
    <ul class="glpiacessivel-hero-points" aria-labelledby="portal-principles-title">
      <li><?= glpiacessivel_e($t('Entrada principal da experiência acessível')) ?></li>
      <li><?= glpiacessivel_e($t('Navegação completa por teclado')) ?></li>
      <li><?= glpiacessivel_e($t('Fluxos críticos preservados no GLPI')) ?></li>
    </ul>
    <?php if (!empty($canCreateTicket)): ?>
      <div class="glpiacessivel-hero-actions">
        <a class="glpiacessivel-button glpiacessivel-button-primary" href="<?= glpiacessivel_e($createTicketUrl) ?>">
          <?= glpiacessivel_e($t('Abrir novo chamado')) ?>
        </a>
        <p class="glpiacessivel-hero-note">
          <?= glpiacessivel_e($t('O chamado é registrado pelo GLPI e respeita seu perfil, sua entidade e as regras do sistema.')) ?>
        </p>
      </div>
    <?php endif; ?>
  </div>

  <aside class="glpiacessivel-hero-panel" aria-labelledby="portal-experience-title" role="region">
    <h2 id="portal-experience-title" class="glpiacessivel-sr-only"><?= glpiacessivel_e($t('Resumo da experiência acessível')) ?></h2>
    <article>
      <strong><?= glpiacessivel_e($t('Diretriz WCAG 2.2 AA')) ?></strong>
      <small><?= glpiacessivel_e($t('Alvo de foco, teclado, contraste e refluxo.')) ?></small>
    </article>
    <article>
      <strong><?= glpiacessivel_e($t('Diretriz eMAG')) ?></strong>
      <small><?= glpiacessivel_e($t('Padrão conservador para serviço público.')) ?></small>
    </article>
    <article>
      <strong><?= glpiacessivel_e($t('Chamados e acompanhamento')) ?></strong>
      <small><?= glpiacessivel_e($t('Abertura, andamento e histórico do atendimento.')) ?></small>
    </article>
    <article>
      <strong><?= glpiacessivel_e($t('Permissões GLPI')) ?></strong>
      <small><?= glpiacessivel_e($t('Perfil, entidade e acesso ao chamado respeitados pelo GLPI.')) ?></small>
    </article>
  </aside>
</section>

<section class="glpiacessivel-section-head" aria-labelledby="portal-start">
  <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e($t('Início rápido')) ?></p>
  <h2 id="portal-start"><?= glpiacessivel_e($t('Escolha o fluxo que deseja iniciar')) ?></h2>
  <p><?= glpiacessivel_e($t('Os atalhos abaixo mantêm seu perfil, sua entidade e suas permissões no GLPI.')) ?></p>
</section>

<section class="glpiacessivel-action-band" aria-labelledby="portal-actions"<?= !$sessionReady ? ' aria-describedby="portal-session-alert-title"' : '' ?>>
  <h2 id="portal-actions"><?= glpiacessivel_e($t('O que você quer fazer agora?')) ?></h2>
  <div class="glpiacessivel-action-grid">
    <?php if (!$sessionReady): ?>
      <div class="glpiacessivel-action-card" aria-disabled="true">
        <strong><?= glpiacessivel_e($t('Funções pausadas')) ?></strong>
        <span><?= glpiacessivel_e($t('Aguardando o GLPI concluir perfil, entidade e permissões da sessão.')) ?></span>
      </div>
    <?php elseif (empty($hasPortalActions)): ?>
      <div class="glpiacessivel-action-card" role="status">
        <strong><?= glpiacessivel_e(glpiacessivel_t('Nenhuma funcionalidade disponível neste contexto.')) ?></strong>
        <span><?= glpiacessivel_e(glpiacessivel_t('Use o seletor Perfil ativo para escolher outro perfil permitido. Se nenhuma opção atender, solicite ao administrador a revisão das permissões e das funcionalidades liberadas.')) ?></span>
      </div>
    <?php else: ?>
      <?php if (!empty($canCreateTicket)): ?>
        <a class="glpiacessivel-action-card glpiacessivel-action-card-primary" href="<?= glpiacessivel_e($createTicketUrl) ?>">
          <strong><?= glpiacessivel_e(glpiacessivel_t('Abrir novo chamado')) ?></strong>
          <span><?= glpiacessivel_e(glpiacessivel_t('Registre uma solicitação em uma tela acessível, com as mesmas regras e permissões do GLPI.')) ?></span>
        </a>
      <?php endif; ?>
      <?php if (!empty($canUseForms)): ?>
        <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/forms.php')) ?>">
          <strong><?= glpiacessivel_e(glpiacessivel_t('Formulários')) ?></strong>
          <span><?= glpiacessivel_e(glpiacessivel_t('Acesse os formulários disponíveis para o seu perfil e a sua entidade.')) ?></span>
        </a>
      <?php endif; ?>
      <?php if (!empty($canViewTickets)): ?>
      <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php?scope=mine')) ?>">
        <strong><?= glpiacessivel_e($t('Meus chamados')) ?></strong>
        <span><?= glpiacessivel_e($t('Acompanhe solicitações das quais você participa.')) ?></span>
      </a>
      <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php')) ?>">
        <strong><?= glpiacessivel_e($t('Todos os chamados')) ?></strong>
        <span><?= glpiacessivel_e($t('Pesquise, filtre e acesse detalhes conforme seu perfil.')) ?></span>
      </a>
      <?php endif; ?>
      <?php if (!empty($canViewCockpit)): ?>
      <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/cockpit.php')) ?>">
        <strong><?= glpiacessivel_e($t('Cockpit')) ?></strong>
        <span><?= glpiacessivel_e($t('Veja indicadores operacionais respeitando seu escopo.')) ?></span>
      </a>
      <?php endif; ?>
      <?php if (!empty($canViewKnowledgeBase)): ?>
      <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/knowledge.php')) ?>">
        <strong><?= glpiacessivel_e($t('Base de conhecimento')) ?></strong>
        <span><?= glpiacessivel_e($t('Consulte orientações e respostas frequentes.')) ?></span>
      </a>
      <?php endif; ?>
      <?php if (!empty($chatbot_enabled)): ?>
        <a class="glpiacessivel-action-card" href="<?= glpiacessivel_e(glpiacessivel_url('front/chatbot.php')) ?>">
          <strong><?= glpiacessivel_e($t('Chatbot operacional')) ?></strong>
          <span><?= glpiacessivel_e($t('Receba orientação e consulte dados permitidos.')) ?></span>
        </a>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</section>
