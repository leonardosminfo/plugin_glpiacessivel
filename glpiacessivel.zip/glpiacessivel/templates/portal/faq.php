<?php

$glpiacessivelHtmlLang = function_exists('glpiacessivel_html_lang') ? glpiacessivel_html_lang() : 'pt-BR';
if (!function_exists('glpiacessivel_faq_e')) {
    function glpiacessivel_faq_e($value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

$filters = is_array($overview['filters'] ?? null) ? $overview['filters'] : [];
$result = is_array($overview['result'] ?? null) ? $overview['result'] : ['items' => [], 'total' => 0, 'page' => 1, 'pages' => 1, 'page_size' => 10];
$article = is_array($overview['article'] ?? null) ? $overview['article'] : null;
$categories = is_array($overview['categories'] ?? null) ? $overview['categories'] : [];
$homeLists = is_array($overview['home_lists'] ?? null) ? $overview['home_lists'] : [];

$query = (string) ($filters['query'] ?? '');
$categoryId = (int) ($filters['category_id'] ?? 0);
$page = max(1, (int) ($result['page'] ?? 1));
$pages = max(1, (int) ($result['pages'] ?? 1));
$total = max(0, (int) ($result['total'] ?? 0));
$items = is_array($result['items'] ?? null) ? $result['items'] : [];
$hasSearch = ($query !== '' || $categoryId > 0);
$accessibilityModeLabels = [
    'embedded' => glpiacessivel_t('Incorporado'),
    'hybrid' => glpiacessivel_t('Híbrido'),
    'standalone' => glpiacessivel_t('Independente'),
];
$accessibilityModeKey = (string) ($accessibilityMode ?? 'hybrid');
$accessibilityModeLabel = $accessibilityModeLabels[$accessibilityModeKey] ?? glpiacessivel_t('Híbrido');
$faqRuntimeMessages = [
    'themeNightOn' => glpiacessivel_t('Tema noturno ativado.'),
    'themeLightOn' => glpiacessivel_t('Tema claro ativado.'),
    'contrastOn' => glpiacessivel_t('Alto contraste ativado.'),
    'contrastOff' => glpiacessivel_t('Alto contraste desativado.'),
    'helpOpened' => glpiacessivel_t('Painel de ajuda aberto.'),
    'helpClosed' => glpiacessivel_t('Painel de ajuda fechado.'),
    'fontSizeAdjusted' => glpiacessivel_t('Tamanho da fonte ajustado para {percent} por cento.'),
];

if (!function_exists('glpiacessivel_faq_query')) {
    function glpiacessivel_faq_query(array $changes = []): string
    {
        global $query, $categoryId, $page;
        $params = [
            'q' => $query !== '' ? $query : null,
            'category' => $categoryId > 0 ? $categoryId : null,
            'page' => $page > 1 ? $page : null,
        ];
        foreach ($changes as $k => $v) {
            $params[$k] = $v;
        }

        return http_build_query(array_filter($params, static fn($v): bool => !($v === null || $v === '')));
    }
}
?>
<!doctype html>
<html lang="<?= htmlspecialchars($glpiacessivelHtmlLang, ENT_QUOTES, 'UTF-8') ?>">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?= glpiacessivel_faq_e(glpiacessivel_t('FAQ pública — Portal acessível')) ?></title>
  <link rel="stylesheet" href="<?= glpiacessivel_faq_e($css) ?>" />
  <link rel="stylesheet" href="<?= glpiacessivel_faq_e($portalCss) ?>" />
</head>
<body class="glpiacessivel-login-page">
  <a class="glpiacessivel-skip-link" href="#faq-principal" aria-keyshortcuts="Alt+1"><?= glpiacessivel_faq_e(glpiacessivel_t('Ir para o conteúdo')) ?></a>
  <a class="glpiacessivel-skip-link" href="#glpiacessivel-faq-header" aria-keyshortcuts="Alt+2"><?= glpiacessivel_faq_e(glpiacessivel_t('Ir para o menu')) ?></a>
  <a class="glpiacessivel-skip-link" href="#faq-search-form" aria-keyshortcuts="Alt+3"><?= glpiacessivel_faq_e(glpiacessivel_t('Ir para a busca')) ?></a>
  <div id="glpiacessivel-faq-live" class="glpiacessivel-sr-only" aria-live="polite" aria-atomic="true"></div>

  <header class="glpiacessivel-login-topbar" aria-label="<?= glpiacessivel_faq_e(glpiacessivel_t('Ferramentas de acessibilidade')) ?>">
    <nav class="glpiacessivel-login-shortcuts" aria-label="<?= glpiacessivel_faq_e(glpiacessivel_t('Atalhos da página')) ?>">
      <a href="#faq-principal" aria-keyshortcuts="Alt+1"><?= glpiacessivel_faq_e(glpiacessivel_t('Ir para o conteúdo [1]')) ?></a>
      <a href="#glpiacessivel-faq-header" aria-keyshortcuts="Alt+2"><?= glpiacessivel_faq_e(glpiacessivel_t('Ir para o menu [2]')) ?></a>
      <a href="#faq-search-form" aria-keyshortcuts="Alt+3"><?= glpiacessivel_faq_e(glpiacessivel_t('Ir para a busca [3]')) ?></a>
    </nav>
    <div class="glpiacessivel-login-tools" role="toolbar" aria-label="<?= glpiacessivel_faq_e(glpiacessivel_t('Controles de acessibilidade')) ?>">
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-theme aria-pressed="false" aria-keyshortcuts="Alt+T Control+Alt+Shift+T" aria-label="<?= glpiacessivel_faq_e(glpiacessivel_t('Alternar tema claro e noturno')) ?>"><?= glpiacessivel_faq_e(glpiacessivel_t('Tema')) ?></button>
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-contrast aria-pressed="false" aria-keyshortcuts="Alt+C Control+Alt+Shift+K" aria-label="<?= glpiacessivel_faq_e(glpiacessivel_t('Ativar ou desativar alto contraste')) ?>"><?= glpiacessivel_faq_e(glpiacessivel_t('Alto contraste')) ?></button>
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-font="decrease" aria-keyshortcuts="Alt+-" aria-label="<?= glpiacessivel_faq_e(glpiacessivel_t('Diminuir tamanho da fonte')) ?>">A-</button>
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-font="reset" aria-keyshortcuts="Alt+0" aria-label="<?= glpiacessivel_faq_e(glpiacessivel_t('Restaurar tamanho da fonte')) ?>">A</button>
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-font="increase" aria-keyshortcuts="Alt++" aria-label="<?= glpiacessivel_faq_e(glpiacessivel_t('Aumentar tamanho da fonte')) ?>">A+</button>
      <button
        type="button"
        class="glpiacessivel-login-tool"
        data-glpiacessivel-help
        aria-expanded="false"
        aria-controls="glpiacessivel-faq-help"
        aria-keyshortcuts="Alt+H Control+Alt+Shift+H"
      ><?= glpiacessivel_faq_e(glpiacessivel_t('Ajuda')) ?></button>
    </div>
  </header>

  <header id="glpiacessivel-faq-header" class="glpiacessivel-login-hero">
    <div class="glpiacessivel-login-brand">
      <div class="glpiacessivel-login-brand-icon" aria-hidden="true">
        <?php if (function_exists('plugin_glpiacessivel_portal_icon_markup')): ?>
          <?= plugin_glpiacessivel_portal_icon_markup() ?>
        <?php endif; ?>
      </div>
      <div>
        <h1><?= glpiacessivel_faq_e(glpiacessivel_t('FAQ pública')) ?></h1>
        <p class="glpiacessivel-login-brand-copy"><?= glpiacessivel_faq_e(glpiacessivel_t('Consulte respostas frequentes sem entrar no GLPI.')) ?></p>
        <p class="glpiacessivel-login-brand-copy"><?= glpiacessivel_faq_e(sprintf(glpiacessivel_t('Modo atual: %s. A FAQ permanece disponível fora da área autenticada do GLPI.'), $accessibilityModeLabel)) ?></p>
      </div>
    </div>
  </header>

  <main id="faq-principal" class="glpiacessivel-login-shell">
    <section class="glpiacessivel-login-panel" style="width:min(100%,980px)">
      <p>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_faq_e($loginUrl) ?>"><?= glpiacessivel_faq_e(glpiacessivel_t('Voltar para o login')) ?></a>
      </p>

      <form method="get" action="<?= glpiacessivel_faq_e($baseUrl) ?>" class="glpiacessivel-kb-filters glpiacessivel-kb-filters-public" id="faq-search-form" role="search" aria-label="<?= glpiacessivel_faq_e(glpiacessivel_t('Pesquisar FAQ pública')) ?>">
        <div class="glpiacessivel-field glpiacessivel-kb-field-search">
          <label for="q"><?= glpiacessivel_faq_e(glpiacessivel_t('Busca pública')) ?></label>
          <input id="q" type="text" name="q" value="<?= glpiacessivel_faq_e($query) ?>" placeholder="<?= glpiacessivel_faq_e(glpiacessivel_t('Ex.: certificado digital')) ?>" />
        </div>
        <div class="glpiacessivel-field glpiacessivel-kb-field-category">
          <label for="category"><?= glpiacessivel_faq_e(glpiacessivel_t('Categoria')) ?></label>
          <select id="category" name="category">
            <option value="0"><?= glpiacessivel_faq_e(glpiacessivel_t('Todas as categorias')) ?></option>
            <?php foreach ($categories as $category): ?>
              <option value="<?= (int) $category['id'] ?>"<?= ((int) $category['id'] === $categoryId) ? ' selected' : '' ?>>
                <?= glpiacessivel_faq_e((string) ($category['label'] ?? '')) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="glpiacessivel-kb-filter-actions">
          <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary"><?= glpiacessivel_faq_e(glpiacessivel_t('Pesquisar')) ?></button>
          <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_faq_e($baseUrl) ?>"><?= glpiacessivel_faq_e(glpiacessivel_t('Limpar')) ?></a>
        </div>
      </form>

      <section
        id="glpiacessivel-faq-help"
        class="glpiacessivel-login-help"
        aria-labelledby="glpiacessivel-faq-help-title"
        role="dialog"
        aria-modal="true"
        tabindex="-1"
        hidden
      >
        <div class="glpiacessivel-help-heading">
          <h2 id="glpiacessivel-faq-help-title"><?= glpiacessivel_faq_e(glpiacessivel_t('Ajuda de acessibilidade')) ?></h2>
          <button type="button" class="glpiacessivel-help-close" data-glpiacessivel-help-close aria-label="<?= glpiacessivel_faq_e(glpiacessivel_t('Fechar ajuda')) ?>">X</button>
        </div>
        <p><?= glpiacessivel_faq_e(glpiacessivel_t('Atalhos disponíveis para facilitar a navegação e a consulta da FAQ pública.')) ?></p>
        <div class="glpiacessivel-shortcut-table-wrap" tabindex="0">
          <table class="glpiacessivel-shortcut-table">
            <thead><tr><th><?= glpiacessivel_faq_e(glpiacessivel_t('Atalho')) ?></th><th><?= glpiacessivel_faq_e(glpiacessivel_t('Ação')) ?></th></tr></thead>
            <tbody>
              <tr><td><kbd>Alt</kbd> + <kbd>1</kbd></td><td><?= glpiacessivel_faq_e(glpiacessivel_t('Ir para o conteúdo principal')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>2</kbd></td><td><?= glpiacessivel_faq_e(glpiacessivel_t('Ir para o menu de navegação')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>3</kbd></td><td><?= glpiacessivel_faq_e(glpiacessivel_t('Ir para o campo de busca')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>C</kbd></td><td><?= glpiacessivel_faq_e(glpiacessivel_t('Alternar alto contraste')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>T</kbd></td><td><?= glpiacessivel_faq_e(glpiacessivel_t('Alternar tema claro ou noturno')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>-</kbd></td><td><?= glpiacessivel_faq_e(glpiacessivel_t('Diminuir tamanho da fonte')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>0</kbd></td><td><?= glpiacessivel_faq_e(glpiacessivel_t('Restaurar tamanho da fonte')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>+</kbd></td><td><?= glpiacessivel_faq_e(glpiacessivel_t('Aumentar tamanho da fonte')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>H</kbd><br><kbd>Ctrl</kbd> + <kbd>Alt</kbd> + <kbd>Shift</kbd> + <kbd>H</kbd></td><td><?= glpiacessivel_faq_e(glpiacessivel_t('Abrir ou fechar a ajuda de acessibilidade')) ?></td></tr>
            </tbody>
          </table>
        </div>
        <div class="glpiacessivel-help-notes" aria-label="<?= glpiacessivel_faq_e(glpiacessivel_t('Orientações complementares de acessibilidade')) ?>">
          <section>
            <h3><?= glpiacessivel_faq_e(glpiacessivel_t('Leitores de tela')) ?></h3>
            <p><?= glpiacessivel_faq_e(glpiacessivel_t('Este portal é otimizado para leitores de tela como NVDA, JAWS e VoiceOver.')) ?></p>
            <ul>
              <li><strong><?= glpiacessivel_faq_e(glpiacessivel_t('Regiões da página:')) ?></strong> <?= glpiacessivel_faq_e(glpiacessivel_t('use as teclas de navegação rápida do leitor de tela, como R no NVDA, para percorrer as seções.')) ?></li>
              <li><strong><?= glpiacessivel_faq_e(glpiacessivel_t('Títulos:')) ?></strong> <?= glpiacessivel_faq_e(glpiacessivel_t('use H para navegar pelos títulos.')) ?></li>
              <li><strong><?= glpiacessivel_faq_e(glpiacessivel_t('Tabelas:')) ?></strong> <?= glpiacessivel_faq_e(glpiacessivel_t('navegue pelas células com os comandos de tabela do leitor, como Ctrl+Alt+Setas, quando houver suporte.')) ?></li>
              <li><strong><?= glpiacessivel_faq_e(glpiacessivel_t('Formulários:')) ?></strong> <?= glpiacessivel_faq_e(glpiacessivel_t('os campos obrigatórios são anunciados como obrigatórios.')) ?></li>
            </ul>
          </section>
          <section>
            <h3><?= glpiacessivel_faq_e(glpiacessivel_t('Recursos visuais')) ?></h3>
            <ul>
              <li><strong><?= glpiacessivel_faq_e(glpiacessivel_t('Modo escuro:')) ?></strong> <?= glpiacessivel_faq_e(glpiacessivel_t('ative pelo botão Tema, por Alt+T ou por Ctrl+Alt+Shift+T.')) ?></li>
              <li><strong><?= glpiacessivel_faq_e(glpiacessivel_t('Alto contraste:')) ?></strong> <?= glpiacessivel_faq_e(glpiacessivel_t('ative pela barra de acessibilidade, por Alt+C ou por Ctrl+Alt+Shift+K.')) ?></li>
              <li><strong><?= glpiacessivel_faq_e(glpiacessivel_t('Foco visível:')) ?></strong> <?= glpiacessivel_faq_e(glpiacessivel_t('bordas destacadas indicam o elemento ativo.')) ?></li>
              <li><strong><?= glpiacessivel_faq_e(glpiacessivel_t('VLibras:')) ?></strong> <?= glpiacessivel_faq_e(glpiacessivel_t('tradução automática para a Língua Brasileira de Sinais, quando habilitada.')) ?></li>
            </ul>
          </section>
        </div>
        <div class="glpiacessivel-help-footer">
          <button type="button" class="glpiacessivel-button glpiacessivel-button-primary" data-glpiacessivel-help-close><?= glpiacessivel_faq_e(glpiacessivel_t('Fechar')) ?></button>
        </div>
      </section>

      <?php if (!$hasSearch): ?>
        <div class="glpiacessivel-kb-home-grid">
          <section>
            <h3><?= glpiacessivel_faq_e(glpiacessivel_t('Entradas recentes')) ?></h3>
            <ul class="glpiacessivel-kb-home-list">
              <?php foreach (($homeLists['recentes'] ?? []) as $item): ?>
                <li><a href="<?= glpiacessivel_faq_e($baseUrl . '?' . http_build_query(['article' => (int) ($item['id'] ?? 0)])) ?>"><?= glpiacessivel_faq_e((string) ($item['assunto'] ?? '')) ?></a></li>
              <?php endforeach; ?>
            </ul>
          </section>
          <section>
            <h3><?= glpiacessivel_faq_e(glpiacessivel_t('Artigos atualizados recentemente')) ?></h3>
            <ul class="glpiacessivel-kb-home-list">
              <?php foreach (($homeLists['atualizadas'] ?? []) as $item): ?>
                <li><a href="<?= glpiacessivel_faq_e($baseUrl . '?' . http_build_query(['article' => (int) ($item['id'] ?? 0)])) ?>"><?= glpiacessivel_faq_e((string) ($item['assunto'] ?? '')) ?></a></li>
              <?php endforeach; ?>
            </ul>
          </section>
          <section>
            <h3><?= glpiacessivel_faq_e(glpiacessivel_t('Mais populares')) ?></h3>
            <ul class="glpiacessivel-kb-home-list">
              <?php foreach (($homeLists['populares'] ?? []) as $item): ?>
                <li><a href="<?= glpiacessivel_faq_e($baseUrl . '?' . http_build_query(['article' => (int) ($item['id'] ?? 0)])) ?>"><?= glpiacessivel_faq_e((string) ($item['assunto'] ?? '')) ?></a></li>
              <?php endforeach; ?>
            </ul>
          </section>
        </div>
      <?php endif; ?>

      <?php if ($article !== null): ?>
        <section class="glpiacessivel-card glpiacessivel-kb-article">
          <h2><?= glpiacessivel_faq_e((string) ($article['assunto'] ?? glpiacessivel_t('Artigo'))) ?></h2>
          <div class="glpiacessivel-content glpiacessivel-kb-reader">
            <?= (string) ($article['body_html'] ?? '') ?>
          </div>
        </section>
      <?php endif; ?>

      <?php if ($hasSearch): ?>
        <section class="glpiacessivel-card glpiacessivel-kb-results">
          <h2><?= glpiacessivel_faq_e(sprintf(glpiacessivel_t('Resultados (%d)'), $total)) ?></h2>
          <div class="glpiacessivel-table-wrap">
            <table class="glpiacessivel-kb-table">
              <thead>
                <tr><th><?= glpiacessivel_faq_e(glpiacessivel_t('Assunto')) ?></th><th><?= glpiacessivel_faq_e(glpiacessivel_t('Categoria')) ?></th><th><?= glpiacessivel_faq_e(glpiacessivel_t('Ações')) ?></th></tr>
              </thead>
              <tbody>
                <?php foreach ($items as $item): ?>
                  <tr>
                    <td><strong><?= glpiacessivel_faq_e((string) ($item['assunto'] ?? '')) ?></strong><div class="glpiacessivel-help-text"><?= glpiacessivel_faq_e((string) ($item['summary'] ?? '')) ?></div></td>
                    <td><?= glpiacessivel_faq_e((string) ($item['category'] ?? glpiacessivel_t('Sem categoria'))) ?></td>
                    <td><a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_faq_e($baseUrl . '?' . glpiacessivel_faq_query(['article' => (int) ($item['id'] ?? 0)])) ?>"><?= glpiacessivel_faq_e(glpiacessivel_t('Abrir')) ?></a></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
          <?php if ($pages > 1): ?>
            <nav class="glpiacessivel-pagination" aria-label="<?= glpiacessivel_faq_e(glpiacessivel_t('Paginação da FAQ pública')) ?>">
              <?php if ($page > 1): ?><a href="<?= glpiacessivel_faq_e($baseUrl . '?' . glpiacessivel_faq_query(['page' => $page - 1])) ?>">&laquo; <?= glpiacessivel_faq_e(glpiacessivel_t('Anterior')) ?></a><?php endif; ?>
              <span><?= glpiacessivel_faq_e(sprintf(glpiacessivel_t('Página %1$d de %2$d'), $page, $pages)) ?></span>
              <?php if ($page < $pages): ?><a href="<?= glpiacessivel_faq_e($baseUrl . '?' . glpiacessivel_faq_query(['page' => $page + 1])) ?>"><?= glpiacessivel_faq_e(glpiacessivel_t('Próxima')) ?> &raquo;</a><?php endif; ?>
            </nav>
          <?php endif; ?>
        </section>
      <?php endif; ?>
    </section>
  </main>
  <script src="<?= glpiacessivel_faq_e((string) ($runtimeConfigJs ?? '')) ?>" data-glpiacessivel-runtime-config="1"></script>
  <script src="<?= glpiacessivel_faq_e((string) ($globalJs ?? '')) ?>"></script>
  <script>
    (function () {
      var messages = <?= json_encode($faqRuntimeMessages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
      var body = document.body;
      var liveRegion = document.getElementById('glpiacessivel-faq-live');
      var storageKey = 'glpiacessivel-login-preferences-v2';
      var defaultPrefs = { theme: 'light', contrast: false, fontScale: 1 };
      var themeButton = document.querySelector('button[data-glpiacessivel-theme], [role="button"][data-glpiacessivel-theme]');
      var contrastButton = document.querySelector('button[data-glpiacessivel-contrast], [role="button"][data-glpiacessivel-contrast]');
      var helpButton = document.querySelector('button[data-glpiacessivel-help], [role="button"][data-glpiacessivel-help]');
      var helpPanel = document.getElementById('glpiacessivel-faq-help');
      var helpCloseButtons = document.querySelectorAll('[data-glpiacessivel-help-close]');

      function announce(message) {
        if (liveRegion) {
          liveRegion.textContent = message;
        }
      }

      function readPrefs() {
        try {
          var saved = window.localStorage.getItem(storageKey);
          if (!saved) {
            return defaultPrefs;
          }
          var parsed = JSON.parse(saved);
          return {
            theme: parsed.theme === 'night' ? 'night' : 'light',
            contrast: parsed.contrast === true,
            fontScale: parsed.fontScale === 0.9 || parsed.fontScale === 1.1 || parsed.fontScale === 1.2 ? parsed.fontScale : 1
          };
        } catch (error) {
          return defaultPrefs;
        }
      }

      function writePrefs(prefs) {
        try {
          window.localStorage.setItem(storageKey, JSON.stringify(prefs));
        } catch (error) {
          // Ignore storage restrictions on privacy modes.
        }
      }

      function applyPrefs(prefs) {
        body.dataset.glpiacessivelTheme = prefs.theme;
        body.dataset.glpiacessivelContrast = prefs.contrast ? 'high' : 'default';
        body.style.fontSize = prefs.fontScale + 'rem';

        if (themeButton) {
          themeButton.setAttribute('aria-pressed', prefs.theme === 'night' ? 'true' : 'false');
        }
        if (contrastButton) {
          contrastButton.setAttribute('aria-pressed', prefs.contrast ? 'true' : 'false');
        }
      }

      var helpLastFocus = null;

      function getHelpFocusableElements() {
        if (!helpPanel) {
          return [];
        }
        return Array.prototype.slice.call(helpPanel.querySelectorAll('a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'))
          .filter(function (element) {
            return element instanceof HTMLElement && !element.hidden && element.offsetParent !== null;
          });
      }

      function setHelpOpen(open) {
        if (!helpButton || !helpPanel) {
          return;
        }

        if (open) {
          helpLastFocus = document.activeElement instanceof HTMLElement ? document.activeElement : helpButton;
        }
        helpButton.setAttribute('aria-expanded', open ? 'true' : 'false');
        helpPanel.hidden = !open;

        if (open) {
          var closeButton = helpPanel.querySelector('[data-glpiacessivel-help-close]');
          if (closeButton) {
            closeButton.focus();
          } else {
            helpPanel.focus();
          }
        } else if (helpLastFocus && typeof helpLastFocus.focus === 'function') {
          helpLastFocus.focus();
        }
      }

      function announceExternal(externalLiveRegion, message) {
        announce(message);
        if (externalLiveRegion && externalLiveRegion !== liveRegion && 'textContent' in externalLiveRegion) {
          externalLiveRegion.textContent = message;
        }
      }

      window.glpiacessivelToggleTheme = function (externalLiveRegion) {
        if (!themeButton) {
          return false;
        }
        var contrastWasActive = prefs.contrast;
        if (contrastWasActive) {
          prefs.contrast = false;
        }
        prefs.theme = prefs.theme === 'light' ? 'night' : 'light';
        applyPrefs(prefs);
        writePrefs(prefs);
        var message = (prefs.theme === 'night' ? messages.themeNightOn : messages.themeLightOn) + (contrastWasActive ? ' ' + messages.contrastOff : '');
        announceExternal(externalLiveRegion, message);
        themeButton.focus();
        return true;
      };

      window.glpiacessivelToggleContrast = function (externalLiveRegion) {
        if (!contrastButton) {
          return false;
        }
        prefs.contrast = !prefs.contrast;
        applyPrefs(prefs);
        writePrefs(prefs);
        var message = prefs.contrast ? messages.contrastOn : messages.contrastOff;
        announceExternal(externalLiveRegion, message);
        contrastButton.focus();
        return true;
      };

      window.glpiacessivelToggleHelp = function (externalLiveRegion) {
        if (!helpButton || !helpPanel) {
          return false;
        }
        var isOpen = helpButton.getAttribute('aria-expanded') === 'true';
        setHelpOpen(!isOpen);
        var message = !isOpen ? messages.helpOpened : messages.helpClosed;
        announce(message);
        if (externalLiveRegion && externalLiveRegion !== liveRegion && 'textContent' in externalLiveRegion) {
          externalLiveRegion.textContent = message;
        }
        return true;
      };
      var prefs = readPrefs();
      applyPrefs(prefs);

      if (themeButton) {
        themeButton.addEventListener('click', function () {
          window.glpiacessivelToggleTheme();
        });
      }

      if (contrastButton) {
        contrastButton.addEventListener('click', function () {
          window.glpiacessivelToggleContrast();
        });
      }

      Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-font]')).forEach(function (button) {
        button.addEventListener('click', function () {
          var action = button.getAttribute('data-glpiacessivel-font');
          if (action === 'increase') {
            prefs.fontScale = Math.min(1.2, prefs.fontScale + 0.1);
          } else if (action === 'decrease') {
            prefs.fontScale = Math.max(0.9, prefs.fontScale - 0.1);
          } else {
            prefs.fontScale = 1;
          }
          applyPrefs(prefs);
          writePrefs(prefs);
          announce(messages.fontSizeAdjusted.replace('{percent}', String(Math.round(prefs.fontScale * 100))));
        });
      });

      if (helpButton && helpPanel) {
        helpButton.addEventListener('click', function () {
          var isOpen = helpButton.getAttribute('aria-expanded') === 'true';
          setHelpOpen(!isOpen);
          announce(!isOpen ? messages.helpOpened : messages.helpClosed);
        });

        helpPanel.addEventListener('keydown', function (event) {
          if (event.key === 'Escape') {
            event.preventDefault();
            setHelpOpen(false);
            announce(messages.helpClosed);
            return;
          }

          if (event.key !== 'Tab') {
            return;
          }

          var focusable = getHelpFocusableElements();
          if (focusable.length === 0) {
            event.preventDefault();
            helpPanel.focus();
            return;
          }

          var first = focusable[0];
          var last = focusable[focusable.length - 1];
          if (event.shiftKey && document.activeElement === first) {
            event.preventDefault();
            last.focus();
          } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault();
            first.focus();
          }
        });

        Array.prototype.slice.call(helpCloseButtons).forEach(function (button) {
          button.addEventListener('click', function () {
            setHelpOpen(false);
            announce(messages.helpClosed);
          });
        });
      }
    })();
  </script>
</body>
</html>

