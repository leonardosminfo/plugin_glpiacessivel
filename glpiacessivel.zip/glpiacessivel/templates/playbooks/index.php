<?php
$criticalConfirmations = is_array($critical_confirmations ?? null) ? $critical_confirmations : [];
$chatbotDisplayName = trim((string) ($chatbot_name ?? 'Assistente'));
if ($chatbotDisplayName === '') {
    $chatbotDisplayName = 'Assistente';
}
$t = static function (string $text): string {
    return __($text, 'glpiacessivel');
};
$playbookLines = static function ($values): string {
    return implode("\n", array_map('strval', (array) $values));
};
$playbookSummary = static function (array $playbook): string {
    $content = is_array($playbook['content'] ?? null) ? $playbook['content'] : [];
    return (string) ($content['answer_summary'] ?? '');
};
$playbookKbArticles = static function (array $playbook): string {
    $lines = [];
    foreach ((array) ($playbook['kb_articles'] ?? []) as $article) {
        if (!is_array($article)) {
            continue;
        }
        $id = (int) ($article['id'] ?? 0);
        $name = trim((string) ($article['name'] ?? ''));
        if ($id > 0 && $name !== '') {
            $lines[] = $id . ' | ' . $name;
        } elseif ($id > 0) {
            $lines[] = (string) $id;
        } elseif ($name !== '') {
            $lines[] = $name;
        }
    }

    return implode("\n", $lines);
};
$playbookKbArticleLinks = static function (array $playbook) use ($t): array {
    $links = [];
    foreach ((array) ($playbook['kb_articles'] ?? []) as $article) {
        if (!is_array($article)) {
            continue;
        }

        $id = (int) ($article['id'] ?? 0);
        $name = trim((string) ($article['name'] ?? ''));
        if ($id <= 0 && $name === '') {
            continue;
        }

        $links[] = [
            'id' => $id,
            'name' => $name !== '' ? $name : sprintf($t('Artigo #%d'), $id),
        ];
    }

    return $links;
};
$playbookContentValue = static function (array $playbook, string $key): string {
    $content = is_array($playbook['content'] ?? null) ? $playbook['content'] : [];
    $value = $content[$key] ?? '';
    if (is_array($value)) {
        $value = implode('; ', array_map('strval', array_slice($value, 0, 4)));
    }

    return trim((string) $value);
};
$playbookSuggestionSummary = static function (array $suggestion) use ($playbookContentValue, $t): string {
    foreach (['answer_summary', 'first_steps', 'when_open_ticket'] as $field) {
        $value = $playbookContentValue($suggestion, $field);
        if ($value !== '') {
            return $value;
        }
    }

    $questions = array_values(array_filter(array_map('strval', (array) ($suggestion['questions'] ?? []))));
    if ($questions !== []) {
        return $questions[0];
    }

    return $t('Sem resumo informado.');
};
$playbookShortText = static function (string $text, int $limit = 220): string {
    $text = trim(preg_replace('/\s+/', ' ', $text) ?? $text);
    if (mb_strlen($text, 'UTF-8') <= $limit) {
        return $text;
    }

    return rtrim(mb_substr($text, 0, $limit - 1, 'UTF-8')) . '...';
};
$playbookConfidenceLabel = static function ($confidence) use ($t): string {
    if ($confidence === null || $confidence === '') {
        return $t('Não informada');
    }

    $score = (float) $confidence;
    if ($score >= 0 && $score <= 1) {
        $score *= 100;
    }

    return (string) min(100, max(0, (int) round($score))) . '%';
};

?>

<section class="glpiacessivel-card" aria-labelledby="playbooks-title">
  <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e($t('Chatbot operacional')) ?></p>
  <h2 id="playbooks-title"><?= glpiacessivel_e($t('Roteiros do chatbot')) ?></h2>
  <p>
      <?= glpiacessivel_e(sprintf($t('Revisão de conteúdos para %s. A varredura cria sugestões a partir da base de conhecimento, mas apenas roteiros aprovados entram nas respostas do chatbot.'), $chatbotDisplayName)) ?>
  </p>

  <?php if (!empty($message)) : ?>
    <p role="status" aria-live="polite" class="glpiacessivel-alert glpiacessivel-alert-info">
        <?= glpiacessivel_e($message) ?>
    </p>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="scan-title">
  <h2 id="scan-title"><?= glpiacessivel_e($t('Varredura inicial da base de conhecimento')) ?></h2>
  <p>
    <?= glpiacessivel_e($t('Execute em lote pequeno e fora do horário crítico. Esta etapa consulta artigos visíveis ao perfil atual e gera sugestões para revisão manual.')) ?>
  </p>

  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-form-grid">
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
    <input type="hidden" name="action" value="run_kb_initial" />

    <label for="playbook-limit"><?= glpiacessivel_e($t('Limite de artigos')) ?></label>
    <input id="playbook-limit" name="limit" type="number" min="10" max="200" step="10" value="80" />

    <label for="playbook-public-only"><?= glpiacessivel_e($t('Escopo')) ?></label>
    <select id="playbook-public-only" name="public_only">
      <option value="1" selected><?= glpiacessivel_e($t('Somente FAQ pública')) ?></option>
      <option value="0"><?= glpiacessivel_e($t('FAQ e artigos visíveis ao perfil')) ?></option>
    </select>

    <div class="glpiacessivel-field" style="grid-column:1 / -1;">
        <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action"><?= glpiacessivel_e($t('Gerar sugestões')) ?></button>
      <a class="glpiacessivel-button glpiacessivel-button-secondary glpiacessivel-secondary-action" href="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php?export=1')) ?>">
        <?= glpiacessivel_e($t('Exportar roteiros aprovados')) ?>
      </a>
    </div>
  </form>

  <?php if (is_array($result ?? null)) : ?>
      <dl class="glpiacessivel-kpi-grid" aria-label="<?= glpiacessivel_e($t('Resultado da última varredura')) ?>">
      <div>
        <dt><?= glpiacessivel_e($t('Artigos analisados')) ?></dt>
        <dd><?= (int) ($result['articles'] ?? 0) ?></dd>
      </div>
      <div>
          <dt><?= glpiacessivel_e($t('Sugestões geradas')) ?></dt>
        <dd><?= (int) ($result['suggestions'] ?? 0) ?></dd>
      </div>
      <div>
        <dt><?= glpiacessivel_e($t('Execução')) ?></dt>
        <?php
          $scanStatus = (string) ($result['status'] ?? '');
          $scanStatusLabels = [
            'completed' => $t('Concluída'),
            'failed' => $t('Falhou'),
            'running' => $t('Em andamento'),
          ];
            ?>
        <dd><?= glpiacessivel_e((string) ($scanStatusLabels[$scanStatus] ?? $scanStatus)) ?></dd>
      </div>
    </dl>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="manual-playbook-title">
  <h2 id="manual-playbook-title"><?= glpiacessivel_e($t('Cadastrar roteiro manualmente')) ?></h2>
  <p>
    <?= glpiacessivel_e($t('Use esta área para cadastrar um roteiro sem varredura. O roteiro pode ser criado como ativo, pendente para análise ou inativo. Associe um artigo da base por linha no formato ID | Título do artigo.')) ?>
  </p>

  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-playbook-manual-form">
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
    <input type="hidden" name="action" value="create_playbook" />

    <fieldset class="glpiacessivel-playbook-form-section">
      <legend><?= glpiacessivel_e($t('Identificação e ativação')) ?></legend>
      <p><?= glpiacessivel_e(sprintf($t('Defina como o roteiro será reconhecido e se ele já pode ser usado por %s.'), $chatbotDisplayName)) ?></p>
      <div class="glpiacessivel-playbook-form-grid">
        <div class="glpiacessivel-field">
          <label for="manual-playbook-name"><?= glpiacessivel_e($t('Nome do roteiro')) ?></label>
          <input id="manual-playbook-name" name="name" type="text" />
        </div>

        <div class="glpiacessivel-field">
          <label for="manual-playbook-status"><?= glpiacessivel_e($t('Estado inicial')) ?></label>
          <select id="manual-playbook-status" name="status">
            <option value="active"><?= glpiacessivel_e($t('Ativo no chatbot')) ?></option>
            <option value="pending"><?= glpiacessivel_e($t('Pendente para análise')) ?></option>
            <option value="inactive"><?= glpiacessivel_e($t('Inativo')) ?></option>
          </select>
        </div>

        <div class="glpiacessivel-field">
          <label for="manual-playbook-intent"><?= glpiacessivel_e($t('Intenção')) ?></label>
          <input id="manual-playbook-intent" name="intent" type="text" value="kb_recomendar_contextual" />
        </div>
      </div>
    </fieldset>

    <fieldset class="glpiacessivel-playbook-form-section">
      <legend><?= glpiacessivel_e($t('Contexto de busca e encaminhamento')) ?></legend>
      <p><?= glpiacessivel_e($t('Cadastre palavras e perguntas que ajudem o chatbot a reconhecer a situação do usuário.')) ?></p>
      <div class="glpiacessivel-playbook-form-grid">
        <div class="glpiacessivel-field">
          <label for="manual-playbook-category"><?= glpiacessivel_e($t('Categoria sugerida')) ?></label>
          <input id="manual-playbook-category" name="category_hint" type="text" />
        </div>

        <div class="glpiacessivel-field">
          <label for="manual-playbook-group"><?= glpiacessivel_e($t('Grupo sugerido')) ?></label>
          <input id="manual-playbook-group" name="group_hint" type="text" />
        </div>

        <div class="glpiacessivel-field span-3">
          <label for="manual-playbook-keywords"><?= glpiacessivel_e($t('Palavras-chave')) ?></label>
          <textarea id="manual-playbook-keywords" name="keywords" rows="5"></textarea>
          <p class="glpiacessivel-field-hint"><?= glpiacessivel_e($t('Use uma palavra ou expressão por linha. Exemplo: VPN, acesso remoto, Forticlient.')) ?></p>
        </div>

        <div class="glpiacessivel-field span-3">
          <label for="manual-playbook-questions"><?= glpiacessivel_e($t('Perguntas de validação')) ?></label>
          <textarea id="manual-playbook-questions" name="questions" rows="5"></textarea>
          <p class="glpiacessivel-field-hint"><?= glpiacessivel_e($t('Perguntas usadas para confirmar o contexto antes de abrir um chamado.')) ?></p>
        </div>
      </div>
    </fieldset>

    <fieldset class="glpiacessivel-playbook-form-section">
      <legend><?= glpiacessivel_e($t('Resposta e base de conhecimento')) ?></legend>
        <p><?= glpiacessivel_e(sprintf($t('Associe artigos do GLPI para que %s apresente orientação e link direto ao usuário.'), $chatbotDisplayName)) ?></p>
      <div class="glpiacessivel-playbook-form-grid">
        <div class="glpiacessivel-field span-2">
          <label for="manual-playbook-summary"><?= glpiacessivel_e($t('Resposta resumida')) ?></label>
          <textarea id="manual-playbook-summary" name="answer_summary" rows="5"></textarea>
        </div>

        <div class="glpiacessivel-field">
          <label for="manual-playbook-kb"><?= glpiacessivel_e($t('Artigos da base associados')) ?></label>
          <textarea id="manual-playbook-kb" name="kb_articles" rows="5" aria-describedby="manual-playbook-kb-help"></textarea>
          <p id="manual-playbook-kb-help" class="glpiacessivel-field-hint">
            <?= glpiacessivel_e($t('Informe um artigo por linha. Exemplo: 123 | VPN - acesso remoto.')) ?>
          </p>
        </div>
      </div>
    </fieldset>

    <div class="glpiacessivel-playbook-actions">
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action"><?= glpiacessivel_e($t('Cadastrar roteiro')) ?></button>
    </div>
  </form>
</section>

<section class="glpiacessivel-card" aria-labelledby="suggestions-title">
  <h2 id="suggestions-title"><?= glpiacessivel_e($t('Sugestões pendentes')) ?></h2>

  <?php if (empty($suggestions)) : ?>
    <p><?= glpiacessivel_e($t('Nenhuma sugestão pendente no momento.')) ?></p>
  <?php else : ?>
    <p role="status" aria-live="polite">
      <?php $pendingSuggestionCount = count((array) $suggestions); ?>
      <?= glpiacessivel_e(sprintf(
          _n(
              'Há %d sugestão pendente para revisão.',
              'Há %d sugestões pendentes para revisão.',
              $pendingSuggestionCount,
              'glpiacessivel'
          ),
          $pendingSuggestionCount
      )) ?>
    </p>
    <ul class="glpiacessivel-playbook-suggestion-list glpiacessivel-playbook-suggestion-list-compact" aria-label="<?= glpiacessivel_e($t('Sugestões pendentes para revisão')) ?>">
      <?php foreach ((array) $suggestions as $suggestionIndex => $suggestion) : ?>
            <?php
            $suggestionId = (int) ($suggestion['id'] ?? 0);
            $suggestionKey = $suggestionId > 0 ? (string) $suggestionId : ('tmp-' . (int) $suggestionIndex);
            $suggestionDisplayId = $suggestionId > 0 ? (string) $suggestionId : $t('sem ID');
            $suggestionTitle = trim((string) ($suggestion['title'] ?? $t('Sugestão')));
            $suggestionTitle = $suggestionTitle !== '' ? $suggestionTitle : $t('Sugestão');
            $sourceType = (string) ($suggestion['source_type'] ?? '');
            $sourceTypeLabels = [
              'kb' => $t('Base de conhecimento'),
              'knowledge_base' => $t('Base de conhecimento'),
              'manual' => $t('Cadastro manual'),
              'manual_review' => $t('Revisão manual'),
              'manual_import' => $t('Importação manual'),
            ];
            $summary = $playbookSuggestionSummary($suggestion);
            $compactSummary = $playbookShortText($summary, 220);
            $firstSteps = $playbookContentValue($suggestion, 'first_steps');
            $whenOpenTicket = $playbookContentValue($suggestion, 'when_open_ticket');
            $requiredData = $playbookContentValue($suggestion, 'required_data');
            $ticketTemplate = is_array($suggestion['ticket_template'] ?? null) ? $suggestion['ticket_template'] : [];
            $questionsAll = array_values(array_filter(array_map('strval', (array) ($suggestion['questions'] ?? []))));
            $keywordsAll = array_values(array_filter(array_map('strval', (array) ($suggestion['keywords'] ?? []))));
            $kbLinks = $playbookKbArticleLinks($suggestion);
            $titleId = 'suggestion-title-' . $suggestionKey;
            $summaryId = 'suggestion-summary-' . $suggestionKey;
            $metaId = 'suggestion-meta-' . $suggestionKey;
            $editId = 'suggestion-edit-' . $suggestionKey;
            ?>
        <li>
          <article class="glpiacessivel-playbook-suggestion-card glpiacessivel-playbook-suggestion-card-compact" aria-labelledby="<?= glpiacessivel_e($titleId) ?>" aria-describedby="<?= glpiacessivel_e($summaryId . ' ' . $metaId) ?>">
            <div class="glpiacessivel-playbook-suggestion-header">
              <div>
                <p class="glpiacessivel-eyebrow">
              <?= glpiacessivel_e(sprintf($t('Sugestão #%s'), $suggestionDisplayId)) ?>
              | <?= glpiacessivel_e((string) ($sourceTypeLabels[$sourceType] ?? $t('Fonte não informada'))) ?>
                </p>
                <h3 id="<?= glpiacessivel_e($titleId) ?>" class="glpiacessivel-playbook-suggestion-title"><?= glpiacessivel_e($suggestionTitle) ?></h3>
              </div>
              <span class="glpiacessivel-badge glpiacessivel-badge-status-neutral">
                <?= glpiacessivel_e(sprintf($t('Confiança: %s'), $playbookConfidenceLabel($suggestion['confidence'] ?? null))) ?>
              </span>
            </div>

            <p id="<?= glpiacessivel_e($summaryId) ?>" class="glpiacessivel-playbook-suggestion-summary glpiacessivel-playbook-suggestion-summary-compact">
              <?= glpiacessivel_e($compactSummary) ?>
            </p>

            <dl id="<?= glpiacessivel_e($metaId) ?>" class="glpiacessivel-playbook-suggestion-meta glpiacessivel-playbook-suggestion-meta-compact">
              <div>
                <dt><?= glpiacessivel_e($t('Categoria')) ?></dt>
            <dd><?= glpiacessivel_e((string) ($suggestion['category_hint'] ?? $t('Não informada'))) ?></dd>
              </div>
              <div>
                <dt><?= glpiacessivel_e($t('Grupo')) ?></dt>
            <dd><?= glpiacessivel_e((string) ($suggestion['group_hint'] ?? $t('Não informado'))) ?></dd>
              </div>
              <div>
                <dt><?= glpiacessivel_e($t('Termos')) ?></dt>
                <dd><?= count($keywordsAll) ?></dd>
              </div>
              <div>
                <dt><?= glpiacessivel_e($t('Perguntas')) ?></dt>
                <dd><?= count($questionsAll) ?></dd>
              </div>
              <div>
                <dt><?= glpiacessivel_e($t('Artigos KB')) ?></dt>
                <dd><?= count($kbLinks) ?></dd>
              </div>
            </dl>

            <div class="glpiacessivel-playbook-suggestion-panels" aria-label="<?= glpiacessivel_e($t('Revisão da sugestão')) ?>">
              <details class="glpiacessivel-playbook-suggestion-details">
                <summary><?= glpiacessivel_e($t('Ver detalhes')) ?></summary>
                <dl class="glpiacessivel-playbook-suggestion-meta">
                  <div>
                    <dt><?= glpiacessivel_e($t('Intenção')) ?></dt>
                <dd><?= glpiacessivel_e((string) ($suggestion['intent'] ?? $t('Não informada'))) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Resposta completa')) ?></dt>
                <dd><?= glpiacessivel_e($summary !== '' ? $summary : $t('Não informada')) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Primeiros passos')) ?></dt>
                <dd><?= glpiacessivel_e($firstSteps !== '' ? $firstSteps : $t('Não informado')) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Quando abrir chamado')) ?></dt>
                <dd><?= glpiacessivel_e($whenOpenTicket !== '' ? $whenOpenTicket : $t('Não informado')) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Dados a coletar')) ?></dt>
                <dd><?= glpiacessivel_e($requiredData !== '' ? $requiredData : $t('Não informado')) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Modelo ITIL')) ?></dt>
                <dd><?= glpiacessivel_e($ticketTemplate !== [] ? (string) json_encode($ticketTemplate, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : $t('Não informado')) ?></dd>
                  </div>
                </dl>

                <?php if ($keywordsAll !== []) : ?>
                  <h4><?= glpiacessivel_e($t('Termos de acionamento')) ?></h4>
                  <ul class="glpiacessivel-playbook-chip-list">
                    <?php foreach ($keywordsAll as $keyword) : ?>
                      <li><span class="glpiacessivel-playbook-chip"><?= glpiacessivel_e($keyword) ?></span></li>
                    <?php endforeach; ?>
                  </ul>
                <?php endif; ?>

                <?php if ($questionsAll !== []) : ?>
                  <h4><?= glpiacessivel_e($t('Perguntas de triagem')) ?></h4>
                  <ol>
                    <?php foreach ($questionsAll as $question) : ?>
                      <li><?= glpiacessivel_e($question) ?></li>
                    <?php endforeach; ?>
                  </ol>
                <?php endif; ?>

                <?php if ($kbLinks !== []) : ?>
                  <h4><?= glpiacessivel_e($t('Artigos vinculados')) ?></h4>
                  <ul class="glpiacessivel-kb-link-list">
                    <?php foreach ($kbLinks as $kbLink) : ?>
                      <li>
                        <?php if ((int) ($kbLink['id'] ?? 0) > 0) : ?>
                          <a href="<?= glpiacessivel_e(glpiacessivel_url('front/knowledge.php?article=' . (int) $kbLink['id'])) ?>">
                            #<?= (int) $kbLink['id'] ?> - <?= glpiacessivel_e((string) $kbLink['name']) ?>
                          </a>
                        <?php else : ?>
                            <?= glpiacessivel_e((string) $kbLink['name']) ?>
                        <?php endif; ?>
                      </li>
                    <?php endforeach; ?>
                  </ul>
                <?php endif; ?>
              </details>

              <details id="<?= glpiacessivel_e($editId) ?>" class="glpiacessivel-playbook-suggestion-details glpiacessivel-playbook-suggestion-edit">
              <summary><?= glpiacessivel_e($t('Editar sugestão')) ?></summary>
                <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-playbook-form-grid">
                  <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                  <input type="hidden" name="action" value="update_suggestion" />
                  <input type="hidden" name="suggestion_id" value="<?= $suggestionId ?>" />

                  <div class="glpiacessivel-field span-2">
                    <label for="suggestion-name-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Nome do roteiro')) ?></label>
                    <input id="suggestion-name-<?= glpiacessivel_e($suggestionKey) ?>" name="name" type="text" value="<?= glpiacessivel_e($suggestionTitle) ?>" />
                  </div>

                  <div class="glpiacessivel-field">
                    <label for="suggestion-intent-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Intenção')) ?></label>
                    <input id="suggestion-intent-<?= glpiacessivel_e($suggestionKey) ?>" name="intent" type="text" value="<?= glpiacessivel_e((string) ($suggestion['intent'] ?? 'kb_recomendar_contextual')) ?>" />
                  </div>

                  <div class="glpiacessivel-field">
                    <label for="suggestion-category-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Categoria sugerida')) ?></label>
                    <input id="suggestion-category-<?= glpiacessivel_e($suggestionKey) ?>" name="category_hint" type="text" value="<?= glpiacessivel_e((string) ($suggestion['category_hint'] ?? '')) ?>" />
                  </div>

                  <div class="glpiacessivel-field">
                    <label for="suggestion-group-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Grupo sugerido')) ?></label>
                    <input id="suggestion-group-<?= glpiacessivel_e($suggestionKey) ?>" name="group_hint" type="text" value="<?= glpiacessivel_e((string) ($suggestion['group_hint'] ?? '')) ?>" />
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-summary-field-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Resposta resumida')) ?></label>
                    <textarea id="suggestion-summary-field-<?= glpiacessivel_e($suggestionKey) ?>" name="answer_summary" rows="4"><?= glpiacessivel_e($playbookContentValue($suggestion, 'answer_summary')) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-first-steps-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Primeiros passos')) ?></label>
                    <textarea id="suggestion-first-steps-<?= glpiacessivel_e($suggestionKey) ?>" name="first_steps" rows="3"><?= glpiacessivel_e($firstSteps) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-when-ticket-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Quando abrir chamado')) ?></label>
                    <textarea id="suggestion-when-ticket-<?= glpiacessivel_e($suggestionKey) ?>" name="when_open_ticket" rows="3"><?= glpiacessivel_e($whenOpenTicket) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-required-data-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Dados a coletar')) ?></label>
                    <textarea id="suggestion-required-data-<?= glpiacessivel_e($suggestionKey) ?>" name="required_data" rows="3"><?= glpiacessivel_e($requiredData) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-keywords-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Palavras-chave')) ?></label>
                    <textarea id="suggestion-keywords-<?= glpiacessivel_e($suggestionKey) ?>" name="keywords" rows="4"><?= glpiacessivel_e($playbookLines($keywordsAll)) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-questions-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Perguntas de validação')) ?></label>
                    <textarea id="suggestion-questions-<?= glpiacessivel_e($suggestionKey) ?>" name="questions" rows="4"><?= glpiacessivel_e($playbookLines($questionsAll)) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-kb-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Artigos da base associados')) ?></label>
                    <textarea id="suggestion-kb-<?= glpiacessivel_e($suggestionKey) ?>" name="kb_articles" rows="4"><?= glpiacessivel_e($playbookKbArticles($suggestion)) ?></textarea>
                    <p class="glpiacessivel-field-hint"><?= glpiacessivel_e($t('Informe um artigo por linha. Exemplo: 123 | VPN - acesso remoto.')) ?></p>
                  </div>

                  <div class="glpiacessivel-playbook-actions span-3">
                  <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action" aria-label="<?= glpiacessivel_e(sprintf($t('Salvar edição da sugestão %s: %s'), $suggestionDisplayId, $suggestionTitle)) ?>"><?= glpiacessivel_e($t('Salvar edição')) ?></button>
                  </div>
                </form>
              </details>
            </div>

            <div class="glpiacessivel-playbook-suggestion-actions">
              <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" data-glpiacessivel-critical-form data-critical-title="<?= glpiacessivel_e($t('Confirmar aprovação de roteiro')) ?>" data-critical-message="<?= glpiacessivel_e(sprintf($t('Revise antes de publicar a sugestão "%s" como roteiro ativo de %s.'), $suggestionTitle, $chatbotDisplayName)) ?>" data-critical-consequence="<?= glpiacessivel_e($t('Roteiros aprovados podem ser usados nas respostas do chatbot.')) ?>">
                <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                <input type="hidden" name="action" value="approve" />
                <input type="hidden" name="critical_confirmed" value="0" />
                <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['approve'] ?? '')) ?>" />
                <input type="hidden" name="suggestion_id" value="<?= $suggestionId ?>" />
                <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action" aria-label="<?= glpiacessivel_e(sprintf($t('Aprovar sugestão %s: %s'), $suggestionDisplayId, $suggestionTitle)) ?>"><?= glpiacessivel_e($t('Aprovar')) ?></button>
              </form>
              <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" data-glpiacessivel-critical-form data-critical-title="<?= glpiacessivel_e($t('Confirmar rejeição de sugestão')) ?>" data-critical-message="<?= glpiacessivel_e(sprintf($t('Revise antes de rejeitar a sugestão "%s".'), $suggestionTitle)) ?>" data-critical-consequence="<?= glpiacessivel_e($t('A sugestão deixa a fila de revisão.')) ?>">
                <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                <input type="hidden" name="action" value="reject" />
                <input type="hidden" name="critical_confirmed" value="0" />
                <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['reject'] ?? '')) ?>" />
                <input type="hidden" name="suggestion_id" value="<?= $suggestionId ?>" />
                <button type="submit" class="glpiacessivel-button glpiacessivel-button-danger glpiacessivel-danger-action" aria-label="<?= glpiacessivel_e(sprintf($t('Rejeitar sugestão %s: %s'), $suggestionDisplayId, $suggestionTitle)) ?>"><?= glpiacessivel_e($t('Rejeitar')) ?></button>
              </form>
            </div>
          </article>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="approved-title">
  <h2 id="approved-title"><?= glpiacessivel_e($t('Roteiros aprovados')) ?></h2>
  <p>
      <?= glpiacessivel_e(sprintf($t('Somente roteiros ativos entram nas respostas de %s. Roteiros inativos ficam preservados para referência, mas não são usados pelo chatbot.'), $chatbotDisplayName)) ?>
  </p>

  <?php if (empty($playbooks)) : ?>
    <p><?= glpiacessivel_e($t('Nenhum roteiro aprovado ainda.')) ?></p>
  <?php else : ?>
    <div class="glpiacessivel-table-wrap glpiacessivel-table-wrapper">
      <table class="glpiacessivel-table">
        <thead>
          <tr>
            <th scope="col"><?= glpiacessivel_e($t('Nome')) ?></th>
            <th scope="col"><?= glpiacessivel_e($t('Estado')) ?></th>
            <th scope="col"><?= glpiacessivel_e($t('Intenção')) ?></th>
            <th scope="col"><?= glpiacessivel_e($t('Categoria')) ?></th>
            <th scope="col"><?= glpiacessivel_e($t('Artigos da base')) ?></th>
            <th scope="col"><?= glpiacessivel_e($t('Palavras-chave')) ?></th>
            <th scope="col"><?= glpiacessivel_e($t('Ações')) ?></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ((array) $playbooks as $playbook) : ?>
                <?php
                $playbookId = (int) ($playbook['id'] ?? 0);
                $isActive = !empty($playbook['is_active']);
                $kbLinks = $playbookKbArticleLinks($playbook);
                ?>
            <tr>
              <td><?= glpiacessivel_e((string) ($playbook['name'] ?? '')) ?></td>
              <td>
                <span class="glpiacessivel-badge <?= $isActive ? 'glpiacessivel-badge-state-active' : 'glpiacessivel-badge-state-inactive' ?>">
                  <?= glpiacessivel_e($isActive ? $t('Ativo') : $t('Inativo')) ?>
                </span>
              </td>
              <td><?= glpiacessivel_e((string) ($playbook['intent'] ?? '')) ?></td>
              <td><?= glpiacessivel_e((string) ($playbook['category_hint'] ?? '')) ?></td>
              <td>
                <?php if ($kbLinks === []) : ?>
                  <span class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Sem artigo vinculado')) ?></span>
                <?php else : ?>
                  <ul class="glpiacessivel-kb-link-list">
                    <?php foreach (array_slice($kbLinks, 0, 3) as $kbLink) : ?>
                      <li>
                        <?php if ((int) ($kbLink['id'] ?? 0) > 0) : ?>
                          <a href="<?= glpiacessivel_e(glpiacessivel_url('front/knowledge.php?article=' . (int) $kbLink['id'])) ?>">
                            #<?= (int) $kbLink['id'] ?> - <?= glpiacessivel_e((string) $kbLink['name']) ?>
                          </a>
                        <?php else : ?>
                            <?= glpiacessivel_e((string) $kbLink['name']) ?>
                        <?php endif; ?>
                      </li>
                    <?php endforeach; ?>
                  </ul>
                    <?php if (count($kbLinks) > 3) : ?>
                        <?php $additionalArticleCount = count($kbLinks) - 3; ?>
                    <span class="glpiacessivel-help-text"><?= glpiacessivel_e(sprintf(
                        _n('+%d artigo', '+%d artigos', $additionalArticleCount, 'glpiacessivel'),
                        $additionalArticleCount
                    )) ?></span>
                    <?php endif; ?>
                <?php endif; ?>
              </td>
              <td><?= glpiacessivel_e(implode(', ', array_slice((array) ($playbook['keywords'] ?? []), 0, 8))) ?></td>
              <td>
                <details class="glpiacessivel-playbook-edit">
                  <summary><?= glpiacessivel_e($t('Editar roteiro')) ?></summary>
                  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-form-grid">
                    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                    <input type="hidden" name="action" value="update_playbook" />
                    <input type="hidden" name="playbook_id" value="<?= $playbookId ?>" />

                    <label for="playbook-name-<?= $playbookId ?>"><?= glpiacessivel_e($t('Nome')) ?></label>
                    <input id="playbook-name-<?= $playbookId ?>" name="name" type="text" value="<?= glpiacessivel_e((string) ($playbook['name'] ?? '')) ?>" />

                    <label for="playbook-status-<?= $playbookId ?>"><?= glpiacessivel_e($t('Estado')) ?></label>
                    <select id="playbook-status-<?= $playbookId ?>" name="status">
                      <option value="active" <?= $isActive ? 'selected' : '' ?>><?= glpiacessivel_e($t('Ativo no chatbot')) ?></option>
                      <option value="pending"><?= glpiacessivel_e($t('Voltar para pendente')) ?></option>
                      <option value="inactive" <?= !$isActive ? 'selected' : '' ?>><?= glpiacessivel_e($t('Inativo')) ?></option>
                    </select>

                    <label for="playbook-intent-<?= $playbookId ?>"><?= glpiacessivel_e($t('Intenção')) ?></label>
                    <input id="playbook-intent-<?= $playbookId ?>" name="intent" type="text" value="<?= glpiacessivel_e((string) ($playbook['intent'] ?? '')) ?>" />

                    <label for="playbook-category-<?= $playbookId ?>"><?= glpiacessivel_e($t('Categoria sugerida')) ?></label>
                    <input id="playbook-category-<?= $playbookId ?>" name="category_hint" type="text" value="<?= glpiacessivel_e((string) ($playbook['category_hint'] ?? '')) ?>" />

                    <label for="playbook-group-<?= $playbookId ?>"><?= glpiacessivel_e($t('Grupo sugerido')) ?></label>
                    <input id="playbook-group-<?= $playbookId ?>" name="group_hint" type="text" value="<?= glpiacessivel_e((string) ($playbook['group_hint'] ?? '')) ?>" />

                    <label for="playbook-keywords-<?= $playbookId ?>"><?= glpiacessivel_e($t('Palavras-chave')) ?></label>
                    <textarea id="playbook-keywords-<?= $playbookId ?>" name="keywords" rows="5"><?= glpiacessivel_e($playbookLines($playbook['keywords'] ?? [])) ?></textarea>

                    <label for="playbook-questions-<?= $playbookId ?>"><?= glpiacessivel_e($t('Perguntas de validação')) ?></label>
                    <textarea id="playbook-questions-<?= $playbookId ?>" name="questions" rows="5"><?= glpiacessivel_e($playbookLines($playbook['questions'] ?? [])) ?></textarea>

                    <label for="playbook-kb-<?= $playbookId ?>"><?= glpiacessivel_e($t('Artigos da base associados')) ?></label>
                    <textarea id="playbook-kb-<?= $playbookId ?>" name="kb_articles" rows="5" aria-describedby="playbook-kb-help-<?= $playbookId ?>"><?= glpiacessivel_e($playbookKbArticles($playbook)) ?></textarea>
                    <p id="playbook-kb-help-<?= $playbookId ?>" class="glpiacessivel-field-hint">
                      <?= glpiacessivel_e($t('Informe um artigo por linha no formato ID | Título. Esses artigos podem ser apresentados como referência na resposta.')) ?>
                    </p>

                    <label for="playbook-summary-<?= $playbookId ?>"><?= glpiacessivel_e($t('Resposta resumida')) ?></label>
                    <textarea id="playbook-summary-<?= $playbookId ?>" name="answer_summary" rows="5"><?= glpiacessivel_e($playbookSummary($playbook)) ?></textarea>

                    <div class="glpiacessivel-field" style="grid-column:1 / -1;">
                      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action"><?= glpiacessivel_e($t('Salvar alterações')) ?></button>
                    </div>
                  </form>

                  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-playbook-delete" data-glpiacessivel-critical-form data-critical-title="<?= glpiacessivel_e($t('Confirmar exclusão de roteiro')) ?>" data-critical-message="<?= glpiacessivel_e(sprintf($t('Revise antes de excluir este roteiro aprovado de %s.'), $chatbotDisplayName)) ?>" data-critical-consequence="<?= glpiacessivel_e($t('A exclusão remove o roteiro da base operacional do chatbot.')) ?>">
                    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                    <input type="hidden" name="action" value="delete_playbook" />
                    <input type="hidden" name="playbook_id" value="<?= $playbookId ?>" />
                    <input type="hidden" name="critical_confirmed" value="0" />
                    <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['delete_playbook'] ?? '')) ?>" />
                    <button type="submit" class="glpiacessivel-button glpiacessivel-button-danger glpiacessivel-danger-action"><?= glpiacessivel_e($t('Excluir roteiro')) ?></button>
                  </form>
                </details>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="import-title">
  <h2 id="import-title"><?= glpiacessivel_e($t('Importar roteiros em JSON')) ?></h2>
  <p>
    <?= glpiacessivel_e($t('Use esta opção para transportar roteiros entre ambientes sem varrer novamente a base. Cada item pode informar o estado active, pending ou inactive. Se não informar, será usado o estado padrão abaixo.')) ?>
  </p>

  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" enctype="multipart/form-data">
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
    <input type="hidden" name="action" value="import_json" />

    <label for="playbooks-import-status"><?= glpiacessivel_e($t('Estado padrão dos itens importados')) ?></label>
    <select id="playbooks-import-status" name="import_status">
      <option value="active"><?= glpiacessivel_e($t('Ativo no chatbot')) ?></option>
      <option value="pending"><?= glpiacessivel_e($t('Pendente para análise')) ?></option>
      <option value="inactive"><?= glpiacessivel_e($t('Inativo')) ?></option>
    </select>

    <label for="playbooks-json-file"><?= glpiacessivel_e($t('Arquivo JSON de roteiros')) ?></label>
    <input id="playbooks-json-file" name="playbooks_json_file" type="file" accept="application/json,.json" aria-describedby="playbooks-json-help" />

    <label for="playbooks-json"><?= glpiacessivel_e($t('Ou cole o JSON de roteiros')) ?></label>
    <textarea id="playbooks-json" name="playbooks_json" rows="8" aria-describedby="playbooks-json-help"></textarea>
    <p id="playbooks-json-help" class="glpiacessivel-field-hint"><?= glpiacessivel_e($t('Aceita a exportação do próprio plugin ou um objeto com a chave playbooks, items ou data. Se o arquivo e o texto forem informados, o arquivo terá prioridade.')) ?></p>
    <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action"><?= glpiacessivel_e($t('Importar roteiros')) ?></button>
  </form>
</section>
