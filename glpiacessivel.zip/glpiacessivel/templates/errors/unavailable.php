<section class="glpiacessivel-section-head" aria-labelledby="module-unavailable-title">
  <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(__('Disponibilidade do portal', 'glpiacessivel')) ?></p>
  <h2 id="module-unavailable-title" tabindex="-1" data-glpiacessivel-focus-alert>
    <?= glpiacessivel_e((string) ($title ?? __('Funcionalidade indisponível', 'glpiacessivel'))) ?>
  </h2>
  <p><?= glpiacessivel_e((string) ($message ?? __('Esta funcionalidade não está disponível neste portal no momento.', 'glpiacessivel'))) ?></p>
</section>

<section
  class="glpiacessivel-alert glpiacessivel-alert-warning"
  role="region"
  aria-labelledby="module-unavailable-guidance"
>
  <h3 id="module-unavailable-guidance"><?= glpiacessivel_e(__('O que fazer agora', 'glpiacessivel')) ?></h3>
  <p><?= glpiacessivel_e(__('Volte ao portal para acessar as funcionalidades liberadas. As permissões do seu perfil GLPI continuam sendo respeitadas.', 'glpiacessivel')) ?></p>
  <p>
    <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e((string) ($return_url ?? glpiacessivel_url('front/acessivel.php'))) ?>">
      <?= glpiacessivel_e(__('Voltar ao portal acessível', 'glpiacessivel')) ?>
    </a>
  </p>
</section>
