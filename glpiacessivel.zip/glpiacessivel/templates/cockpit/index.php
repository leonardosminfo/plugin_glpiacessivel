<?php

declare(strict_types=1);

$metrics = is_array($metrics ?? null) ? $metrics : [];
$escape = static fn(string $text): string => glpiacessivel_e($text);

$definitions = [
    'total_open' => [
        'label' => glpiacessivel_t('Chamados abertos'),
        'description' => glpiacessivel_t('Chamados novos, atribuídos, planejados ou pendentes.'),
        'period' => glpiacessivel_t('Situação no momento da atualização'),
        'scope' => glpiacessivel_t('Chamados que o perfil ativo pode visualizar'),
        'link_label' => glpiacessivel_t('Ver chamados abertos'),
        'fallback_link_label' => glpiacessivel_t('Abrir lista geral de chamados'),
        'fallback_url' => glpiacessivel_url('front/tickets.php'),
    ],
    'pending' => [
        'label' => glpiacessivel_t('Chamados pendentes'),
        'description' => glpiacessivel_t('Chamados que aguardam informação, decisão ou evento externo.'),
        'period' => glpiacessivel_t('Situação no momento da atualização'),
        'scope' => glpiacessivel_t('Chamados que o perfil ativo pode visualizar'),
        'link_label' => glpiacessivel_t('Ver chamados pendentes'),
        'fallback_link_label' => glpiacessivel_t('Abrir lista com status pendente'),
        'fallback_url' => glpiacessivel_url('front/tickets.php?status=4'),
    ],
    'solved_today' => [
        'label' => glpiacessivel_t('Chamados solucionados hoje'),
        'description' => glpiacessivel_t('Chamados solucionados na data e no fuso horário informados.'),
        'period' => glpiacessivel_t('Hoje, no fuso horário informado'),
        'scope' => glpiacessivel_t('Chamados que o perfil ativo pode visualizar'),
        'link_label' => glpiacessivel_t('Ver chamados solucionados hoje'),
        'fallback_link_label' => glpiacessivel_t('Abrir lista com status solucionado'),
        'fallback_url' => glpiacessivel_url('front/tickets.php?status=5'),
    ],
    'mine_open' => [
        'label' => glpiacessivel_t('Meus chamados abertos'),
        'description' => glpiacessivel_t(
            'Chamados abertos em que você participa como requerente, técnico responsável ou observador.'
        ),
        'period' => glpiacessivel_t('Situação no momento da atualização'),
        'scope' => glpiacessivel_t('Participação do usuário autenticado'),
        'link_label' => glpiacessivel_t('Ver meus chamados abertos'),
        'fallback_link_label' => glpiacessivel_t('Abrir lista dos meus chamados'),
        'fallback_url' => glpiacessivel_url('front/tickets.php?scope=mine'),
    ],
    'group_open' => [
        'label' => glpiacessivel_t('Chamados dos grupos responsáveis'),
        'description' => glpiacessivel_t(
            'Chamados abertos atribuídos a pelo menos um grupo responsável do qual você faz parte.'
        ),
        'period' => glpiacessivel_t('Situação no momento da atualização'),
        'scope' => glpiacessivel_t('Grupos responsáveis do usuário autenticado'),
        'link_label' => glpiacessivel_t('Ver chamados dos grupos responsáveis'),
        'fallback_link_label' => glpiacessivel_t('Abrir lista dos chamados dos grupos responsáveis'),
        'fallback_url' => glpiacessivel_url('front/tickets.php?scope=group&group_by=group'),
    ],
];

$scopeLabels = [
    'allowed' => glpiacessivel_t('Chamados que o perfil ativo pode visualizar'),
    'mine' => glpiacessivel_t('Participação do usuário autenticado'),
    'group' => glpiacessivel_t('Grupos responsáveis do usuário autenticado'),
];

$nestedMetrics = [];
foreach (['items', 'metrics'] as $containerKey) {
    if (is_array($metrics[$containerKey] ?? null)) {
        $nestedMetrics = $metrics[$containerKey];
        break;
    }
}

$firstString = static function (array $source, array $keys): string {
    foreach ($keys as $key) {
        $value = trim((string) ($source[$key] ?? ''));
        if ($value !== '') {
            return $value;
        }
    }
    return '';
};

$safeTimezone = static function (string $timezone): string {
    $timezone = trim($timezone);
    if ($timezone === '' || strlen($timezone) > 80) {
        return '';
    }
    try {
        new DateTimeZone($timezone);
        return $timezone;
    } catch (Throwable $e) {
        return '';
    }
};

$formatTimestamp = static function (string $timestamp, string $timezone): string {
    if ($timestamp === '' || strlen($timestamp) > 80) {
        return '';
    }
    try {
        $date = new DateTimeImmutable($timestamp);
        if ($timezone !== '') {
            $date = $date->setTimezone(new DateTimeZone($timezone));
        }
        return $date->format('d/m/Y H:i');
    } catch (Throwable $e) {
        return '';
    }
};

$safeDrilldownUrl = static function (string $candidate): string {
    $candidate = trim($candidate);
    if (
        $candidate === ''
        || strlen($candidate) > 2048
        || preg_match('/[\x00-\x1F\x7F]/', $candidate) === 1
        || str_starts_with($candidate, '//')
        || str_contains($candidate, '\\')
        || !str_starts_with($candidate, '/')
    ) {
        return '';
    }
    return $candidate;
};

$globalTimestamp = $firstString($metrics, ['generated_at', 'data_as_of', 'updated_at']);
$globalTimezone = $safeTimezone($firstString($metrics, ['timezone']));
$resolvedMetrics = [];

foreach ($definitions as $key => $definition) {
    $raw = array_key_exists($key, $metrics)
        ? $metrics[$key]
        : ($nestedMetrics[$key] ?? null);
    $entry = is_array($raw) ? $raw : [];
    $legacyScalar = !is_array($raw) && is_numeric($raw);
    $rawValue = $legacyScalar ? $raw : ($entry['value'] ?? ($entry['count'] ?? null));
    $completeness = strtolower(trim((string) ($entry['completeness'] ?? '')));
    $available = $legacyScalar || (($entry['available'] ?? null) === true);
    if (!array_key_exists('available', $entry) && is_numeric($rawValue) && $completeness !== 'unknown') {
        $available = true;
    }
    if (
        !in_array($completeness, ['', 'exact'], true)
        || $rawValue === null
        || !is_numeric($rawValue)
        || (int) $rawValue < 0
    ) {
        $available = false;
    }

    $timestamp = $firstString($entry, ['generated_at', 'data_as_of', 'updated_at']);
    if ($timestamp === '') {
        $timestamp = $globalTimestamp;
    }
    $timezone = $safeTimezone($firstString($entry, ['timezone']));
    if ($timezone === '') {
        $timezone = $globalTimezone;
    }
    $scopeKey = strtolower($firstString($entry, ['scope']));
    $scopeLabel = $scopeLabels[$scopeKey] ?? $definition['scope'];
    $candidateUrl = $firstString($entry, ['drilldown_url', 'url']);
    $drilldownUrl = $safeDrilldownUrl($candidateUrl);
    $specificDrilldown = $available && $drilldownUrl !== '';

    $resolvedMetrics[] = [
        'key' => $key,
        'label' => $definition['label'],
        'description' => $definition['description'],
        'period' => $definition['period'],
        'scope' => $scopeLabel,
        'available' => $available,
        'value' => $available ? (int) $rawValue : null,
        'timestamp_raw' => $timestamp,
        'timestamp' => $formatTimestamp($timestamp, $timezone),
        'timezone' => $timezone,
        'link_label' => $specificDrilldown
            ? $definition['link_label']
            : $definition['fallback_link_label'],
        'url' => $specificDrilldown ? $drilldownUrl : $definition['fallback_url'],
    ];
}

$pageTitle = glpiacessivel_t('Cockpit operacional');
$sectionTitle = glpiacessivel_t('Indicadores do seu escopo de atendimento');
// phpcs:ignore Generic.Files.LineLength.TooLong -- Keep the complete literal available to Gettext extraction.
$unavailableExplanation = glpiacessivel_t('Resultado indisponível significa que não foi possível calcular um valor completo e autorizado. Esse estado nunca é apresentado como zero.');
$genericLinkExplanation = glpiacessivel_t(
    'Quando ele não estiver disponível, o link será identificado como uma lista mais ampla.'
);
?>

<section class="glpiacessivel-section-head" aria-labelledby="cockpit-resumo">
  <p class="glpiacessivel-eyebrow"><?= $escape($pageTitle) ?></p>
  <h2 id="cockpit-resumo"><?= $escape($sectionTitle) ?></h2>
  <p>
    <?= $escape(glpiacessivel_t(
        'Os indicadores consideram somente os chamados que o perfil e a entidade ativos podem visualizar.'
    )) ?>
  </p>
</section>

<h2 id="cockpit-kpis-title" class="glpiacessivel-sr-only"><?= $escape(glpiacessivel_t('Indicadores principais')) ?></h2>
<section class="glpiacessivel-kpis" role="list" aria-labelledby="cockpit-kpis-title" data-glpiacessivel-cockpit-kpis>
  <?php foreach ($resolvedMetrics as $metric) : ?>
        <?php
        $metricId = 'cockpit-kpi-' . $metric['key'];
        $descriptionId = $metricId . '-description';
        $metadataId = $metricId . '-metadata';
        $visualClass = [
            'total_open' => 'glpiacessivel-kpi-open',
            'pending' => 'glpiacessivel-kpi-pending',
            'solved_today' => 'glpiacessivel-kpi-solved',
            'mine_open' => 'glpiacessivel-kpi-mine',
            'group_open' => 'glpiacessivel-kpi-group',
        ][$metric['key']] ?? '';
        ?>
    <article
      role="listitem"
      class="glpiacessivel-kpi <?= $escape($visualClass) ?><?= $metric['available'] ? '' : ' glpiacessivel-kpi-unavailable' ?>"
      aria-labelledby="<?= $escape($metricId) ?>"
      aria-describedby="<?= $escape($descriptionId) ?>"
      data-cockpit-kpi="<?= $escape($metric['key']) ?>"
      data-cockpit-completeness="<?= $metric['available'] ? 'exact' : 'unknown' ?>"
    >
      <h3 id="<?= $escape($metricId) ?>" class="glpiacessivel-kpi-label"><?= $escape($metric['label']) ?></h3>
      <p class="glpiacessivel-kpi-value" data-cockpit-kpi-value>
        <strong><?= $metric['available']
          ? (int) $metric['value']
                    : $escape(glpiacessivel_t('Resultado indisponível')) ?></strong>
      </p>
      <p id="<?= $escape($descriptionId) ?>"><?= $escape($metric['description']) ?></p>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= $escape($metric['url']) ?>">
        <?= $escape($metric['link_label']) ?>
      </a>
      <details class="glpiacessivel-kpi-details">
        <summary><?= $escape(glpiacessivel_t('Detalhes do indicador')) ?></summary>
        <dl id="<?= $escape($metadataId) ?>" class="glpiacessivel-kpi-metadata">
        <div>
          <dt><?= $escape(glpiacessivel_t('Período')) ?></dt>
          <dd><?= $escape($metric['period']) ?></dd>
        </div>
        <div>
          <dt><?= $escape(glpiacessivel_t('Escopo')) ?></dt>
          <dd><?= $escape($metric['scope']) ?></dd>
        </div>
        <div>
          <dt><?= $escape(glpiacessivel_t('Atualização')) ?></dt>
          <dd>
            <?php if ($metric['timestamp'] !== '') : ?>
              <time datetime="<?= $escape($metric['timestamp_raw']) ?>"><?= $escape($metric['timestamp']) ?></time>
            <?php else : ?>
                <?= $escape(glpiacessivel_t('Atualização não informada')) ?>
            <?php endif; ?>
          </dd>
        </div>
        <div>
          <dt><?= $escape(glpiacessivel_t('Fuso horário')) ?></dt>
          <dd><?= $escape($metric['timezone'] !== ''
            ? $metric['timezone']
              : glpiacessivel_t('Fuso horário não informado')) ?></dd>
        </div>
        </dl>
      </details>
    </article>
  <?php endforeach; ?>
</section>

<section class="glpiacessivel-note" aria-labelledby="cockpit-orientacoes">
  <h2 id="cockpit-orientacoes"><?= $escape(glpiacessivel_t('Como interpretar os indicadores')) ?></h2>
  <p><?= $escape($unavailableExplanation) ?></p>
  <p><?= $escape(glpiacessivel_t('O detalhamento específico usa os mesmos critérios do indicador.')) ?></p>
  <p><?= $escape($genericLinkExplanation) ?></p>
</section>
