<?php
$overview = is_array($overview ?? null) ? $overview : [];
$filters = is_array($overview['filters'] ?? null) ? $overview['filters'] : [];
$result = is_array($overview['result'] ?? null) ? $overview['result'] : ['items' => [], 'total' => 0, 'page' => 1, 'pages' => 1, 'page_size' => 10];
$article = is_array($overview['article'] ?? null) ? $overview['article'] : null;
$categories = is_array($overview['categories'] ?? null) ? $overview['categories'] : [];
$homeLists = is_array($overview['home_lists'] ?? null) ? $overview['home_lists'] : [];

$query = (string) ($filters['query'] ?? '');
$categoryId = (int) ($filters['category_id'] ?? 0);
$publicOnly = !empty($filters['public_only']);
$page = max(1, (int) ($result['page'] ?? 1));
$pages = max(1, (int) ($result['pages'] ?? 1));
$total = max(0, (int) ($result['total'] ?? 0));
$pageSize = max(1, (int) ($result['page_size'] ?? 10));
$items = is_array($result['items'] ?? null) ? $result['items'] : [];
$hasSearch = ($query !== '' || $categoryId > 0);
$showHome = !$hasSearch && $article === null;
$baseUrl = glpiacessivel_url('front/knowledge.php');
$homeBaseParams = $publicOnly ? ['public' => '1'] : [];

if (!function_exists('glpiacessivel_kb_query')) {
    function glpiacessivel_kb_query(array $changes = []): string
    {
        global $query, $categoryId, $publicOnly, $page;

        $params = [
            'q' => $query,
            'category' => $categoryId > 0 ? $categoryId : null,
            'public' => $publicOnly ? '1' : null,
            'page' => $page > 1 ? $page : null,
        ];

        foreach ($changes as $key => $value) {
            $params[$key] = $value;
        }

        $params = array_filter(
            $params,
            static fn($value): bool => !($value === null || $value === '' || $value === false)
        );

        return http_build_query($params);
    }
}

if (!function_exists('glpiacessivel_kb_mark')) {
    function glpiacessivel_kb_mark(string $text, string $queryString): string
    {
        $escaped = glpiacessivel_e($text);
        $terms = array_values(array_filter(preg_split('/\s+/u', trim($queryString)) ?: []));
        foreach ($terms as $term) {
            if (mb_strlen($term) < 2) {
                continue;
            }

            $escapedTerm = preg_quote(glpiacessivel_e($term), '/');
            $escaped = preg_replace('/(' . $escapedTerm . ')/iu', '<mark>$1</mark>', $escaped) ?? $escaped;
        }

        return nl2br($escaped);
    }
}

if (!function_exists('glpiacessivel_kb_home_list')) {
    function glpiacessivel_kb_home_list(array $items, string $emptyLabel, string $baseUrl, array $baseParams = []): void
    {
        if ($items === []) {
            echo '<li>' . glpiacessivel_e($emptyLabel) . '</li>';
            return;
        }

        foreach ($items as $item) {
            $query = http_build_query(array_merge($baseParams, ['article' => (int) ($item['id'] ?? 0)]));
            $href = $baseUrl . ($query !== '' ? '?' . $query : '');
            echo '<li>';
            echo '<a href="' . glpiacessivel_e($href) . '">' . glpiacessivel_e((string) ($item['assunto'] ?? glpiacessivel_t('Artigo'))) . '</a>';
            echo '<small>' . glpiacessivel_e((string) ($item['category'] ?? glpiacessivel_t('Sem categoria'))) . '</small>';
            echo '</li>';
        }
    }
}

$currentStart = $total === 0 ? 0 : (($page - 1) * $pageSize) + 1;
$currentEnd = $total === 0 ? 0 : min($total, $page * $pageSize);
$resultsSummary = sprintf(
    glpiacessivel_n(
        'Exibindo %1$d–%2$d de %3$d artigo.',
        'Exibindo %1$d–%2$d de %3$d artigos.',
        $total
    ),
    $currentStart,
    $currentEnd,
    $total
);
?>

<section class="glpiacessivel-section-head" aria-labelledby="kb-titulo">
  <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Consulta orientada')) ?></p>
  <h2 id="kb-titulo"><?= glpiacessivel_e(glpiacessivel_t('Base de conhecimento')) ?></h2>
  <p><?= glpiacessivel_e(glpiacessivel_t('Consulte orientações diretamente no GLPI, respeitando seu perfil, sua entidade e as regras de acesso.')) ?></p>
</section>

<section class="glpiacessivel-card glpiacessivel-kb-card" aria-labelledby="kb-busca-titulo">
  <div class="glpiacessivel-kb-header">
    <div>
      <h3 id="kb-busca-titulo"><?= glpiacessivel_e(glpiacessivel_t('Pesquisar artigos e FAQ')) ?></h3>
      <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Pesquise por assunto ou selecione uma categoria. O artigo completo aparece na mesma tela.')) ?></p>
    </div>
    <div class="glpiacessivel-kb-header-actions">
      <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" id="glpiacessivel-kb-toggle-a11y" aria-expanded="false" aria-controls="glpiacessivel-kb-a11y">
        <?= glpiacessivel_e(glpiacessivel_t('Acessibilidade')) ?>
      </button>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($baseUrl . ($publicOnly ? '?public=1' : '')) ?>">
        <?= glpiacessivel_e(glpiacessivel_t('Atualizar')) ?>
      </a>
    </div>
  </div>

  <form method="get" action="<?= glpiacessivel_e($baseUrl) ?>" class="glpiacessivel-kb-filters" role="search" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Pesquisar artigos e FAQ')) ?>">
    <div class="glpiacessivel-field glpiacessivel-kb-field-search">
      <label for="q"><?= glpiacessivel_e(glpiacessivel_t('Busca por assunto ou conteúdo')) ?></label>
      <input id="q" type="text" name="q" value="<?= glpiacessivel_e($query) ?>" placeholder="<?= glpiacessivel_e(glpiacessivel_t('Ex.: certificado digital')) ?>" />
    </div>

    <div class="glpiacessivel-field glpiacessivel-kb-field-category">
      <label for="category"><?= glpiacessivel_e(glpiacessivel_t('Categoria')) ?></label>
      <select id="category" name="category">
        <option value="0"><?= glpiacessivel_e(glpiacessivel_t('Todas as categorias')) ?></option>
        <?php foreach ($categories as $category): ?>
          <option value="<?= (int) $category['id'] ?>"<?= ((int) $category['id'] === $categoryId) ? ' selected' : '' ?>>
            <?= glpiacessivel_e((string) $category['label']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="glpiacessivel-kb-filter-options">
      <label class="glpiacessivel-kb-check glpiacessivel-kb-field-public">
        <input type="checkbox" name="public" value="1"<?= $publicOnly ? ' checked' : '' ?> />
        <?= glpiacessivel_e(glpiacessivel_t('Somente FAQ pública')) ?>
      </label>
    </div>

    <div class="glpiacessivel-kb-filter-actions">
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary"><?= glpiacessivel_e(glpiacessivel_t('Buscar')) ?></button>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($baseUrl) ?>"><?= glpiacessivel_e(glpiacessivel_t('Limpar')) ?></a>
    </div>
  </form>

  <div id="glpiacessivel-kb-a11y" class="glpiacessivel-kb-a11y" hidden>
    <label class="glpiacessivel-kb-check">
      <input type="checkbox" id="glpiacessivel-kb-compact" checked />
      <?= glpiacessivel_e(glpiacessivel_t('Layout compacto')) ?>
    </label>
    <label class="glpiacessivel-kb-check">
      <input type="checkbox" id="glpiacessivel-kb-highlight" checked />
      <?= glpiacessivel_e(glpiacessivel_t('Destacar termo pesquisado')) ?>
    </label>
  </div>
</section>

<section class="glpiacessivel-card glpiacessivel-kb-article" aria-labelledby="kb-artigo-titulo">
  <div class="glpiacessivel-kb-article-head">
    <h3 id="kb-artigo-titulo"><?= glpiacessivel_e(glpiacessivel_t('Artigo completo')) ?></h3>
    <div class="glpiacessivel-kb-article-actions">
      <?php if ($article !== null): ?>
        <?php if ($hasSearch): ?>
          <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($baseUrl . '?' . glpiacessivel_kb_query(['article' => null])) ?>">
            <?= glpiacessivel_e(glpiacessivel_t('Voltar para os resultados')) ?>
          </a>
        <?php endif; ?>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($baseUrl . ($publicOnly ? '?public=1' : '')) ?>">
          <?= glpiacessivel_e(glpiacessivel_t('Voltar para as listas iniciais')) ?>
        </a>
      <?php endif; ?>
    </div>
  </div>

  <?php if ($article === null): ?>
    <p class="glpiacessivel-empty"><?= glpiacessivel_e(glpiacessivel_t('Selecione um resultado e use a ação “Abrir artigo completo” para carregar os detalhes nesta área.')) ?></p>
  <?php else: ?>
    <article class="glpiacessivel-kb-article-body" tabindex="-1">
      <header class="glpiacessivel-kb-article-meta">
        <div>
          <h4><?= glpiacessivel_e((string) ($article['assunto'] ?? glpiacessivel_t('Artigo'))) ?></h4>
          <p class="glpiacessivel-help-text">
            <?= glpiacessivel_e(glpiacessivel_t('Categoria:')) ?> <?= glpiacessivel_e((string) ($article['category'] ?? glpiacessivel_t('Sem categoria'))) ?>
            <?php if (!empty($article['is_faq'])): ?>
              <span class="glpiacessivel-meta-chip">FAQ</span>
            <?php endif; ?>
          </p>
        </div>
        <p class="glpiacessivel-help-text">
          <?= glpiacessivel_e(glpiacessivel_t('Atualizado em')) ?> <?= glpiacessivel_e((string) ($article['date_mod'] ?? '')) ?>
        </p>
      </header>
      <div class="glpiacessivel-content glpiacessivel-kb-reader">
        <?= (string) ($article['body_html'] ?? '') ?>
      </div>
      <dl class="glpiacessivel-kb-article-grid">
        <div>
          <dt><?= glpiacessivel_e(glpiacessivel_t('Elementos associados')) ?></dt>
          <dd><?= glpiacessivel_e((string) ($article['associados'] ?? glpiacessivel_t('Não informado'))) ?></dd>
        </div>
        <div>
          <dt><?= glpiacessivel_e(glpiacessivel_t('Criado em')) ?></dt>
          <dd><?= glpiacessivel_e((string) ($article['date_creation'] ?? '')) ?></dd>
        </div>
      </dl>
    </article>
  <?php endif; ?>
</section>

<?php if ($showHome): ?>
  <section class="glpiacessivel-card glpiacessivel-kb-home" aria-labelledby="kb-home-title">
    <h3 id="kb-home-title" class="glpiacessivel-sr-only"><?= glpiacessivel_e(glpiacessivel_t('Listas iniciais da base de conhecimento')) ?></h3>
    <div class="glpiacessivel-kb-home-grid">
      <section>
        <h4><?= glpiacessivel_e(glpiacessivel_t('Artigos recentes')) ?></h4>
        <ul class="glpiacessivel-kb-home-list">
          <?php glpiacessivel_kb_home_list((array) ($homeLists['recentes'] ?? []), glpiacessivel_t('Nenhuma entrada recente disponível.'), $baseUrl, $homeBaseParams); ?>
        </ul>
      </section>
      <section>
        <h4><?= glpiacessivel_e(glpiacessivel_t('Artigos atualizados recentemente')) ?></h4>
        <ul class="glpiacessivel-kb-home-list">
          <?php glpiacessivel_kb_home_list((array) ($homeLists['atualizadas'] ?? []), glpiacessivel_t('Nenhum artigo atualizado recentemente.'), $baseUrl, $homeBaseParams); ?>
        </ul>
      </section>
      <section>
        <h4><?= glpiacessivel_e(glpiacessivel_t('Artigos mais consultados')) ?></h4>
        <ul class="glpiacessivel-kb-home-list">
          <?php glpiacessivel_kb_home_list((array) ($homeLists['populares'] ?? []), glpiacessivel_t('Nenhuma questão popular disponível.'), $baseUrl, $homeBaseParams); ?>
        </ul>
      </section>
    </div>
  </section>
<?php endif; ?>

<?php if ($hasSearch): ?>
  <section class="glpiacessivel-card glpiacessivel-kb-results" aria-labelledby="kb-resultados-titulo">
    <div class="glpiacessivel-kb-results-head">
      <div>
        <h3 id="kb-resultados-titulo"><?= glpiacessivel_e(glpiacessivel_t('Resultados')) ?></h3>
        <p class="glpiacessivel-help-text"><?= glpiacessivel_e($resultsSummary) ?></p>
      </div>
      <?php if ($publicOnly): ?>
        <span class="glpiacessivel-meta-chip"><?= glpiacessivel_e(glpiacessivel_t('Somente FAQ pública')) ?></span>
      <?php endif; ?>
    </div>

    <div class="glpiacessivel-table-wrap">
      <table class="glpiacessivel-kb-table">
      <caption class="glpiacessivel-sr-only"><?= glpiacessivel_e(glpiacessivel_t('Tabela de resultados da base de conhecimento')) ?></caption>
        <thead>
          <tr>
            <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Assunto')) ?></th>
            <th scope="col" class="glpiacessivel-kb-col-category"><?= glpiacessivel_e(glpiacessivel_t('Categoria')) ?></th>
            <th scope="col" class="glpiacessivel-kb-col-associated"><?= glpiacessivel_e(glpiacessivel_t('Elementos associados')) ?></th>
            <th scope="col" class="glpiacessivel-kb-col-actions"><?= glpiacessivel_e(glpiacessivel_t('Ações')) ?></th>
          </tr>
        </thead>
        <tbody>
          <?php if ($items === []): ?>
            <tr>
              <td colspan="4"><?= glpiacessivel_e(glpiacessivel_t('Nenhum artigo encontrado para os filtros informados.')) ?></td>
            </tr>
          <?php else: ?>
            <?php foreach ($items as $item): ?>
              <?php $articleQuery = glpiacessivel_kb_query(['article' => (int) ($item['id'] ?? 0)]); ?>
              <tr>
                <td class="glpiacessivel-kb-cell-subject">
                  <strong><?= glpiacessivel_e((string) ($item['assunto'] ?? glpiacessivel_t('Artigo'))) ?></strong>
                  <div class="glpiacessivel-help-text"><?= glpiacessivel_kb_mark((string) ($item['summary'] ?? ''), $query) ?></div>
                </td>
              <td><?= glpiacessivel_e((string) ($item['category'] ?? glpiacessivel_t('Sem categoria'))) ?></td>
              <td><?= glpiacessivel_e((string) ($item['associados'] ?? glpiacessivel_t('Não informado'))) ?></td>
                <td>
                  <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($baseUrl . ($articleQuery !== '' ? '?' . $articleQuery : '')) ?>">
                    <?= glpiacessivel_e(glpiacessivel_t('Abrir artigo completo')) ?>
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <?php if ($pages > 1): ?>
      <nav class="glpiacessivel-pagination glpiacessivel-kb-pagination" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Paginação da base de conhecimento')) ?>">
        <?php if ($page > 1): ?>
          <a href="<?= glpiacessivel_e($baseUrl . '?' . glpiacessivel_kb_query(['page' => $page - 1])) ?>">&laquo; <?= glpiacessivel_e(glpiacessivel_t('Anterior')) ?></a>
        <?php else: ?>
          <span aria-disabled="true">&laquo; <?= glpiacessivel_e(glpiacessivel_t('Anterior')) ?></span>
        <?php endif; ?>

        <span aria-current="page"><?= glpiacessivel_e(sprintf(glpiacessivel_t('Página %1$d de %2$d'), $page, $pages)) ?></span>

        <?php if ($page < $pages): ?>
          <a href="<?= glpiacessivel_e($baseUrl . '?' . glpiacessivel_kb_query(['page' => $page + 1])) ?>"><?= glpiacessivel_e(glpiacessivel_t('Próxima')) ?> &raquo;</a>
        <?php else: ?>
          <span aria-disabled="true"><?= glpiacessivel_e(glpiacessivel_t('Próxima')) ?> &raquo;</span>
        <?php endif; ?>
      </nav>
    <?php endif; ?>
  </section>
<?php endif; ?>

<script>
  (function () {
    var storageKey = 'glpiacessivel-kb-preferences-v1';
    var toggleButton = document.getElementById('glpiacessivel-kb-toggle-a11y');
    var panel = document.getElementById('glpiacessivel-kb-a11y');
    var compact = document.getElementById('glpiacessivel-kb-compact');
    var highlight = document.getElementById('glpiacessivel-kb-highlight');
    var root = document.getElementById('conteudo-principal');

    if (!toggleButton || !panel || !compact || !highlight || !root) {
      return;
    }

    function readPrefs() {
      try {
        var raw = window.localStorage.getItem(storageKey);
        if (!raw) {
          return { compact: true, highlight: true };
        }
        var parsed = JSON.parse(raw);
        return {
          compact: parsed.compact !== false,
          highlight: parsed.highlight !== false
        };
      } catch (error) {
        return { compact: true, highlight: true };
      }
    }

    function writePrefs(state) {
      window.localStorage.setItem(storageKey, JSON.stringify(state));
    }

    function applyPrefs(state) {
      compact.checked = state.compact;
      highlight.checked = state.highlight;
      root.classList.toggle('glpiacessivel-kb-compact-mode', state.compact);
      root.classList.toggle('glpiacessivel-kb-hide-highlight', !state.highlight);
    }

    var state = readPrefs();
    applyPrefs(state);

    toggleButton.addEventListener('click', function () {
      var expanded = toggleButton.getAttribute('aria-expanded') === 'true';
      toggleButton.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      panel.hidden = expanded;
    });

    function onChange() {
      state.compact = compact.checked;
      state.highlight = highlight.checked;
      applyPrefs(state);
      writePrefs(state);
    }

    compact.addEventListener('change', onChange);
    highlight.addEventListener('change', onChange);
  })();
</script>
