# Plugin GLPI Acessivel (GLPI 10/11)

Plugin nativo GLPI para substituir o portal externo (`portal_glpi_acessivel`) com paridade funcional, seguranca e acessibilidade prioritaria.

## Estrutura

- `setup.php` / `hook.php`: bootstrap e registro de hooks.
- `front/`: pontos de entrada do plugin.
- `src/`: camadas Dominio, Aplicacao, Infraestrutura, UI.
- `templates/`: telas em pt-BR com foco em WCAG 2.2 AA/eMAG.
- `assets/`: fontes de CSS/JS acessiveis mantidas no projeto.
- `public/assets/`: arquivos web publicados para GLPI 10/11, incluindo GLPI 11.
- `docs/`: arquitetura, paridade, seguranca, migracao, testes e operacao.

## Sprint Status

- Sprint 0: scaffolding, arquitetura, sessao/contexto GLPI.
- Sprint 1: listagem de tickets, filtros, detalhe, timeline.
- Sprint 2: acoes ITIL, chatbot, base de conhecimento.
- Sprint 3: hardening de acessibilidade/seguranca, plano de testes e documentacao.

## Instalacao rapida

1. Gere o pacote de release com `tools/build-release.ps1`.
2. Use `.release/glpiacessivel.zip` ou copie `.release/glpiacessivel` para `glpi/plugins/glpiacessivel`.
3. Acesse GLPI: `Configurar > Plugins`.
4. Instale e habilite `GLPI Acessivel`.
5. Valide a entrada acessivel em `/plugins/glpiacessivel/front/acessivel.php`.

O diretorio no GLPI precisa se chamar exatamente `glpiacessivel`.

Guia completo: `docs/installation_operation.md`.

## Modo portal

Esta versao inicia com `accessibility_mode=portal` como padrao. O GLPI padrao continua disponivel, e a experiencia acessivel fica concentrada na entrada dedicada do plugin.

## Liberacao gradual de funcionalidades

Em Configuracao do plugin, cada funcionalidade do portal pode ficar:

- Disponivel: aparece na navegacao quando a ACL nativa permitir;
- Oculta: nao aparece em menus, cards, ajuda ou atalhos, mas a URL direta continua sujeita a ACL;
- Indisponivel: fica oculta e suas rotas GET/POST e intents relacionadas sao bloqueadas.

Essa configuracao nunca concede direitos adicionais. Perfil, entidade, ACL e regras do GLPI 10/11 continuam sendo a autoridade final.

## Voz no navegador

O plugin suporta motores de voz com estrategia `local-first`.

- Producao: prefira arquivos locais hospedados no mesmo servidor do GLPI.
- Homologacao/dev: use fallback externo apenas se os arquivos locais ainda nao estiverem publicados.

Estrutura local padrao:

- `public/assets/vendor/vosklet/Vosklet.js`
- `public/assets/vendor/vosklet/Vosklet.wasm`
- `public/assets/vendor/piper/piper-tts-web.js`
- `public/assets/voice/vosk/pt-BR/vosk-model-small-pt-0.3.zip`

O modo de origem dos arquivos de voz pode ser configurado em `Configuracao do plugin`.

Status da base atual:

- STT local ja embutido no pacote: `Vosklet.js`, `Vosklet.wasm` e modelo `vosk-model-small-pt-0.3.zip`
- TTS local com Piper ja embutido no pacote: `piper-tts-web.js`

## Publicacao beta

A versao publica atual e `0.2-beta`. Publique-a como pre-release com a tag `v0.2-beta` e os ativos:

- `glpiacessivel.zip`: pacote publico enxuto, com raiz unica `glpiacessivel/`;
- `SHA256SUMS`: checksum do pacote.

Documentos principais:

- descricao da release: `docs/release_0.2-beta_github.md`;
- instalacao e operacao: `docs/installation_operation.md`;
- seguranca, acessibilidade e suporte: `docs/operation_security_accessibility_support.md`;
- auditoria autenticada: `docs/authenticated_accessibility_audit.md`;
- politica de seguranca: `SECURITY.md`.

O pacote publico exclui modelos e runtimes locais de voz cuja evidencia de redistribuicao ainda nao esta completa. Esses recursos continuam opcionais e devem ser homologados separadamente.