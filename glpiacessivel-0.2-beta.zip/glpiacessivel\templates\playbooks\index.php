<?php
$criticalConfirmations = is_array($critical_confirmations ?? null) ? $critical_confirmations : [];
$chatbotDisplayName = trim((string) ($chatbot_name ?? 'TiAjuda'));
if ($chatbotDisplayName === '') {
    $chatbotDisplayName = 'TiAjuda';
}
$t = static function (string $text): string {
    return __($text, 'glpiacessivel');
};
$playbookLines = static function ($values): string {
    return implode("\n", array_map('strval', (array) $values));
};
$playbookSummary = static function (array $playbook): string {
    $content = is_array($playbook['content'] ?? null) ? $playbook['content'] : [];
    return (string) ($content['answer_summary'] ?? '');
};
$playbookKbArticles = static function (array $playbook): string {
    $lines = [];
    foreach ((array) ($playbook['kb_articles'] ?? []) as $article) {
        if (!is_array($article)) {
            continue;
        }
        $id = (int) ($article['id'] ?? 0);
        $name = trim((string) ($article['name'] ?? ''));
        if ($id > 0 && $name !== '') {
            $lines[] = $id . ' | ' . $name;
        } elseif ($id > 0) {
            $lines[] = (string) $id;
        } elseif ($name !== '') {
            $lines[] = $name;
        }
    }

    return implode("\n", $lines);
};
$playbookKbArticleLinks = static function (array $playbook): array {
    $links = [];
    foreach ((array) ($playbook['kb_articles'] ?? []) as $article) {
        if (!is_array($article)) {
            continue;
        }

        $id = (int) ($article['id'] ?? 0);
        $name = trim((string) ($article['name'] ?? ''));
        if ($id <= 0 && $name === '') {
            continue;
        }

        $links[] = [
            'id' => $id,
            'name' => $name !== '' ? $name : ('Artigo #' . $id),
        ];
    }

    return $links;
};
$playbookContentValue = static function (array $playbook, string $key): string {
    $content = is_array($playbook['content'] ?? null) ? $playbook['content'] : [];
    $value = $content[$key] ?? '';
    if (is_array($value)) {
        $value = implode('; ', array_map('strval', array_slice($value, 0, 4)));
    }

    return trim((string) $value);
};
$playbookSuggestionSummary = static function (array $suggestion) use ($playbookContentValue): string {
    foreach (['answer_summary', 'first_steps', 'when_open_ticket'] as $field) {
        $value = $playbookContentValue($suggestion, $field);
        if ($value !== '') {
            return $value;
        }
    }

    $questions = array_values(array_filter(array_map('strval', (array) ($suggestion['questions'] ?? []))));
    if ($questions !== []) {
        return $questions[0];
    }

    return 'Sem resumo informado.';
};
$playbookShortText = static function (string $text, int $limit = 220): string {
    $text = trim(preg_replace('/\s+/', ' ', $text) ?? $text);
    if (mb_strlen($text, 'UTF-8') <= $limit) {
        return $text;
    }

    return rtrim(mb_substr($text, 0, $limit - 1, 'UTF-8')) . '...';
};
$playbookConfidenceLabel = static function ($confidence): string {
    if ($confidence === null || $confidence === '') {
        return 'Nao informada';
    }

    $score = (float) $confidence;
    if ($score >= 0 && $score <= 1) {
        $score *= 100;
    }

    return (string) min(100, max(0, (int) round($score))) . '%';
};

?>

<section class="glpiacessivel-card" aria-labelledby="playbooks-title">
  <p class="glpiacessivel-eyebrow">Chatbot operacional</p>
  <h2 id="playbooks-title">Roteiros do chatbot</h2>
  <p>
    <?= glpiacessivel_e(sprintf($t('Curadoria de insumos para %s. A varredura cria sugestoes a partir da base de conhecimento, mas apenas roteiros aprovados entram nas respostas do chatbot.'), $chatbotDisplayName)) ?>
  </p>

  <?php if (!empty($message)): ?>
    <p role="status" aria-live="polite" class="glpiacessivel-alert glpiacessivel-alert-info">
      <?= glpiacessivel_e($message) ?>
    </p>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="scan-title">
  <h2 id="scan-title">Varredura inicial da base de conhecimento</h2>
  <p>
    Execute em lote pequeno e fora de horario critico. Esta etapa consulta artigos visiveis
    ao perfil atual e gera sugestoes para revisao manual.
  </p>

  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-form-grid">
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
    <input type="hidden" name="action" value="run_kb_initial" />

    <label for="playbook-limit">Limite de artigos</label>
    <input id="playbook-limit" name="limit" type="number" min="10" max="200" step="10" value="80" />

    <label for="playbook-public-only">Escopo</label>
    <select id="playbook-public-only" name="public_only">
      <option value="1" selected>Somente FAQ publica</option>
      <option value="0">FAQ e artigos visiveis ao perfil</option>
    </select>

    <div class="glpiacessivel-field" style="grid-column:1 / -1;">
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action">Gerar sugestoes</button>
      <a class="glpiacessivel-button glpiacessivel-button-secondary glpiacessivel-secondary-action" href="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php?export=1')) ?>">
        Exportar roteiros aprovados
      </a>
    </div>
  </form>

  <?php if (is_array($result ?? null)): ?>
    <dl class="glpiacessivel-kpi-grid" aria-label="Resultado da ultima varredura">
      <div>
        <dt>Artigos analisados</dt>
        <dd><?= (int) ($result['articles'] ?? 0) ?></dd>
      </div>
      <div>
        <dt>Sugestoes geradas</dt>
        <dd><?= (int) ($result['suggestions'] ?? 0) ?></dd>
      </div>
      <div>
        <dt>Execucao</dt>
        <dd><?= glpiacessivel_e((string) ($result['status'] ?? '')) ?></dd>
      </div>
    </dl>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="manual-playbook-title">
  <h2 id="manual-playbook-title">Cadastrar roteiro manual</h2>
  <p>
    Use esta area para cadastrar um roteiro sem varredura. Itens podem nascer ativos,
    pendentes para analise futura ou inativos. Associe artigos da base usando uma linha
    por artigo no formato <code>ID | Titulo do artigo</code>.
  </p>

  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-playbook-manual-form">
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
    <input type="hidden" name="action" value="create_playbook" />

    <fieldset class="glpiacessivel-playbook-form-section">
      <legend>Identificacao e ativacao</legend>
      <p><?= glpiacessivel_e(sprintf($t('Defina como o roteiro sera reconhecido e se ele ja pode ser usado por %s.'), $chatbotDisplayName)) ?></p>
      <div class="glpiacessivel-playbook-form-grid">
        <div class="glpiacessivel-field">
          <label for="manual-playbook-name">Nome do roteiro</label>
          <input id="manual-playbook-name" name="name" type="text" />
        </div>

        <div class="glpiacessivel-field">
          <label for="manual-playbook-status">Status inicial</label>
          <select id="manual-playbook-status" name="status">
            <option value="active">Ativo no chatbot</option>
            <option value="pending">Pendente para analise futura</option>
            <option value="inactive">Inativo</option>
          </select>
        </div>

        <div class="glpiacessivel-field">
          <label for="manual-playbook-intent">Intencao</label>
          <input id="manual-playbook-intent" name="intent" type="text" value="kb_recomendar_contextual" />
        </div>
      </div>
    </fieldset>

    <fieldset class="glpiacessivel-playbook-form-section">
      <legend>Contexto de busca e roteamento</legend>
      <p>Cadastre palavras e perguntas que ajudem o chatbot a reconhecer a situacao do usuario.</p>
      <div class="glpiacessivel-playbook-form-grid">
        <div class="glpiacessivel-field">
          <label for="manual-playbook-category">Categoria sugerida</label>
          <input id="manual-playbook-category" name="category_hint" type="text" />
        </div>

        <div class="glpiacessivel-field">
          <label for="manual-playbook-group">Grupo sugerido</label>
          <input id="manual-playbook-group" name="group_hint" type="text" />
        </div>

        <div class="glpiacessivel-field span-3">
          <label for="manual-playbook-keywords">Palavras-chave</label>
          <textarea id="manual-playbook-keywords" name="keywords" rows="5"></textarea>
          <p class="glpiacessivel-field-hint">Use uma palavra ou expressao por linha. Exemplo: VPN, acesso remoto, Forticlient.</p>
        </div>

        <div class="glpiacessivel-field span-3">
          <label for="manual-playbook-questions">Perguntas de validacao</label>
          <textarea id="manual-playbook-questions" name="questions" rows="5"></textarea>
          <p class="glpiacessivel-field-hint">Perguntas usadas para confirmar contexto antes de abrir chamado.</p>
        </div>
      </div>
    </fieldset>

    <fieldset class="glpiacessivel-playbook-form-section">
      <legend>Resposta e base de conhecimento</legend>
      <p><?= glpiacessivel_e(sprintf($t('Associe artigos do GLPI para que %s apresente orientacao e link direto ao usuario.'), $chatbotDisplayName)) ?></p>
      <div class="glpiacessivel-playbook-form-grid">
        <div class="glpiacessivel-field span-2">
          <label for="manual-playbook-summary">Resposta resumida</label>
          <textarea id="manual-playbook-summary" name="answer_summary" rows="5"></textarea>
        </div>

        <div class="glpiacessivel-field">
          <label for="manual-playbook-kb">Artigos da base associados</label>
          <textarea id="manual-playbook-kb" name="kb_articles" rows="5" aria-describedby="manual-playbook-kb-help"></textarea>
          <p id="manual-playbook-kb-help" class="glpiacessivel-field-hint">
            Informe um artigo por linha. Exemplo: <code>123 | VPN - acesso remoto</code>.
          </p>
        </div>
      </div>
    </fieldset>

    <div class="glpiacessivel-playbook-actions">
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action">Cadastrar roteiro</button>
    </div>
  </form>
</section>

<section class="glpiacessivel-card" aria-labelledby="suggestions-title">
  <h2 id="suggestions-title"><?= glpiacessivel_e($t('Sugestoes pendentes')) ?></h2>

  <?php if (empty($suggestions)): ?>
    <p><?= glpiacessivel_e($t('Nenhuma sugestao pendente no momento.')) ?></p>
  <?php else: ?>
    <p role="status" aria-live="polite">
      <?= glpiacessivel_e(sprintf($t('Ha %d sugestao(oes) pendente(s) para curadoria.'), count((array) $suggestions))) ?>
    </p>
    <ul class="glpiacessivel-playbook-suggestion-list glpiacessivel-playbook-suggestion-list-compact" aria-label="<?= glpiacessivel_e($t('Sugestoes pendentes para curadoria')) ?>">
      <?php foreach ((array) $suggestions as $suggestionIndex => $suggestion): ?>
        <?php
          $suggestionId = (int) ($suggestion['id'] ?? 0);
          $suggestionKey = $suggestionId > 0 ? (string) $suggestionId : ('tmp-' . (int) $suggestionIndex);
          $suggestionDisplayId = $suggestionId > 0 ? (string) $suggestionId : $t('sem ID');
          $suggestionTitle = trim((string) ($suggestion['title'] ?? $t('Sugestao')));
          $suggestionTitle = $suggestionTitle !== '' ? $suggestionTitle : $t('Sugestao');
          $summary = $playbookSuggestionSummary($suggestion);
          $compactSummary = $playbookShortText($summary, 220);
          $firstSteps = $playbookContentValue($suggestion, 'first_steps');
          $whenOpenTicket = $playbookContentValue($suggestion, 'when_open_ticket');
          $requiredData = $playbookContentValue($suggestion, 'required_data');
          $ticketTemplate = is_array($suggestion['ticket_template'] ?? null) ? $suggestion['ticket_template'] : [];
          $questionsAll = array_values(array_filter(array_map('strval', (array) ($suggestion['questions'] ?? []))));
          $keywordsAll = array_values(array_filter(array_map('strval', (array) ($suggestion['keywords'] ?? []))));
          $kbLinks = $playbookKbArticleLinks($suggestion);
          $titleId = 'suggestion-title-' . $suggestionKey;
          $summaryId = 'suggestion-summary-' . $suggestionKey;
          $metaId = 'suggestion-meta-' . $suggestionKey;
          $editId = 'suggestion-edit-' . $suggestionKey;
        ?>
        <li>
          <article class="glpiacessivel-playbook-suggestion-card glpiacessivel-playbook-suggestion-card-compact" aria-labelledby="<?= glpiacessivel_e($titleId) ?>" aria-describedby="<?= glpiacessivel_e($summaryId . ' ' . $metaId) ?>">
            <div class="glpiacessivel-playbook-suggestion-header">
              <div>
                <p class="glpiacessivel-eyebrow">
                  <?= glpiacessivel_e(sprintf($t('Sugestao #%s'), $suggestionDisplayId)) ?>
                  | <?= glpiacessivel_e((string) ($suggestion['source_type'] ?? $t('fonte nao informada'))) ?>
                </p>
                <h3 id="<?= glpiacessivel_e($titleId) ?>" class="glpiacessivel-playbook-suggestion-title"><?= glpiacessivel_e($suggestionTitle) ?></h3>
              </div>
              <span class="glpiacessivel-badge glpiacessivel-badge-status-neutral">
                <?= glpiacessivel_e(sprintf($t('Confianca: %s'), $playbookConfidenceLabel($suggestion['confidence'] ?? null))) ?>
              </span>
            </div>

            <p id="<?= glpiacessivel_e($summaryId) ?>" class="glpiacessivel-playbook-suggestion-summary glpiacessivel-playbook-suggestion-summary-compact">
              <?= glpiacessivel_e($compactSummary) ?>
            </p>

            <dl id="<?= glpiacessivel_e($metaId) ?>" class="glpiacessivel-playbook-suggestion-meta glpiacessivel-playbook-suggestion-meta-compact">
              <div>
                <dt><?= glpiacessivel_e($t('Categoria')) ?></dt>
                <dd><?= glpiacessivel_e((string) ($suggestion['category_hint'] ?? $t('Nao informada'))) ?></dd>
              </div>
              <div>
                <dt><?= glpiacessivel_e($t('Grupo')) ?></dt>
                <dd><?= glpiacessivel_e((string) ($suggestion['group_hint'] ?? $t('Nao informado'))) ?></dd>
              </div>
              <div>
                <dt><?= glpiacessivel_e($t('Termos')) ?></dt>
                <dd><?= count($keywordsAll) ?></dd>
              </div>
              <div>
                <dt><?= glpiacessivel_e($t('Perguntas')) ?></dt>
                <dd><?= count($questionsAll) ?></dd>
              </div>
              <div>
                <dt><?= glpiacessivel_e($t('Artigos KB')) ?></dt>
                <dd><?= count($kbLinks) ?></dd>
              </div>
            </dl>

            <div class="glpiacessivel-playbook-suggestion-panels" aria-label="<?= glpiacessivel_e($t('Revisao da sugestao')) ?>">
              <details class="glpiacessivel-playbook-suggestion-details">
                <summary><?= glpiacessivel_e($t('Ver dossie')) ?></summary>
                <dl class="glpiacessivel-playbook-suggestion-meta">
                  <div>
                    <dt><?= glpiacessivel_e($t('Intencao')) ?></dt>
                    <dd><?= glpiacessivel_e((string) ($suggestion['intent'] ?? $t('Nao informada'))) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Resposta completa')) ?></dt>
                    <dd><?= glpiacessivel_e($summary !== '' ? $summary : $t('Nao informada')) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Primeiros passos')) ?></dt>
                    <dd><?= glpiacessivel_e($firstSteps !== '' ? $firstSteps : $t('Nao informado')) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Quando abrir chamado')) ?></dt>
                    <dd><?= glpiacessivel_e($whenOpenTicket !== '' ? $whenOpenTicket : $t('Nao informado')) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Dados a coletar')) ?></dt>
                    <dd><?= glpiacessivel_e($requiredData !== '' ? $requiredData : $t('Nao informado')) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Template ITIL')) ?></dt>
                    <dd><?= glpiacessivel_e($ticketTemplate !== [] ? (string) json_encode($ticketTemplate, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : $t('Nao informado')) ?></dd>
                  </div>
                </dl>

                <?php if ($keywordsAll !== []): ?>
                  <h4><?= glpiacessivel_e($t('Termos de acionamento')) ?></h4>
                  <ul class="glpiacessivel-playbook-chip-list">
                    <?php foreach ($keywordsAll as $keyword): ?>
                      <li><span class="glpiacessivel-playbook-chip"><?= glpiacessivel_e($keyword) ?></span></li>
                    <?php endforeach; ?>
                  </ul>
                <?php endif; ?>

                <?php if ($questionsAll !== []): ?>
                  <h4><?= glpiacessivel_e($t('Perguntas de triagem')) ?></h4>
                  <ol>
                    <?php foreach ($questionsAll as $question): ?>
                      <li><?= glpiacessivel_e($question) ?></li>
                    <?php endforeach; ?>
                  </ol>
                <?php endif; ?>

                <?php if ($kbLinks !== []): ?>
                  <h4><?= glpiacessivel_e($t('Artigos vinculados')) ?></h4>
                  <ul class="glpiacessivel-kb-link-list">
                    <?php foreach ($kbLinks as $kbLink): ?>
                      <li>
                        <?php if ((int) ($kbLink['id'] ?? 0) > 0): ?>
                          <a href="<?= glpiacessivel_e(glpiacessivel_url('front/knowledge.php?article=' . (int) $kbLink['id'])) ?>">
                            #<?= (int) $kbLink['id'] ?> - <?= glpiacessivel_e((string) $kbLink['name']) ?>
                          </a>
                        <?php else: ?>
                          <?= glpiacessivel_e((string) $kbLink['name']) ?>
                        <?php endif; ?>
                      </li>
                    <?php endforeach; ?>
                  </ul>
                <?php endif; ?>
              </details>

              <details id="<?= glpiacessivel_e($editId) ?>" class="glpiacessivel-playbook-suggestion-details glpiacessivel-playbook-suggestion-edit">
                <summary><?= glpiacessivel_e($t('Editar sugestao')) ?></summary>
                <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-playbook-form-grid">
                  <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                  <input type="hidden" name="action" value="update_suggestion" />
                  <input type="hidden" name="suggestion_id" value="<?= $suggestionId ?>" />

                  <div class="glpiacessivel-field span-2">
                    <label for="suggestion-name-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Nome do roteiro')) ?></label>
                    <input id="suggestion-name-<?= glpiacessivel_e($suggestionKey) ?>" name="name" type="text" value="<?= glpiacessivel_e($suggestionTitle) ?>" />
                  </div>

                  <div class="glpiacessivel-field">
                    <label for="suggestion-intent-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Intencao')) ?></label>
                    <input id="suggestion-intent-<?= glpiacessivel_e($suggestionKey) ?>" name="intent" type="text" value="<?= glpiacessivel_e((string) ($suggestion['intent'] ?? 'kb_recomendar_contextual')) ?>" />
                  </div>

                  <div class="glpiacessivel-field">
                    <label for="suggestion-category-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Categoria sugerida')) ?></label>
                    <input id="suggestion-category-<?= glpiacessivel_e($suggestionKey) ?>" name="category_hint" type="text" value="<?= glpiacessivel_e((string) ($suggestion['category_hint'] ?? '')) ?>" />
                  </div>

                  <div class="glpiacessivel-field">
                    <label for="suggestion-group-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Grupo sugerido')) ?></label>
                    <input id="suggestion-group-<?= glpiacessivel_e($suggestionKey) ?>" name="group_hint" type="text" value="<?= glpiacessivel_e((string) ($suggestion['group_hint'] ?? '')) ?>" />
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-summary-field-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Resposta resumida')) ?></label>
                    <textarea id="suggestion-summary-field-<?= glpiacessivel_e($suggestionKey) ?>" name="answer_summary" rows="4"><?= glpiacessivel_e($playbookContentValue($suggestion, 'answer_summary')) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-first-steps-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Primeiros passos')) ?></label>
                    <textarea id="suggestion-first-steps-<?= glpiacessivel_e($suggestionKey) ?>" name="first_steps" rows="3"><?= glpiacessivel_e($firstSteps) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-when-ticket-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Quando abrir chamado')) ?></label>
                    <textarea id="suggestion-when-ticket-<?= glpiacessivel_e($suggestionKey) ?>" name="when_open_ticket" rows="3"><?= glpiacessivel_e($whenOpenTicket) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-required-data-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Dados a coletar')) ?></label>
                    <textarea id="suggestion-required-data-<?= glpiacessivel_e($suggestionKey) ?>" name="required_data" rows="3"><?= glpiacessivel_e($requiredData) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-keywords-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Palavras-chave')) ?></label>
                    <textarea id="suggestion-keywords-<?= glpiacessivel_e($suggestionKey) ?>" name="keywords" rows="4"><?= glpiacessivel_e($playbookLines($keywordsAll)) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-questions-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Perguntas de validacao')) ?></label>
                    <textarea id="suggestion-questions-<?= glpiacessivel_e($suggestionKey) ?>" name="questions" rows="4"><?= glpiacessivel_e($playbookLines($questionsAll)) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-kb-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Artigos da base associados')) ?></label>
                    <textarea id="suggestion-kb-<?= glpiacessivel_e($suggestionKey) ?>" name="kb_articles" rows="4"><?= glpiacessivel_e($playbookKbArticles($suggestion)) ?></textarea>
                    <p class="glpiacessivel-field-hint"><?= glpiacessivel_e($t('Informe um artigo por linha. Exemplo: 123 | VPN - acesso remoto.')) ?></p>
                  </div>

                  <div class="glpiacessivel-playbook-actions span-3">
                    <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action" aria-label="<?= glpiacessivel_e(sprintf($t('Salvar edicao da sugestao %s: %s'), $suggestionDisplayId, $suggestionTitle)) ?>"><?= glpiacessivel_e($t('Salvar edicao')) ?></button>
                  </div>
                </form>
              </details>
            </div>

            <div class="glpiacessivel-playbook-suggestion-actions">
              <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" data-glpiacessivel-critical-form data-critical-title="<?= glpiacessivel_e($t('Confirmar aprovacao de roteiro')) ?>" data-critical-message="<?= glpiacessivel_e(sprintf($t('Revise antes de publicar a sugestao "%s" como roteiro ativo de %s.'), $suggestionTitle, $chatbotDisplayName)) ?>" data-critical-consequence="<?= glpiacessivel_e($t('Roteiros aprovados podem ser usados nas respostas do chatbot.')) ?>">
                <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                <input type="hidden" name="action" value="approve" />
                <input type="hidden" name="critical_confirmed" value="0" />
                <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['approve'] ?? '')) ?>" />
                <input type="hidden" name="suggestion_id" value="<?= $suggestionId ?>" />
                <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action" aria-label="<?= glpiacessivel_e(sprintf($t('Aprovar sugestao %s: %s'), $suggestionDisplayId, $suggestionTitle)) ?>"><?= glpiacessivel_e($t('Aprovar')) ?></button>
              </form>
              <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" data-glpiacessivel-critical-form data-critical-title="<?= glpiacessivel_e($t('Confirmar rejeicao de sugestao')) ?>" data-critical-message="<?= glpiacessivel_e(sprintf($t('Revise antes de rejeitar a sugestao "%s".'), $suggestionTitle)) ?>" data-critical-consequence="<?= glpiacessivel_e($t('A sugestao deixa a fila de curadoria.')) ?>">
                <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                <input type="hidden" name="action" value="reject" />
                <input type="hidden" name="critical_confirmed" value="0" />
                <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['reject'] ?? '')) ?>" />
                <input type="hidden" name="suggestion_id" value="<?= $suggestionId ?>" />
                <button type="submit" class="glpiacessivel-button glpiacessivel-button-danger glpiacessivel-danger-action" aria-label="<?= glpiacessivel_e(sprintf($t('Rejeitar sugestao %s: %s'), $suggestionDisplayId, $suggestionTitle)) ?>"><?= glpiacessivel_e($t('Rejeitar')) ?></button>
              </form>
            </div>
          </article>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="approved-title">
  <h2 id="approved-title">Roteiros aprovados</h2>
  <p>
    <?= glpiacessivel_e(sprintf($t('Somente roteiros ativos entram nas respostas de %s. Roteiros inativos ficam preservados para referencia, mas nao sao usados pelo chatbot.'), $chatbotDisplayName)) ?>
  </p>

  <?php if (empty($playbooks)): ?>
    <p>Nenhum roteiro aprovado ainda.</p>
  <?php else: ?>
    <div class="glpiacessivel-table-wrap glpiacessivel-table-wrapper">
      <table class="glpiacessivel-table">
        <thead>
          <tr>
            <th scope="col">Nome</th>
            <th scope="col">Status</th>
            <th scope="col">Intencao</th>
            <th scope="col">Categoria</th>
            <th scope="col">Artigos KB</th>
            <th scope="col">Palavras-chave</th>
            <th scope="col">Acoes</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ((array) $playbooks as $playbook): ?>
            <?php
              $playbookId = (int) ($playbook['id'] ?? 0);
              $isActive = !empty($playbook['is_active']);
              $kbLinks = $playbookKbArticleLinks($playbook);
            ?>
            <tr>
              <td><?= glpiacessivel_e((string) ($playbook['name'] ?? '')) ?></td>
              <td>
                <span class="glpiacessivel-badge <?= $isActive ? 'glpiacessivel-badge-state-active' : 'glpiacessivel-badge-state-inactive' ?>">
                  <?= $isActive ? 'Ativo' : 'Inativo' ?>
                </span>
              </td>
              <td><?= glpiacessivel_e((string) ($playbook['intent'] ?? '')) ?></td>
              <td><?= glpiacessivel_e((string) ($playbook['category_hint'] ?? '')) ?></td>
              <td>
                <?php if ($kbLinks === []): ?>
                  <span class="glpiacessivel-help-text">Sem artigo vinculado</span>
                <?php else: ?>
                  <ul class="glpiacessivel-kb-link-list">
                    <?php foreach (array_slice($kbLinks, 0, 3) as $kbLink): ?>
                      <li>
                        <?php if ((int) ($kbLink['id'] ?? 0) > 0): ?>
                          <a href="<?= glpiacessivel_e(glpiacessivel_url('front/knowledge.php?article=' . (int) $kbLink['id'])) ?>">
                            #<?= (int) $kbLink['id'] ?> - <?= glpiacessivel_e((string) $kbLink['name']) ?>
                          </a>
                        <?php else: ?>
                          <?= glpiacessivel_e((string) $kbLink['name']) ?>
                        <?php endif; ?>
                      </li>
                    <?php endforeach; ?>
                  </ul>
                  <?php if (count($kbLinks) > 3): ?>
                    <span class="glpiacessivel-help-text">+<?= count($kbLinks) - 3 ?> artigo(s)</span>
                  <?php endif; ?>
                <?php endif; ?>
              </td>
              <td><?= glpiacessivel_e(implode(', ', array_slice((array) ($playbook['keywords'] ?? []), 0, 8))) ?></td>
              <td>
                <details class="glpiacessivel-playbook-edit">
                  <summary>Editar roteiro</summary>
                  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-form-grid">
                    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                    <input type="hidden" name="action" value="update_playbook" />
                    <input type="hidden" name="playbook_id" value="<?= $playbookId ?>" />

                    <label for="playbook-name-<?= $playbookId ?>">Nome</label>
                    <input id="playbook-name-<?= $playbookId ?>" name="name" type="text" value="<?= glpiacessivel_e((string) ($playbook['name'] ?? '')) ?>" />

                    <label for="playbook-status-<?= $playbookId ?>">Status</label>
                    <select id="playbook-status-<?= $playbookId ?>" name="status">
                      <option value="active" <?= $isActive ? 'selected' : '' ?>>Ativo no chatbot</option>
                      <option value="pending">Voltar para pendente</option>
                      <option value="inactive" <?= !$isActive ? 'selected' : '' ?>>Inativo</option>
                    </select>

                    <label for="playbook-intent-<?= $playbookId ?>">Intencao</label>
                    <input id="playbook-intent-<?= $playbookId ?>" name="intent" type="text" value="<?= glpiacessivel_e((string) ($playbook['intent'] ?? '')) ?>" />

                    <label for="playbook-category-<?= $playbookId ?>">Categoria sugerida</label>
                    <input id="playbook-category-<?= $playbookId ?>" name="category_hint" type="text" value="<?= glpiacessivel_e((string) ($playbook['category_hint'] ?? '')) ?>" />

                    <label for="playbook-group-<?= $playbookId ?>">Grupo sugerido</label>
                    <input id="playbook-group-<?= $playbookId ?>" name="group_hint" type="text" value="<?= glpiacessivel_e((string) ($playbook['group_hint'] ?? '')) ?>" />

                    <label for="playbook-keywords-<?= $playbookId ?>">Palavras-chave</label>
                    <textarea id="playbook-keywords-<?= $playbookId ?>" name="keywords" rows="5"><?= glpiacessivel_e($playbookLines($playbook['keywords'] ?? [])) ?></textarea>

                    <label for="playbook-questions-<?= $playbookId ?>">Perguntas de validacao</label>
                    <textarea id="playbook-questions-<?= $playbookId ?>" name="questions" rows="5"><?= glpiacessivel_e($playbookLines($playbook['questions'] ?? [])) ?></textarea>

                    <label for="playbook-kb-<?= $playbookId ?>">Artigos da base associados</label>
                    <textarea id="playbook-kb-<?= $playbookId ?>" name="kb_articles" rows="5" aria-describedby="playbook-kb-help-<?= $playbookId ?>"><?= glpiacessivel_e($playbookKbArticles($playbook)) ?></textarea>
                    <p id="playbook-kb-help-<?= $playbookId ?>" class="glpiacessivel-field-hint">
                      Um artigo por linha. Use <code>ID | Titulo</code>. Esses artigos podem ser apresentados como referencia na resposta.
                    </p>

                    <label for="playbook-summary-<?= $playbookId ?>">Resposta resumida</label>
                    <textarea id="playbook-summary-<?= $playbookId ?>" name="answer_summary" rows="5"><?= glpiacessivel_e($playbookSummary($playbook)) ?></textarea>

                    <div class="glpiacessivel-field" style="grid-column:1 / -1;">
                      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action">Salvar alteracoes</button>
                    </div>
                  </form>

                  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-playbook-delete" data-glpiacessivel-critical-form data-critical-title="Confirmar exclusao de roteiro" data-critical-message="<?= glpiacessivel_e(sprintf($t('Revise antes de excluir este roteiro aprovado de %s.'), $chatbotDisplayName)) ?>" data-critical-consequence="A exclusao remove o roteiro da base operacional do chatbot.">
                    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                    <input type="hidden" name="action" value="delete_playbook" />
                    <input type="hidden" name="playbook_id" value="<?= $playbookId ?>" />
                    <input type="hidden" name="critical_confirmed" value="0" />
                    <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['delete_playbook'] ?? '')) ?>" />
                    <button type="submit" class="glpiacessivel-button glpiacessivel-button-danger glpiacessivel-danger-action">Excluir roteiro</button>
                  </form>
                </details>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="import-title">
  <h2 id="import-title">Importar roteiro JSON</h2>
  <p>
    Use para transportar roteiros entre ambientes sem varrer novamente a base.
    Cada item pode declarar <code>status</code> como <code>active</code>,
    <code>pending</code> ou <code>inactive</code>. Se nao declarar, vale o status padrao abaixo.
  </p>

  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" enctype="multipart/form-data">
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
    <input type="hidden" name="action" value="import_json" />

    <label for="playbooks-import-status">Status padrao dos itens importados</label>
    <select id="playbooks-import-status" name="import_status">
      <option value="active">Ativo no chatbot</option>
      <option value="pending">Pendente para analise futura</option>
      <option value="inactive">Inativo</option>
    </select>

    <label for="playbooks-json-file">Arquivo JSON de roteiros</label>
    <input id="playbooks-json-file" name="playbooks_json_file" type="file" accept="application/json,.json" aria-describedby="playbooks-json-help" />

    <label for="playbooks-json">Ou cole o JSON de roteiros</label>
    <textarea id="playbooks-json" name="playbooks_json" rows="8" aria-describedby="playbooks-json-help"></textarea>
    <p id="playbooks-json-help" class="glpiacessivel-field-hint">Aceita exportacao do proprio plugin ou um objeto com a chave <code>playbooks</code>, <code>items</code> ou <code>data</code>. Se arquivo e texto forem informados, o arquivo tem prioridade.</p>
    <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action">Importar roteiros</button>
  </form>
</section>
