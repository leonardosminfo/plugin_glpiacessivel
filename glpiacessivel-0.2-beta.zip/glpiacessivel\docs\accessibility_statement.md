# Declaracao de acessibilidade

Versao de referencia: 0.1.86-beta.

O GLPI Acessivel busca atender WCAG 2.2 nivel AA e eMAG 3.1 nas telas sob seu controle. O plugin oferece navegacao por teclado, foco visivel, modos de contraste, atalhos opcionais, mensagens anunciaveis e compatibilidade progressiva com leitores de tela.

## Limites conhecidos

- Formularios nativos incorporados preservam o motor e os componentes da fonte GLPI/Formcreator.
- Voz e VLibras sao opcionais; falhas ou indisponibilidade nao impedem a operacao.
- A conformidade final depende da matriz assistiva e da homologacao da versao GLPI instalada.

## Evidencias obrigatorias por release

- axe/Pa11y em rotas autenticadas;
- teclado, zoom 400%, alto contraste e reflow;
- NVDA, JAWS e VoiceOver nos fluxos criticos;
- registro de excecoes, responsavel e prazo de correcao.