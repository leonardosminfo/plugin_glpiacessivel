# Guia de Instalação e Operação

## Pré-requisitos
- GLPI 10.x ou 11.x
- PHP >= 8.1
- Permissão de escrita para instalação de plugin

## Instalação
1. Gere o pacote com `tools/build-release.ps1`.
2. Use `.release/glpiacessivel.zip` ou copie `.release/glpiacessivel` para `GLPI/plugins/glpiacessivel`.
3. Acesse `Configurar > Plugins`.
4. Instale e habilite `GLPI Acessível`.

O nome tecnico da pasta deve ser exatamente `glpiacessivel`, porque o GLPI associa esse nome as funcoes `plugin_init_glpiacessivel()` e aos caminhos publicos do plugin.

Nao publique a pasta de trabalho diretamente: ela contem `.backup/`, testes e artefatos locais que nao devem ir para producao.

## Operação diária
- Entrada acessivel dedicada: `/plugins/glpiacessivel/front/acessivel.php`
- Chamados: `/plugins/glpiacessivel/front/ticket.php`
- Cockpit: `/plugins/glpiacessivel/front/cockpit.php`
- Base de conhecimento: `/plugins/glpiacessivel/front/knowledge.php`
- Chatbot: `/plugins/glpiacessivel/front/chatbot.php`
- Botao no GLPI padrao: o plugin injeta o link "Acessibilidade" nas paginas padrao autenticadas.

## Modos de acessibilidade
- `portal`: modo padrao. Usa uma entrada acessivel dedicada e preserva a interface padrao do GLPI fora do portal.
- `global`: modo reservado para aplicar uma camada acessivel ao GLPI inteiro em sprint posterior.

## Governança
- Revisar logs de auditoria periodicamente.
- Revisar logs de revelação de PII.
- Validar perfis GLPI para segregação de acesso.

## Desinstalação
- Menu de plugins do GLPI: desativar e desinstalar.
- Processo remove tabelas do plugin (`SchemaManager::uninstall`).

